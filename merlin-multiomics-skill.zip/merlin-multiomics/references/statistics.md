# Which test the design earns

MErlin chooses its model from what the input carries, not from a flag. That
means the honest sentence you can write about a result is decided long before
the run, by how many samples exist and whether they carry read counts. Read this
before promising a user a differential analysis.

---

## 1. The design table

| Input | Model MErlin uses | What a small p supports |
|---|---|---|
| ≥2 replicates per condition, coverage + fraction (real bedMethyl) | beta-binomial LRT, dispersion shrunk to a level-dependent trend | differential methylation between the *conditions* |
| ≥2 replicates per condition, presence-only calls | quasi-Poisson LRT on call counts with a library-size offset | a difference in the *distribution of calls* |
| 1 sample per condition | contingency test within the sample (Fisher/χ²) | a candidate screen, nothing about reproducibility |

The `test` and `n_replicates` columns of `dixam`'s differential table record
which of these ran, per feature. Read them before writing.

**Why the single-sample case is not a differential test.** With one sample per
condition, biological variation and the effect of interest are the same number.
On the reference synthetic data a genome-wide drift from 0.90 to 0.88 — no true
per-feature effect at all — made 58 % of features "significant" under the
single-sample read test. The test is not broken; it answers "did these two piles
of reads come from the same binomial", which is a question about sequencing, not
about biology.

So: with n = 1 per condition, report ranked candidates and effect sizes, say
explicitly that reproducibility is untested, and do not compute a false
discovery rate over the genome as though it meant one.

---

## 2. What replication buys, measured

Simulated null data — no true difference anywhere, only replicate variation at
φ = 0.03, 3 v 3, 8 sites at 50× coverage:

| | rejects at p < 0.05 | false discoveries at BH q < 0.05 |
|---|---|---|
| single-sample read test | 60.0 % | 1672 / 3000 |
| beta-binomial LRT (2.0.1) | 9.6 % | 8 / 3000 |

Dispersion is recovered (median 0.027 against a true 0.03).

**Null calibration by design size**, nominal 5 %:

| design | χ²(1) — the default | F(1, n−2) — `--lrt-dist f` |
|---|---|---|
| 2 v 2 | 10.6 % | 0.1 % |
| 3 v 3 | 6.0 % | 1.0 % |
| 5 v 5 | 7.8 % | 4.1 % |

χ² is mildly anti-conservative at small n; F over-corrects badly. χ² is the
default and MErlin warns at run time rather than hiding it. At 2 v 2, treat
q-values as approximate and say so — the honest phrasing is "at a nominal 5 %
the test rejects about 10 % of null features at this design size".

**Dispersion shrinkage.** A per-feature dispersion from three replicates is far
too noisy to use raw, so each feature's method-of-moments estimate is pulled
towards the median dispersion of features at a similar methylation level
(`--dispersion-prior`, default 5). The `dispersion` and `dispersion_trend`
columns are both in the output: when they are far apart, the result depends on
the shrinkage decision, and that is worth a sentence.

**Technical replicates are not biological replicates.** Passing resequencing
runs of one culture as `--methylation a b c` measures library variation and
calls it biology. Ask which kind they are; if technical, pool them into one file
per condition and report the single-sample caveat instead.

---

## 3. Positional data needs a structure-preserving null

Genomic tracks are autocorrelated: neighbouring bins share operons, replication
timing, GC. Permuting labels destroys that structure, so a permutation p over
positions is anti-conservative by a lot. Two *independent* smoothed tracks on
the reference data:

```
naive Spearman p = 4e-07        circular-shift null p = 0.14
```

MErlin therefore reports, for anything positional:

- `circular_shift_p` — one track rotated around the replicon, preserving its
  autocorrelation exactly. **This is the p-value to quote.**
- `bootstrap_ci_low/high` — block bootstrap, so the interval respects the same
  structure.

`spearman_p` is kept in the table for comparison. Quoting it as the result is
the single easiest way to publish a false positive from a Hi-C or spatial
analysis.

---

## 4. Confounder adjustment in `diem`

With `--gff` and `--fasta`, `diem` builds a covariate block — gene length, gene
density, upstream intergenic distance, GC content, GC skew, ori→ter position,
assayed-site density, coverage, per-motif density, expression baseMean — and
reports the **marginal and the partial (adjusted) correlation side by side**,
plus which covariates the methylation track itself follows.

On the reference data:

```
marginal rho = +0.0305    partial rho = -0.0124   (gc_skew and log_length absorb it)
```

When the two disagree, *the disagreement is the finding*: the marginal
association was carried by something structural. Report both, name the
covariates that absorbed it, and do not present the marginal value alone. MErlin
warns when adjustment removes more than half the marginal strength.

Adjustment cannot rescue a confounded design — batch, growth phase and
sequencing run are not in the covariate block because they are not in the files.
If the conditions were sequenced in different runs, say so as a limitation.

---

## 5. Multiple testing

`dixam`, `hicam` and `evidence` apply Benjamini–Hochberg within their own table.
Nothing corrects *across* modules. If a user asks for "the significant genes"
after five modules ran, the honest answer names the table each q-value came
from; `merlin evidence` exists precisely so that cross-layer ranking is done
once, explicitly, rather than by eye across five files.

`evidence` combines per-layer statistics with Stouffer's method and robust rank
aggregation, then applies BH across genes. It is a **ranking**, not a new test:
a high-ranked gene is a gene worth looking at. `n_layers` says how many layers
contributed — a gene ranked by one layer is not multi-omic evidence — and
`direction_concordance` says whether they agree about sign.

---

## 6. Effect size before p-value, always

At genomic n, significance is cheap.

| \|ρ\| | Reading at genomics n |
|---|---|
| < 0.1 | detectable, not meaningful |
| 0.1–0.3 | weak |
| 0.3–0.5 | moderate — worth discussing |
| > 0.5 | strong; check for a technical driver |

Report the effect, then n, then the p-value and which null produced it. A
classifier AUC near 0.5 alongside a small significant correlation is coherent,
not contradictory: a weak monotonic association can exist with no predictive
power at the level of individual genes.
