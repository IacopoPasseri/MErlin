# Reading `merlin preflight`

```
merlin preflight --gff ann.gff3 --fasta ref.fasta --methylation calls.bed \
    --modbam reads.bam --motifs motifs.txt --geneexp deseq2.csv \
    --meth-table xam.tsv --hic c.cool [--strip-version] [--out preflight.txt]
```

Exit `0` clean, `1` warnings only, `2` blocking. Output is a list of named
checks, each `ok`, `WARN` or `FAIL`, with the evidence underneath.

Both joins MErlin depends on — seqid and locus_tag — fail by returning fewer
rows, not by raising. That is the whole reason this runs first: it converts "no
signal" from an ambiguous output into a finding.

---

## `seqid reconciliation`

The check that matters most.

**`ok`, method=version-strip.** Namespaces differ only by a trailing `.N` and
were reconciled by stripping it. **Not user error**: INSDC accessions carry a
version (`JBUDZE010000001.1`), FASTA headers and basecalling output keep it,
and annotation converters (Prokka, GbkToGff) commonly drop it. Every module
detects and applies this automatically, logging a warning when it does;
`--strip-version` forces the same behaviour explicitly. Note it in the report as
a provenance fact and move on.

**`ok`, method=identity.** Nothing to do.

**`WARN` `seqid coverage [layer]`.** Some identifiers matched, some did not, and
the unmatched ones are ignored. Usually a replicon present in one file and
absent from another — a plasmid dropped in assembly filtering, a contig excluded
from the annotation. Confirm the absence is intended and state which replicons
were analysed.

**`FAIL`.** A layer shares nothing with the canonical namespace even after
stripping versions. Usually two different assemblies (annotation from a
reference, methylation mapped to a local assembly), sometimes informal replicon
names (`chromosome`, `pSymA`) against accessions.

There is no flag for this. Establish with the user which assembly is
authoritative and have the mismatched file regenerated against it, or get an
explicit correspondence from them and write it to a two-column TSV for
`--seqid-map`. Do not hand-build a mapping between different assemblies:
confident wrong coordinates are worse than no analysis.

**Never resolve this with `--allow-rank-map`.** That flag pairs the two sorted
seqid lists by position with nothing connecting them. The join then succeeds and
attributes methylation to the wrong replicon, producing fully populated,
entirely plausible output. Compare the failure modes:

| State | What you see |
|---|---|
| unequal counts | empty output — obviously broken |
| version suffix only | correct pairing — fine |
| disjoint, equal counts, rank-mapped | populated output, wrong replicons — looks fine |

---

## `modbam [file]`, `modbam alignment`, `modbam index`, `modbam duplex`

Reports references, sort order, index, how many sampled reads carry MM/ML,
which modification codes, and duplex tags — then adds the BAM's reference names
to the seqid reconciliation above, so a BAM aligned to a different assembly than
the annotation is caught before the pileup rather than after it.

- **`FAIL`, no MM/ML tags.** The BAM was not produced by a modification-aware
  basecaller, or a downstream step dropped the tags. There is nothing to pile
  up; do not run anything else until this is resolved.
- **`WARN`, unaligned.** `merlin pileup` will align it with minimap2 (needs
  minimap2 and samtools on PATH). Confirm that is wanted — aligning takes time,
  and if the user believes it is already aligned, something upstream is wrong.
- **`WARN`, not coordinate-sorted or not indexed.** MErlin sorts and indexes a
  copy, which costs time and disk.
- **`WARN`, duplex.** A pileup collapses both strands of a duplex molecule into
  per-position counts; per-molecule hemimethylation needs `merlin phase`.

## `pileup backend`

Which backend a pileup would use. `ok` means modkit is on PATH; `WARN` means
MErlin's internal pysam pileup would run. The internal one is a real fallback,
not a stub, but the two agree closely rather than exactly — if the user needs
numbers comparable to a previous modkit run, install modkit and say so.

## `annotation` and `annotation locus_tag`

Feature count, replicons and types; then how many features carry a `locus_tag`.
A `WARN` here means downstream joins on locus_tag will lose features —
frequently because `--features CDS` was used with an annotation that puts
`locus_tag` on `gene` rows, or because `--id-attr` needs to point somewhere
else.

## `methylation [file]`

Detected format (bedMethyl / bed6 / GFF3), call count, modification codes and
strands present.

**Do not assume which modifications are there.** A dataset may hold 6mA and 4mC
and no 5mC at all. Every sentence you write should name the modification rather
than saying "methylation".

## `methylation basis`

Whether the input carries coverage and fraction-modified (`assayed with
fraction-modified`) or is presence-only. This decides which model `dixam` can
use — beta-binomial needs read counts; presence-only gets quasi-Poisson on call
counts. See `statistics.md`.

## `methylation levels`

The span of fraction-modified and how much sits near zero. If a large share of
calls are below 1 %, the file contains every assayed position rather than
methylated ones, and `--min-frac` is what defines "methylated" for the run.
Choose it explicitly and record it; the value changes every count downstream.

## `methylation strands`

A `WARN` here usually means every call was reported on `+`. `xam` counts
same-strand calls by default, so most calls then miss their features. Compare a
run with `--ignore-strand`: a large jump in counts confirms it.

## `expression` and `expression / methylation join`

Row count, how many have an adjusted p-value, and the fraction of expression IDs
matching either the xam table (if `--meth-table` was passed) or the annotation's
locus_tags.

- `ok` — more than half match.
- `WARN` — fewer than half; `diem` drops the rest, so n is much smaller than the
  DESeq2 row count. Report n as the merged value and state the fraction dropped.
- `FAIL` — nothing matches; `diem` would produce an empty table. Preflight
  prints example IDs from both sides. If xam's IDs look like
  `JBUDZE010000001.source.1` while expression uses `ACY3MO_00005`, the wrong
  `--id-attr` was used — rerun xam. If the ID spaces are genuinely different,
  the user must supply a mapping.

`--meth-table` should point at an xam per-feature table, not at raw methylation.

## `motifs`, `motif offsets`, `motif occurrence`

`motif offsets` warns for motifs with no modified-base offset (`GATC<TAB>1`):
site-level statistics fall back to whole-motif coverage, which is coarser. If
the offsets are unknown, `merlin discover` will find them from the data.

`motif occurrence` warns for motifs absent from the reference — usually a typo
or a motif from a different organism.

## `GC skew / oriC-ter`

Warns per replicon when cumulative GC-skew amplitude is too flat to place oriC
and ter (common on plasmids and small replicons). Every `spacem` spatial
statistic for that replicon inherits the flag. Supply `--oric`/`--ter` if the
user knows them, or report the spatial results as undefined for that replicon —
do not quietly accept the detected landmarks.

## `hi-c`, `hi-c seqids`, `hi-c resolution`

Chromosome count and bins per replicon. `hi-c resolution` warns for replicons
with fewer than 20 bins: insulation and compartment calls there are unstable, so
either use a finer `--resolution` or exclude the replicon from those claims. On
bacteria a plasmid at 5 kb resolution routinely lands in this state.

---

## When preflight passes

Exit 0 means the joins will work. It does not mean the analysis is
well-specified. Contrast direction, condition labels, replicate structure and
replicon handling remain unknowable from the files and still have to come from
the user.
