# The `merlin run` configuration

YAML or JSON. Paths resolve relative to the config file, so a config next to the
data can be handed to a collaborator unchanged.

```
merlin run --config merlin.yaml --dry-run     # print the plan, run nothing
merlin run --config merlin.yaml               # run it
merlin run --config merlin.yaml --only xam dixam
merlin run --config merlin.yaml --keep-going  # continue past a failed module
merlin export --config merlin.yaml --workflow nextflow    # or snakemake, json
```

Always show the user `--dry-run` output before executing. It lists every module
as it will run or be skipped, **with the missing input named for each skip** —
which is also the fastest way to discover that a path is wrong.

---

## Top-level keys

| Key | Type | Meaning |
|---|---|---|
| `outdir` | path | output root; one subdirectory per module (default `merlin_results`) |
| `prefix` | str | prefix for every output filename (default `sample`) |
| `annotation` | path | GFF3 |
| `reference` | path | reference FASTA |
| `methylation` | see below | methylation calls |
| `motifs` | path | IUPAC motif list; **omit it and `discover` runs instead**, feeding its own `motifs.txt` to `mematch`, `spacem`, `mtase` and `phase` |
| `expression` | path | DESeq2/edgeR/limma table → enables `diem` |
| `hic` | path | `.cool`/`.mcool`/HiC-Pro/dense matrix → enables `hicam` |
| `hic_bins` | path | bins BED for HiC-Pro or dense input |
| `resolution` | int | resolution to read from an `.mcool`, or bin size for a dense matrix |
| `modbam` | path, list or map | basecalled BAM(s) with MM/ML tags. Enables `phase`, and — when there is no `methylation` key — a `pileup` step per condition whose output every other module then uses |
| `knockout_gene` | str | gene deleted in the second condition → `mtase --knockout-gene` |
| `seqid_map` | path | applied to every module |
| `strip_version` | bool | applied to every module |
| `mod_codes` | str | e.g. `a,m` — applied to every module |
| `min_coverage` | float | applied to every module |
| `min_frac` | float | applied to every module |
| `harmonise` | bool | run harmonise/evidence/report at the end (default true) |
| `options` | map | per-module extra flags, see below |

## Starting from BAMs

`modbam` takes exactly the same three shapes as `methylation`:

```yaml
modbam: calls.bam                      # one sample
```
```yaml
modbam: [wt.bam, ko.bam]               # two conditions, unnamed
```
```yaml
modbam:                                # named conditions with replicates
  WT:     [wt_rep1.bam, wt_rep2.bam, wt_rep3.bam]
  dam_kd: [ko_rep1.bam, ko_rep2.bam, ko_rep3.bam]
```

With no `methylation:` key, the planner inserts one `pileup[<label>]` step per
condition and points `xam`, `dixam`, `spacem`, `mematch`, `discover` and `mtase`
at the bedMethyl it will produce — `--dry-run` prints those paths before
anything runs, which is the fastest way to confirm the plan is what you meant.

With **both** keys, the pileup is skipped with a stated reason and the modBAM is
used only by `phase`. That is the right configuration when the user already
trusts a bedMethyl someone else produced.

Configure the step under `options`:

```yaml
options:
  pileup: {backend: auto, threads: 8, min-mapq: 20, filter-threshold: 0.7}
```

`backend: modkit` makes a missing modkit a hard error instead of a silent
fallback — worth setting when the numbers have to match a previous modkit run.

## The `methylation` key decides the design

```yaml
methylation: calls.bed                 # one sample  -> xam only, no dixam
```
```yaml
methylation: [wt.bed, ko.bed]          # two conditions, unnamed (cond1, cond2)
```
```yaml
methylation:                           # named conditions with replicates
  WT:     [wt_rep1.bed.gz, wt_rep2.bed.gz, wt_rep3.bed.gz]
  dam_kd: [ko_rep1.bed.gz, ko_rep2.bed.gz, ko_rep3.bed.gz]
```

A list under one label is **biological replicates of that condition** and is
what licenses the beta-binomial LRT in `dixam`. The mapping form is the one to
use for anything you will report — the labels flow into column names, filenames
and figures, so `WT`/`dam_kd` beats `cond1`/`cond2` everywhere downstream.

Exactly two conditions are compared. More than two runs `xam` on each and
compares the first pair; if the user has a time course or a factorial design,
say that MErlin tests one contrast at a time and run the contrasts they
care about explicitly.

## `options` — per-module flags

Keys are module names; values are that module's long flags without the leading
dashes. Booleans become bare flags, lists become repeated values.

```yaml
options:
  xam:     {features: CDS}
  dixam:   {features: CDS, min-effect: 0.10,
            regions: [upstream:-300..50, body], operons: true}
  mematch: {features: CDS, gzip-calls: true}
  diem:    {n-perm: 5000, gff: annotation.gff3, fasta: reference.fasta}
  hicam:   {insulation-window: 5}
  phase:   {min-reads: 20}
```

`diem` does not inherit `annotation`/`reference` from the top level — pass
`gff` and `fasta` under `options.diem` if you want the confounder block, which
you normally do.

---

## Worked configs

**Methylation only** — no expression, no Hi-C, no motif list. `dixam`,
`mematch`, `diem`, `hicam` and `phase` are skipped with reasons; `discover`
finds the motifs from the data. This is a complete, valid run.

```yaml
outdir: results_meth_only
prefix: F5
annotation:  annotation.gff3
reference:   reference.fasta      # drop this and spacem/discover skip too
methylation: F5.methylation.gff3
```

**Replicated two-condition design** — the configuration whose `dixam` q-values
actually support a claim of differential methylation:

```yaml
outdir: results_replicated
prefix: T1
annotation: annotation.gff3
reference:  reference.fasta
methylation:
  WT:     [F5_rep1.bedmethyl.bed.gz, F5_rep2.bedmethyl.bed.gz, F5_rep3.bedmethyl.bed.gz]
  dam_kd: [F9_rep1.bedmethyl.bed.gz, F9_rep2.bedmethyl.bed.gz, F9_rep3.bedmethyl.bed.gz]
min_frac: 0.5
options:
  xam:   {features: CDS}
  dixam: {features: CDS, min-effect: 0.10,
          regions: [upstream:-300..50, body], operons: true}
```

**From basecalling output** — no bedMethyl anywhere:

```yaml
outdir: results_from_bam
prefix: BAM1
annotation: annotation.gff3
reference:  reference.fasta
modbam:
  WT: [reads.modbam.bam]
min_frac: 0.5
options:
  pileup: {threads: 8}
  xam:    {features: CDS}
```

**Everything** — add the layers that exist; nothing else changes:

```yaml
motifs:     motifs.txt
expression: deseq2_results.csv
hic:        contacts.cool
modbam:     reads.modbam.bam
resolution: 5000
knockout_gene: dam
```

---

## After the run

`<outdir>/merlin_run_report.txt` lists every module as OK, FAILED or SKIPPED
with its reason and duration:

```
  OK       pileup[WT]        0.7s
  OK       xam[WT]           2.0s
  OK       dixam             5.6s
  SKIPPED  discover       a motif list was supplied, so nothing needs discovering
  SKIPPED  roundtable     Rscript is not on PATH
  OK       harmonise         0.3s

Skipped modules are not failures: MErlin runs whatever the supplied inputs support.
```

Quote this file in the report rather than describing the run from memory. With
`harmonise: true` (the default) the run also leaves `<prefix>.merlin_store.h5`,
`<prefix>.features.tsv`, `<prefix>.bins.tsv`, `<prefix>.evidence.tsv` and
`<prefix>.report.html` in `outdir`.

`evidence` is skipped when no layer produced a score to combine — a
methylation-only run with a single condition has nothing to rank, and the skip
reason says so.
