# Troubleshooting

Resolve issues *with* the user. Two moves are never appropriate: editing the
user's input files to make a join work, and loosening a threshold to make a
warning disappear.

`merlin doctor` first for anything that looks like an environment problem;
`merlin preflight` first for anything that looks like a data problem.

---

## Empty or near-empty output

**The most common MErlin failure, and it does not raise an error.**

1. **Seqids.** Run `merlin preflight`. A namespace mismatch produces exactly
   zero feature–methylation overlaps, which looks identical to an unmethylated
   genome. Version-suffix differences are handled automatically; anything else
   needs `--seqid-map`.
2. **Strand.** `xam` counts same-strand calls by default. If the caller reported
   everything on `+`, most calls miss their features. Compare with
   `--ignore-strand`: a large jump identifies this.
3. **Feature types.** `--features CDS` excludes `gene` rows, and some
   annotations carry `locus_tag` only on `gene`. Preflight's annotation check
   reports how many features have one.
4. **`--min-frac`.** With assayed input (every position, most of them at
   fraction ≈ 0), the threshold *defines* what counts as methylated. Too high
   and everything vanishes; unset and everything counts.
5. **`--min-coverage`.** Set above the actual depth, it removes every call.

Only after all five: report it as a genuine biological absence.

## `pileup`: "no MM/ML modification tags"

The BAM was not basecalled with a modification model, or a downstream step
dropped the tags. Check with `samtools view file.bam | head -1 | grep -o 'MM:Z:[^\t]*'`.
Re-basecalling with `dorado basecaller --modified-bases 6mA 5mC` is the fix;
there is no way to recover modification calls that were never made.

Aligning through `samtools fastq` **without** `-T MM,ML` silently drops them,
which is why `merlin pileup` uses that flag when it aligns.

## `pileup`: the bedMethyl is empty or every site has zero valid coverage

In order: `--min-mapq` above the actual mapping qualities; `--filter-threshold`
above the probabilities the caller emits (try `--no-filtering` to see the
unfiltered picture — then set a defensible threshold, do not leave filtering
off); `--region` naming a seqid that does not match the BAM header; or a BAM
whose reads are all unmapped. `<prefix>.pileup_summary.tsv` distinguishes these:
zero rows means nothing was called at all, rows with `N_valid_cov = 0` mean
everything failed the confidence filter.

## `pileup`: modkit and the internal backend give different numbers

Expected, within limits. modkit models deletions, reference mismatches and
duplex reads and defaults to an adaptive percentile threshold; the internal
backend does none of that and uses a fixed `--filter-threshold`. Site *positions*
should agree; coverage and percent-modified can differ by a few percent. A large
disagreement is worth investigating — start by running both with
`--no-filtering`, which removes the thresholding difference.

Never mix backends within one comparison. Two conditions piled up by different
backends will differ for reasons that have nothing to do with biology.

## `pileup`: "is not aligned and minimap2 is not on PATH"

MErlin will not guess an aligner. Either install minimap2 and samtools, or run
the printed command yourself and pass the aligned BAM. `--align never` makes the
unaligned state an error rather than a silent 20-minute alignment.

## `mod_code` values are not what was expected

Basecalling GFF3 uses labels in column 3 (`m6A`, `m4C`); bedMethyl uses
single-letter codes (`a`, `m`, `h`). MErlin maps `m`→5mC, `a`→6mA, `h`→5hmC and
passes explicit labels through unchanged. If a modification is missing from the
output, check whether it was in the input at all — preflight prints the codes it
found. Do not assume 5mC is present because the organism is bacterial.

## `dixam` reports no differential features

Check `n_replicates` and `test` in the output first. With one sample per
condition the test is a within-sample contingency test and a null result is
weakly informative; with replicates, a null result under the beta-binomial LRT
is a real finding. Then check `--min-effect` and `--qvalue`, and whether
`--min-frac` removed the signal before testing.

## `dixam`: "anti-conservative at this design size" warning

A 2 v 2 design. The χ² reference distribution rejects about 10 % of null
features at a nominal 5 %. Report q-values as approximate, or run `--lrt-dist f`
and report both — F is conservative to the point of rejecting almost nothing at
2 v 2 (see `statistics.md`).

## `diem`: n much smaller than the expression table

Expected when `xam` ran without `--include-zero` — genes with no methylation
call are absent from the methylation table, so the join has nothing to keep.
Rerun `xam --include-zero` and rerun `diem` with `--join left` (the default).
Report n as the analysed value and state the fraction dropped.

## `diem`: "complete separation" warning from the logistic regression

One predictor separates the classes perfectly, so its odds ratio and interval
are not interpretable. Report the random forest and the correlations instead,
and say why the odds ratio was omitted. Not a bug and not fixable by dropping
the gene.

## `diem` is slow

`--n-perm 5000` on a large table, or `--n-perm-auc` (label permutations of a
cross-validated classifier) which is slow by construction. Reduce
deliberately and record the reduced setting; `--cv kfold` is already the default
and `--no-ml` skips the classifier entirely.

## `mematch`: enrichment table is all NaN

scipy is missing. MErlin warns to stderr and continues rather than failing. NaN
p-values are a missing dependency, never an absence of enrichment. `merlin
doctor` reports this.

## `discover` finds motifs with implausible flanks

A k-mer seed fixes its own flanking bases — they look conserved because they
were selected on. MErlin refines seeds by trimming and degenerating against the
unclaimed foreground, which is why `GATC` comes back rather than `GATCG`. If
long, over-specific motifs still appear, raise `--min-enrichment`, raise
`--min-sites`, or lower `--seed-k`; report what was changed.

## `spacem`: weak GC-skew warning

Below `--min-skew-amplitude` the oriC/ter calls are unreliable and every spatial
statistic inherits that. Pass explicit `--oric`/`--ter` if the user knows them,
increase `--skew-window` for a smoother signal, or report the results with the
warning attached. Common on plasmids and small replicons, which often have no
skew inversion at all.

## `hicam`: cooler/h5py errors, or "fewer than 20 bins"

`.cool`/`.mcool` reading needs `h5py` (native reader) or `cooler`; `merlin
doctor` reports which is available. For an `.mcool`, `--resolution` is required
— without it there is no single matrix to read.

Fewer than 20 bins on a replicon means insulation and compartment calls there
are unstable: use a finer `--resolution` or exclude that replicon from those
claims.

## `phase`: no sites, or no bistable features

Check that the BAM is aligned, indexed, and carries MM/ML tags (`samtools view
-h file.bam | grep -m1 'MM:Z:'`), and that `--min-reads` is not above the
coverage. Hemimethylation needs palindromic motifs *with offsets* in
`--motifs`. If a region was requested with `--region`, confirm the seqid
matches the BAM's naming, not the annotation's.

## `harmonise` / `evidence` / `report` produce little

They read a `merlin run` output tree. If modules were run by hand into scattered
directories, pass the tables explicitly (`--xam`, `--dixam`, `--diem`,
`--mematch`, `--hic-bins`). `evidence` needs at least one layer carrying a
score; a single-condition methylation-only run has nothing to rank, which is why
`merlin run` skips it with that reason.

`evidence`'s TSV carries `#` provenance lines above the header — read it with
`comment='#'`.

## `roundtable.R`: package installation

The script installs missing CRAN and Bioconductor packages at startup, which
needs network access and modifies the user's R library. Never run it without
telling the user first; `optparse`, `data.table`, `circlize` and `Biostrings`
installed beforehand avoid it. `merlin spacem --circular` produces a circular
figure with no R at all.

## Slow runs

`mematch` scans the genome for every motif on both strands; `hicam` builds dense
per-replicon matrices and runs bootstrap and circular-shift nulls; `phase` reads
every read in the BAM. Minutes on a real genome is expected. Say what is
running rather than going quiet, and do not reduce the workload to finish sooner
unless the user asks — if they do, record the reduced setting in the report.

## Memory

`mematch` holds the reference in memory and its per-call table is O(calls) rows
— use `--gzip-calls` or `--no-call-table`. `hicam`'s dense matrices are fine for
bacterial genomes and would not be for a eukaryotic one. If a module is killed,
run one replicon at a time and note in the report that replicons were analysed
separately.

## When MErlin's output contradicts what the user knows

Worth investigating — but the investigation belongs in MErlin's code, not in a
workaround. Capture the command, the inputs, the relevant output rows and the
contradiction, and offer to help debug the tool. The `<prefix>.provenance.txt`
sidecar has the exact command line and input digests, which is what makes the
report reproducible.

Never compute the value another way to "check". That produces a number with no
provenance and hides the bug rather than finding it.
