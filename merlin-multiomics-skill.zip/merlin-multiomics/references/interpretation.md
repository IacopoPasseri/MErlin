# Interpretation

Read this before writing any sentence with a direction ("up", "increases",
"represses") or a mechanism in it.

The statistics MErlin produces are usually fine. The gap between a correct table
and an incorrect sentence about that table is where multi-omics errors actually
live.

---

## 1. Sign conventions

### Expression (`diem`)

Nothing in a DESeq2 table records which direction the contrast runs.
`log2FoldChange` and `padj` are direction-agnostic; the filename is not
evidence. The only authority is what the user tells you.

Ask: *"Does a positive log2FoldChange mean the gene is up in the treatment or up
in the control, and which condition is the treatment?"* Record the answer and
quote it in the report. If it was never established, report magnitudes only and
say the direction is unresolved.

User states positive means up under salt stress; a gene with
`log2FoldChange = +2.4`:

- correct: "up ~5.3-fold under salt stress"
- wrong: "up in the control"
- wrong: "repressed by the salt response" — a mechanism, not the datum

### Differential methylation (`dixam`)

`--labels` is positional and defaults to `control treatment` regardless of what
the files hold. A swapped pair inverts every differential call and produces
output that looks entirely normal. Confirm the assignment and quote it.

`effect` is signed as treatment − control in `effect_name`'s units
(methylation-level difference, or log2 CPM ratio for presence-only input).

### Methylation counts (`xam`)

`raw_count` is calls per feature; `norm_count` divides by length;
`calls_per_kb` is the same per kilobase; `cpm` normalises by library size and is
the one to compare across samples; `mean_frac_modified` is the mean fraction
modified where the input carries read counts. Higher means more methylated —
that much is stable.

The *correlation* direction is not stable and must not be assumed. Different
modifications can correlate with expression in opposite directions in the same
organism (observed for 5mC versus 6mA). Read the sign from `diem`'s
per-modification correlations each time.

### Spatial position (`spacem`)

Positions are relative to oriC and ter detected from cumulative GC skew. A
weak-skew warning means the landmarks are unreliable and every spatial statistic
for that replicon inherits it. Report the warning or pass explicit
`--oric`/`--ter`.

---

## 2. What `diem`'s statistics license

`statistics_summary.txt` holds the correlations, the confounder-adjusted
association, per-modification breakdowns, and cross-validated classifier
performance.

**Quote the permutation p, not the analytic one.** The analytic p assumes
independent observations, which genomic data violates through operon structure
and spatial autocorrelation.

**Quote the partial (confounder-adjusted) correlation alongside the marginal
one.** When they disagree, the disagreement *is* the finding: the marginal
association was carried by gene length, GC or replication position. MErlin warns
when adjustment removes more than half the marginal strength.

**Effect size before p-value, always.** With n in the thousands, ρ = 0.05 will
be significant and explains 0.25 % of variance.

| \|ρ\| | Reading at genomics n |
|---|---|
| < 0.1 | detectable, not meaningful |
| 0.1–0.3 | weak |
| 0.3–0.5 | moderate — worth discussing |
| > 0.5 | strong; check for a technical driver |

**An AUC near 0.5 is a real, reportable result.** It means the methylation
features do not predict differential expression in this dataset. Do not reach
for a different model, more features or a looser DE threshold until something
predicts — that is a search for a positive result. Report the CV strategy and
the prevalence baseline with it: accuracy 0.75 against a 0.52 majority-class
baseline is informative; accuracy 0.75 against a 0.75 baseline is not.

**Never write causal language.** Both layers respond to the same experimental
condition, neighbouring loci are non-independent, and direction of effect is
unidentifiable from cross-sectional data. "Methylation at X correlates with
expression of Y" is the finding. If the user wants causation, say what would
license it: a knockout, a point mutation of the methylation site, or MTase
complementation.

### Worked example

From a real `statistics_summary.txt`:

```
genes analysed : 121   join: left
DE definition  : padj < 0.05 and |log2FC| >= 1.0
Spearman rho = -0.2062  p = 2.3269e-02   permutation p (2000 shuffles) = 0.0330
  [5mC] rho=-0.2796  BH q=0.00379
  [6mA] rho=-0.2062  BH q=0.0233
Confounder-adjusted: marginal rho = -0.2154   partial rho = -0.2178 (n=117)
Random forest: 5-fold stratified CV, accuracy 0.7521, DE prevalence 0.4793, AUC 0.8662
```

A correct reading:

> Across 121 genes carrying both layers, methylation density and log2 fold
> change are weakly negatively associated (Spearman ρ = −0.21, permutation
> p = 0.033), and the association survives adjustment for gene length, GC, gene
> density, replication position and expression level (partial ρ = −0.22,
> n = 117) — so it is not a by-product of those confounders. 5mC carries it
> slightly more strongly than 6mA (ρ = −0.28 versus −0.21, BH q < 0.05 for
> both). A random forest on the methylation features separated DE from non-DE
> genes at AUC 0.87 under 5-fold stratified cross-validation, against a 0.48 DE
> prevalence.

Why it is phrased that way: n first and it is the analysed n; "weakly" attached
to a significant result; permutation p quoted; marginal and partial reported
together; modifications separated rather than pooled; the classifier reported
with its CV strategy and baseline; no mechanism claimed anywhere.

Wrong readings to avoid: leading with "significantly correlated (p = 0.02)";
calling ρ = −0.21 "a strong relationship"; "methylation represses these genes";
quoting accuracy without the prevalence baseline.

---

## 3. `diem`'s thresholds

**`--lfc_thr 1.0`** defines DE as at least a doubling — stricter than the DESeq2
convention of 0, so the DE set is smaller than a user may expect from their own
DESeq2 work. State it with every DE count.

**`--meth_thr 0.004`** is roughly the 75th percentile of one real dataset:
data-derived and **not portable**. On a different organism, protocol or coverage
it is arbitrary. Prefer `--dm-table`, which replaces "highly methylated" with
"differentially methylated" and makes the threshold moot.

**The join.** The default `--join left` keeps genes with no methylation, which
is what makes the correlation unbiased — provided `xam` ran with
`--include-zero`, otherwise those genes are simply absent from the table.
`--join inner` reproduces 1.x behaviour and biases every statistic towards the
methylated subset. Whichever ran, report n as the analysed count, never the
DESeq2 row count.

A "dual hit" is DE ∩ DM under these thresholds — a threshold intersection, not a
biological category. Describe it as one.

---

## 4. `mematch` enrichment

Report each motif with observed count, expected count, fold enrichment and the
test's p-value. Fold enrichment without counts is uninterpretable — 10× on 2
sites out of 4 is noise.

Motif hits are sequence matches. A motif can be present and unmethylated;
MErlin's value is precisely in separating those, so keep "motif occurrences"
and "methylated motif occurrences" distinct in the prose. Palindromic motifs are
reported once per strand and MErlin logs when it does — halve accordingly before
comparing to a site count from elsewhere.

## 5. `discover` output

`enrichment` and `n_sites` are read together. A motif with enrichment 300 over
3000 sites is a methylation system; enrichment 300 over 60 sites is more likely
a k-mer artefact of the seeding step. The `note` column records how the motif
was refined.

A discovered motif is a pattern in the calls. Calling it "the Dam site" requires
either the canonical table (`mtase`) or a knockout — say which one you are
relying on.

## 6. `mtase` attribution

`confidence` is the column that decides the verb:

- annotation match only → "consistent with", "candidate"
- canonical motif table match → "matches the known specificity of"
- knockout-confirmed loss → "attributable to", and name the loss threshold used

Quote the `evidence` string rather than paraphrasing it. RM systems cluster, so
`adjacent_rm_genes` often matters: a methyltransferase adjacent to a restriction
endonuclease is a system, and that context belongs in the report.

## 7. `hicam` output

Quote `circular_shift_p`, not `spearman_p` — see `statistics.md` §3. Report
`bootstrap_ci_low/high` with any ρ.

Compartments in bacteria are not A/B compartments in the mammalian sense; MErlin
labels the eigenvector sign and orients it by GC, and `pc1_orientation_r`
records how well that orientation held. Boundaries are insulation minima
(chromosomal interaction domains), not CTCF loops — MErlin does not call loops
and a "loop" in a bacterial contact map is usually an artefact.

Replicons with fewer than ~20 bins at the chosen resolution do not support
insulation or compartment claims at all.

## 8. `phase` output

Hemimethylation here is *population* strand asymmetry — a short read covers one
strand, so "half the cells methylated on one strand" and "every cell
hemimethylated" are indistinguishable without duplex reads. Say which the data
can support.

`bimodal` is Sarle's bimodality coefficient over per-read fractions and needs
`n_reads` beside it: bimodality on 12 reads is a coin-flip pattern. Bistability
is a hypothesis about a locus, testable by sorting or single-cell work, not a
demonstrated epigenetic switch.

## 9. `evidence` ranking

`stouffer_q` and `rra_q` rank genes; they do not test a new hypothesis. Always
report `n_layers` (a gene ranked by one layer is not multi-omic evidence) and
`direction_concordance` (near zero means the layers disagree about sign even
where each is individually significant). Weighting via `--weights` is a choice —
state it.

---

## 10. Multi-replicon genomes

*S. meliloti* has a chromosome and two megaplasmids; *B. cenocepacia* has three
chromosomes and a plasmid. These differ systematically in GC content, expression
level and methylation density.

Pooling replicons can produce a correlation driven entirely by between-replicon
differences rather than any within-replicon relationship. If replicons were
pooled, say so; if the correlation is strong, proposing a within-replicon check
is worth it.

## 11. Observed versus inferred

- **Observed** — the feature is in MErlin's output with measured values
- **Inferred** — the feature is a pathway member from annotation, unmeasured here

A pathway called "coordinately methylated" when four of seven members were never
measured is a claim about a database, not an experiment.

## 12. Negative results

No significant correlation, no enrichment, no differential features, AUC at
chance — all valid, reportable findings. Report them plainly with the n
available. Do not respond by loosening a threshold, dropping the permutation
null, or narrowing the feature set until something appears. If the user asks for
a parameter change, make it explicit and report both runs.

---

## 13. Report template

```
## What was run
merlin <version>, modules <list>, <organism>.
Inputs: <files>. Seqid reconciliation: <method>.
Design: <n> replicate(s) per condition -> <test used, from the 'test' column>.
Contrast: <label> vs <label>. Positive log2FC means <user's statement>.
Thresholds: padj <x>, |LFC| <y>, min-frac <z>, q <q>.

## Findings
<Numbers from output tables only, naming the file for each.>
<Effect size, then n, then p — permutation / circular-shift / LRT, named.>

## Caveats
<Every preflight warning, verbatim.>
<Replicate structure and what it does and does not license.>
<n analysed and the fraction dropped.>
<Whether replicons were pooled; weak-skew replicons; low-bin replicons.>

## Files
<Every output, one line each — and deliver them.>
```
