# MErlin modules — arguments and outputs

Real flags, real output files, real columns, taken from MErlin 2.1.0. Every
module also takes `--help`, which is the authority if this file and the binary
ever disagree.

## Contents

- [Options shared by almost every module](#options-shared-by-almost-every-module)
- [pileup](#pileup) — basecalled modBAM to bedMethyl
- [xam](#xam) — methylation per feature
- [dixam](#dixam) — differential methylation
- [spacem](#spacem) — oriC/ter spatial distribution
- [mematch](#mematch) — motif × methylation association
- [discover](#discover) — de novo motif discovery
- [mtase](#mtase) — motif → methyltransferase attribution
- [diem](#diem) — expression × methylation
- [hicam](#hicam) — Hi-C 3D organisation
- [phase](#phase) — read-level methylation from modBAM
- [harmonise](#harmonise) — one store
- [evidence](#evidence) — ranked genes
- [report](#report) — one HTML report
- [preflight, doctor, run, export](#preflight-doctor-run-export)
- [roundtable.R](#roundtabler) — circos figure
- [Chaining](#chaining)

---

## Options shared by almost every module

**Annotation and sequence**

| Flag | Meaning |
|---|---|
| `-g, --gff FILE` | GFF3 (Prokka/Bakta/NCBI; may embed `##FASTA`) |
| `--features TYPE …` | feature types to keep; default all non-meta types |
| `--id-attr ATTR` | GFF attribute used as the feature id; falls back to `locus_tag`, then `Name` |
| `--fasta FILE` | reference FASTA; optional when the GFF3 embeds one |

**Methylation input** — format auto-detected (modkit bedMethyl, 6-column BED,
GFF3 modification calls):

| Flag | Meaning |
|---|---|
| `--methylation FILE …` | one file, or several **biological replicates of one condition** |
| `-b/--bed`, `-m/--methyl-gff` | aliases kept for 1.x compatibility |
| `--methylation2 FILE …` (`-B`, `-M`) | second condition, for `dixam` and `mtase` |
| `--meth-format {auto,bedmethyl,bed6,gff}` | override detection |
| `--mod-codes a,m` | keep only these modification codes |
| `--min-coverage X` | minimum valid coverage per call (default 0) |
| `--min-frac X` | fraction-modified threshold for "methylated"; ignored for presence-only input |

**Seqid reconciliation** — `--seqid-map FILE` (two-column TSV, no header),
`--strip-version` (drop a trailing `.N`; applied automatically when it
reconciles the layers), `--allow-rank-map` (last-resort pairing by sorted rank —
a guess; verify what it logs).

**Output** — `-o/--outdir DIR` (required), `--prefix STR`, `-n/--name`
(compatibility alias), `--quiet`, `--provenance`.

Every module always writes `<prefix>.provenance.txt` (command line, versions,
SHA-256 of each input) and `<prefix>.warnings.txt` next to its tables.
`--provenance` *additionally* prefixes each TSV with `#` lines; it is off by
default because that breaks readers which do not skip comments. The sidecar is
what you cite in a report.

**Plotting** — `--no-plot` (xam, dixam, diem) or `--plots` (the rest, where
figures are opt-in), `--plot-format {png,pdf,svg}`, `--plot-dpi`, `--bins N`.

---

## pileup

Turns a basecalled modBAM into a bedMethyl. This is what makes a raw BAM a valid
MErlin input rather than something the user has to convert first.

```
merlin pileup --modbam calls.bam --fasta ref.fasta -o results/pileup \
    --backend auto --threads 8 --min-mapq 20 --filter-threshold 0.7
```

| Flag | Meaning |
|---|---|
| `--modbam FILE …` (`--bam`) | BAM(s) with MM/ML tags. Several files are piled up separately, one bedMethyl each |
| `--fasta FILE` | reference; required to align an unaligned BAM, passed to modkit as `--ref` |
| `--backend {auto,modkit,internal}` | `auto` uses modkit when it is on PATH |
| `--modkit-path EXE` | explicit modkit binary |
| `--threads N`, `--min-mapq N`, `--region STR` | as they sound |
| `--filter-threshold X` | confidence below which a call goes to `N_fail` instead of being used. Internal backend default 0.667; unset means modkit's own adaptive percentile |
| `--mod-thresholds CODE:X …` | per-code threshold, e.g. `a:0.9 m:0.75` |
| `--no-filtering` | use every call regardless of confidence |
| `--align {auto,never,force}` | align an unaligned BAM with minimap2. `never` fails instead — use it when you believe the BAM is already aligned |
| `--preset X` | minimap2 preset (default `map-ont`) |
| `--cpg`, `--motif SEQ:OFFSET`, `--combine-strands`, `--modkit-arg …` | modkit only; the internal backend refuses them rather than silently ignoring them |
| `--mod-codes a,m` | keep only these codes (internal backend) |
| `--gzip` | write the bedMethyl gzipped |

**Outputs.** `<prefix>.bedmethyl.bed[.gz]` in modkit's 18-column order, and
`<prefix>.pileup_summary.tsv` — `sample, backend, mod_code, n_sites,
n_sites_with_coverage, mean_coverage, mean_percent_modified`.

**The two backends.**

| | modkit | internal |
|---|---|---|
| when | on PATH, or `--backend modkit` | modkit absent, or `--backend internal` |
| what it is | ONT's reference implementation | a pysam pileup inside MErlin |
| models deletions, reference mismatches, duplex | yes | no — `N_delete`, `N_diff`, `N_nocall` are 0 |
| thresholding | adaptive percentile by default | fixed `--filter-threshold`, argmax over mod and canonical probabilities |

They agree closely, not exactly. Say which one ran — the summary table, the log
and `<prefix>.provenance.txt` all record it.

**Unaligned BAMs.** dorado's uBAM is aligned with
`samtools fastq -T MM,ML | minimap2 -y | samtools sort`, which is the recipe
that keeps MM/ML attached through the FASTQ round trip. Losing them there gives
an empty pileup rather than an error, so if minimap2 or samtools is missing
MErlin refuses and prints the command to run by hand.

**A BAM with no MM/ML tags is a fatal error**, not an empty bedMethyl — the two
would otherwise be indistinguishable in the output, and one of them means "this
genome has no methylation".

---

## xam

Methylation per annotated feature. The table `diem` and `harmonise` consume.

```
merlin xam -g ann.gff3 --methylation rep1.bed rep2.bed rep3.bed \
    -o results/xam --prefix WT --features CDS --include-zero
```

| Flag | Meaning |
|---|---|
| `--include-zero` | emit features with no methylation. **Pass this if `diem` follows** — otherwise unmethylated genes are absent rather than zero |
| `--ignore-strand` | count both strands per feature (default: same strand only) |
| `--no-split` | one combined TSV instead of one file per modification |
| `--regions SPEC …` | score windows, not whole features: `upstream:-300..50 body downstream:0..200 intergenic`. Strand-aware, relative to the translation start |
| `--operons` | infer transcription units; scores the leader's upstream window for every member |
| `--operon-max-gap BP` | same-strand gap joining two genes into one operon (default 50) |

**Outputs.** `<prefix>.<replicate>.by_feature.tsv` per input file,
`<prefix>.pooled.by_feature.tsv` across them, `<prefix>.along_replicons.png`.

**Columns.** `replicon, feature_type, feat_start, feat_end, strand,
feat_length_bp, locus_tag, gene, product, mod_code, mod_label, mod_description,
raw_count, norm_count, calls_per_kb, cpm, mean_frac_modified`.

One row per feature × modification. `norm_count` is per base, `calls_per_kb` per
kilobase, `cpm` per million calls in the sample (the depth-robust one — use it
when comparing samples), `mean_frac_modified` the mean fraction-modified where
the input carries read counts.

---

## dixam

Differential methylation between two conditions, replicate-aware.

```
merlin dixam -g ann.gff3 --methylation wt1.bed wt2.bed wt3.bed \
    --methylation2 ko1.bed ko2.bed ko3.bed --labels WT dam_kd \
    -o results/dixam --features CDS
```

| Flag | Meaning |
|---|---|
| `--labels CONTROL TREATMENT` | positional, defaults to `control treatment` **regardless of file contents** — always set it |
| `--test {auto,fisher,chi2}` | single-sample association test |
| `--test-on {auto,reads,calls}` | modified-vs-canonical reads (needs bedMethyl) or the distribution of calls |
| `--lrt-dist {chi2,f}` | reference distribution for the replicate LRT. `chi2` (default) is mildly anti-conservative at small n; `f` is conservative |
| `--dispersion-prior X` | shrinkage weight towards the dispersion trend (default 5) |
| `--qvalue X`, `--min-effect X` | reporting thresholds (default 0.05, 0) |
| `--pseudocount X` | added in CPM units before the log2 ratio |
| `--regions`, `--operons` | as in `xam` |
| `--no-test` | descriptive output only |

Which test runs is decided by the design, not by a flag — see
`statistics.md`. The `test` column of the output states it per feature.

**Outputs.** `<prefix>.differential.tsv`, `<prefix>.by_feature.<label>.tsv` per
condition, `<prefix>.differential_ma_volcano.png`,
`<prefix>.along_replicons_overlay.png`, `<prefix>.along_replicons_diff.png`.

**Key columns.** `<label>_raw, <label>_cpm, <label>_norm, delta_raw, delta_cpm,
log2FC_cpm, mean_cpm, n_replicates, <label>_meth_level, delta_meth_level,
dispersion, dispersion_trend, LR_statistic, effect, effect_name, pvalue, test,
level_<sample>_<i>, odds_ratio, qvalue`.

`n_replicates` and `test` are the two columns to read before writing any
sentence about the result.

---

## spacem

Where methylation sits relative to the replication origin and terminus.

```
merlin spacem -g ann.gff3 --methylation calls.bed --fasta ref.fasta \
    -o results/spacem --plots --circular
```

| Flag | Meaning |
|---|---|
| `--skew-window BP` | window for cumulative GC-skew oriC/ter detection (default 10000) |
| `--oric SPEC`, `--ter SPEC` | override as `seqid:pos[,seqid:pos]`, 0-based |
| `--min-skew-amplitude X` | minimum swing / replicon length for the call to be trusted (default 0.02) |
| `--skip-weak-skew` | omit ori→ter statistics for weak-skew replicons instead of flagging them |
| `--circular` | also render the whole-genome circular figure |
| `--motifs FILE` | adds per-motif spatial tracks |
| `--no-motif-rings` | drop motif rings from the circular figure |

**Outputs.** `<prefix>.oriter_stats.tsv`, `<prefix>.spatial_bins.tsv`,
`<prefix>.<replicon>.spatial.png`, `<prefix>.<replicon>.motif_spatial.png`,
`<prefix>.circular_genome.png`.

Weak skew is common on plasmids and small replicons. If it is flagged, every
spatial statistic for that replicon inherits the flag — report it or supply
`--oric`/`--ter`.

---

## mematch

Motif occurrences, which of them are methylated, and whether methylated motifs
are enriched in features.

```
merlin mematch -g ann.gff3 --methylation calls.bed --fasta ref.fasta \
    --motifs motifs.txt -o results/mematch --fisher --gzip-calls
```

Motif file: one IUPAC motif per line, optional second column giving the 0-based
offset of the modified base (`GATC<TAB>1`). Without an offset MErlin scores the
whole motif.

| Flag | Meaning |
|---|---|
| `--fisher` | write the enrichment table (always computed for figures) |
| `--test {auto,fisher,chi2}` | enrichment test |
| `--ignore-motif-strand` | match motifs irrespective of the call's strand |
| `--linear` | treat replicons as linear (default circular, so origin-spanning motifs are found) |
| `--feature-meth-min-calls N` | methylated calls needed for a feature to count as methylated |
| `--gzip-calls`, `--no-call-table`, `--no-hit-table` | control the two large tables |

**Outputs.** `<prefix>.motif_summary.tsv`, `<prefix>.enrichment.tsv`,
`<prefix>.per_feature.tsv`, `<prefix>.per_feature_motif.tsv`,
`<prefix>.methylation_calls.tsv[.gz]`, `<prefix>.motif_hits.tsv[.gz]`,
`<prefix>.replicons.tsv`, two PNGs.

The per-call table is the largest output MErlin produces; `--gzip-calls` or
`--no-call-table` on a full genome.

---

## discover

Finds the motifs from the data — no motif list required. Run it when the user
does not know the organism's methylome, or to check a supplied list.

```
merlin discover --fasta ref.fasta --methylation calls.bed -o results/discover
```

| Flag | Meaning |
|---|---|
| `--flank BP` | bases either side of the modified base examined (default 8) |
| `--seed-k K` | exact k-mer length seeding distinct motifs (default 5) |
| `--max-motifs N` | motifs reported per modification (default 4) |
| `--min-enrichment X` | fold enrichment a seed needs over background (default 10) |
| `--min-sites N` | calls a motif must explain (default 50) |
| `--min-base-freq X`, `--ic-threshold BITS` | how bases join an IUPAC code, and which positions count as informative |
| `--background-multiple N` | background positions sampled per methylated position |

**Outputs.** `<prefix>.discovered_motifs.tsv` and `<prefix>.motifs.txt` — the
latter drops straight into `mematch --motifs`, `spacem --motifs`, `mtase
--motifs` and `phase --motifs`.

**Columns.** `motif, offset, mod_code, mod_label, n_sites, enrichment,
information_bits, seed_kmer, note`.

On the reference synthetic data this recovers `GATC/1`, `GANTC/1` and `CCWGG/1`
with the correct offsets. A motif whose enrichment is high but whose `n_sites`
is small is a k-mer artefact; report both numbers together.

---

## mtase

Attributes motifs to methyltransferase genes: annotation-based inventory of RM
genes, a canonical motif table, and — if a knockout condition is supplied — the
observed loss of methylation.

```
merlin mtase -g ann.gff3 --motifs motifs.txt \
    --methylation wt.bed --methylation2 ko.bed --knockout-gene dam \
    -o results/mtase
```

| Flag | Meaning |
|---|---|
| `--motifs FILE` | without it, only the RM gene inventory is produced |
| `--knockout-gene NAME` | gene deleted in the second condition |
| `--loss-threshold X` | methylation drop counting as loss (default 0.2) |
| `--neighbour-window BP` | window for reporting adjacent RM genes — systems cluster (default 5000) |

**Outputs.** `<prefix>.motif_attribution.tsv` (`motif, confidence,
known_enzyme, known_modification, known_note, candidate_genes, n_occurrences,
level_<cond>, knockout_effect, knockout_gene, evidence`) and
`<prefix>.rm_genes.tsv` (`locus_tag, gene, role, replicon, start, end, strand,
product, adjacent_rm_genes`).

`confidence` is the column that matters: an annotation-only match is a
hypothesis, a knockout-confirmed loss is an attribution. Quote the `evidence`
string rather than paraphrasing it.

---

## diem

Differential expression × methylation, adjusted for genomic confounders.

```
merlin diem --geneexp deseq2.csv --methylation results/xam/WT.pooled.by_feature.tsv \
    --dm-table results/dixam/x.differential.tsv \
    --gff ann.gff3 --fasta ref.fasta -o results/diem
```

| Flag | Meaning |
|---|---|
| `--geneexp FILE` | DESeq2/edgeR/limma table, CSV or TSV |
| `--methylation FILE` | an **xam** per-feature table (run xam with `--include-zero`) |
| `--dm-table FILE` | a dixam table; makes "DM" mean *differentially* methylated rather than *highly* methylated |
| `--gff`, `--fasta` | build the confounder block: length, GC, GC skew, replication position, gene density, upstream intergenic distance, baseMean |
| `--covariates auto\|none\|LIST` | which confounders to adjust for |
| `--gene-col`, `--lfc-col`, `--padj-col` | override column detection |
| `--join {left,inner}` | `left` (default) keeps genes with no methylation; `inner` reproduces 1.x behaviour and biases every statistic |
| `--n-perm N` | permutations for the Spearman permutation p (default 5000) |
| `--n-perm-auc N` | label permutations for a null CV AUC (slow; 200 is enough) |
| `--cv {auto,kfold,loocv}`, `--n-trees N`, `--no-ml` | classifier controls |
| `--padj_thr`, `--lfc_thr`, `--meth_thr`, `--dm-qvalue`, `--dm-lfc` | thresholds (0.05, 1.0, 0.004, 0.05, 0) |

**Outputs.** `<prefix>.integrated_table.tsv`, `<prefix>.statistics_summary.txt`,
`<prefix>.dual_hit_genes.tsv`, `<prefix>.logistic_regression.tsv`, figures.

`statistics_summary.txt` holds Pearson r, Spearman ρ with a permutation p, the
partial (confounder-adjusted) correlation, per-modification correlations, and
cross-validated classifier performance. Report the permutation and partial
values — see `interpretation.md`.

`--meth_thr 0.004` is derived from one real dataset and is **not portable**;
with `--dm-table` supplied it is unused.

---

## hicam

Hi-C organisation, on its own or crossed with methylation and expression.

```
merlin hicam --hic contacts.cool --resolution 5000 -g ann.gff3 \
    --methylation calls.bed --geneexp deseq2.csv -o results/hicam --plots
```

| Flag | Meaning |
|---|---|
| `--hic FILE` | `.cool`/`.mcool`, HiC-Pro `.matrix`, or a dense text matrix |
| `--hic-bins FILE`, `--resolution BP` | bins BED for HiC-Pro/dense input; resolution to read from an `.mcool` |
| `--no-balance` | skip cooler weights and ICE |
| `--linear` | treat replicons as linear — the default is circular, which is what makes the distance-expected normalisation correct for bacteria |
| `--insulation-window BINS`, `--boundary-prominence X`, `--boundary-flank BINS` | insulation and boundary calling |
| `--strata N`, `--max-pairs N` | separation strata and cap for the contact-weighted co-methylation test |
| `--hic2 FILE`, `--hic2-bins`, `--labels A B` | second contact map → differential insulation, boundary changes, compartment flips |
| `--n-bootstrap N`, `--n-shift N` | block-bootstrap intervals and the circular-shift null |
| `--geneexp`, `--dm-table` | place DE and DM genes on the map |

**Outputs.** `<prefix>.hic_bins.tsv` (per-bin compartment, insulation,
boundary flag, GC, gene density, expression and methylation summaries),
`<prefix>.hic_boundaries.tsv`, `<prefix>.hic_integration.tsv` (one row per
cross-layer test, with `spearman_rho`, `bootstrap_ci_low/high`,
`circular_shift_p`, odds ratios), `<prefix>.hic_comethylation_strata.tsv`,
`<prefix>.hic_boundary_contrast.tsv`, figures.

**`circular_shift_p` is the p-value to quote**, not `spearman_p`. Two
independently smoothed genomic tracks correlate strongly by construction; on
the reference data the naive p is 4e-07 and the shift-null p is 0.14.

---

## phase

Read-level methylation from an aligned modBAM with MM/ML tags.

```
merlin phase --modbam reads.bam -g ann.gff3 --motifs motifs.txt \
    -o results/phase --plots
```

| Flag | Meaning |
|---|---|
| `--modbam FILE` | aligned BAM with MM/ML tags |
| `--region STR` | restrict, e.g. `chr:1-100000` |
| `--high P`, `--low P` | ML probability thresholds (0.8 / 0.2). Calls in between are dropped, not forced to a side |
| `--min-reads N` | reads needed at a site (default 10) |
| `--min-mapq`, `--max-reads` | filtering and subsampling |
| `--motifs FILE` | palindromic motifs with an offset enable the hemimethylation analysis |
| `--max-distance BP` | maximum separation for cis co-methylation (default 2000) |
| `--min-sites-per-read N` | sites a read must cover to contribute a per-read fraction |

**Outputs.** `<prefix>.read_sites.tsv` (`replicon, pos, strand, mod_code,
n_reads, n_meth, frac`), `<prefix>.hemimethylation.tsv`,
`<prefix>.bistability.tsv` (`feature, n_reads, mean_frac, sd_frac,
frac_reads_high, frac_reads_low, bimodality_coefficient, bimodal`),
`<prefix>.cis_comethylation.tsv` (φ by distance bin), figures.

Hemimethylation here is *population* strand asymmetry: a short read covers one
strand, so "half the cells methylated on one strand" and "every cell
hemimethylated" are not distinguishable without duplex reads. Say which one the
data can support.

---

## harmonise

Joins every module's output into one store, on feature id and on genomic bin.

```
merlin harmonise --results results --gff ann.gff3 -o results --prefix run1
```

`--results DIR` searches a `merlin run` output tree recursively; the explicit
`--xam/--dixam/--diem/--mematch/--hic-bins` flags take file lists instead.
`--export-tsv` also writes the joined tables as TSV.

**Outputs.** `<prefix>.merlin_store.h5` (`/features`, `/bins`, feature→bin map,
provenance), plus `<prefix>.features.tsv` and `<prefix>.bins.tsv`.

Columns are namespaced by layer — `meth_<condition>_<mod>_cpm`,
`dmeth_<mod>_qvalue`, `expr_log2FoldChange`, `motif_frac_methylated_on_motif`,
`hic_compartment` — so a column name tells you which module produced it.

---

## evidence

Ranks genes by combined evidence across layers.

```
merlin evidence --store results/run1.merlin_store.h5 -o results --plots \
    --weights expression=2 dmeth_6mA=1
```

`--store` or `--features TSV`; `--weights LAYER=W`; `--top N` rows in the
console summary; `--qvalue X`.

**Output.** `<prefix>.evidence.tsv` — `z_<layer>`, `rank_<layer>`,
`stouffer_Z`, `stouffer_p`, `stouffer_q`, `rra_score`, `rra_q`, `n_layers`,
`direction_concordance`.

This file carries `#` provenance lines above the header — read it with
`comment='#'`.

`n_layers` and `direction_concordance` qualify every ranking: a gene ranked by
one layer is not multi-omic evidence, and concordance near zero means the layers
disagree about direction even where each is individually significant.

---

## report

```
merlin report --results results --store results/run1.merlin_store.h5 -o results
```

`--title`, `--max-figures N` (per module, default 8), `--max-rows N` (per table,
default 40). Writes one self-contained `<prefix>.report.html` — figures inlined,
no external assets. Usually the artefact to deliver first.

---

## preflight, doctor, run, export

```
merlin preflight --gff ann.gff3 --fasta ref.fasta --methylation calls.bed \
    --motifs motifs.txt --geneexp deseq2.csv --meth-table xam.tsv --hic c.cool \
    [--strip-version] [--out preflight.txt]

merlin doctor [--check-r] [--out doctor.txt]

merlin run --config merlin.yaml [--dry-run] [--only xam dixam] [--keep-going]

merlin export --config merlin.yaml --workflow nextflow|snakemake|json [-o FILE]
```

Preflight exit codes: `0` clean, `1` warnings, `2` blocking — see
`preflight.md`. `run` writes `merlin_run_report.txt` listing every module as OK,
FAILED or SKIPPED *with the reason it was skipped*; quote that file rather than
describing the run from memory. See `run_config.md` for the YAML schema.

---

## roundtable.R

The circos figure, unchanged from 1.x and still shipped as
`scripts/roundtable.R` in the package. Needs `optparse`, `data.table`,
`circlize` and `Biostrings`. It installs missing packages at startup, which
touches the user's R library — say so before running it. `merlin run` skips it
with a stated reason when `Rscript` is not on PATH, and `merlin spacem
--circular` produces a matplotlib circular figure that needs no R at all.

---

## Chaining

```
pileup ──▶ bedMethyl ──▶ xam, dixam, spacem, mematch, discover, mtase
discover ──▶ motifs.txt ──▶ mematch, spacem, mtase, phase
xam ──▶ per-feature TSV ──▶ diem
dixam ──▶ differential TSV ──▶ diem --dm-table, hicam --dm-table, mtase
every module ──▶ harmonise ──▶ evidence ──▶ report
```

`merlin run` enforces this order. Running modules by hand means enforcing it
yourself — in particular `pileup` before anything that needs a bedMethyl,
`xam --include-zero` before `diem`, and `discover` before `mematch` when there
is no motif list.
