# Setting up MErlin 2.1.0

Two separate things, in this order:

1. **The skill** — this folder. It teaches Claude how to drive MErlin correctly.
2. **The package** — the `merlin` command itself, which does the analysis.

The skill without the package leaves Claude able to explain MErlin but not run
it. The package without the skill works fine from a terminal. Install both.

---

# Part A — Install the skill

The skill is a folder named `merlin-multiomics` containing `SKILL.md`,
`SETUP.md`, `references/`, `scripts/` and `assets/`. It is delivered as a
`.skill` file, which is a zip archive of that folder.

**The folder name inside the zip must stay `merlin-multiomics`** — it has to
match the `name:` in `SKILL.md`'s frontmatter, and a mismatch is the most common
upload failure.

## A1 — Claude desktop app or claude.ai

1. Download the delivered `merlin-multiomics.skill` file. If the upload dialog
   only accepts `.zip`, rename the extension — the contents are identical.
2. Open **Customize → Skills**.
3. Click **+**, then **Create skill**, then **Upload a skill**.
4. Select the file.
5. The skill appears in the list with a toggle. Turn it on.

Personal skills stay private to your account. On Team and Enterprise plans you
can share one organisation-wide from the same screen.

If the delivered file card in the conversation offers a save or install option,
that does the same thing in one click — whether it appears depends on your
organisation's settings.

## A2 — Claude Code (or anything reading `.claude/skills/`)

```bash
mkdir -p ~/.claude/skills
unzip merlin-multiomics.skill -d ~/.claude/skills/
ls ~/.claude/skills/merlin-multiomics/SKILL.md    # must exist
```

| Scope | Path | Available in |
|---|---|---|
| Personal | `~/.claude/skills/merlin-multiomics/SKILL.md` | all your projects |
| Project | `.claude/skills/merlin-multiomics/SKILL.md` | that project only |

A skill enabled on claude.ai also syncs down to Claude Code, so you generally
only need one of A1 and A2. A local copy takes precedence over the synced one if
both exist.

## A3 — Check it took

Start a new session and ask something the skill should own:

> I have bedMethyl files for a *Sinorhizobium* WT and a dam knockout, three
> replicates each, plus a Prokka GFF3. What can MErlin tell me?

A working install answers with `merlin doctor` → `merlin preflight` → a
replicated `dixam` design, and asks which condition is the treatment before
running anything. If it instead offers to write a pandas script, the skill did
not load — check that the folder name matches and the toggle is on.

---

# Part B — Install the MErlin package

## B0 — Prerequisites

- Python **3.10 or newer** (`python3 --version`)
- `pip`
- Optional external binaries, none of them required:

| Binary | Needed for | Without it |
|---|---|---|
| [`modkit`](https://github.com/nanoporetech/modkit) | the reference modBAM pileup | MErlin's internal pysam pileup runs instead |
| `minimap2` + `samtools` | aligning an *unaligned* modBAM | `merlin pileup` refuses and prints the command to run by hand |
| R + `optparse`, `data.table`, `circlize`, `Biostrings` | the `roundtable.R` circos figure | `merlin spacem --circular` draws one without R |

`conda install -c bioconda modkit samtools minimap2` installs all three; modkit
also ships prebuilt binaries on its releases page.

MErlin is not on PyPI. Install it from the bundled wheel or from your source
tree.

## B1 — The one-liner

```bash
sh ~/.claude/skills/merlin-multiomics/scripts/install_merlin.sh
```

This installs `assets/merlin_multiomics-2.1.0-py3-none-any.whl` with all
optional extras and then runs `merlin doctor`. It is idempotent — if `merlin`
already runs, it only reports and checks.

To install your own working copy in editable mode instead, pass its path:

```bash
sh scripts/install_merlin.sh /path/to/merlin-2.1.0
```

## B2 — By hand

From the wheel:

```bash
python3 -m pip install "merlin_multiomics-2.1.0-py3-none-any.whl[all]"
```

From a source tree (what you want if you are still developing MErlin — changes
take effect without reinstalling):

```bash
cd /path/to/merlin-2.1.0
python3 -m pip install -e ".[all]"
```

On a Debian/Ubuntu system Python that refuses to install into itself, add
`--break-system-packages`, or better, use a virtual environment:

```bash
python3 -m venv ~/.venvs/merlin
~/.venvs/merlin/bin/pip install "merlin_multiomics-2.1.0-py3-none-any.whl[all]"
~/.venvs/merlin/bin/merlin doctor
```

If you use a venv or conda environment, Claude has to be able to find `merlin`
on PATH — either activate the environment before starting the session, or tell
Claude the absolute path to the executable.

## B3 — What the extras buy

`[all]` is the sensible default. Individually:

| Extra | Packages | Without it |
|---|---|---|
| *(core)* | numpy, pandas, scipy, matplotlib | nothing runs |
| `ml` | scikit-learn, statsmodels, seaborn | `diem` loses its classifier and logistic regression |
| `store` / `hic` | h5py | no `harmonise` store; no `.cool` reading |
| `cooler` | cooler | h5py's native `.cool` reader is used instead — fine for most files |
| `reads` | pysam | `phase` and `pileup` cannot run |
| `config` | pyyaml | `merlin run` accepts JSON configs only |

## B4 — Verify

```bash
merlin --version        # merlin 2.1.0
merlin doctor --check-r
```

`doctor` prints each dependency, then the external binaries (`modkit`,
`samtools`, `minimap2`), then a module-availability table — `ready`, `degraded`
or `unavailable`, with the reason. A `warn` on `cooler`, `modkit` or `Rscript` is
normal: each has a fallback inside MErlin.

If `merlin` installed but is not on PATH:

```bash
python3 -m merlin.cli doctor
# and add this to PATH:
python3 -m site --user-base    # then .../bin
```

## B5 — End-to-end check on the shipped test data

Only if you have the source tree (the wheel does not carry `testdata/`):

```bash
cd /path/to/merlin-2.1.0
python3 tools/make_testdata.py          # regenerate the synthetic dataset
cd examples && merlin run --config merlin.full.yaml
```

That should finish with a run report showing every module OK except the ones
skipped for a stated reason, and leave `results/<prefix>.report.html`.
`merlin run --config merlin.from_bam.yaml` does the same starting from the
synthetic modBAM, with no bedMethyl anywhere — that is the 2.1.0 path. The
synthetic data has known ground truth planted in it — three MTase systems
(GATC, GANTC, CCWGG), hypomethylated-and-downregulated genes, Hi-C domains, a
bistable locus, a deliberate seqid version-suffix mismatch — so
`pytest tests/ -q` asserts the biology comes back out.

## B6 — Docker, if you would rather not install anything

The source tree ships a Dockerfile with R, its packages, samtools and minimap2,
so `roundtable.R` and the alignment path stop being the things that fail on a
new machine:

```bash
docker build -t merlin:2.1.0 .
docker run --rm -v "$PWD":/data merlin:2.1.0 doctor
docker run --rm -v "$PWD":/data merlin:2.1.0 run --config merlin.yaml

# to bake modkit into the image, pass the release tarball URL for your arch:
docker build --build-arg MODKIT_URL=https://github.com/nanoporetech/modkit/releases/download/vX.Y.Z/modkit_vX.Y.Z_<target>.tar.gz -t merlin:2.1.0 .
```

The entrypoint is `merlin`, so pass subcommands directly. `/data` is the working
directory inside the container — mount your data there and use relative paths.

## B7 — R, for `roundtable.R` only

```r
install.packages(c("optparse", "data.table", "circlize"))
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
BiocManager::install("Biostrings")
```

`roundtable.R` installs missing packages itself at startup, which needs network
access and modifies your R library — install them yourself first if you would
rather it did not. `merlin spacem --circular` produces a circular genome figure
with no R at all.

---

# Part C — Upgrading and removing

```bash
python3 -m pip install --upgrade "merlin_multiomics-<new>.whl[all]"   # package
python3 -m pip uninstall merlin-multiomics
rm -rf ~/.claude/skills/merlin-multiomics                             # local skill
```

For a skill uploaded to claude.ai, upload the new version from **Customize →
Skills** and it replaces the old one; the toggle there also removes it.

---

# Troubleshooting the setup

| Symptom | Cause and fix |
|---|---|
| Upload rejected: "folder name doesn't match" | the zip's top-level folder must be `merlin-multiomics` |
| Upload rejected: "missing SKILL.md" | zip the *folder*, not its contents — `SKILL.md` must sit one level down |
| Claude ignores the skill | toggle is off, or a local `.claude/skills/merlin-multiomics` is shadowing it |
| `merlin: command not found` | not installed, wrong environment, or the user script dir is not on PATH (B4) |
| `ModuleNotFoundError: h5py` | installed without `[all]` — reinstall with the extras (B3) |
| `pileup` says modkit is missing | expected; the internal backend runs. Install modkit only if you need modkit-identical numbers |
| `pip` refuses: externally-managed-environment | use a venv, or `--break-system-packages` (B2) |
| `merlin doctor` says a module is `unavailable` | the reason is printed next to it; it names the package to install |

For anything past installation, `references/troubleshooting.md` covers the
analysis failures.
