---
name: merlin-multiomics
description: Run MErlin 2.1.0 (Methylation-driven Expression & Regulation Linkage in Interacting Nuclear-domains), a prokaryotic multi-omics toolkit driven by a single `merlin` CLI - pileup (basecalled modBAM to bedMethyl via modkit), xam (methylation per feature), dixam (replicate-aware differential methylation), spacem (oriC/ter distribution), mematch (motif association), diem (expression x methylation), hicam (Hi-C compartments and CIDs), phase (read-level hemimethylation and bistability), discover (de novo motifs), mtase (motif to methyltransferase), harmonise, evidence, report, preflight, doctor and run. Use it whenever the user mentions merlin, xam, dixam, spacem, mematch, diem, hicam, phase, discover, mtase, modkit or roundtable; points at methylation calls or basecalled BAMs (bedMethyl, modification GFF3, modBAM with MM/ML tags) with a bacterial annotation; or asks to cross DNA methylation with expression, motifs, methyltransferases, genome position or Hi-C in a prokaryote. Also use it to install or set up MErlin.
---

# MErlin 2.1.0

One command, seventeen subcommands, three groups. Every module is independent and
runs on whatever inputs exist — that modularity is the design, not a fallback.

```
analysis        pileup  xam  dixam  spacem  mematch  diem  hicam  phase  discover  mtase
integration     harmonise  evidence  report
orchestration   preflight  doctor  run  export
```

| Command | Needs | Produces |
|---|---|---|
| `pileup` | basecalled modBAM (MM/ML tags) | bedMethyl — where a raw BAM becomes an input |
| `xam` | annotation + methylation | methylation per feature (per replicate + pooled) |
| `dixam` | annotation + 2 conditions | differential methylation, replicate-aware |
| `spacem` | annotation + methylation + FASTA | oriC/ter spatial distribution |
| `mematch` | + motif list | motif × methylation association, enrichment |
| `discover` | methylation + FASTA | motifs found *de novo* (no motif list needed) |
| `mtase` | annotation + motifs (+ knockout) | motif → MTase gene attribution |
| `diem` | expression table + xam table | expression × methylation, confounder-adjusted |
| `hicam` | `.cool`/`.mcool` (+ any other layer) | compartments, CIDs, contact-weighted co-methylation |
| `phase` | modBAM with MM/ML tags | hemimethylation, bistability, cis co-methylation |
| `harmonise` | a results directory | one HDF5 store, everything joined on feature and bin |
| `evidence` | that store | genes ranked by combined evidence across layers |
| `report` | that results directory | one self-contained HTML report |

Your job is to run these correctly and report what they found — not to
reimplement them, and not to compute statistics alongside them.

Full argument lists and output columns: `references/tools.md`.
Installation and environment: `SETUP.md`.

## Step 0 — Is MErlin installed?

```
merlin doctor
```

Reports the Python version, every optional dependency, which modules are
runnable and why the others are not. If `merlin` is not on PATH, read `SETUP.md`
and install it — `scripts/install_merlin.sh` does the whole thing if the source
tree or a wheel is available.

If a dependency for a module the user needs is missing, say so and stop. Do not
write a substitute analysis in pandas.

## Step 1 — Inventory the inputs, then decide the modules

MErlin runs only what the inputs support, so start by listing what actually
exists — annotation, reference FASTA, methylation calls (how many files per
condition?), motif list, expression table, `.cool`, modBAM.

**A basecalled BAM is a valid starting point.** If the user has modBAMs and no
bedMethyl, `merlin pileup` produces one — modkit when it is on PATH, MErlin's own
pysam pileup when it is not — and `merlin run` inserts that step automatically
from a `modbam:` key. Do not ask them to run modkit by hand, and do not treat a
BAM-only project as missing an input. `--backend` and `--filter-threshold` are
the two settings worth stating in the report: the threshold at which an ML
probability becomes a call decides every number downstream.

Then let the plan follow from that inventory rather than from a default
pipeline. `merlin run --config x.yaml --dry-run` prints exactly which modules
will run and, for each skipped one, the input that was missing. Show the user
that plan before executing it; a plan with three skipped modules is a normal
methylation-only run, not a broken configuration.

Methylation-only is a first-class case. Never tell a user their run is
incomplete because they have no Hi-C.

## Step 2 — Preflight (do not skip this)

```
merlin preflight --gff ANN.gff3 --fasta REF.fasta --methylation METH.bed \
    --motifs motifs.txt --geneexp deseq2.csv --hic contacts.cool
```

Pass whatever exists. Exit `0` clean, `1` warnings, `2` blocking.

This exists because every module joins on either seqid or locus_tag and **both
joins fail silently**. A seqid namespace mismatch does not raise — it returns
zero overlaps, which in the output is indistinguishable from a genome with no
methylation. Running first and interpreting later means interpreting an
artefact.

`references/preflight.md` explains every finding and its fix. The
version-suffix mismatch (`NZ_XXX.1` in methylation and FASTA versus `NZ_XXX` in
a Prokka/GbkToGff annotation) is common, expected, and reconciled automatically
by every module — say so, note it as provenance, move on. The dangerous state
is disjoint namespaces with equal counts, where a guessed pairing (never accept
`--allow-rank-map` here) yields fully populated, entirely wrong output.

If preflight blocks, resolve it with the user before running anything.

## Step 3 — Establish what the files cannot tell you

Ask; do not infer. Each of these silently inverts or invalidates conclusions:

- **Contrast direction.** For any DESeq2/edgeR table: does positive
  `log2FoldChange` mean up in the treatment or up in the control, and which
  condition is the treatment? Nothing in the file records this, and every
  directional sentence you later write rests on the answer.
- **Which condition is which in `dixam`.** `--labels` is positional and
  defaults to `control treatment` regardless of file contents. A swapped pair
  inverts every differential call and looks completely normal.
- **Which backend piled up the BAM**, when the run started from one. modkit and
  MErlin's internal pileup agree closely, not exactly; the summary table and the
  provenance sidecar both name the one that ran.
- **Replicate structure.** Are the several methylation files biological
  replicates, technical replicates, or separate samples the user wants pooled?
  This decides which statistical model is legitimate (see below and
  `references/statistics.md`). Technical replicates passed as biological ones
  understate dispersion and manufacture significance.
- **Which replicons matter.** Chromosome plus megaplasmids can be analysed
  jointly or separately; pooling can create correlations driven entirely by
  between-replicon differences.
- **The knockout gene**, if a condition is a mutant — `mtase --knockout-gene`
  turns a correlation into an attribution.

## Step 4 — Run

**Several modules → write a config and use `merlin run`.** It resolves paths
relative to the config, orders the modules correctly (`discover` before
`mematch`, `xam` before `diem`), records the plan, and skips with a reason.

```yaml
outdir: results
prefix: SmBL225C
annotation: annotation.gff3
reference:  reference.fasta
methylation:                  # 'modbam:' takes the same shape; with no
  WT:     [wt_rep1.bed.gz, wt_rep2.bed.gz, wt_rep3.bed.gz]   # 'methylation:' a
  dam_kd: [ko_rep1.bed.gz, ko_rep2.bed.gz, ko_rep3.bed.gz]   # pileup runs first
motifs:     motifs.txt        # omit it and 'discover' finds them
expression: deseq2_results.csv
hic:        contacts.cool
modbam:     reads.modbam.bam
resolution: 5000
knockout_gene: dam
min_frac: 0.5
options:
  dixam: {features: CDS, regions: [upstream:-300..50, body]}
  diem:  {gff: annotation.gff3, fasta: reference.fasta, n-perm: 5000}
```

```
merlin run --config merlin.yaml --dry-run     # show the plan first
merlin run --config merlin.yaml
```

`references/run_config.md` documents every key. `merlin export --config x.yaml
--workflow nextflow|snakemake|json` emits the same plan for a cluster.

**One module → call it directly**, e.g.

```
merlin pileup --modbam calls.bam --fasta ref.fasta -o out/pileup
merlin xam -g ann.gff3 --methylation r1.bed r2.bed r3.bed -o out --include-zero
merlin dixam -g ann.gff3 --methylation wt*.bed --methylation2 ko*.bed -o out
merlin discover --fasta ref.fasta --methylation calls.bed -o out
```

Two flags decide whether downstream work is honest:

- **`xam --include-zero`** before `diem`. Without it, features with no
  methylation call are absent rather than zero, and every correlation describes
  the methylated subset only.
- **Replicate files as a list**, not concatenated. `--methylation a b c` is
  three replicates and licenses the beta-binomial LRT; `cat a b c` is one
  sample and licenses only a descriptive comparison.

Report progress as modules complete rather than going silent — `mematch` and
`hicam` take minutes on a real genome. If a module exits non-zero, capture
stderr, report it, and stop; do not feed a failed output downstream. Read
`references/troubleshooting.md` before retrying anything.

## Step 5 — Integrate

Only worth doing when more than one layer ran, and the whole point when it did:

```
merlin harmonise --results results --gff ann.gff3 -o results/harmonised
merlin evidence  --store results/harmonised/merlin.h5 -o results/evidence
merlin report    --results results --store results/harmonised/merlin.h5 -o results
```

`evidence` combines per-layer statistics per gene (Stouffer + robust rank
aggregation, BH across genes). It ranks; it does not test a new hypothesis, and
a gene high in the ranking is a gene worth looking at, not a gene shown to be
regulated by methylation.

## Step 6 — Report

Read `references/interpretation.md` before writing any sentence containing a
direction or a mechanism. Then:

```
## What was run
[merlin version, modules, inputs, seqid reconciliation, key thresholds]
[Contrast: which label is treatment; what positive log2FC means, per the user]
[Replicate structure and therefore which test was used]

## Findings
[Numbers from the output tables only. Name the file for each claim.]
[Effect size first, then n, then p — permutation or LRT p, not the analytic one.]

## Caveats
[Every preflight warning, verbatim. Every applicable caveat from interpretation.md.]

## Files
[Everything produced, one line each.]
```

Deliver the output files after each analysis block, not only at the end. The
HTML report from `merlin report` is usually the single most useful artefact —
send it.

## Rules

**Do not compute statistics yourself.** No correlations, p-values, enrichments
or fold-changes calculated by you, in any language, including as a check on
MErlin. Two numbers of different provenance in one report is worse than one.

**Report only what is in the output tables.** If MErlin did not produce it, say
so and offer to configure a run that would. Never read values off a figure.

**Never present a zero result before preflight passes.** "No methylation found"
and "the seqids didn't match" produce identical-looking output. Rule out the
second before reporting the first.

**Match the claim to the design.** With one sample per condition, `dixam` gives
a descriptive comparison with a within-sample test — the p-value speaks to
sampling of reads, not to biological reproducibility, so no statement about the
population of cells or strains is licensed. Replicates change that; nothing else
does. `references/statistics.md` says which test each design earns.

**Distinguish observed from inferred.** Genes measured in the data and genes
inferred from annotation are different categories. Label inferred as inferred.

**Association, not causation.** MErlin quantifies co-variation. "Methylation
correlates with expression" is a finding; "methylation regulates expression" is
not, and significance does not convert one into the other. The exception is
narrow: `mtase` with a knockout condition licenses "motif X is lost when gene Y
is deleted", which is an attribution and still not a claim about expression.

**Never retry with looser thresholds to obtain a result.** If the user wants a
threshold changed, make the change explicit, record it, and report both runs.

**Never disable a check to make a warning disappear**, and never edit the
user's input files to make a join work. Fix the flag, not the data.

## Reference files

- `SETUP.md` — installing MErlin and this skill; dependencies, Docker, R
- `references/tools.md` — every module's real arguments and outputs
- `references/statistics.md` — which model each design licenses; the tests and their calibration
- `references/run_config.md` — the `merlin run` YAML schema, with worked configs
- `references/preflight.md` — every preflight finding and its fix
- `references/interpretation.md` — what MErlin's statistics do and do not license
- `references/troubleshooting.md` — failures and their causes
