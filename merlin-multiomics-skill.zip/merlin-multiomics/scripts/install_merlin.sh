#!/bin/sh
# Install the MErlin package so `merlin <command>` works, then check it.
#
#   sh scripts/install_merlin.sh                # bundled wheel, or a source tree if found
#   sh scripts/install_merlin.sh /path/to/merlin   # explicit source tree (editable install)
#
# Idempotent: if `merlin` already runs, it only reports and checks the version.
set -eu

SKILL_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC=${1:-}
PIP="python3 -m pip"

say() { printf '%s\n' "$*"; }

if command -v merlin >/dev/null 2>&1; then
    say "merlin is already installed: $(merlin --version 2>&1 | head -1)"
    say "Re-installing anyway is safe; skipping. Pass a source path to force an editable install."
else
    if [ -n "$SRC" ] && [ -f "$SRC/pyproject.toml" ]; then
        say "Installing from source tree: $SRC"
        $PIP install -e "$SRC[all]" || $PIP install --break-system-packages -e "$SRC[all]"
    elif [ -n "$(ls "$SKILL_DIR"/assets/merlin_multiomics-*.whl 2>/dev/null)" ]; then
        WHL="$(ls "$SKILL_DIR"/assets/merlin_multiomics-*.whl | tail -1)"
        say "Installing the bundled wheel: $WHL"
        $PIP install "$WHL[all]" || $PIP install --break-system-packages "$WHL[all]"
    else
        say "No source tree given and no bundled wheel found."
        say "Run:  sh scripts/install_merlin.sh /path/to/merlin-2.1.0"
        exit 1
    fi
fi

say ""
if command -v merlin >/dev/null 2>&1; then
    merlin doctor --check-r || true
else
    say "merlin installed but not on PATH — try:  python3 -m merlin.cli doctor"
    say "and add the user script directory (python3 -m site --user-base)/bin to PATH."
    exit 1
fi
