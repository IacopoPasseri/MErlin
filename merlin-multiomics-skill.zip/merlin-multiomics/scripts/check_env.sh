#!/bin/sh
# Is this machine able to run MErlin? Wraps `merlin doctor` and says what to do
# when the answer is no.
#
#   sh scripts/check_env.sh
set -u

if command -v merlin >/dev/null 2>&1; then
    merlin doctor --check-r
    exit $?
fi

echo "merlin is not on PATH."
echo

if command -v python3 >/dev/null 2>&1; then
    echo "python3: $(python3 --version 2>&1)  ($(command -v python3))"
    python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    print("  MErlin needs Python >= 3.10; this interpreter is too old.")
try:
    import merlin  # noqa: F401
    print("  the merlin package IS importable — the console script is just not on PATH.")
    print("  use:  python3 -m merlin.cli doctor")
except ImportError:
    print("  the merlin package is not installed.")
PY
else
    echo "python3 not found — install Python 3.10 or newer first."
fi

echo
echo "To install:  sh scripts/install_merlin.sh            # bundled wheel"
echo "         or: sh scripts/install_merlin.sh /path/to/merlin-2.1.0"
echo "See SETUP.md for the full guide."
exit 1
