#!/usr/bin/env Rscript
# =============================================================================
# roundtable.R — circular genome figure for MErlin
#
# Ring layout (outermost -> innermost):
#   [motif rings]  one density ring per motif (only with --motifs)
#   replicon       ideogram with oriC (green) and ter (red) + Mb axis
#   features       + strand up (red) / - strand down (blue), mirrored
#   methylation    density (area) with LOESS smoothing + highlighted genes
#   GC skew        diverging (G>C green / C>G purple), confirms oriC/ter
#
# Changes from the original circos_methylation.R
# ----------------------------------------------
# * Dependencies are CHECKED, not silently installed. The original called
#   install.packages()/BiocManager::install() at load time, which writes to the
#   user's library without consent and fails on a read-only cluster library.
#   Use --install-deps to opt in.
# * Methylation input accepts GFF3 modification calls as well as bedMethyl, and
#   a 6-column BED. The original indexed V10/V11 unconditionally and crashed on
#   anything that was not a full bedMethyl — including the GFF3 that every other
#   MErlin tool takes.
# * --min-frac is applied to the methylation density ring, so the ring shows
#   methylation rather than assay coverage.
# * The FASTA is read once (the original read it twice, doubling peak memory on
#   a multi-megabase genome).
# * Replicon labels are made unique and safe; oriC/ter detection matches
#   merlin.genome exactly (origin = minimum of cumulative skew; terminus =
#   maximum of the skew restarted at the origin, walked around the circle).
# * Weak GC skew is reported rather than silently drawn as a confident marker.
# =============================================================================

suppressWarnings(suppressMessages({
  .need_cran <- c("optparse", "data.table", "circlize")
  .need_bioc <- c("Biostrings")
  .have <- function(p) requireNamespace(p, quietly = TRUE)
  .missing <- c(.need_cran[!vapply(.need_cran, .have, logical(1))],
                .need_bioc[!vapply(.need_bioc, .have, logical(1))])
  if (length(.missing)) {
    if ("--install-deps" %in% commandArgs(trailingOnly = TRUE)) {
      cran <- intersect(.missing, .need_cran)
      bioc <- intersect(.missing, .need_bioc)
      if (length(cran)) install.packages(cran, repos = "https://cloud.r-project.org")
      if (length(bioc)) {
        if (!.have("BiocManager"))
          install.packages("BiocManager", repos = "https://cloud.r-project.org")
        BiocManager::install(bioc, update = FALSE, ask = FALSE)
      }
    } else {
      stop(sprintf(paste0(
        "roundtable.R needs these R packages, which are not installed: %s\n",
        "  install.packages(c(%s))\n",
        "  BiocManager::install(c(%s))\n",
        "Or rerun with --install-deps to install them now."),
        paste(.missing, collapse = ", "),
        paste(sprintf('"%s"', intersect(.missing, .need_cran)), collapse = ", "),
        paste(sprintf('"%s"', intersect(.missing, .need_bioc)), collapse = ", ")),
        call. = FALSE)
    }
  }
  library(optparse); library(data.table); library(circlize); library(Biostrings)
}))

# ---------------------------------------------------------------------------- #
# CLI
# ---------------------------------------------------------------------------- #
opt_list <- list(
  make_option("--gff", type = "character", help = "GFF3 annotation [required]"),
  make_option("--fasta", type = "character", help = "Reference FASTA [required]"),
  make_option("--methylation", type = "character",
              help = "Methylation calls: bedMethyl, 6-column BED or GFF3 [required]"),
  make_option("--meth-format", type = "character", default = "auto",
              dest = "meth_format",
              help = "auto | bedmethyl | bed6 | gff [default %default]."),
  make_option("--motifs", type = "character", default = NULL,
              help = "Optional motif list (one IUPAC motif per line)."),
  make_option("--mod-codes", type = "character", default = NULL, dest = "mod_codes",
              help = "Comma-separated modification codes to keep, e.g. 'a'."),
  make_option("--feature-types", type = "character", default = "CDS",
              dest = "feature_types",
              help = "Comma-separated GFF types to keep [default %default]."),
  make_option("--min-coverage", type = "double", default = 0, dest = "min_cov",
              help = "Minimum valid coverage for a call [default %default]."),
  make_option("--min-frac", type = "double", default = 0.5, dest = "min_frac",
              help = "Fraction-modified threshold for 'methylated' [default %default]."),
  make_option("--bin", type = "double", default = 0,
              help = "Bin size (bp) for the density rings; 0 = auto (~1500 bins)."),
  make_option("--skew-window", type = "double", default = 10000, dest = "skew_window",
              help = "Window (bp) for oriC/ter GC-skew detection [default %default]."),
  make_option("--loess-span", type = "double", default = 0.30, dest = "loess_span",
              help = "LOESS span for methylation smoothing [default %default]."),
  make_option("--highlight-top", type = "integer", default = 12, dest = "highlight_top",
              help = "Most-methylated genes to highlight [default %default]."),
  make_option("--highlight-min-calls", type = "integer", default = 4,
              dest = "highlight_min_calls",
              help = "Min calls in a gene to be eligible [default %default]."),
  make_option("--oric", type = "character", default = NULL,
              help = "Override oriC, 'seqid:pos[,seqid:pos]' (0-based)."),
  make_option("--ter", type = "character", default = NULL,
              help = "Override ter, 'seqid:pos[,seqid:pos]' (0-based)."),
  make_option("--strip-version", action = "store_true", default = FALSE,
              dest = "strip_version",
              help = "Strip trailing .N from seqids (auto if it reconciles GFF/FASTA)."),
  make_option("--install-deps", action = "store_true", default = FALSE,
              dest = "install_deps", help = "Install missing R packages and continue."),
  make_option("--out", type = "character", default = "circos_genome.pdf",
              help = "Output file (.pdf/.png/.svg) [default %default]."),
  make_option("--width", type = "double", default = 11, help = "Figure width (in)."),
  make_option("--height", type = "double", default = 11, help = "Figure height (in)."),
  make_option("--title", type = "character", default = NULL, help = "Plot title.")
)
opt <- parse_args(OptionParser(option_list = opt_list))
for (req in c("gff", "fasta", "methylation"))
  if (is.null(opt[[req]])) stop("Missing required --", req, call. = FALSE)
for (req in c("gff", "fasta", "methylation"))
  if (!file.exists(opt[[req]])) stop("File not found: ", opt[[req]], call. = FALSE)

split_csv <- function(x) if (is.null(x)) NULL else strsplit(x, ",")[[1]]
strip_ver <- function(x) sub("\\.[0-9]+$", "", x)

parse_loci <- function(s) {
  out <- list()
  if (is.null(s)) return(out)
  for (tok in strsplit(s, ",")[[1]]) {
    kv <- strsplit(trimws(tok), ":")[[1]]
    if (length(kv) == 2) out[[kv[1]]] <- as.numeric(kv[2])
  }
  out
}

# ---------------------------------------------------------------------------- #
# Read inputs
# ---------------------------------------------------------------------------- #
message("Reading FASTA / GFF / methylation ...")
genome_raw <- readDNAStringSet(opt$fasta)
headers <- names(genome_raw)                    # read once, reused for labels
names(genome_raw) <- sub("\\s.*", "", headers)
genome <- genome_raw

read_gff <- function(path, ftypes) {
  dt <- fread(path, sep = "\t", header = FALSE, fill = TRUE, quote = "",
              showProgress = FALSE)
  dt <- dt[!startsWith(as.character(V1), "#")]
  dt <- dt[!is.na(V3) & !is.na(V4) & !is.na(V5)]
  if (!is.null(ftypes)) dt <- dt[V3 %in% ftypes]
  if (!nrow(dt)) stop("No features of type(s) '", paste(ftypes, collapse = ","),
                      "' in ", path, call. = FALSE)
  dt[, `:=`(seqid = as.character(V1),
            start = as.integer(V4) - 1L,
            end   = as.integer(V5) - 1L,
            strand = as.character(V7),
            type = as.character(V3))]
  dt[, locus := ifelse(grepl("locus_tag=", V9),
                       sub(".*locus_tag=([^;]+).*", "\\1", V9), NA_character_)]
  dt[, .(seqid, start, end, strand, type, locus)]
}
feat <- read_gff(opt$gff, split_csv(opt$feature_types))

sniff_meth <- function(path) {
  con <- file(path, "r"); on.exit(close(con))
  repeat {
    ln <- readLines(con, n = 1, warn = FALSE)
    if (!length(ln)) return(list(fmt = "bed6", n = 0L))
    if (!startsWith(ln, "#") && nzchar(trimws(ln))) break
  }
  cols <- strsplit(ln, "\t")[[1]]
  if (length(cols) < 4) cols <- strsplit(trimws(ln), "[ \t]+")[[1]]
  n <- length(cols)
  looks_gff <- n >= 8 &&
    !is.na(suppressWarnings(as.integer(cols[4]))) &&
    !is.na(suppressWarnings(as.integer(cols[5]))) &&
    cols[7] %in% c("+", "-", ".")
  looks_bed <- n >= 4 && !is.na(suppressWarnings(as.integer(cols[2])))
  if (n >= 11 && looks_bed) return(list(fmt = "bedmethyl", n = n))
  if (looks_gff)            return(list(fmt = "gff", n = n))
  list(fmt = "bed6", n = n)
}

read_meth <- function(path, fmt, keep_codes, min_cov) {
  sn <- sniff_meth(path)
  if (identical(fmt, "auto")) fmt <- sn$fmt
  message("  methylation format: ", fmt, " (", sn$n, " columns)")
  dt <- fread(path, sep = "\t", header = FALSE, showProgress = FALSE, fill = TRUE)
  if (fmt == "gff") {
    dt <- dt[!startsWith(as.character(V1), "#")]
    out <- dt[, .(seqid = as.character(V1),
                  pos = as.integer(V4) - 1L,
                  code = as.character(V3),
                  strand = as.character(V7),
                  cov = NA_real_, frac = NA_real_)]
    # normalise the common type spellings to modkit codes
    out[code %in% c("5mC", "m5C", "CpG", "modified_base", "methylation"), code := "m"]
    out[code %in% c("6mA", "m6A", "GATC", "dam"), code := "a"]
    out[code %in% c("5hmC"), code := "h"]
    if (ncol(dt) >= 9) {
      a <- as.character(dt$V9)
      cv <- suppressWarnings(as.numeric(sub(".*(?:coverage|Nvalid_cov)=([^;]+).*",
                                            "\\1", a)))
      fr <- suppressWarnings(as.numeric(sub(
        ".*(?:frac_modified|percent_modified|frac)=([^;]+).*", "\\1", a)))
      out[, cov := cv][, frac := fr]
    }
  } else if (fmt == "bedmethyl" && ncol(dt) >= 11) {
    out <- dt[, .(seqid = as.character(V1), pos = as.integer(V2),
                  code = as.character(V4), strand = as.character(V6),
                  cov = as.numeric(V10), frac = as.numeric(V11))]
  } else {                                            # 6-column BED: presence only
    out <- dt[, .(seqid = as.character(V1), pos = as.integer(V2),
                  code = as.character(V4),
                  strand = if (ncol(dt) >= 6) as.character(V6) else ".",
                  cov = NA_real_, frac = NA_real_)]
  }
  out[!is.na(frac) & frac > 1, frac := frac / 100]     # percent -> fraction
  if (!is.null(keep_codes)) out <- out[code %in% keep_codes]
  out <- out[!is.na(pos)]
  out[is.na(cov) | cov >= min_cov]
}
meth <- read_meth(opt$methylation, opt$meth_format, split_csv(opt$mod_codes),
                  opt$min_cov)
if (!nrow(meth)) stop("No methylation calls survived parsing/filtering.", call. = FALSE)
presence_only <- all(is.na(meth$frac))
if (presence_only)
  message("  presence-only input: every call counts as methylated ",
          "(--min-frac has no effect).")

# ---- seqid reconciliation (auto-strip a pure .N version mismatch) ----
gff_ids <- unique(feat$seqid); fa_ids <- names(genome)
do_strip <- opt$strip_version
if (!do_strip && length(intersect(gff_ids, fa_ids)) == 0 &&
    length(intersect(strip_ver(gff_ids), strip_ver(fa_ids))) > 0) {
  message("[auto] stripping the '.N' version suffix to reconcile seqids.")
  do_strip <- TRUE
}
if (do_strip) {
  names(genome) <- strip_ver(names(genome))
  feat[, seqid := strip_ver(seqid)]
  meth[, seqid := strip_ver(seqid)]
}
if (length(intersect(names(genome), unique(feat$seqid))) == 0)
  stop("GFF and FASTA seqids do not match; try --strip-version. ",
       "Every ring would be empty.", call. = FALSE)
if (length(intersect(names(genome), unique(meth$seqid))) == 0)
  stop("Methylation and FASTA seqids do not match; try --strip-version.", call. = FALSE)
glen <- setNames(as.integer(width(genome)), names(genome))

# ---- replicon labels (unique, from the FASTA descriptions) ----
labels <- character(0)
used <- character(0)
for (i in seq_along(headers)) {
  sid <- sub("\\s.*", "", headers[i]); if (do_strip) sid <- strip_ver(sid)
  d <- tolower(headers[i]); lab <- sid
  if (grepl("chromosome", d)) {
    lab <- "chromosome"
  } else if (grepl("plasmid", d)) {
    tok <- sub(".*[Pp]lasmid[ ]+([^, ]+).*", "\\1", headers[i])
    lab <- if (nzchar(tok) && tok != headers[i]) tok else "plasmid"
  }
  if (lab %in% used) lab <- paste0(lab, "_", sum(used == lab) + 1L)
  used <- c(used, lab)
  labels[sid] <- lab
}
lab_of <- function(sid) if (!is.na(labels[sid])) labels[sid] else sid

# ---------------------------------------------------------------------------- #
# oriC / ter from cumulative GC skew
# ---------------------------------------------------------------------------- #
gc_oriter <- function(seq, window) {
  L <- length(seq)
  window <- max(1, min(window, max(1, L %/% 4)))
  starts <- seq(1, L, by = window)
  widths <- pmin(window, L - starts + 1)
  v <- Views(seq, start = starts, width = widths)
  lf <- letterFrequency(v, c("G", "C"))
  delta <- lf[, "G"] - lf[, "C"]
  cum <- cumsum(delta); n <- length(delta)
  if (n < 4) return(list(oric = 0, ter = L %/% 2, rel = 0))
  oi <- which.min(cum)
  rot <- cumsum(delta[c(oi:n, seq_len(max(oi - 1, 0)))])
  ti <- ((oi - 1 + which.max(rot) - 1) %% n) + 1
  centers <- (starts - 1) + widths / 2
  list(oric = centers[oi], ter = centers[ti],
       rel = (max(rot) - min(rot)) / L)
}
oric_ov <- parse_loci(opt$oric); ter_ov <- parse_loci(opt$ter)
orit <- list()
for (sid in names(genome)) {
  d <- gc_oriter(genome[[sid]], opt$skew_window)
  oc <- if (!is.null(oric_ov[[sid]])) oric_ov[[sid]] else d$oric
  tr <- if (!is.null(ter_ov[[sid]])) ter_ov[[sid]] else d$ter
  weak <- d$rel < 0.02 && is.null(oric_ov[[sid]])
  if (weak)
    message("[warn] ", lab_of(sid), ": cumulative GC skew is only ",
            sprintf("%.4f", d$rel), " of replicon length — the oriC/ter markers ",
            "on this replicon are not reliable.")
  orit[[sid]] <- list(oric = oc, ter = tr, weak = weak)
}

# ---------------------------------------------------------------------------- #
# Binning helpers
# ---------------------------------------------------------------------------- #
bin <- if (opt$bin > 0) opt$bin else max(1000, round(sum(glen) / 1500 / 500) * 500)
message("Bin size: ", format(bin, big.mark = ","), " bp")
bin_counts <- function(pos, L) {
  nb <- max(1, ceiling(L / bin))
  if (length(pos) == 0) return(rep(0L, nb))
  idx <- pmin(floor(pos / bin) + 1L, nb)
  tabulate(idx, nbins = nb)
}
bin_centers <- function(L) {
  nb <- max(1, ceiling(L / bin))
  (seq_len(nb) - 0.5) * bin
}
skew_bins <- function(seq) {
  L <- length(seq); nb <- max(1, ceiling(L / bin))
  starts <- (seq_len(nb) - 1) * bin + 1
  widths <- pmin(bin, L - starts + 1)
  lf <- letterFrequency(Views(seq, start = starts, width = widths), c("G", "C"))
  g <- lf[, "G"]; cc <- lf[, "C"]
  (g - cc) / pmax(g + cc, 1)
}

find_motif_pos <- function(seq, motif) {
  pat <- DNAString(motif)
  fwd <- start(matchPattern(pat, seq, fixed = "subject"))
  rev <- start(matchPattern(reverseComplement(pat), seq, fixed = "subject"))
  as.integer(c(fwd, rev)) - 1L
}
motifs <- if (!is.null(opt$motifs)) {
  m <- toupper(trimws(readLines(opt$motifs, warn = FALSE)))
  m <- m[nzchar(m) & !startsWith(m, "#")]
  sub("[ \t].*", "", m)                          # drop the offset column
} else character(0)

# ---------------------------------------------------------------------------- #
# Per-sector data + global normalisers
# ---------------------------------------------------------------------------- #
ord <- names(glen)[order(-glen)]
feat_dat <- meth_dat <- skew_dat <- list()
motif_dat <- setNames(vector("list", length(motifs)), motifs)
meth_meth <- if (presence_only) meth else meth[is.na(frac) | frac >= opt$min_frac]
message("Density ring uses ", nrow(meth_meth), " methylated call(s) of ",
        nrow(meth), " assayed.")

for (sid in ord) {
  L <- glen[[sid]]
  cen <- bin_centers(L)
  fp <- feat[seqid == sid & strand == "+"]
  fm <- feat[seqid == sid & strand == "-"]
  feat_dat[[sid]] <- data.frame(
    x = cen,
    pos = bin_counts(fp$start + (fp$end - fp$start) / 2, L),
    neg = bin_counts(fm$start + (fm$end - fm$start) / 2, L))
  mm <- meth_meth[seqid == sid]
  meth_dat[[sid]] <- data.frame(x = cen, dens = bin_counts(mm$pos, L))
  skew_dat[[sid]] <- data.frame(x = cen, skew = skew_bins(genome[[sid]]))
  for (mo in motifs) {
    p <- find_motif_pos(genome[[sid]], mo)
    motif_dat[[mo]][[sid]] <- data.frame(x = cen, dens = bin_counts(p, L))
  }
}
feat_max <- max(1, unlist(lapply(feat_dat, function(d) max(d$pos, d$neg))))
meth_max <- max(1, unlist(lapply(meth_dat, function(d) max(d$dens))))
skew_max <- max(1e-9, unlist(lapply(skew_dat, function(d) max(abs(d$skew)))))
motif_max <- if (length(motifs))
  sapply(motifs, function(mo)
    max(1, unlist(lapply(motif_dat[[mo]], function(d) max(d$dens))))) else numeric(0)

for (sid in ord) {
  feat_dat[[sid]]$pos <- feat_dat[[sid]]$pos / feat_max
  feat_dat[[sid]]$neg <- feat_dat[[sid]]$neg / feat_max
  meth_dat[[sid]]$dens <- meth_dat[[sid]]$dens / meth_max
  skew_dat[[sid]]$skew <- skew_dat[[sid]]$skew / skew_max
  for (mo in motifs)
    motif_dat[[mo]][[sid]]$dens <- motif_dat[[mo]][[sid]]$dens / motif_max[[mo]]
}

# ---- most-methylated genes, for the highlight lines ----
highlight <- setNames(vector("list", length(ord)), ord)
genes <- feat[strand %in% c("+", "-")]
if (nrow(genes)) {
  genes[, gid := ifelse(is.na(locus), paste0(seqid, ":", start), locus)]
  setkey(genes, seqid, start, end)
  # rank by mean fraction when available, otherwise by call density
  mc <- meth_meth[, .(seqid, s = pos, e = pos, frac)]
  ov <- foverlaps(mc, genes, by.x = c("seqid", "s", "e"),
                  by.y = c("seqid", "start", "end"), nomatch = NULL)
  if (nrow(ov)) {
    agg <- ov[, .(mean_frac = if (all(is.na(frac))) NA_real_
                              else mean(frac, na.rm = TRUE), n = .N),
              by = .(seqid, gid, start, end)]
    agg <- agg[n >= opt$highlight_min_calls]
    if (nrow(agg)) {
      agg[, score := if (all(is.na(mean_frac))) n / pmax(end - start, 1) else mean_frac]
      top <- agg[order(-score)][seq_len(min(opt$highlight_top, .N))]
      for (sid in ord) {
        t <- top[seqid == sid]
        if (nrow(t))
          highlight[[sid]] <- data.frame(mid = (t$start + t$end) / 2, gid = t$gid)
      }
    }
  }
}

# ---------------------------------------------------------------------------- #
# Plot
# ---------------------------------------------------------------------------- #
dir.create(dirname(opt$out), showWarnings = FALSE, recursive = TRUE)
message("Rendering ", opt$out, " ...")
ext <- tolower(tools::file_ext(opt$out))
if (ext == "pdf") {
  pdf(opt$out, width = opt$width, height = opt$height)
} else if (ext == "svg") {
  svg(opt$out, width = opt$width, height = opt$height)
} else {
  png(opt$out, width = opt$width, height = opt$height, units = "in", res = 200)
}

pal <- c("#2c6fbb", "#e08a1e", "#3a9b78", "#b5446e", "#7d6bb0")
repcol <- setNames(pal[(seq_along(ord) - 1) %% length(pal) + 1], ord)

xlim <- cbind(rep(0, length(ord)), as.numeric(glen[ord]))
par(mar = c(1, 1, 2, 1))
gaps <- if (length(ord) > 1) c(rep(3, length(ord) - 1), 14) else 14
circos.clear()
circos.par(start.degree = 90 - 7, gap.after = gaps,
           cell.padding = c(0, 0, 0, 0), track.margin = c(0.004, 0.004),
           points.overflow.warning = FALSE)
circos.initialize(factors = factor(ord, levels = ord), xlim = xlim)

# ---- (outer) motif rings ----
motif_pal <- c("#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e")
for (i in seq_along(motifs)) {
  local({
    m <- motifs[i]; cc <- motif_pal[(i - 1) %% length(motif_pal) + 1]
    circos.track(ylim = c(0, 1), track.height = 0.05, bg.border = NA,
      panel.fun = function(x, y) {
        d <- motif_dat[[m]][[CELL_META$sector.index]]
        circos.lines(d$x, d$dens, area = TRUE,
                     col = adjustcolor(cc, 0.55), border = cc, lwd = 0.5)
        if (CELL_META$sector.numeric.index == length(ord))
          circos.text(CELL_META$xlim[2], 0.5, paste0(" ", m), col = cc,
                      cex = 0.5, adj = c(0, 0.5), facing = "downward")
      })
  })
}

# ---- replicon ideogram + oriC/ter ----
circos.track(ylim = c(0, 1), track.height = 0.09, bg.border = NA,
  panel.fun = function(x, y) {
    si <- CELL_META$sector.index; xl <- CELL_META$xlim
    circos.rect(xl[1], 0, xl[2], 0.55, col = repcol[si], border = "white", lwd = 0.5)
    circos.text(mean(xl), 0.93, lab_of(si), facing = "bending.inside",
                niceFacing = TRUE, cex = 0.8, font = 2, col = repcol[si])
    step <- if (xl[2] > 2e6) 5e5 else max(5e4, signif(xl[2] / 8, 1))
    mj <- seq(0, xl[2], by = step)
    circos.axis(h = 0.55, major.at = mj, labels = sprintf("%.2f", mj / 1e6),
                labels.cex = 0.35, major.tick.length = mm_y(1),
                labels.facing = "clockwise", col = "grey40", labels.col = "grey30")
    o <- orit[[si]]$oric; t <- orit[[si]]$ter
    ocol <- if (isTRUE(orit[[si]]$weak)) "#7f8c8d" else "#1e8449"
    tcol <- if (isTRUE(orit[[si]]$weak)) "#7f8c8d" else "#c0392b"
    suffix <- if (isTRUE(orit[[si]]$weak)) "?" else ""
    circos.segments(o, 0, o, 0.75, col = ocol, lwd = 2.5)
    circos.text(o, 0.9, paste0("ori", suffix), col = ocol, cex = 0.5, font = 2,
                facing = "clockwise", niceFacing = TRUE)
    circos.segments(t, 0, t, 0.75, col = tcol, lwd = 2.5)
    circos.text(t, 0.9, paste0("ter", suffix), col = tcol, cex = 0.5, font = 2,
                facing = "clockwise", niceFacing = TRUE)
  })

# ---- features: + up (red) / - down (blue) ----
circos.track(ylim = c(-1, 1), track.height = 0.15, bg.border = NA,
  panel.fun = function(x, y) {
    d <- feat_dat[[CELL_META$sector.index]]
    hw <- bin / 2
    circos.rect(d$x - hw, 0, d$x + hw, d$pos, col = "#d62728", border = NA)
    circos.rect(d$x - hw, -d$neg, d$x + hw, 0, col = "#1f77b4", border = NA)
    circos.segments(CELL_META$xlim[1], 0, CELL_META$xlim[2], 0,
                    col = "grey55", lwd = 0.4)
  })

# ---- methylation density: area + LOESS + highlights ----
circos.track(ylim = c(0, 1.18), track.height = 0.17, bg.border = NA,
  panel.fun = function(x, y) {
    si <- CELL_META$sector.index; d <- meth_dat[[si]]
    circos.lines(d$x, pmin(d$dens, 1), area = TRUE,
                 col = "#f5b7b1", border = "#cd6155", lwd = 0.4)
    if (nrow(d) >= 6) {
      lo <- tryCatch(loess(dens ~ x, data = d, span = opt$loess_span),
                     error = function(e) NULL)
      if (!is.null(lo)) {
        xs <- seq(min(d$x), max(d$x), length.out = 250)
        pr <- pmax(0, predict(lo, newdata = data.frame(x = xs)))
        circos.lines(xs, pmin(pr, 1.05), col = "#7b241c", lwd = 2)
      }
    }
    h <- highlight[[si]]
    if (!is.null(h) && nrow(h) > 0) {
      circos.segments(h$mid, 0, h$mid, 1.05, col = "#e67e22", lwd = 1.4)
      circos.points(h$mid, rep(1.05, nrow(h)), pch = 18, col = "#e67e22", cex = 0.6)
      circos.text(h$mid, 1.12, h$gid, col = "#b9690f", cex = 0.32,
                  facing = "clockwise", niceFacing = TRUE)
    }
  })

# ---- GC skew (innermost) ----
circos.track(ylim = c(-1, 1), track.height = 0.11, bg.border = NA,
  panel.fun = function(x, y) {
    d <- skew_dat[[CELL_META$sector.index]]; hw <- bin / 2
    circos.rect(d$x - hw, 0, d$x + hw, pmax(d$skew, 0), col = "#27ae60", border = NA)
    circos.rect(d$x - hw, pmin(d$skew, 0), d$x + hw, 0, col = "#8e44ad", border = NA)
    circos.segments(CELL_META$xlim[1], 0, CELL_META$xlim[2], 0,
                    col = "grey55", lwd = 0.4)
  })

circos.clear()

ttl <- if (!is.null(opt$title)) opt$title else
  paste0("Genome-wide methylation & feature distribution",
         if (length(motifs)) "  (+ motif rings)" else "")
title(main = ttl, cex.main = 1.05, line = 0)

leg_items <- c("genes + strand", "genes - strand",
               "methylation density", "LOESS", "highly methylated gene",
               "GC skew G>C", "GC skew C>G", "oriC", "ter")
leg_cols  <- c("#d62728", "#1f77b4", "#f5b7b1", "#7b241c", "#e67e22",
               "#27ae60", "#8e44ad", "#1e8449", "#c0392b")
leg_pch   <- c(15, 15, 15, NA, 18, 15, 15, NA, NA)
leg_lty   <- c(NA, NA, NA, 1, NA, NA, NA, 1, 1)
if (length(motifs)) {
  leg_items <- c(leg_items, paste("motif", motifs))
  mc2 <- motif_pal[(seq_along(motifs) - 1) %% length(motif_pal) + 1]
  leg_cols <- c(leg_cols, mc2)
  leg_pch <- c(leg_pch, rep(15, length(motifs)))
  leg_lty <- c(leg_lty, rep(NA, length(motifs)))
}
if (any(vapply(orit, function(o) isTRUE(o$weak), logical(1)))) {
  leg_items <- c(leg_items, "ori/ter marked '?' = weak GC skew")
  leg_cols <- c(leg_cols, "#7f8c8d"); leg_pch <- c(leg_pch, NA)
  leg_lty <- c(leg_lty, 1)
}
par(xpd = NA)
legend("bottomleft", legend = leg_items, col = leg_cols, pch = leg_pch,
       lty = leg_lty, bty = "n", cex = 0.62, pt.cex = 1.1,
       inset = c(0, 0), ncol = 1, seg.len = 1.4, text.col = "grey15")

invisible(dev.off())
message("Done: ", opt$out)
