# Roadmap

The 2.0 roadmap is implemented in 2.0.1 and 2.1.0 — see `CHANGELOG.md` for what
each item became and what it is measured against. This file records **what is
done**, in one line each, and **what is still missing**, in detail.

---

## Done in 2.0.1

| # | Item | Landed as |
|---|---|---|
| 1.1 | Biological replication | beta-binomial / quasi-Poisson LRT with shrunken dispersion (`merlin/replicates.py`); null false-positive rate 60 % → 9.6 % |
| 1.2 | Confounder control | covariate block + partial correlation (`merlin/covariates.py`); circular-shift and block-bootstrap nulls (`merlin/stats.py`) |
| 1.3 | Regulatory geometry | `--regions upstream:-300..50 body`, `--operons`, intergenic features (`merlin/regions.py`) |
| 2.1 | One result object | `merlin harmonise` → HDF5 store with `/features`, `/bins`, feature→bin map, provenance |
| 2.2 | Integrated evidence score | `merlin evidence` — Stouffer + robust rank aggregation, BH over genes |
| 2.3 | One report | `merlin report` — self-contained HTML |
| 3.1 | Read-level methylation | `merlin phase` — hemimethylation, bistability, cis co-methylation from modBAM |
| 3.2 | MTase attribution | `merlin mtase` — annotation + canonical table + knockout, with stated confidence |
| 3.3 | De novo motif discovery | `merlin discover` — recovers GATC, GANTC and CCWGG with correct offsets |
| 3.4 | Differential 3D organisation | `merlin hicam --hic2` — boundary changes, compartment flips, Le *et al.* expression test |
| 5 | Raw BAM input | `merlin pileup` — modkit when present, an internal pysam pileup when not; unaligned BAMs aligned with minimap2; `merlin run` inserts the step from `modbam:` (2.1.0) |
| 4 | Streaming, workflow export, provenance, CI, container, `doctor` | chunked parsing; `merlin export --workflow nextflow\|snakemake\|json`; `<prefix>.provenance.txt`; GitHub Actions incl. an R job; Dockerfile; `merlin doctor`; 6 positive-control tests |

---

## What is still missing

Ordered by what it unlocks.

### 1. Replication for expression, on the same samples

`diem` consumes a finished DESeq2 table, which is the right boundary — but it
means MErlin never sees the count matrix and cannot model methylation and
expression on the same samples with a shared dispersion. A *joint* test needs
both.

**What to build.** An optional `--counts` path that either runs the DE model
inside MErlin (negative binomial GLM with shrunken dispersion, the pieces are
already in `replicates.py`) or calls DESeq2 through `rpy2`. Then a per-gene
joint model — expression counts and methylated/total reads in one likelihood —
which is the only way to ask whether a gene's methylation change *and* its
expression change are more concordant than chance across replicates, rather than
correlating two independently-fitted point estimates.

### 2. Multi-factor and paired designs

`Design` is two groups. Real experiments have time courses, strain × treatment
factorials, and paired samples. The beta-binomial machinery generalises to a
design matrix — the LRT already compares nested models — but the CLI, the
`Design` object and the effect reporting all assume a single contrast.

**What to build.** `--design 'condition + batch'` with a formula parser,
model-matrix construction, and an LRT of a named coefficient. Batch is the
common case and is currently unmodellable, which means a batch-confounded
experiment silently reports batch as biology.

### 3. Interval-level differential methylation

`dixam` tests annotated features. Regulatory methylation happens in windows that
do not respect the annotation — `--regions` helps, but only where a feature
already exists. Sliding-window testing with merging of adjacent significant
windows would find changes in unannotated space.

This is close to DMR calling, which the roadmap argued against reimplementing.
The distinction worth keeping: sliding windows *scored against MErlin's other
layers* is integration; region-finding for its own sake is what DSS does better.
Consuming a DMR caller's BED as an input layer is the cheaper half of this.

### 4. Duplex and phased read-level analysis, and a pileup that models them

`merlin phase` measures hemimethylation as *population* strand asymmetry,
because a short read covers one strand. Duplex reads (dorado duplex, or paired
strands of the same molecule) make per-molecule hemimethylation directly
observable — the difference between "half the cells have this GATC methylated on
one strand" and "every cell has it hemimethylated".

**What to build.** Duplex tag handling (`dx:i:1`), pairing of the two strands of
one molecule, and a per-molecule hemimethylation state. Also read-level phasing
against variants, for mixed populations.

`merlin pileup` warns when it sees `dx` tags but treats duplex reads like any
other, and its internal backend models neither deletions nor reference
mismatches (`N_delete`, `N_diff` and `N_nocall` are written as 0). Both are
reasons to prefer modkit where it exists, and both are worth closing if the
internal backend is ever to be more than a fallback.

### 5. A real reference dataset

Every validation here is on synthetic data with known ground truth, which proves
the code recovers what was planted and nothing about real basecalling noise,
real coverage bias or real annotation quality.

**What to build.** A small public dataset — *E. coli* K-12 (Dam, Dcm, EcoKI) or
*Caulobacter* (CcrM) with ONT modification calls — pinned by accession, with the
expected motifs, enrichments and oriC/ter positions as assertions. Run it in CI
weekly rather than per-commit.

### 6. Interactive outputs

`merlin report` renders static figures. For a genome browser view — tracks that
can be panned, a contact map that can be zoomed, a gene table that can be
filtered — the natural target is a self-contained HTML with an embedded
visualisation library, or emitting bigWig/BED for IGV and JBrowse.

`merlin export --workflow igv` writing a session file with every track MErlin
produced is the cheap version and probably the useful one.

### 7. Performance ceilings not yet hit

- `mematch`'s per-call table is O(calls) rows; already skippable and gzippable,
  but a columnar format would be better for a 10⁸-call bedMethyl.
- `hicam` builds dense per-replicon matrices. Fine for bacteria (10³ bins);
  a sparse path would be needed for anything eukaryotic.
- The store holds everything in memory when read. Chunked reads matter above
  ~10⁶ features, which no prokaryotic genome reaches.

None of these bind on a bacterial genome. They are listed so the next person
knows where the edges are.

---

## Still deliberately not built

- **A general DMR caller.** DSS, methylKit and `modkit dmr` do coverage-aware
  region finding well. MErlin should consume their output as a layer.
- **Loop calling.** Bacterial contact maps have CIDs and a replichore-alignment
  signal, not CTCF loops. A loop caller here would produce confident-looking
  artefacts.
- **A causal claim.** More layers narrow a hypothesis; a knockout, a point
  mutation of the methylation site, or an MTase complementation tests it.
  Keeping that line visible in the output is a feature, not a disclaimer.
