# MErlin

**M**ethylation-driven **E**xpression & **R**egulation **L**inkage in **I**nteracting **N**uclear-domains

A modular multi-omics toolkit for prokaryotic genomes. It crosses DNA
methylation basecalling with genome annotation, differential expression, DNA
motifs, replication geometry, 3D genome organisation and single reads.

**Modularity is the design constraint, not a feature.** Every module needs only
the layers it uses. A methylation-only project runs the same code path as a
methylation + expression + Hi-C one; the difference is which modules run.
`merlin run --config` executes the subset your inputs support and tells you what
it skipped and why.

---

## Install

```bash
pip install -e ".[all]"        # everything
pip install -e .               # core only: numpy, pandas, scipy, matplotlib
merlin doctor                  # what this machine can and cannot run
```

Optional extras: `scikit-learn`/`statsmodels`/`seaborn` (diem), `h5py` (the
store, and `.cool` without cooler), `pysam` (read-level and `pileup`), `pyyaml`
(YAML configs), R + `optparse`/`data.table`/`circlize`/`Biostrings`
(roundtable.R). External binaries, all optional:
[`modkit`](https://github.com/nanoporetech/modkit) for the reference modBAM
pileup, `minimap2` + `samtools` to align an unaligned modBAM. A `Dockerfile`
with all of it, R included, is in the repository.

## Modules

```
analysis
  pileup     basecalled modBAM (MM/ML tags)            -> bedMethyl (via modkit)
  xam        methylation GFF3/bedMethyl + annotation   -> methylation per feature
  dixam      replicates x 2 conditions + annotation    -> differential methylation
  spacem     + FASTA                                   -> oriC/ter spatial distribution
  mematch    + motifs                                  -> motif/methylation association
  diem       DESeq2 table + xam [+ dixam]              -> expression x methylation
  hicam      Hi-C contacts [+ any other layer]         -> 3D organisation x omics
  phase      aligned modBAM (MM/ML tags)               -> hemimethylation, bistability
  discover   methylation + FASTA                       -> motifs, de novo
  mtase      motifs + annotation [+ knockout]          -> which enzyme does it
  roundtable methylation + annotation + FASTA          -> circos genome figure

integration
  harmonise  every module's output                     -> one HDF5 store
  evidence   the store                                 -> genes ranked across layers
  report     a results directory                       -> one self-contained HTML

orchestration
  preflight  any inputs        -> do they actually join?
  doctor     this machine      -> can it run every module?
  run        a config          -> everything the inputs support
  export     a config          -> Nextflow / Snakemake / JSON
```

Every module is also a standalone script under `scripts/`, so existing command
lines keep working:

```bash
merlin xam -g ann.gff3 -m calls.gff3 -o results/                # umbrella CLI
python3 scripts/xam.py -g ann.gff3 -m calls.gff3 -o results/    # standalone
```

---

## Starting from a BAM

Raw basecalling output is a valid starting point — there is no need to produce a
bedMethyl first:

```bash
merlin pileup --modbam calls.bam --fasta ref.fasta -o results/pileup
```

`modkit pileup` runs when modkit is on PATH; otherwise MErlin's own pysam pileup
produces the same 18-column bedMethyl, so a missing modkit degrades the run
rather than ending it. Which backend ran is printed, recorded in the provenance
sidecar and written into `<prefix>.pileup_summary.tsv`.

An unaligned modBAM (dorado's uBAM) is aligned first with
`samtools fastq -T MM,ML | minimap2 -y`, which is the recipe that keeps the
modification tags attached — `--align never` refuses instead, which is what you
want if you believe the BAM is already aligned.

In a config, `modbam:` takes the same shape as `methylation:`, and when no
`methylation:` is given `merlin run` inserts one pileup per condition and points
every downstream module at what it produced:

```yaml
modbam:
  WT:     [wt_rep1.bam, wt_rep2.bam, wt_rep3.bam]
  dam_kd: [ko_rep1.bam, ko_rep2.bam, ko_rep3.bam]
options:
  pileup: {backend: auto, threads: 8, filter-threshold: 0.7}
```

The threshold that turns an ML probability into a methylation call is the single
most consequential parameter in the whole analysis. Keeping the pileup inside
MErlin is what puts it in the provenance record instead of in someone's shell
history.

---

## Start here: preflight

Every MErlin join is keyed on a seqid or a locus_tag, and **both fail silently**.
A namespace mismatch does not raise — it returns zero overlaps, which in the
output is indistinguishable from a genome with no methylation. Run this first:

```bash
merlin preflight --gff ann.gff3 --fasta ref.fasta \
    --methylation WT.bed KD.bed --motifs motifs.txt --geneexp deseq2.csv
```

Exit `0` clean, `1` warnings, `2` blocking. It reports the detected formats,
whether methylation carries fraction-modified values, whether the seqid
namespaces reconcile (and how), how many expression identifiers survive the
join, and whether the GC skew is strong enough for oriC/ter to mean anything.

---

## Run everything your inputs support

```yaml
# merlin.yaml
outdir: results
prefix: SmBL225C

annotation: SmBL225C.gff3
reference:  SmBL225C_reference.fasta

methylation:                       # a list under one label = biological replicates
  WT:       [WT_1.bed.gz, WT_2.bed.gz, WT_3.bed.gz]
  secDF_kd: [KD_1.bed.gz, KD_2.bed.gz, KD_3.bed.gz]

motifs:     motifs.txt             # omit it and 'discover' finds them instead
expression: DESeq2_results.csv
hic:        contacts.mcool
modbam:     calls.bam              # -> merlin phase; and -> pileup if no 'methylation:' 
resolution: 5000
min_frac:   0.5

options:
  dixam: {min-effect: 0.1, regions: [upstream:-300..50, body]}
  diem:  {gff: SmBL225C.gff3, fasta: SmBL225C_reference.fasta}
```

```bash
merlin run --config merlin.yaml --dry-run     # see the plan
merlin run --config merlin.yaml               # ... then run it
merlin export --config merlin.yaml --workflow nextflow > main.nf   # or a cluster
```

Delete `hic:` and hicam is skipped with a stated reason. Delete a condition and
dixam and the DM half of diem are skipped. Nothing needs commenting out.

The run ends with `harmonise` → `evidence` → `report`, so a complete run leaves
one store, one ranked gene table and one HTML file alongside the per-module
outputs.

---

## Module reference

### pileup — basecalled modBAM to bedMethyl

```bash
merlin pileup --modbam calls.bam --fasta ref.fasta -o results/pileup \
    --backend auto --threads 8 --min-mapq 20 --filter-threshold 0.7
```

Writes `<prefix>.bedmethyl.bed` (modkit column order) plus
`<prefix>.pileup_summary.tsv` with per-code site counts, mean coverage and mean
percent modified. Several `--modbam` files are piled up separately, one
bedMethyl each.

| Backend | When | Notes |
|---|---|---|
| `modkit` | modkit on PATH | the reference implementation; `--cpg`, `--motif`, `--combine-strands` and `--modkit-arg` are passed through |
| `internal` | modkit absent, or `--backend internal` | pysam argmax over the modification and canonical probabilities; `N_delete`, `N_diff` and `N_nocall` are written as 0 and duplex tags are not modelled |

### xam — methylation per annotated feature

```bash
merlin xam -g ann.gff3 --methylation calls.bed.gz -o results/ \
    --prefix WT --include-zero --min-frac 0.7 \
    --regions upstream:-300..50 body --operons
```

Per feature × modification: `raw_count`, `norm_count` (calls/bp), `calls_per_kb`,
`cpm` and `mean_frac_modified`. Several files are treated as samples: one table
each plus a pooled one.

Use `--include-zero` when the output feeds `diem`; without it, features with no
methylation are absent and every downstream statistic is conditioned on a gene
being methylated.

`--regions` scores strand-aware windows instead of whole features — which is how
you see Dam-in-a-promoter regulation at all, since a whole-CDS average dilutes a
200 bp effect to nothing. `--operons` adds the transcription unit, so a promoter
is scored once per operon rather than once per co-transcribed gene.

### dixam — differential methylation

```bash
merlin dixam -g ann.gff3 \
    --methylation  WT_1.bed.gz WT_2.bed.gz WT_3.bed.gz \
    --methylation2 KD_1.bed.gz KD_2.bed.gz KD_3.bed.gz \
    --labels WT secDF_kd -o results/ --min-effect 0.1
```

The model follows the input:

| design | model | what it supports |
|---|---|---|
| ≥2 replicates, coverage + fraction | beta-binomial LRT with shrunken dispersion | differential methylation |
| ≥2 replicates, presence-only | quasi-Poisson LRT on call counts | differential call distribution |
| 1 per condition | single-sample contingency test | a candidate screen, and it says so |

On simulated null data (no true difference, only replicate scatter), the
single-sample test rejects 60 % of features at p < 0.05; the replicate model
rejects 9.6 %, against a nominal 5 %. **Three or more replicates per condition is
what makes a q-value here mean anything.**

Watch the genome-wide level row: when most features come out significant, that
is a global shift, and `--min-effect` is how you require more than it.

### spacem — replication geometry

```bash
merlin spacem -g ann.gff3 --fasta ref.fasta --methylation calls.bed.gz \
    --motifs motifs.txt -o results/ --plots
```

oriC/ter from cumulative GC skew, an ori→ter coordinate for every position, gene
co-orientation with a Wilson interval, and spatial uniformity reported with its
**KS D statistic** — with 10⁵ calls the p-value is ~0 for any deviation, so D is
the number that carries the information. Replicons with a flat skew are flagged;
their ori→ter statistics rest on a noise-driven origin.

### mematch — motif association

```bash
merlin mematch -g ann.gff3 --fasta ref.fasta --methylation calls.bed.gz \
    --motifs motifs.txt -o results/ --plots --fisher
```

Motif file: one IUPAC motif per line, optional second column giving the 0-based
offset of the modified base (`GATC<TAB>1` for Dam).

The site-level test has two regimes and reports which one ran. With
fraction-modified values: methylated versus unmethylated among on- and off-motif
assayed positions. With presence-only input there is no unmethylated class, so
the contrast is against a genomic background — called versus not-called among
the candidate bases of the modification.

### discover — motifs from the data

```bash
merlin discover --fasta ref.fasta --methylation calls.bed.gz -o results/ --plots
merlin mematch --motifs results/discover.motifs.txt ...
```

Flanks of methylated positions against a background of the same canonical base
assayed but not methylated; k-mer seeds, then greedy relaxation. On a synthetic
genome carrying three systems it returns `GATC/1`, `GANTC/1` and `CCWGG/1` — the
planted answers — from both bedMethyl and presence-only input.

A discovered motif is a hypothesis until something independent agrees.

### mtase — which enzyme does it

```bash
merlin mtase -g ann.gff3 --fasta ref.fasta --motifs motifs.txt \
    --methylation WT.bed --methylation2 dam_KO.bed --knockout-gene dam -o results/
```

Annotation scan + a canonical-systems table + the knockout effect, with the
confidence stated: `weak (canonical motif table only)` is annotation transfer,
`strong (knockout + annotation)` is evidence from this genome.

### diem — expression × methylation

```bash
merlin diem --geneexp DESeq2_results.csv \
    --methylation results/WT.by_feature.tsv --dm-table results/differential.tsv \
    --gff ann.gff3 --fasta ref.fasta --outdir results/
```

Without `--dm-table`, "DM" means *highly* methylated in one condition (the column
is named `is_HM`). With it, DM means differentially methylated, and Δmethylation
is correlated against Δexpression.

With `--gff`/`--fasta`, the marginal and **covariate-adjusted** associations are
reported side by side — gene length, GC, gene density, replication position and
expression level held fixed — and the run warns when adjustment removes more than
half the marginal strength. That disagreement is the finding.

Reads DESeq2, edgeR and limma tables. Joins on locus_tag, keeping genes with no
methylation by default.

### hicam — 3D organisation

```bash
merlin hicam --hic WT.mcool --hic2 mutant.mcool --labels WT mutant \
    --resolution 5000 -g ann.gff3 --fasta ref.fasta \
    --methylation calls.bed.gz --geneexp DESeq2_results.csv -o results/ --plots
```

Reads `.cool`/`.mcool` (cooler if installed, else natively via h5py), HiC-Pro
`.matrix` + `_abs.bed`, or a dense matrix with a bins BED.

Hi-C alone: distance decay P(s), iterative correction, observed/expected with
**circular** separations, a compartment eigenvector sign-anchored to GC content,
insulation, domain boundaries, saddle strength. Each further layer adds
questions: methylation and expression per bin, DE/DM enrichment at boundaries,
and **distance-controlled contact/co-methylation** — whether bins that touch in
3D carry similar methylation once separation is held fixed. With `--hic2`:
boundary changes, compartment flips and Δinsulation correlated against the other
layers.

Bin correlations carry a block-bootstrap interval and a circular-shift p-value,
because neighbouring bins are not independent.

### phase — read-level

```bash
merlin phase --modbam calls.bam -g ann.gff3 --fasta ref.fasta \
    --motifs motifs.txt -o results/ --plots
```

What a per-position bedMethyl cannot answer: is this GATC methylated on one
strand only; is this locus methylated in *some cells* rather than half-methylated
in all of them; do nearby sites on the same molecule agree. Needs an aligned BAM
with `MM`/`ML` tags — what dorado and modkit already produce on the way to a
bedMethyl.

### harmonise / evidence / report

```bash
merlin harmonise --results results/ --gff ann.gff3 -o results/ --prefix run1
merlin evidence  --store results/run1.merlin_store.h5 -o results/ --plots
merlin report    --results results/ -o results/
```

One HDF5 store with `/features`, `/bins`, the feature→bin map and provenance;
one gene table combining every layer (Stouffer on signed z-scores, plus robust
rank aggregation, BH over genes, with `n_layers` and `direction_concordance` so
one strong signal is distinguishable from four weak ones); one self-contained
HTML report with the warnings at the top.

### roundtable.R — circos figure

```bash
Rscript scripts/roundtable.R --gff ann.gff3 --fasta ref.fasta \
    --methylation calls.bed.gz --motifs motifs.txt --out circos.pdf
```

Dependencies are checked, not silently installed; `--install-deps` opts in.
Accepts bedMethyl, 6-column BED and GFF3 methylation.

---

## Sequence identifiers

Resolution order, applied once in `merlin.seqids` for every module:

1. explicit `--seqid-map` (two-column TSV);
2. identity, when the namespaces already intersect;
3. version-suffix stripping (`NZ_CP012345.1` vs `NZ_CP012345`) — the common
   Prokka/GbkToGff case, applied automatically with a loud notice;
4. accession containment (`gi|123|ref|NZ_X.1|` → `NZ_X.1`);
5. rank-order pairing — **only** with `--allow-rank-map`, because guessing that
   the n-th name in one file means the n-th in another produces plausible, wrong
   results silently.

When a layer that was supplied cannot be reconciled, the run aborts with an
explanation rather than producing a table of zeros.

## Warnings and provenance

Every module writes `<prefix>.warnings.txt` (presence-only input, unstranded
calls, weak GC skew, orphan replicons, degenerate tests, global methylation
shifts, spatial autocorrelation, covariate attenuation …) and
`<prefix>.provenance.txt` (version, inputs with SHA-256 digests, thresholds,
resolved seqid mapping). `--provenance` also prefixes each table with the same
block; it is off by default because `#` headers break readers that do not skip
them.

Read the warnings before the numbers.

## Testing

```bash
python3 tools/make_testdata.py --outdir testdata --replicates 3
python3 -m pytest tests/ -v
```

92 tests. The synthetic data deliberately includes the failure modes — an
annotation that dropped the version suffix its FASTA carries, a plasmid with no
usable GC skew, a bedMethyl containing unmethylated assayed positions — and
plants signal with known ground truth: three methylation systems (Dam/GATC,
CcrM/GANTC, Dcm/CCWGG), hypomethylated-and-downregulated genes, Hi-C domains at
known boundaries, bistable loci and a hemimethylated region in the modBAM.

`tests/test_positive_control.py` asserts that the biology comes back out. A
refactor that quietly stops finding GATC passes every other test in the suite.

## Documents

- `CHANGELOG.md` — 2.0.1 (the roadmap, implemented) and 2.0 (changes from the
  original scripts), with the measurements behind each claim
- `ROADMAP.md` — what is done, and what is still missing
