#!/usr/bin/env python3
"""Generate a small synthetic prokaryotic dataset covering every MErlin input.

Produces a two-replicon genome with a real GC-skew signature (so oriC/ter are
detectable), a Prokka-style annotation, methylation in two conditions in both
GFF3 (presence-only) and bedMethyl (with coverage and fraction) flavours, a
motif list, a DESeq2-style expression table, and Hi-C contacts as both a .cool
file and a dense matrix.

Deliberately included so the tools are exercised on realistic failure modes:
  * the annotation drops the '.1' version suffix that the FASTA and methylation
    carry (the Prokka/GbkToGff case);
  * the plasmid has no usable GC skew;
  * the bedMethyl contains unmethylated assayed positions;
  * methylation is enriched on GATC and depleted in a set of genes that are also
    differentially expressed, so the integration steps have signal to find.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import numpy as np

BASES = np.array(list("ACGT"))


def make_sequence(length: int, rng, skewed: bool) -> str:
    if not skewed:
        probs = np.tile(np.array([0.25, 0.25, 0.25, 0.25]), (length, 1))
    else:
        half = length // 2
        lead = np.array([0.24, 0.20, 0.30, 0.26])     # G > C
        lag = np.array([0.24, 0.30, 0.20, 0.26])      # C > G
        probs = np.vstack([np.tile(lead, (half, 1)),
                           np.tile(lag, (length - half, 1))])
    cum = np.cumsum(probs, axis=1)
    u = rng.random(length)[:, None]
    idx = (u > cum).sum(axis=1)
    return "".join(BASES[np.clip(idx, 0, 3)])


def implant(seq: str, motif: str, n: int, rng) -> str:
    arr = np.frombuffer(seq.encode(), dtype="S1").astype("U1").copy()
    L = len(motif)
    for pos in rng.choice(len(seq) - L, size=n, replace=False):
        arr[pos:pos + L] = list(motif)
    return "".join(arr)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--outdir", default="testdata")
    ap.add_argument("--chrom-length", type=int, default=300_000)
    ap.add_argument("--plasmid-length", type=int, default=60_000)
    ap.add_argument("--n-genes", type=int, default=320)
    ap.add_argument("--replicates", type=int, default=3,
                    help="Biological replicates per condition (bedMethyl only).")
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    # ---- genome ---------------------------------------------------------
    reps = {
        "NZ_TEST001.1": dict(length=args.chrom_length, skewed=True,
                             desc="Synthetica testensis strain T1 chromosome, "
                                  "complete sequence"),
        "NZ_TEST002.1": dict(length=args.plasmid_length, skewed=False,
                             desc="Synthetica testensis strain T1 plasmid pSYN1, "
                                  "complete sequence"),
    }
    genome = {}
    for sid, meta in reps.items():
        seq = make_sequence(meta["length"], rng, meta["skewed"])
        seq = implant(seq, "GATC", meta["length"] // 900, rng)
        seq = implant(seq, "GAGTC", meta["length"] // 2500, rng)   # GANTC / CcrM
        seq = implant(seq, "CCAGG", meta["length"] // 3000, rng)   # CCWGG / Dcm
        genome[sid] = seq

    with open(out / "reference.fasta", "w") as fh:
        for sid, meta in reps.items():
            fh.write(f">{sid} {meta['desc']}\n")
            s = genome[sid]
            for i in range(0, len(s), 70):
                fh.write(s[i:i + 70] + "\n")

    # ---- annotation (note: no version suffix, on purpose) ---------------
    genes = []
    gi = 0
    for sid, meta in reps.items():
        L = meta["length"]
        n = args.n_genes if meta["skewed"] else max(20, args.n_genes // 8)
        pos = np.sort(rng.choice(L - 1200, size=n, replace=False))
        pos = pos[np.r_[True, np.diff(pos) > 1100]]
        for start in pos:
            gi += 1
            length = int(rng.integers(300, 1100))
            strand = "+" if rng.random() < (0.75 if meta["skewed"] and
                                            start < L / 2 else 0.35) else "-"
            genes.append(dict(seqid=sid.split(".")[0], full=sid, start=int(start),
                              end=int(start + length), strand=strand,
                              locus_tag=f"SYNT_{gi:05d}",
                              gene=f"gen{gi % 40}" if gi % 5 == 0 else "",
                              product="hypothetical protein" if gi % 3 else
                                      "DNA adenine methyltransferase Dam"))
    with open(out / "annotation.gff3", "w") as fh:
        fh.write("##gff-version 3\n")
        for sid, meta in reps.items():
            fh.write(f"##sequence-region {sid.split('.')[0]} 1 {meta['length']}\n")
        for g in genes:
            attrs = (f"ID={g['locus_tag']};locus_tag={g['locus_tag']};"
                     f"product={g['product'].replace(',', '%2C')}")
            if g["gene"]:
                attrs += f";gene={g['gene']}"
            fh.write("\t".join([g["seqid"], "Prodigal:2.6", "CDS",
                                str(g["start"] + 1), str(g["end"]), ".",
                                g["strand"], "0", attrs]) + "\n")
            fh.write("\t".join([g["seqid"], "Prodigal:2.6", "gene",
                                str(g["start"] + 1), str(g["end"]), ".",
                                g["strand"], ".",
                                f"ID={g['locus_tag']}_gene;locus_tag={g['locus_tag']}"])
                     + "\n")

    # ---- methylation ----------------------------------------------------
    import re
    hypo = {g["locus_tag"] for g in genes[:60]}          # will also be DE

    def sites_for(seq, sid):
        """Three real prokaryotic systems: Dam (GATC), CcrM (GANTC), Dcm (CCWGG).

        Each modification sits on its correct canonical base, so 'merlin
        discover' has to recover two distinct 6mA motifs from one genome — the
        case the seeding step exists for — plus a 5mC motif on an actual C.
        """
        rows = []
        for m in re.finditer("(?=(GATC))", seq):
            p = m.start()
            rows.append((sid, p + 1, "a", "+"))          # A of GATC, offset 1
            rows.append((sid, p + 2, "a", "-"))          # A on the other strand
        for m in re.finditer("(?=(GA[ACGT]TC))", seq):
            rows.append((sid, m.start() + 1, "a", "+"))  # A of GANTC, offset 1
        for m in re.finditer("(?=(CC[AT]GG))", seq):
            rows.append((sid, m.start() + 1, "m", "+"))  # inner C of CCWGG
        return rows

    all_sites = {sid: sites_for(genome[sid], sid) for sid in genome}

    def in_hypo(sid, pos):
        for g in genes:
            if g["full"] == sid and g["start"] <= pos < g["end"]:
                return g["locus_tag"] in hypo
        return False

    # Replicates share the condition's true level and differ by a per-feature
    # random effect, so the dispersion the beta-binomial estimates is real.
    site_index = {sid: [(pos, code, strand) for (_s, pos, code, strand) in rows]
                  for sid, rows in all_sites.items()}
    hypo_flag = {sid: np.array([in_hypo(sid, pos) for pos, _c, _st in rows])
                 for sid, rows in site_index.items()}

    for cond, base_rate, hypo_rate in (("F5", 0.90, 0.88), ("F9", 0.88, 0.35)):
        for rep in range(1, max(1, args.replicates) + 1):
            gff_lines, bed_lines = [], []
            rep_shift = float(rng.normal(0, 0.02))          # replicate batch effect
            for sid, rows in site_index.items():
                flags = hypo_flag[sid]
                for k, (pos, code, strand) in enumerate(rows):
                    rate = (hypo_rate if flags[k] else base_rate) + rep_shift
                    rate = float(np.clip(rate, 0.01, 0.99))
                    frac = float(np.clip(rng.normal(rate, 0.10), 0.0, 1.0))
                    cov = int(rng.integers(25, 80))
                    if rng.random() < rate:
                        gff_lines.append("\t".join([
                            sid, "dorado", code, str(pos + 1), str(pos + 1), ".",
                            strand, ".", f"ID=mod{len(gff_lines)};coverage={cov}"]))
                    bed_lines.append("\t".join([
                        sid, str(pos), str(pos + 1), code, str(min(1000, cov * 10)),
                        strand, str(pos), str(pos + 1), "255,0,0", str(cov),
                        f"{100 * frac:.2f}", str(int(round(cov * frac))),
                        str(cov - int(round(cov * frac))), "0", "0", "0", "0"]))
            suffix = "" if rep == 1 else f"_rep{rep}"
            if rep == 1:
                (out / f"{cond}.methylation.gff3").write_text(
                    "##gff-version 3\n" + "\n".join(gff_lines) + "\n")
                with gzip.open(out / f"{cond}.bedmethyl.bed.gz", "wt") as fh:
                    fh.write("\n".join(bed_lines) + "\n")
            with gzip.open(out / f"{cond}_rep{rep}.bedmethyl.bed.gz", "wt") as fh:
                fh.write("\n".join(bed_lines) + "\n")

    (out / "motifs.txt").write_text(
        "# motif<TAB>0-based offset of the modified base\n"
        "GATC\t1\nGANTC\t1\nCCWGG\t1\n")

    # ---- expression ------------------------------------------------------
    rows = ["deg,baseMean,log2FoldChange,lfcSE,stat,pvalue,padj"]
    for g in genes:
        de = g["locus_tag"] in hypo
        lfc = float(rng.normal(-2.2 if de else 0.0, 0.6 if de else 0.8))
        padj = float(rng.beta(0.4, 30) if de else rng.uniform(0.05, 1.0))
        base = float(rng.lognormal(5, 1.2))
        rows.append(f"{g['locus_tag']},{base:.3f},{lfc:.4f},0.3,"
                    f"{lfc / 0.3:.3f},{padj / 3:.5g},{padj:.5g}")
    (out / "deseq2_results.csv").write_text("\n".join(rows) + "\n")

    # ---- Hi-C ------------------------------------------------------------
    res = 5000
    write_hic(out, genome, res, rng)

    # ---- modBAM (read-level) ---------------------------------------------
    write_modbam(out, genome, genes, hypo, rng, args)

    print(f"Synthetic dataset written to {out}/")
    for p in sorted(out.iterdir()):
        print(f"  {p.name:<32} {p.stat().st_size / 1024:8.1f} kB")
    return 0


def write_hic(out: Path, genome: dict[str, str], res: int, rng) -> None:
    """A .cool file (native HDF5 layout) plus a dense matrix and bins BED."""
    chrom_names = list(genome)
    chrom_len = [len(genome[c]) for c in chrom_names]
    bin_chrom, bin_start, bin_end = [], [], []
    per_chrom = {}
    for ci, c in enumerate(chrom_names):
        n = int(np.ceil(len(genome[c]) / res))
        per_chrom[c] = n
        for b in range(n):
            bin_chrom.append(ci)
            bin_start.append(b * res)
            bin_end.append(min((b + 1) * res, len(genome[c])))
    bin_chrom = np.array(bin_chrom, dtype=np.int32)
    bin_start = np.array(bin_start, dtype=np.int32)
    bin_end = np.array(bin_end, dtype=np.int32)

    b1_all, b2_all, cnt_all = [], [], []
    offset = 0
    dense_blocks = {}
    for ci, c in enumerate(chrom_names):
        n = per_chrom[c]
        ii = np.arange(n)
        d = np.abs(ii[:, None] - ii[None, :])
        d = np.minimum(d, n - d)                      # circular
        with np.errstate(divide="ignore"):
            base = 20000.0 / np.power(np.maximum(d, 1), 1.1)
        np.fill_diagonal(base, base.max())
        # chromosomal interaction domains: block-diagonal boost
        n_dom = max(2, n // 12)
        edges = np.linspace(0, n, n_dom + 1).astype(int)
        for a, b in zip(edges[:-1], edges[1:]):
            base[a:b, a:b] *= 1.9
        m = rng.poisson(np.clip(base, 0, None)).astype(np.float64)
        m = np.triu(m) + np.triu(m, 1).T
        dense_blocks[c] = m
        iu, ju = np.triu_indices(n)
        v = m[iu, ju]
        keep = v > 0
        b1_all.append(iu[keep] + offset)
        b2_all.append(ju[keep] + offset)
        cnt_all.append(v[keep])
        offset += n

    b1 = np.concatenate(b1_all).astype(np.int64)
    b2 = np.concatenate(b2_all).astype(np.int64)
    cnt = np.concatenate(cnt_all).astype(np.int32)
    order = np.lexsort((b2, b1))

    try:
        import h5py
    except ImportError:
        print("  (h5py missing: skipping the .cool file)")
    else:
        with h5py.File(out / "contacts.cool", "w") as f:
            f.attrs["format"] = "HDF5::Cooler"
            f.attrs["bin-size"] = res
            g = f.create_group("chroms")
            g.create_dataset("name", data=np.array(chrom_names, dtype="S32"))
            g.create_dataset("length", data=np.array(chrom_len, dtype=np.int64))
            g = f.create_group("bins")
            g.create_dataset("chrom", data=bin_chrom)
            g.create_dataset("start", data=bin_start)
            g.create_dataset("end", data=bin_end)
            g = f.create_group("pixels")
            g.create_dataset("bin1_id", data=b1[order])
            g.create_dataset("bin2_id", data=b2[order])
            g.create_dataset("count", data=cnt[order])

    big = max(chrom_names, key=lambda c: per_chrom[c])
    np.savetxt(out / "contacts_dense.txt", dense_blocks[big], fmt="%d", delimiter="\t")
    with open(out / "contacts_dense_bins.bed", "w") as fh:
        n = per_chrom[big]
        for b in range(n):
            fh.write(f"{big}\t{b * res}\t{min((b + 1) * res, len(genome[big]))}\n")


def write_modbam(out: Path, genome: dict, genes: list, hypo: set, rng, args,
                 depth: int = 30, read_len: int = 3000) -> None:
    """An aligned modBAM with MM/ML tags, on both strands.

    A subset of genes is made *bistable* — methylated in some molecules and not
    in others — and one region is made hemimethylated, so ``merlin phase`` has
    both phenomena to recover rather than only an average.
    """
    try:
        import pysam
    except ImportError:
        print("  (pysam missing: skipping the modBAM)")
        return

    seqid = max(genome, key=lambda k: len(genome[k]))
    seq = genome[seqid]
    L = min(len(seq), 60_000)                      # keep the test file small
    in_window = [g for g in genes if g["full"] == seqid and g["end"] < L]
    bistable = {g["locus_tag"] for g in in_window[:12]}
    bist_spans = [(g["start"], g["end"]) for g in in_window
                  if g["locus_tag"] in bistable]
    hemi_span = (int(L * 0.30), int(L * 0.35))

    header = {"HD": {"VN": "1.6", "SO": "coordinate"},
              "SQ": [{"SN": s.split(".")[0], "LN": len(v)}
                     for s, v in genome.items()]}
    path = out / "reads.modbam.bam"
    tmp = out / "reads.unsorted.bam"
    n_reads = max(10, int(depth * L / read_len))
    with pysam.AlignmentFile(tmp, "wb", header=header) as bam:
        for i in range(n_reads):
            start = int(rng.integers(0, max(L - read_len, 1)))
            end = min(start + read_len, L)
            ref = seq[start:end]
            # Reads are written as forward alignments and carry BOTH strands via
            # the MM strand character ('A+a' top, 'T-a' bottom). Writing
            # reverse-mapped reads would require the MM deltas to be counted on
            # the pre-alignment orientation, which is a generator detail with no
            # bearing on what merlin phase is being tested for.
            reverse = False
            # molecule-level state for the bistable regions
            molecule_on = rng.random() < 0.5

            a_idx = [j for j, b in enumerate(ref) if b == "A"]
            t_idx = [j for j, b in enumerate(ref) if b == "T"]

            def calls_for(idx_list, plus_strand):
                # GATC is palindromic: the top-strand adenine sits at offset 1 of
                # a GATC, and the bottom-strand adenine is the T at offset 2 of
                # the same GATC. Testing the top-strand context against the
                # bottom-strand base — which an earlier version of this generator
                # did — plants a second, spurious motif that 'discover' then
                # dutifully finds.
                deltas, quals, prev = [], [], -1
                for k, j in enumerate(idx_list):
                    gpos = start + j
                    if plus_strand:
                        ok = (j >= 1 and j + 2 < len(ref) and ref[j - 1] == "G"
                              and ref[j + 1] == "T" and ref[j + 2] == "C")
                    else:
                        ok = (j >= 2 and j + 1 < len(ref) and ref[j - 2] == "G"
                              and ref[j - 1] == "A" and ref[j + 1] == "C")
                    if not ok:
                        continue
                    in_bist = any(s <= gpos < e for s, e in bist_spans)
                    in_hemi = hemi_span[0] <= gpos < hemi_span[1]
                    if in_bist:
                        p = 0.95 if molecule_on else 0.03
                    elif in_hemi and not plus_strand:
                        p = 0.05           # minus strand unmethylated: hemi
                    else:
                        p = 0.93
                    q = int(np.clip(rng.normal(p, 0.05), 0.01, 0.99) * 255)
                    deltas.append(k - prev - 1)
                    quals.append(q)
                    prev = k
                return deltas, quals

            d_plus, q_plus = calls_for(a_idx, True)
            d_minus, q_minus = calls_for(t_idx, False)
            if not d_plus and not d_minus:
                continue

            seg = pysam.AlignedSegment()
            seg.query_name = f"read{i:06d}"
            seg.query_sequence = ref
            seg.flag = 16 if reverse else 0
            seg.reference_id = list(genome).index(seqid)
            seg.reference_start = start
            seg.mapping_quality = 60
            seg.cigar = [(0, len(ref))]
            seg.query_qualities = pysam.qualitystring_to_array("I" * len(ref))
            mm, ml = [], []
            if d_plus:
                mm.append("A+a?," + ",".join(str(d) for d in d_plus) + ";")
                ml += q_plus
            if d_minus:
                mm.append("T-a?," + ",".join(str(d) for d in d_minus) + ";")
                ml += q_minus
            seg.set_tag("MM", "".join(mm), value_type="Z")
            seg.set_tag("ML", ml)
            bam.write(seg)

    pysam.sort("-o", str(path), str(tmp))
    pysam.index(str(path))
    tmp.unlink()


if __name__ == "__main__":
    raise SystemExit(main())
