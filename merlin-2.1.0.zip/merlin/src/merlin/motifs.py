"""IUPAC motif location on both strands of a (circular) replicon.

Differences from the original per-script implementations:

* **Circular genomes are handled.**  Bacterial replicons are circular, but a
  linear regex scan cannot see a motif that spans the origin.  The sequence is
  scanned with an ``L-1`` base overlap and wrapped hits are folded back.
* **Membership is a bitmask, not a set of tuples.**  ``spacem`` built a
  ``set[(seqid, pos)]`` covering every base of every occurrence; for GATC on a
  7 Mb genome that is ~440 000 tuples (~50 MB) where a boolean array is 7 MB and
  is queried by index rather than by hash.
* Results are columnar, so downstream containment tests are vectorised.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np

from .io import IUPAC_TO_REGEX
from .logging_utils import get_logger, warn_once

logger = get_logger("motifs")

IUPAC_COMPLEMENT = {
    "A": "T", "T": "A", "U": "A", "G": "C", "C": "G",
    "R": "Y", "Y": "R", "S": "S", "W": "W", "K": "M", "M": "K",
    "B": "V", "V": "B", "D": "H", "H": "D", "N": "N",
}


def reverse_complement(motif: str) -> str:
    try:
        return "".join(IUPAC_COMPLEMENT[b] for b in reversed(motif.upper()))
    except KeyError as exc:
        raise ValueError(f"Illegal IUPAC base in motif {motif!r}: {exc}") from exc


def motif_to_regex(motif: str) -> re.Pattern:
    """Overlap-aware compiled pattern (lookahead, so 'AA' matches twice in 'AAA')."""
    body = "".join(IUPAC_TO_REGEX[b] for b in motif.upper())
    return re.compile(f"(?=({body}))")


@dataclass(slots=True)
class MotifHits:
    """All occurrences of one motif, columnar. Coordinates 0-based half-open."""

    motif: str
    offset: int | None
    seqid: np.ndarray
    start: np.ndarray
    end: np.ndarray
    strand: np.ndarray
    mod_pos: np.ndarray          # -1 where no offset was supplied

    def __len__(self) -> int:
        return int(self.start.size)

    @property
    def has_offset(self) -> bool:
        return self.offset is not None

    def anchor(self) -> np.ndarray:
        """Position used to place an occurrence inside a feature."""
        return np.where(self.mod_pos >= 0, self.mod_pos, self.start)

    def for_seqid(self, seqid: str) -> np.ndarray:
        return np.flatnonzero(self.seqid == seqid)

    def covered_mask(self, seqid: str, length: int) -> np.ndarray:
        """Boolean array over the replicon: True where any occurrence covers a base."""
        mask = np.zeros(length, dtype=bool)
        sel = self.for_seqid(seqid)
        if sel.size == 0:
            return mask
        L = len(self.motif)
        starts = self.start[sel]
        idx = (starts[:, None] + np.arange(L)[None, :]) % length
        mask[idx.ravel()] = True
        return mask

    def modbase_mask(self, seqid: str, length: int,
                     strand: str | None = None) -> np.ndarray:
        """Boolean array: True at the modified base of an occurrence."""
        mask = np.zeros(length, dtype=bool)
        sel = self.for_seqid(seqid)
        if strand is not None:
            sel = sel[self.strand[sel] == strand]
        mp = self.mod_pos[sel]
        mp = mp[mp >= 0]
        if mp.size:
            mask[mp % length] = True
        return mask


def find_motifs(
    genome: dict[str, str],
    motifs: list[tuple[str, int | None]],
    circular: bool = True,
) -> dict[str, MotifHits]:
    """Locate every motif on both strands of every replicon."""
    out: dict[str, MotifHits] = {}
    for motif, offset in motifs:
        L = len(motif)
        fwd_re = motif_to_regex(motif)
        rc = reverse_complement(motif)
        palindromic = (rc == motif)
        rev_re = fwd_re if palindromic else motif_to_regex(rc)

        seq_l, st_l, en_l, str_l, mp_l = [], [], [], [], []
        for seqid, seq in genome.items():
            n = len(seq)
            if n == 0:
                continue
            scan = seq + seq[:L - 1] if (circular and n > L) else seq
            for pattern, strand in ((fwd_re, "+"), (rev_re, "-")):
                for m in pattern.finditer(scan):
                    s = m.start()
                    if s >= n:
                        continue                     # duplicate of a wrapped hit
                    e = s + L
                    if offset is None:
                        mp = -1
                    elif strand == "+":
                        mp = (s + offset) % n
                    else:
                        mp = (e - 1 - offset) % n
                    seq_l.append(seqid); st_l.append(s); en_l.append(e)
                    str_l.append(strand); mp_l.append(mp)

        hits = MotifHits(
            motif=motif, offset=offset,
            seqid=np.array(seq_l, dtype=object),
            start=np.array(st_l, dtype=np.int64),
            end=np.array(en_l, dtype=np.int64),
            strand=np.array(str_l, dtype=object),
            mod_pos=np.array(mp_l, dtype=np.int64),
        )
        out[motif] = hits
        if len(hits) == 0:
            warn_once(logger, f"MOTIF_ABSENT_{motif}",
                      f"Motif {motif!r} does not occur anywhere in the reference; "
                      f"its enrichment statistics will be empty.")
        elif palindromic:
            logger.info("Motif %s is palindromic: each site is reported once per "
                        "strand (%d occurrences total).", motif, len(hits))
    total = sum(len(h) for h in out.values())
    logger.info("Motif search: %d occurrence(s) across %d motif(s)%s.",
                total, len(out), " (circular-aware)" if circular else "")
    return out


def expected_site_fraction(genome: dict[str, str], motif: str) -> float:
    """Fraction of genomic bases covered by a motif under a 0-order base model.

    Used as the background for presence-only enrichment, where there is no
    "assayed but unmethylated" class to contrast against.
    """
    counts = {b: 0 for b in "ACGT"}
    total = 0
    for seq in genome.values():
        for b in "ACGT":
            counts[b] += seq.count(b)
        total += len(seq)
    if total == 0:
        return 0.0
    freq = {b: counts[b] / total for b in "ACGT"}
    p = 1.0
    for base in motif.upper():
        allowed = IUPAC_TO_REGEX[base]
        letters = allowed.strip("[]") if allowed.startswith("[") else allowed
        p *= sum(freq.get(x, 0.0) for x in letters)
    return min(1.0, 2 * p)   # both strands
