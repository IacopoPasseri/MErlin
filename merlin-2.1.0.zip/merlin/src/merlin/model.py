"""Core data model shared by every MErlin tool.

Two conventions are enforced package-wide, because the original standalone
scripts disagreed about both and the disagreement was invisible in the output:

**Coordinates.**  Everything internal is 0-based half-open ``[start, end)``.
``xam``/``dixam`` already used that; ``mematch``/``spacem`` used 0-based
*inclusive* ends, so per-feature windows differed by one base between tools.
Conversion to 1-based inclusive happens only in writers.

**Methylation.**  One record type covers bedMethyl, 6-column BED and GFF3
modification calls.  ``frac`` is ``NaN`` when the source carries no
fraction-modified column; a set where *every* record has ``NaN`` is flagged
``presence_only``, which downstream statistics must branch on rather than
silently treating "assayed" as "methylated".
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# --------------------------------------------------------------------------- #
# Modification vocabulary
# --------------------------------------------------------------------------- #
MOD_CODE_TO_LABEL: dict[str, str] = {
    "m": "5mC",
    "h": "5hmC",
    "a": "6mA",
    "f": "5fC",
    "c": "5caC",
    "g": "7mG",
    "e": "3mC",
    "b": "5hmU",
    "21839": "4mC",  # ChEBI code emitted by modkit for 4mC
}

MOD_LABEL_TO_DESC: dict[str, str] = {
    "5mC": "5-methylcytosine",
    "m5C": "5-methylcytosine",
    "4mC": "4-methylcytosine",
    "m4C": "4-methylcytosine",
    "5hmC": "5-hydroxymethylcytosine",
    "6mA": "6-methyladenine",
    "m6A": "6-methyladenine",
    "5fC": "5-formylcytosine",
    "5caC": "5-carboxylcytosine",
    "7mG": "N7-methylguanine",
    "3mC": "N3-methylcytosine",
    "5hmU": "5-hydroxymethyluracil",
}

MOD_LABEL_TO_CODE: dict[str, str] = {v: k for k, v in MOD_CODE_TO_LABEL.items()}

METHYL_GFF_TYPE_SYNONYMS: dict[str, str] = {
    "cpg": "m", "5mc": "m", "m5c": "m", "5-mc": "m",
    "methylation": "m", "modified_base": "m", "dcm": "m", "ccwgg": "m",
    "6ma": "a", "m6a": "a", "6-ma": "a", "dam": "a", "gatc": "a",
    "5hmc": "h", "5-hmc": "h",
    "4mc": "21839", "m4c": "21839",
}

GFF_META_TYPES = {"region", "sequence_feature", "sequence_alteration", "biological_region"}


def mod_label(code: str) -> str:
    return MOD_CODE_TO_LABEL.get(code, code)


def mod_description(code: str) -> str:
    return MOD_LABEL_TO_DESC.get(mod_label(code), "unknown modification")


def resolve_mod_code(feat_type: str, attrs: dict[str, str] | None = None) -> str:
    """Normalise a modification identifier from a GFF3 type field or attributes."""
    attrs = attrs or {}
    if feat_type in MOD_CODE_TO_LABEL:
        return feat_type
    if feat_type in MOD_LABEL_TO_CODE:
        return MOD_LABEL_TO_CODE[feat_type]
    lower = feat_type.lower()
    if lower in METHYL_GFF_TYPE_SYNONYMS:
        return METHYL_GFF_TYPE_SYNONYMS[lower]
    for key in ("mod", "modification", "Name", "type", "mod_code"):
        val = attrs.get(key, "")
        if not val:
            continue
        if val in MOD_CODE_TO_LABEL:
            return val
        if val in MOD_LABEL_TO_CODE:
            return MOD_LABEL_TO_CODE[val]
        if val.lower() in METHYL_GFF_TYPE_SYNONYMS:
            return METHYL_GFF_TYPE_SYNONYMS[val.lower()]
    return feat_type


# --------------------------------------------------------------------------- #
# Annotation
# --------------------------------------------------------------------------- #
@dataclass(slots=True)
class Feature:
    """One annotated feature. Coordinates are 0-based half-open."""

    seqid: str
    ftype: str
    start: int
    end: int
    strand: str
    fid: str = ""
    locus_tag: str = ""
    gene: str = ""
    product: str = ""

    @property
    def length(self) -> int:
        return self.end - self.start

    @property
    def mid(self) -> int:
        return (self.start + self.end) // 2

    @property
    def key(self) -> str:
        """Preferred join key: locus_tag if present, else the feature id."""
        return self.locus_tag or self.fid


@dataclass(slots=True)
class Annotation:
    features: list[Feature] = field(default_factory=list)
    seq_regions: dict[str, int] = field(default_factory=dict)
    embedded_fasta: dict[str, str] = field(default_factory=dict)
    n_skipped_type: int = 0
    n_malformed: int = 0

    def __len__(self) -> int:
        return len(self.features)

    def __iter__(self):
        return iter(self.features)

    @property
    def seqids(self) -> set[str]:
        return {f.seqid for f in self.features}

    @property
    def feature_types(self) -> set[str]:
        return {f.ftype for f in self.features}

    def by_seqid(self) -> dict[str, list[Feature]]:
        out: dict[str, list[Feature]] = {}
        for f in self.features:
            out.setdefault(f.seqid, []).append(f)
        return out


# --------------------------------------------------------------------------- #
# Methylation
# --------------------------------------------------------------------------- #
@dataclass(slots=True)
class MethylGroup:
    """Positions for one (seqid, strand, mod) triple, sorted ascending."""

    pos: np.ndarray      # int64
    frac: np.ndarray     # float64, NaN when unknown
    cov: np.ndarray      # float64, NaN when unknown


class MethylSet:
    """A columnar set of methylation calls with O(log n) range queries.

    The original scripts stored one dataclass per call and counted overlaps by
    slicing a Python list (``positions[lo:]``), which copies the tail of the
    list for *every feature*.  Here positions live in sorted numpy arrays and
    counting is a vectorised ``searchsorted`` over all features at once.
    """

    __slots__ = ("seqid", "pos", "mod", "strand", "cov", "frac",
                 "source", "fmt", "_groups", "_totals")

    def __init__(self, seqid, pos, mod, strand, cov, frac, source="", fmt=""):
        self.seqid = np.asarray(seqid, dtype=object)
        self.pos = np.asarray(pos, dtype=np.int64)
        self.mod = np.asarray(mod, dtype=object)
        self.strand = np.asarray(strand, dtype=object)
        self.cov = np.asarray(cov, dtype=np.float64)
        self.frac = np.asarray(frac, dtype=np.float64)
        self.source = source
        self.fmt = fmt
        self._groups: dict[tuple[str, str, str], MethylGroup] | None = None
        self._totals: dict[str, int] | None = None

    # -- basics ------------------------------------------------------------ #
    def __len__(self) -> int:
        return int(self.pos.size)

    def __bool__(self) -> bool:
        return len(self) > 0

    @property
    def presence_only(self) -> bool:
        """True when no call carries a fraction-modified value."""
        return bool(len(self)) and bool(np.all(np.isnan(self.frac)))

    @property
    def has_coverage(self) -> bool:
        return bool(len(self)) and bool(np.any(~np.isnan(self.cov)))

    @property
    def seqids(self) -> set[str]:
        return set(np.unique(self.seqid).tolist())

    @property
    def mod_codes(self) -> set[str]:
        return set(np.unique(self.mod).tolist())

    @property
    def strands(self) -> set[str]:
        return set(np.unique(self.strand).tolist())

    # -- derivation -------------------------------------------------------- #
    def subset(self, mask: np.ndarray) -> "MethylSet":
        return MethylSet(self.seqid[mask], self.pos[mask], self.mod[mask],
                         self.strand[mask], self.cov[mask], self.frac[mask],
                         source=self.source, fmt=self.fmt)

    def filter(self, min_cov: float = 0.0, min_frac: float | None = None) -> "MethylSet":
        """Coverage/fraction filter.

        Calls with unknown coverage or unknown fraction are *kept* (a presence-only
        file carries neither), so the filter never silently empties a set that
        simply lacks the columns.
        """
        mask = np.ones(len(self), dtype=bool)
        if min_cov and min_cov > 0:
            mask &= np.isnan(self.cov) | (self.cov >= min_cov)
        if min_frac is not None:
            mask &= np.isnan(self.frac) | (self.frac >= min_frac)
        return self.subset(mask)

    def rename_seqids(self, mapping: dict[str, str]) -> "MethylSet":
        if not mapping:
            return self
        new = np.array([mapping.get(s, s) for s in self.seqid], dtype=object)
        return MethylSet(new, self.pos, self.mod, self.strand, self.cov,
                         self.frac, source=self.source, fmt=self.fmt)

    # -- indexing ---------------------------------------------------------- #
    def groups(self) -> dict[tuple[str, str, str], MethylGroup]:
        """(seqid, strand, mod) -> sorted positions with aligned frac/cov."""
        if self._groups is not None:
            return self._groups
        groups: dict[tuple[str, str, str], MethylGroup] = {}
        if len(self):
            keys = np.array(
                [f"{s}\x00{st}\x00{m}" for s, st, m
                 in zip(self.seqid, self.strand, self.mod)], dtype=object)
            order = np.lexsort((self.pos, keys))
            k_sorted = keys[order]
            bounds = np.flatnonzero(np.r_[True, k_sorted[1:] != k_sorted[:-1]])
            bounds = np.r_[bounds, len(k_sorted)]
            for i in range(len(bounds) - 1):
                lo, hi = bounds[i], bounds[i + 1]
                idx = order[lo:hi]
                seq, strand, mod = k_sorted[lo].split("\x00")
                groups[(seq, strand, mod)] = MethylGroup(
                    pos=self.pos[idx], frac=self.frac[idx], cov=self.cov[idx])
        self._groups = groups
        return groups

    def positions(self, seqid: str, mod: str | None = None) -> np.ndarray:
        """Sorted positions on one replicon, optionally restricted to one mod."""
        mask = self.seqid == seqid
        if mod is not None:
            mask &= self.mod == mod
        return np.sort(self.pos[mask])

    def totals_per_mod(self) -> dict[str, int]:
        if self._totals is None:
            codes, counts = np.unique(self.mod, return_counts=True)
            self._totals = dict(zip(codes.tolist(), counts.tolist()))
        return self._totals

    # -- counting ---------------------------------------------------------- #
    def count_in_windows(self, seqid: str, mod: str, starts: np.ndarray,
                         ends: np.ndarray, strands: list[str]) -> np.ndarray:
        """Vectorised count of calls in ``[start, end)`` for many windows.

        ``strands`` is the list of methylation strands that count towards these
        windows.  O((F + n) log n) for F windows, versus the original
        O(F * n) list-slicing implementation.
        """
        total = np.zeros(len(starts), dtype=np.int64)
        groups = self.groups()
        for strand in strands:
            grp = groups.get((seqid, strand, mod))
            if grp is None or grp.pos.size == 0:
                continue
            lo = np.searchsorted(grp.pos, starts, side="left")
            hi = np.searchsorted(grp.pos, ends, side="left")
            total += (hi - lo)
        return total

    def mean_frac_in_windows(self, seqid: str, mod: str | None, starts: np.ndarray,
                             ends: np.ndarray, strands: list[str]) -> np.ndarray:
        """Mean fraction-modified per window (NaN where no call carries a fraction)."""
        groups = self.groups()
        sums = np.zeros(len(starts))
        cnts = np.zeros(len(starts))
        for (seq, strand, m), grp in groups.items():
            if seq != seqid or strand not in strands:
                continue
            if mod is not None and m != mod:
                continue
            valid = ~np.isnan(grp.frac)
            if not valid.any():
                continue
            pos, frac = grp.pos[valid], grp.frac[valid]
            cum = np.r_[0.0, np.cumsum(frac)]
            lo = np.searchsorted(pos, starts, side="left")
            hi = np.searchsorted(pos, ends, side="left")
            sums += cum[hi] - cum[lo]
            cnts += (hi - lo)
        with np.errstate(invalid="ignore", divide="ignore"):
            out = np.where(cnts > 0, sums / np.maximum(cnts, 1), np.nan)
        return out


def empty_methylset() -> MethylSet:
    e = np.array([], dtype=object)
    f = np.array([], dtype=np.float64)
    return MethylSet(e, np.array([], dtype=np.int64), e, e, f, f)
