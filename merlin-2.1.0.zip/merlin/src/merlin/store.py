"""The canonical MErlin store (ROADMAP 2.1).

Each 2.0 module wrote its own tables in its own unit — features in
``xam``/``dixam``/``mematch``, positions in ``spacem``, bins in ``hicam``.  Any
cross-layer question was answered by whichever module happened to have two
layers in scope, which is why "DM genes at Hi-C boundaries" lived in ``hicam``
and "DM genes that are DE" lived in ``diem``, computed from different joins.

The store fixes that by construction: one file, two tables, one map between
them, and a provenance block.

::

    merlin_store.h5
      /features   locus_tag, replicon, start, end, strand, type, product,
                  length, gc, oriter_folded, motif_*, meth_*, dmeth_*,
                  expr_*, hic_bin, hic_compartment, hic_insulation, ...
      /bins       replicon, bin, start, end, pc1, insulation, is_boundary,
                  meth_density, mean_frac_modified, n_genes, mean_log2FC, ...
      /maps       feature_to_bin  (many-to-one, so either unit can be used)
      /meta       merlin version, inputs, checksums, thresholds, warnings

HDF5 through :mod:`h5py` is the storage format because it is already a
dependency of the Hi-C reader and needs no compiler.  Columns are stored
individually (strings as variable-length UTF-8), so a reader can pull one
column without materialising the table.  Parquet is used instead when
:mod:`pyarrow` is installed and ``format='parquet'`` is asked for.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from . import __version__
from .logging_utils import get_logger

logger = get_logger("store")

FEATURES = "features"
BINS = "bins"
MAP_FEATURE_BIN = "feature_to_bin"


def file_digest(path: str | Path, block: int = 1 << 20) -> str:
    """Short content hash, so a rerun can prove it used the same inputs."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            while True:
                chunk = fh.read(block)
                if not chunk:
                    break
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()[:16]


@dataclass
class Provenance:
    """What produced this store, in enough detail to reproduce it."""

    merlin_version: str = __version__
    created: str = ""
    command: str = ""
    inputs: dict[str, str] = field(default_factory=dict)     # role -> path
    checksums: dict[str, str] = field(default_factory=dict)  # role -> digest
    thresholds: dict[str, object] = field(default_factory=dict)
    seqid_mapping: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    modules: list[str] = field(default_factory=list)

    def add_input(self, role: str, path) -> None:
        if not path:
            return
        self.inputs[role] = str(path)
        self.checksums[role] = file_digest(path)

    def to_json(self) -> str:
        return json.dumps(self.__dict__, indent=2, default=str)

    @classmethod
    def from_json(cls, text: str) -> "Provenance":
        data = json.loads(text) if text else {}
        obj = cls()
        for k, v in data.items():
            if hasattr(obj, k):
                setattr(obj, k, v)
        return obj

    def header_lines(self, comment: str = "# ") -> list[str]:
        out = [f"{comment}MErlin {self.merlin_version}"]
        if self.created:
            out.append(f"{comment}created: {self.created}")
        if self.command:
            out.append(f"{comment}command: {self.command}")
        for role, path in self.inputs.items():
            digest = self.checksums.get(role, "")
            out.append(f"{comment}input[{role}]: {path}"
                       + (f"  sha256:{digest}" if digest else ""))
        if self.thresholds:
            out.append(f"{comment}thresholds: "
                       + ", ".join(f"{k}={v}" for k, v in self.thresholds.items()))
        if self.seqid_mapping:
            out.append(f"{comment}seqid mapping: "
                       + ", ".join(f"{k}->{v}" for k, v in
                                   list(self.seqid_mapping.items())[:6]))
        return out


# --------------------------------------------------------------------------- #
class MerlinStore:
    """Read/write access to the canonical store."""

    def __init__(self, path: str | Path, mode: str = "r"):
        self.path = Path(path)
        self.mode = mode
        self._h5 = None

    # -- context ----------------------------------------------------------
    def __enter__(self):
        import h5py
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._h5 = h5py.File(self.path, self.mode)
        return self

    def __exit__(self, *exc):
        if self._h5 is not None:
            self._h5.close()
            self._h5 = None
        return False

    # -- tables -----------------------------------------------------------
    def write_table(self, name: str, df) -> None:
        import h5py
        grp = self._h5.require_group(name)
        for key in list(grp.keys()):
            del grp[key]
        grp.attrs["columns"] = json.dumps([str(c) for c in df.columns])
        grp.attrs["n_rows"] = int(len(df))
        for col in df.columns:
            values = df[col].to_numpy()
            key = str(col)
            if values.dtype.kind in "OUS":
                data = np.array(["" if v is None or (isinstance(v, float)
                                                     and np.isnan(v)) else str(v)
                                 for v in values], dtype=object)
                grp.create_dataset(key, data=data,
                                   dtype=h5py.string_dtype("utf-8"),
                                   compression="gzip", compression_opts=4)
            else:
                grp.create_dataset(key, data=values.astype(
                    np.float64 if values.dtype.kind == "f" else values.dtype),
                    compression="gzip", compression_opts=4)
        logger.info("store: /%s  %d row(s) x %d column(s)", name, len(df),
                    df.shape[1])

    def read_table(self, name: str):
        import pandas as pd
        if name not in self._h5:
            return pd.DataFrame()
        grp = self._h5[name]
        cols = json.loads(grp.attrs.get("columns", "[]"))
        data = {}
        for col in cols:
            if col not in grp:
                continue
            arr = grp[col][:]
            if arr.dtype.kind in "OS":
                arr = np.array([v.decode() if isinstance(v, bytes) else str(v)
                                for v in arr], dtype=object)
            data[col] = arr
        return pd.DataFrame(data)

    def tables(self) -> list[str]:
        return [k for k in self._h5.keys() if k not in ("meta", "maps")]

    # -- maps -------------------------------------------------------------
    def write_map(self, name: str, values: np.ndarray) -> None:
        grp = self._h5.require_group("maps")
        if name in grp:
            del grp[name]
        grp.create_dataset(name, data=np.asarray(values), compression="gzip")

    def read_map(self, name: str) -> np.ndarray:
        grp = self._h5.get("maps")
        if grp is None or name not in grp:
            return np.empty(0, dtype=np.int64)
        return grp[name][:]

    # -- meta -------------------------------------------------------------
    def write_provenance(self, prov: Provenance) -> None:
        grp = self._h5.require_group("meta")
        grp.attrs["provenance"] = prov.to_json()
        self._h5.attrs["merlin_version"] = prov.merlin_version

    @property
    def provenance(self) -> Provenance:
        grp = self._h5.get("meta")
        if grp is None:
            return Provenance()
        return Provenance.from_json(grp.attrs.get("provenance", ""))


# --------------------------------------------------------------------------- #
def assign_features_to_bins(features_df, bins_df) -> np.ndarray:
    """Bin index for each feature midpoint; -1 where the replicon has no bins."""
    out = np.full(len(features_df), -1, dtype=np.int64)
    if bins_df is None or len(bins_df) == 0 or len(features_df) == 0:
        return out
    mids = ((features_df["start"].to_numpy(dtype=float)
             + features_df["end"].to_numpy(dtype=float)) / 2)
    for rep, sub in bins_df.groupby("replicon"):
        starts = sub["start"].to_numpy(dtype=float)
        order = np.argsort(starts)
        starts, ends = starts[order], sub["end"].to_numpy(dtype=float)[order]
        rows = sub.index.to_numpy()[order]
        sel = np.flatnonzero(features_df["replicon"].to_numpy() == rep)
        if sel.size == 0:
            continue
        j = np.searchsorted(starts, mids[sel], side="right") - 1
        ok = (j >= 0) & (j < starts.size)
        jj = np.clip(j, 0, max(starts.size - 1, 0))
        ok &= mids[sel] < ends[jj]
        out[sel[ok]] = rows[jj[ok]]
    n_placed = int((out >= 0).sum())
    logger.info("feature -> bin map: %d/%d feature(s) placed.", n_placed, len(out))
    return out


def write_provenance_header(path: str | Path, prov: Provenance) -> None:
    """Prefix an existing TSV with commented provenance lines."""
    path = Path(path)
    if not path.exists():
        return
    body = path.read_text(encoding="utf-8")
    if body.startswith("# MErlin"):
        return
    path.write_text("\n".join(prov.header_lines()) + "\n" + body, encoding="utf-8")
