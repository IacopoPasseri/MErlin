"""Confounder block and adjusted association testing (ROADMAP 1.2).

Every cross-layer statistic in 2.0 was marginal.  Methylation density per gene
correlates with gene length, GC content, motif density, distance from oriC
(replication timing) and coverage — and so does almost everything else.
"Methylation correlates with log2FC (rho = 0.13)" is equally consistent with
methylation mattering and with both tracking GC content.

This module builds the covariate block once, and provides the two things that
make the difference visible:

* **partial correlation** — the rank correlation of x and y after both are
  residualised on the covariates;
* **an adjusted regression report** — the methylation coefficient in
  ``y ~ methylation + covariates`` next to the marginal one.

When the marginal and adjusted numbers disagree, that disagreement is the
finding, and both are printed rather than one being quietly preferred.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .genome import base_cumsums, gc_skew_bins, ori_ter_coordinate
from .logging_utils import get_logger, warn_once

logger = get_logger("covariates")

# Covariates that are always available from an annotation alone
BASE_COVARIATES = ("log_length", "gene_density_10kb", "upstream_intergenic")


@dataclass
class CovariateBlock:
    names: list[str]
    matrix: np.ndarray                      # features x covariates
    index: dict[str, int] = field(default_factory=dict)

    def __post_init__(self):
        self.index = {n: i for i, n in enumerate(self.names)}

    def get(self, name: str) -> np.ndarray:
        return self.matrix[:, self.index[name]]

    def select(self, names) -> np.ndarray:
        cols = [self.index[n] for n in names if n in self.index]
        return self.matrix[:, cols] if cols else np.empty((self.matrix.shape[0], 0))

    def to_frame(self, ids=None):
        import pandas as pd
        df = pd.DataFrame(self.matrix, columns=self.names)
        if ids is not None:
            df.insert(0, "locus_tag", list(ids))
        return df

    def usable(self, min_finite: float = 0.8) -> list[str]:
        """Covariates that are neither constant nor mostly missing."""
        out = []
        n = self.matrix.shape[0]
        for i, name in enumerate(self.names):
            v = self.matrix[:, i]
            if np.isfinite(v).sum() < min_finite * n:
                continue
            if np.nanstd(v) <= 0:
                continue
            out.append(name)
        return out


def _gene_density(features, window: int = 10000) -> np.ndarray:
    """Genes whose midpoint falls within +/- window of each gene's midpoint."""
    out = np.zeros(len(features))
    by_seq: dict[str, list[int]] = {}
    for i, f in enumerate(features):
        by_seq.setdefault(f.seqid, []).append(i)
    for _seq, idxs in by_seq.items():
        mids = np.array([features[i].mid for i in idxs], dtype=np.int64)
        order = np.argsort(mids)
        srt = mids[order]
        lo = np.searchsorted(srt, srt - window, side="left")
        hi = np.searchsorted(srt, srt + window, side="right")
        counts = (hi - lo - 1).astype(float)
        out[np.array(idxs)[order]] = counts
    return out


def _upstream_intergenic(features) -> np.ndarray:
    """Distance to the previous feature on the same strand (promoter room)."""
    out = np.full(len(features), np.nan)
    by_key: dict[tuple, list[int]] = {}
    for i, f in enumerate(features):
        by_key.setdefault((f.seqid, f.strand), []).append(i)
    for _k, idxs in by_key.items():
        arr = sorted(idxs, key=lambda i: features[i].start)
        for pos, i in enumerate(arr):
            f = features[i]
            if f.strand == "-":
                nxt = arr[pos + 1] if pos + 1 < len(arr) else None
                out[i] = (features[nxt].start - f.end) if nxt is not None else np.nan
            else:
                prv = arr[pos - 1] if pos > 0 else None
                out[i] = (f.start - features[prv].end) if prv is not None else np.nan
    return np.clip(out, 0, None)


def build_feature_covariates(annotation, genome=None, methyl=None,
                             motif_hits=None, origins=None,
                             expression=None) -> CovariateBlock:
    """Assemble the per-feature confounder block from whichever layers exist."""
    feats = annotation.features if hasattr(annotation, "features") else annotation
    n = len(feats)
    names: list[str] = []
    cols: list[np.ndarray] = []

    length = np.array([f.length for f in feats], dtype=float)
    names.append("log_length"); cols.append(np.log10(np.maximum(length, 1)))
    names.append("gene_density_10kb"); cols.append(_gene_density(feats))
    up = _upstream_intergenic(feats)
    names.append("upstream_intergenic"); cols.append(np.log10(np.maximum(up, 1)))

    if genome:
        gc = np.full(n, np.nan)
        at_skew = np.full(n, np.nan)
        cums = {sid: base_cumsums(seq) for sid, seq in genome.items()}
        for i, f in enumerate(feats):
            c = cums.get(f.seqid)
            if c is None:
                continue
            L = len(genome[f.seqid])
            s, e = max(0, min(f.start, L)), max(0, min(f.end, L))
            if e <= s:
                continue
            g = c["G"][e] - c["G"][s]
            cc = c["C"][e] - c["C"][s]
            gc[i] = (g + cc) / (e - s)
            at_skew[i] = (g - cc) / max(g + cc, 1)
        names.append("gc_content"); cols.append(gc)
        names.append("gc_skew"); cols.append(at_skew)

    if origins and genome:
        folded = np.full(n, np.nan)
        for i, f in enumerate(feats):
            sp = origins.get(f.seqid)
            if sp is None or f.seqid not in genome:
                continue
            _s, fold, _a = ori_ter_coordinate(np.array([f.mid]), sp.oric, sp.ter,
                                              len(genome[f.seqid]))
            folded[i] = float(fold[0])
        names.append("oriter_folded"); cols.append(folded)

    if methyl is not None and len(methyl):
        from .intervals import FeatureIndex, count_per_feature
        idx = FeatureIndex(feats)
        assayed = count_per_feature(idx, methyl, sorted(methyl.mod_codes),
                                    ignore_strand=True).sum(axis=1).astype(float)
        names.append("assayed_sites_per_kb")
        cols.append(1000.0 * assayed / np.maximum(length, 1))
        if methyl.has_coverage:
            from .intervals import mean_frac_per_feature  # noqa: F401
            cov = np.full(n, np.nan)
            groups = methyl.groups()
            for seqid, sf in idx.by_seq.items():
                sums = np.zeros(sf.idx.size); cnts = np.zeros(sf.idx.size)
                for (sq, _st, _md), grp in groups.items():
                    if sq != seqid:
                        continue
                    valid = np.isfinite(grp.cov)
                    if not valid.any():
                        continue
                    pos, cv = grp.pos[valid], grp.cov[valid]
                    cum = np.r_[0.0, np.cumsum(cv)]
                    lo = np.searchsorted(pos, sf.start, "left")
                    hi = np.searchsorted(pos, sf.end, "left")
                    sums += cum[hi] - cum[lo]; cnts += (hi - lo)
                with np.errstate(invalid="ignore", divide="ignore"):
                    cov[sf.idx] = np.where(cnts > 0, sums / np.maximum(cnts, 1), np.nan)
            names.append("mean_coverage"); cols.append(cov)

    if motif_hits:
        from .intervals import FeatureIndex, points_in_intervals
        idx = FeatureIndex(feats)
        for motif, hits in motif_hits.items():
            counts = np.zeros(n)
            anchors = hits.anchor()
            for seqid, sf in idx.by_seq.items():
                sel = hits.for_seqid(seqid)
                if sel.size == 0:
                    continue
                csr = points_in_intervals(anchors[sel], sf.start, sf.end, sf.idx)
                if csr.values.size:
                    np.add.at(counts, csr.values, 1)
            names.append(f"motif_{motif}_per_kb")
            cols.append(1000.0 * counts / np.maximum(length, 1))

    if expression is not None and "baseMean" in getattr(expression, "columns", []):
        lut = dict(zip(expression["locus_tag"].astype(str),
                       expression["baseMean"].astype(float)))
        bm = np.array([lut.get(f.locus_tag, np.nan) for f in feats])
        names.append("log_baseMean"); cols.append(np.log10(np.maximum(bm, 1e-3)))

    block = CovariateBlock(names=names, matrix=np.column_stack(cols) if cols
                           else np.empty((n, 0)))
    logger.info("Covariate block: %d feature(s) x %d covariate(s) [%s]",
                n, len(names), ", ".join(names))
    return block


# --------------------------------------------------------------------------- #
# Adjusted association
# --------------------------------------------------------------------------- #
def _rank(x: np.ndarray) -> np.ndarray:
    from .stats import _rankdata
    return _rankdata(x)


def _residualise(y: np.ndarray, Z: np.ndarray) -> np.ndarray:
    """Residuals of y on [1, Z], with non-finite rows dropped by the caller."""
    if Z.size == 0:
        return y - y.mean()
    X = np.column_stack([np.ones(len(y)), Z])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    return y - X @ beta


@dataclass
class AdjustedResult:
    n: int
    marginal_rho: float = float("nan")
    marginal_p: float = float("nan")
    partial_rho: float = float("nan")
    partial_p: float = float("nan")
    coef: float = float("nan")
    coef_se: float = float("nan")
    coef_p: float = float("nan")
    covariates: list[str] = field(default_factory=list)
    note: str = ""

    @property
    def attenuated(self) -> bool:
        """True when adjustment removes most of the marginal association."""
        if not (np.isfinite(self.marginal_rho) and np.isfinite(self.partial_rho)):
            return False
        return abs(self.partial_rho) < 0.5 * abs(self.marginal_rho)


def partial_correlation(x, y, Z, covariate_names=None) -> AdjustedResult:
    """Spearman partial correlation of x and y given Z, plus the OLS coefficient.

    Ranks are residualised rather than the raw values, so the result is a
    Spearman partial correlation and inherits its robustness to the skewed
    distributions methylation densities have.
    """
    from .stats import _scipy

    x = np.asarray(x, float); y = np.asarray(y, float)
    Z = np.asarray(Z, float) if Z is not None else np.empty((x.size, 0))
    if Z.ndim == 1:
        Z = Z[:, None]
    ok = np.isfinite(x) & np.isfinite(y)
    if Z.size:
        ok &= np.isfinite(Z).all(axis=1)
    res = AdjustedResult(n=int(ok.sum()),
                         covariates=list(covariate_names or []))
    k = Z.shape[1]
    if res.n < max(10, k + 3):
        res.note = "too few complete observations"
        return res
    xs, ys, Zs = x[ok], y[ok], Z[ok]
    keep = [j for j in range(Zs.shape[1]) if np.std(Zs[:, j]) > 0]
    Zs = Zs[:, keep]
    res.covariates = [res.covariates[j] for j in keep] if res.covariates else []

    st = _scipy()
    if st is not None:
        res.marginal_rho, res.marginal_p = (float(v) for v in st.spearmanr(xs, ys))
    else:
        res.marginal_rho = float(np.corrcoef(_rank(xs), _rank(ys))[0, 1])

    rx = _residualise(_rank(xs), _rank_matrix(Zs))
    ry = _residualise(_rank(ys), _rank_matrix(Zs))
    if np.std(rx) == 0 or np.std(ry) == 0:
        res.note = "no variance left after adjustment"
        return res
    rho = float(np.corrcoef(rx, ry)[0, 1])
    res.partial_rho = rho
    df = res.n - Zs.shape[1] - 2
    if df > 0 and abs(rho) < 1:
        t = rho * np.sqrt(df / max(1 - rho ** 2, 1e-12))
        if st is not None:
            res.partial_p = float(2 * st.t.sf(abs(t), df))

    X = np.column_stack([np.ones(res.n), xs, Zs])
    beta, *_ = np.linalg.lstsq(X, ys, rcond=None)
    resid = ys - X @ beta
    dof = max(res.n - X.shape[1], 1)
    sigma2 = float(resid @ resid) / dof
    try:
        xtx_inv = np.linalg.pinv(X.T @ X)
        se = float(np.sqrt(max(sigma2 * xtx_inv[1, 1], 0)))
        res.coef, res.coef_se = float(beta[1]), se
        if se > 0 and st is not None:
            res.coef_p = float(2 * st.t.sf(abs(beta[1] / se), dof))
    except np.linalg.LinAlgError:  # pragma: no cover
        res.note = "covariate matrix is singular"
    if res.attenuated:
        warn_once(logger, "COVARIATE_ATTENUATION",
                  "At least one association loses more than half its strength "
                  "once gene length, GC content, motif density and replication "
                  "position are adjusted for. Report the adjusted estimate, or "
                  "report both and say which covariate absorbs it.")
    return res


def _rank_matrix(Z: np.ndarray) -> np.ndarray:
    if Z.size == 0:
        return Z
    return np.column_stack([_rank(Z[:, j]) for j in range(Z.shape[1])])


def covariate_screen(target, block: CovariateBlock, names=None) -> list[dict]:
    """How strongly each covariate relates to ``target`` — what to worry about."""
    from .stats import _scipy
    st = _scipy()
    rows = []
    for name in (names or block.usable()):
        v = block.get(name)
        ok = np.isfinite(v) & np.isfinite(target)
        if ok.sum() < 10 or np.std(v[ok]) == 0:
            continue
        rho = (float(st.spearmanr(v[ok], target[ok])[0]) if st is not None
               else float(np.corrcoef(_rank(v[ok]), _rank(target[ok]))[0, 1]))
        rows.append(dict(covariate=name, n=int(ok.sum()), spearman_rho=rho))
    rows.sort(key=lambda r: -abs(r["spearman_rho"]))
    return rows
