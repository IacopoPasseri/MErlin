"""Shared logging + warning collection for all MErlin tools.

Every tool logs through :func:`get_logger` so that message formatting, verbosity
and the *warning ledger* behave identically everywhere.

The warning ledger exists because MErlin's joins fail silently: a seqid
namespace mismatch produces zero overlaps, which looks exactly like a genome
with no methylation.  Tools record such conditions with :func:`warn_once`, and
every tool writes the accumulated ledger to ``<prefix>.warnings.txt`` so a
downstream reader (human or agent) can see what was shaky about a run without
scrolling back through stderr.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

_FMT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATEFMT = "%Y-%m-%d %H:%M:%S"

_CONFIGURED = False


def configure(level: int | str = logging.INFO, stream=sys.stderr) -> None:
    """Install the shared handler once."""
    global _CONFIGURED
    if _CONFIGURED:
        logging.getLogger("merlin").setLevel(level)
        return
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter(_FMT, datefmt=_DATEFMT))
    root = logging.getLogger("merlin")
    root.handlers[:] = [handler]
    root.setLevel(level)
    root.propagate = False
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    configure(os.environ.get("MERLIN_LOGLEVEL", "INFO"))
    return logging.getLogger(f"merlin.{name}" if not name.startswith("merlin") else name)


# --------------------------------------------------------------------------- #
# Warning ledger
# --------------------------------------------------------------------------- #
@dataclass
class Ledger:
    """Accumulates data-quality warnings for the run."""

    entries: list[tuple[str, str]] = field(default_factory=list)
    _seen: set[str] = field(default_factory=set)

    def add(self, code: str, message: str, *, once: bool = True) -> None:
        if once and code in self._seen:
            return
        self._seen.add(code)
        self.entries.append((code, message))

    def __bool__(self) -> bool:
        return bool(self.entries)

    def __len__(self) -> int:
        return len(self.entries)

    def render(self) -> str:
        if not self.entries:
            return "No data-quality warnings recorded.\n"
        out = ["MErlin data-quality warnings", "=" * 60, ""]
        for code, msg in self.entries:
            out.append(f"[{code}] {msg}")
        return "\n".join(out) + "\n"

    def write(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.render(), encoding="utf-8")
        return path


LEDGER = Ledger()


def warn_once(logger: logging.Logger, code: str, message: str) -> None:
    """Log a warning and record it in the run-wide ledger."""
    if code not in LEDGER._seen:
        logger.warning(message)
    LEDGER.add(code, message)


def reset_ledger() -> None:
    LEDGER.entries.clear()
    LEDGER._seen.clear()
