"""modBAM → bedMethyl, so a raw basecalled BAM is a valid MErlin input.

Until 2.1.0 the only module that read a BAM was ``phase``, and every per-feature
layer needed a bedMethyl someone had produced elsewhere.  That made ``modkit``
an undocumented prerequisite of the whole toolkit, and put the single most
consequential parameter of the analysis — the threshold at which an ML
probability becomes a methylation call — outside MErlin's provenance record.

Two backends produce the same file:

**modkit** (preferred, ``--backend modkit``)
    ONT's own tool.  It knows the MM/ML specification including the details this
    module does not model — deletions, reference-mismatch positions, implicit
    versus explicit canonical calls, duplex tags — and its output is the format
    every downstream tool already expects.  If it is on PATH, MErlin uses it.

**internal** (fallback, ``--backend internal``)
    A pysam pileup written here so that a missing modkit degrades the run
    instead of ending it.  Per position and strand it takes the argmax over the
    modification probabilities and the implied canonical probability, counts the
    winner, and drops calls whose winning probability is below
    ``--filter-threshold``.  It emits the same 18-column bedMethyl.

    What it does *not* model: deletions and reference mismatches (columns
    ``N_delete``, ``N_diff`` and ``N_nocall`` are written as 0), duplex tags, and
    modkit's adaptive percentile threshold.  Numbers from the two backends are
    therefore close but not identical, which is why the backend used is recorded
    in the provenance and printed in the summary.

Both write the modkit column order, so anything that reads a bedMethyl — MErlin
included — takes either without knowing which produced it.
"""

from __future__ import annotations

import gzip
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("pileup")

# modkit's bedMethyl column order (https://github.com/nanoporetech/modkit).
BEDMETHYL_COLUMNS = [
    "chrom", "start", "end", "mod_code", "score", "strand",
    "thick_start", "thick_end", "color", "N_valid_cov", "percent_modified",
    "N_mod", "N_canonical", "N_other_mod", "N_delete", "N_fail", "N_diff",
    "N_nocall",
]

DEFAULT_FILTER_THRESHOLD = 0.667


def _pysam():
    try:
        import pysam
        return pysam
    except ImportError:  # pragma: no cover - exercised only without pysam
        raise SystemExit(
            "[FATAL] reading a BAM needs pysam (`pip install pysam`, or "
            "`pip install 'merlin-multiomics[reads]'`). Supply a bedMethyl "
            "instead if you cannot install it.") from None


# --------------------------------------------------------------------------- #
# What is actually in this BAM?
# --------------------------------------------------------------------------- #
@dataclass
class BamStatus:
    """Everything a caller needs to decide what to do with a BAM, read once."""

    path: str
    n_refs: int = 0
    ref_names: list[str] = field(default_factory=list)
    sort_order: str = "unknown"
    has_index: bool = False
    n_checked: int = 0
    n_mapped: int = 0
    n_with_tags: int = 0
    mod_codes: list[str] = field(default_factory=list)
    is_duplex: bool = False

    @property
    def is_aligned(self) -> bool:
        return self.n_refs > 0 and self.n_mapped > 0

    @property
    def is_coordinate_sorted(self) -> bool:
        return self.sort_order == "coordinate"

    @property
    def has_modifications(self) -> bool:
        return self.n_with_tags > 0

    def describe(self) -> str:
        bits = [f"{self.n_refs} reference(s)",
                f"sort={self.sort_order}",
                f"index={'yes' if self.has_index else 'no'}"]
        if self.n_checked:
            bits.append(f"{self.n_with_tags}/{self.n_checked} sampled read(s) "
                        f"carry MM/ML")
        if self.mod_codes:
            bits.append("codes: " + ",".join(self.mod_codes))
        if self.is_duplex:
            bits.append("duplex tags present")
        return "; ".join(bits)


def inspect_bam(path: str | Path, n_check: int = 500) -> BamStatus:
    """Read the header and sample the first reads. Never scans the whole file."""
    pysam = _pysam()
    st = BamStatus(path=str(path))
    with pysam.AlignmentFile(str(path), "rb", check_sq=False) as bam:
        header = bam.header.to_dict()
        st.sort_order = header.get("HD", {}).get("SO", "unknown")
        st.n_refs = bam.nreferences or 0
        st.ref_names = list(bam.references or [])
        try:
            st.has_index = bam.has_index()
        except (ValueError, AttributeError):
            st.has_index = False
        codes: set[str] = set()
        for read in bam.head(n_check) if hasattr(bam, "head") else bam.fetch(until_eof=True):
            st.n_checked += 1
            if not read.is_unmapped:
                st.n_mapped += 1
            if read.has_tag("dx"):
                st.is_duplex = True
            try:
                mods = read.modified_bases
            except (AttributeError, ValueError):
                mods = None
            if mods:
                st.n_with_tags += 1
                for (_canon, _strand, code) in mods:
                    codes.add(str(code))
            if st.n_checked >= n_check:
                break
        st.mod_codes = sorted(codes)
    return st


def _run(argv: list[str], what: str, stdout=None) -> None:
    logger.info("running: %s", " ".join(argv))
    try:
        proc = subprocess.run(argv, check=False, stdout=stdout,
                              stderr=subprocess.PIPE, text=(stdout is None))
    except FileNotFoundError:
        raise SystemExit(f"[FATAL] {argv[0]} is not on PATH ({what}).") from None
    if proc.returncode != 0:
        err = (proc.stderr or b"") if isinstance(proc.stderr, bytes) else (proc.stderr or "")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "replace")
        tail = "\n".join(err.strip().splitlines()[-12:])
        raise SystemExit(f"[FATAL] {what} failed (exit {proc.returncode}):\n{tail}")


# --------------------------------------------------------------------------- #
# Getting to an aligned, sorted, indexed BAM
# --------------------------------------------------------------------------- #
def align_modbam(bam: str, fasta: str, outdir: Path, threads: int = 4,
                 preset: str = "map-ont") -> str:
    """Align an unaligned modBAM, carrying MM/ML through to the alignment.

    The recipe is the ONT-standard one — ``samtools fastq -T MM,ML`` into
    ``minimap2 -y`` — because the tags have to survive the round trip through
    FASTQ or the modification calls are silently lost, which is a failure mode
    that produces an empty pileup rather than an error.
    """
    for tool in ("samtools", "minimap2"):
        if not shutil.which(tool):
            raise SystemExit(
                f"[FATAL] {Path(bam).name} is not aligned and {tool} is not on "
                f"PATH, so MErlin cannot align it.\n"
                f"Install minimap2 and samtools, or align it yourself with:\n"
                f"  samtools fastq -T MM,ML {bam} | \\\n"
                f"    minimap2 -ax {preset} -y -t {threads} {fasta} - | \\\n"
                f"    samtools sort -o aligned.bam - && samtools index aligned.bam")
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / (Path(bam).stem + ".aligned.bam")
    logger.info("Aligning %s against %s with minimap2 (preset %s).",
                Path(bam).name, Path(fasta).name, preset)
    fq = subprocess.Popen(["samtools", "fastq", "-T", "MM,ML", str(bam)],
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    mm = subprocess.Popen(["minimap2", "-ax", preset, "-y", "-t", str(threads),
                           str(fasta), "-"],
                          stdin=fq.stdout, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL)
    fq.stdout.close()
    with open(out, "wb") as fh:
        srt = subprocess.Popen(["samtools", "sort", "-@", str(max(1, threads - 1)),
                                "-o", "-", "-"],
                               stdin=mm.stdout, stdout=fh,
                               stderr=subprocess.PIPE)
        mm.stdout.close()
        _, err = srt.communicate()
    fq.wait(); mm.wait()
    if srt.returncode != 0 or not out.exists() or out.stat().st_size == 0:
        raise SystemExit("[FATAL] alignment failed:\n"
                         + (err or b"").decode("utf-8", "replace")[-2000:])
    _run(["samtools", "index", str(out)], "samtools index")
    return str(out)


def prepare_bam(bam: str, fasta: str | None, workdir: Path, threads: int = 4,
                align: str = "auto", preset: str = "map-ont") -> tuple[str, BamStatus]:
    """Return a coordinate-sorted, indexed, aligned BAM — aligning if asked to.

    ``align='auto'`` aligns only when the input carries no alignments at all;
    ``'never'`` refuses instead, which is the right setting when the user
    believes their BAM is already aligned and wants to know if it is not.
    """
    st = inspect_bam(bam)
    logger.info("modBAM %s: %s", Path(bam).name, st.describe())

    if not st.has_modifications:
        raise SystemExit(
            f"[FATAL] no MM/ML modification tags in the first {st.n_checked} "
            f"read(s) of {Path(bam).name}. This BAM was not produced by a "
            f"modification-aware basecaller (dorado --modified-bases, guppy with "
            f"a mod model), or the tags were dropped by a downstream step that "
            f"did not carry them.")

    if not st.is_aligned:
        if align == "never":
            raise SystemExit(
                f"[FATAL] {Path(bam).name} is unaligned and --align never was "
                f"given. A pileup needs reference coordinates.")
        if not fasta:
            raise SystemExit(
                f"[FATAL] {Path(bam).name} is unaligned, so it must be aligned "
                f"before a pileup — pass --fasta with the reference.")
        aligned = align_modbam(bam, fasta, workdir, threads=threads, preset=preset)
        st = inspect_bam(aligned)
        return aligned, st

    if align == "force":
        if not fasta:
            raise SystemExit("[FATAL] --align force needs --fasta.")
        aligned = align_modbam(bam, fasta, workdir, threads=threads, preset=preset)
        return aligned, inspect_bam(aligned)

    path = bam
    if not st.is_coordinate_sorted:
        pysam = _pysam()
        workdir.mkdir(parents=True, exist_ok=True)
        srt = workdir / (Path(bam).stem + ".sorted.bam")
        logger.info("BAM is %s-sorted; sorting by coordinate into %s.",
                    st.sort_order, srt.name)
        pysam.sort("-@", str(max(1, threads - 1)), "-o", str(srt), str(bam))
        path = str(srt)
        st = inspect_bam(path)

    if not st.has_index:
        pysam = _pysam()
        logger.info("Indexing %s.", Path(path).name)
        try:
            pysam.index(str(path))
        except Exception as exc:  # pragma: no cover - pysam raises many types
            warn_once(logger, "PILEUP_NO_INDEX",
                      f"could not index {path} ({exc}); a whole-file pass will be "
                      f"used and --region will be ignored.")
        st = inspect_bam(path)
    return path, st


# --------------------------------------------------------------------------- #
# Backend selection
# --------------------------------------------------------------------------- #
def find_modkit(explicit: str | None = None) -> str | None:
    if explicit:
        return explicit if (Path(explicit).exists() or shutil.which(explicit)) else None
    return shutil.which("modkit")


def modkit_version(exe: str) -> str:
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True,
                             timeout=30)
        return (out.stdout or out.stderr).strip().splitlines()[0]
    except Exception:  # pragma: no cover
        return "unknown"


def resolve_backend(prefer: str = "auto", modkit_path: str | None = None
                    ) -> tuple[str, str | None, str]:
    """``(backend, modkit_exe, why)``."""
    exe = find_modkit(modkit_path)
    if prefer == "modkit":
        if not exe:
            raise SystemExit(
                "[FATAL] --backend modkit was requested but modkit is not on "
                "PATH. Install it from https://github.com/nanoporetech/modkit "
                "(or `conda install -c bioconda modkit`), or use "
                "--backend internal.")
        return "modkit", exe, f"requested; {modkit_version(exe)}"
    if prefer == "internal":
        return "internal", None, "requested"
    if exe:
        return "modkit", exe, f"found on PATH; {modkit_version(exe)}"
    return "internal", None, (
        "modkit is not on PATH, so MErlin's own pysam pileup is used. Install "
        "modkit for the reference implementation — the two agree closely but "
        "not exactly (see 'merlin pileup --help' and the docs).")


# --------------------------------------------------------------------------- #
# modkit backend
# --------------------------------------------------------------------------- #
def modkit_pileup(bam: str, out_path: Path, exe: str, fasta: str | None = None,
                  threads: int = 4, min_mapq: int = 20,
                  filter_threshold: float | None = None,
                  mod_thresholds: list[str] | None = None,
                  no_filtering: bool = False, region: str | None = None,
                  combine_strands: bool = False, cpg: bool = False,
                  motifs: list[str] | None = None,
                  extra_args: list[str] | None = None,
                  log_path: Path | None = None) -> Path:
    argv = [exe, "pileup", str(bam), str(out_path), "--threads", str(threads)]
    if fasta:
        argv += ["--ref", str(fasta)]
    if min_mapq:
        argv += ["--min-mapq", str(min_mapq)]
    if no_filtering:
        argv += ["--no-filtering"]
    elif filter_threshold is not None:
        argv += ["--filter-threshold", str(filter_threshold)]
    for spec in (mod_thresholds or []):
        argv += ["--mod-thresholds", spec]
    if region:
        argv += ["--region", region]
    if cpg:
        argv += ["--cpg"]
    for motif in (motifs or []):
        parts = motif.replace(":", " ").split()
        if len(parts) != 2:
            raise SystemExit(f"[FATAL] --motif takes 'SEQ OFFSET', got {motif!r}.")
        argv += ["--motif", parts[0], parts[1]]
    if combine_strands:
        argv += ["--combine-strands"]
    if log_path:
        argv += ["--log-filepath", str(log_path)]
    argv += list(extra_args or [])
    _run(argv, "modkit pileup")
    if not out_path.exists():
        raise SystemExit("[FATAL] modkit reported success but wrote no output.")
    return out_path


# --------------------------------------------------------------------------- #
# Internal backend
# --------------------------------------------------------------------------- #
class _Counters:
    """Four per-base counters for one modification code, both strands."""

    __slots__ = ("mod", "canonical", "other", "fail")

    def __init__(self, length: int):
        shape = (2, length)
        self.mod = np.zeros(shape, dtype=np.uint32)
        self.canonical = np.zeros(shape, dtype=np.uint32)
        self.other = np.zeros(shape, dtype=np.uint32)
        self.fail = np.zeros(shape, dtype=np.uint32)


def internal_pileup(bam: str, out_path: Path, *, min_mapq: int = 20,
                    filter_threshold: float = DEFAULT_FILTER_THRESHOLD,
                    mod_thresholds: dict[str, float] | None = None,
                    region: str | None = None,
                    keep_codes: set[str] | None = None,
                    max_reads: int | None = None,
                    gzip_output: bool = False) -> tuple[Path, dict]:
    """Pile MM/ML calls into a modkit-shaped bedMethyl.

    Memory is ``4 counters x 2 strands x 4 bytes`` per reference base per
    modification code — about 160 MB for a 5 Mb genome with two codes, which is
    fine for a prokaryote and is the reason modkit remains the recommended
    backend for anything larger.
    """
    pysam = _pysam()
    mod_thresholds = mod_thresholds or {}
    per_chrom: dict[str, dict[str, _Counters]] = {}
    lengths: dict[str, int] = {}
    n_reads = n_used = n_calls = 0

    with pysam.AlignmentFile(str(bam), "rb") as fh:
        lengths = dict(zip(fh.references, fh.lengths))
        if region:
            try:
                it = fh.fetch(region=region)
            except ValueError as exc:
                raise SystemExit(f"[FATAL] --region {region!r}: {exc}") from None
        else:
            it = fh.fetch(until_eof=True)
        for read in it:
            n_reads += 1
            if read.is_unmapped or read.is_secondary or read.is_supplementary:
                continue
            if read.is_duplicate or read.is_qcfail:
                continue
            if (read.mapping_quality or 0) < min_mapq:
                continue
            try:
                mods = read.modified_bases
            except (AttributeError, ValueError):
                mods = None
            if not mods:
                continue

            q2r = dict(read.get_aligned_pairs(matches_only=True))
            if not q2r:
                continue
            read_strand = 1 if read.is_reverse else 0
            chrom = read.reference_name
            length = lengths.get(chrom)
            if length is None:
                continue
            table = per_chrom.setdefault(chrom, {})

            # Regroup by (query position, MM strand) so the argmax is taken over
            # every modification competing for the same base, which is what makes
            # 'other_mod' meaningful when a caller emits both 5mC and 5hmC.
            grouped: dict[tuple[int, int], dict[str, float]] = {}
            for (_canon, mstrand, code), calls in mods.items():
                code = str(code)
                if keep_codes and code not in keep_codes:
                    continue
                for qpos, qual in calls:
                    if qual is None or qual < 0:
                        continue
                    grouped.setdefault((qpos, int(mstrand)), {})[code] = qual / 255.0

            used_here = False
            for (qpos, mstrand), probs in grouped.items():
                ref = q2r.get(qpos)
                if ref is None or ref >= length:
                    continue
                # MM key strand 1 means the modification sits on the strand
                # opposite the read; taking the read's strand for those would put
                # every 'G-m'/'T-a' record on the wrong strand.
                strand = (1 - read_strand) if mstrand == 1 else read_strand
                p_canon = 1.0 - sum(probs.values())
                best_code, best_p = max(probs.items(), key=lambda kv: kv[1])
                for code in probs:
                    if code not in table:
                        table[code] = _Counters(length)
                thr = mod_thresholds.get(best_code, filter_threshold)
                if max(best_p, p_canon) < thr:
                    for code in probs:
                        table[code].fail[strand, ref] += 1
                elif best_p > p_canon:
                    for code in probs:
                        if code == best_code:
                            table[code].mod[strand, ref] += 1
                        else:
                            table[code].other[strand, ref] += 1
                else:
                    for code in probs:
                        table[code].canonical[strand, ref] += 1
                n_calls += 1
                used_here = True
            if used_here:
                n_used += 1
            if max_reads and n_used >= max_reads:
                break

    summary = _write_bedmethyl(per_chrom, out_path, gzip_output=gzip_output)
    summary.update(n_reads_seen=n_reads, n_reads_used=n_used, n_calls=n_calls)
    logger.info("internal pileup: %d read(s) used of %d, %d call(s), %d site row(s).",
                n_used, n_reads, n_calls, summary["n_rows"])
    if n_used == 0:
        warn_once(logger, "PILEUP_NO_READS",
                  "no read passed the filters, so the bedMethyl is empty. Check "
                  "--min-mapq, --region and that the BAM is aligned.")
    return out_path, summary


def _write_bedmethyl(per_chrom, out_path: Path, gzip_output: bool = False) -> dict:
    opener = (lambda p: gzip.open(p, "wt")) if gzip_output else (
        lambda p: open(p, "w", encoding="utf-8"))
    n_rows = 0
    per_code: dict[str, dict] = {}
    with opener(out_path) as out:
        for chrom in sorted(per_chrom):
            table = per_chrom[chrom]
            for code in sorted(table):
                c = table[code]
                valid = (c.mod.astype(np.int64) + c.canonical + c.other)
                touched = valid + c.fail
                for strand_idx, strand in ((0, "+"), (1, "-")):
                    positions = np.flatnonzero(touched[strand_idx])
                    if positions.size == 0:
                        continue
                    v = valid[strand_idx, positions]
                    m = c.mod[strand_idx, positions]
                    can = c.canonical[strand_idx, positions]
                    oth = c.other[strand_idx, positions]
                    fail = c.fail[strand_idx, positions]
                    with np.errstate(invalid="ignore", divide="ignore"):
                        pct = np.where(v > 0, 100.0 * m / np.maximum(v, 1), 0.0)
                    score = np.minimum(v, 1000)
                    stat = per_code.setdefault(
                        code, {"n_sites": 0, "cov_sum": 0.0, "pct_sum": 0.0,
                               "n_valid": 0})
                    stat["n_sites"] += int(positions.size)
                    stat["cov_sum"] += float(v.sum())
                    stat["pct_sum"] += float(pct[v > 0].sum())
                    stat["n_valid"] += int((v > 0).sum())
                    for i, pos in enumerate(positions):
                        out.write(
                            f"{chrom}\t{pos}\t{pos + 1}\t{code}\t{score[i]}\t{strand}\t"
                            f"{pos}\t{pos + 1}\t255,0,0\t{v[i]}\t{pct[i]:.2f}\t"
                            f"{m[i]}\t{can[i]}\t{oth[i]}\t0\t{fail[i]}\t0\t0\n")
                    n_rows += int(positions.size)
    for stat in per_code.values():
        stat["mean_coverage"] = (stat["cov_sum"] / stat["n_sites"]
                                 if stat["n_sites"] else 0.0)
        stat["mean_percent_modified"] = (stat["pct_sum"] / stat["n_valid"]
                                         if stat["n_valid"] else 0.0)
    return {"n_rows": n_rows, "per_code": per_code}


# --------------------------------------------------------------------------- #
# Summarising whatever backend produced the file
# --------------------------------------------------------------------------- #
def summarise_bedmethyl(path: Path, chunk: int = 2_000_000):
    """Per-code site counts, coverage and mean percent-modified, streamed."""
    import pandas as pd

    stats: dict[str, dict] = {}
    reader = pd.read_csv(path, sep="\t", header=None, comment="#", dtype=str,
                         na_filter=False, on_bad_lines="skip", chunksize=chunk)
    for block in reader:
        if block.shape[1] < 11:
            tail = block[block.columns[-1]].str.split(expand=True)
            block = pd.concat([block.drop(columns=[block.columns[-1]]), tail],
                              axis=1)
            block.columns = list(range(block.shape[1]))
        code = block[3].to_numpy(dtype=object)
        cov = pd.to_numeric(block[9], errors="coerce").to_numpy(dtype=float)
        pct = pd.to_numeric(block[10], errors="coerce").to_numpy(dtype=float)
        for c in np.unique(code):
            sel = code == c
            s = stats.setdefault(str(c), {"n_sites": 0, "cov_sum": 0.0,
                                          "pct_sum": 0.0, "n_valid": 0})
            s["n_sites"] += int(sel.sum())
            good = sel & np.isfinite(cov) & (cov > 0)
            s["cov_sum"] += float(np.nansum(cov[good]))
            s["pct_sum"] += float(np.nansum(pct[good]))
            s["n_valid"] += int(good.sum())
    rows = []
    for code, s in sorted(stats.items()):
        rows.append({
            "mod_code": code,
            "n_sites": s["n_sites"],
            "n_sites_with_coverage": s["n_valid"],
            "mean_coverage": s["cov_sum"] / s["n_valid"] if s["n_valid"] else 0.0,
            "mean_percent_modified": s["pct_sum"] / s["n_valid"] if s["n_valid"] else 0.0,
        })
    import pandas as pd  # noqa: F811  (local import keeps the module import light)
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# One call that does the whole thing
# --------------------------------------------------------------------------- #
def pileup(bam: str, outdir: Path, prefix: str, *, fasta: str | None = None,
           backend: str = "auto", modkit_path: str | None = None,
           threads: int = 4, min_mapq: int = 20,
           filter_threshold: float | None = None, no_filtering: bool = False,
           mod_thresholds: list[str] | None = None, region: str | None = None,
           keep_codes: set[str] | None = None, combine_strands: bool = False,
           cpg: bool = False, motifs: list[str] | None = None,
           align: str = "auto", preset: str = "map-ont",
           gzip_output: bool = False, extra_args: list[str] | None = None,
           max_reads: int | None = None) -> dict:
    """modBAM in, bedMethyl out. Returns a dict describing what happened."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    work = outdir / "work"

    chosen, exe, why = resolve_backend(backend, modkit_path)
    if chosen == "internal" and backend == "auto":
        warn_once(logger, "PILEUP_BACKEND_INTERNAL", why)
    logger.info("pileup backend: %s (%s)", chosen, why)

    ready, status = prepare_bam(bam, fasta, work, threads=threads, align=align,
                                preset=preset)
    if status.is_duplex:
        warn_once(logger, "PILEUP_DUPLEX",
                  "duplex tags (dx) are present. A pileup collapses both strands "
                  "of a duplex read into per-position counts; per-molecule "
                  "hemimethylation needs 'merlin phase', not this table.")

    suffix = "bedmethyl.bed.gz" if gzip_output else "bedmethyl.bed"
    out_path = outdir / f"{prefix}.{suffix}"
    info = {"backend": chosen, "backend_note": why, "bam": ready,
            "aligned_here": ready != str(bam), "status": status,
            "bedmethyl": out_path}

    if chosen == "modkit":
        if gzip_output:
            raw = outdir / f"{prefix}.bedmethyl.bed"
            modkit_pileup(ready, raw, exe, fasta=fasta, threads=threads,
                          min_mapq=min_mapq, filter_threshold=filter_threshold,
                          mod_thresholds=mod_thresholds,
                          no_filtering=no_filtering, region=region,
                          combine_strands=combine_strands, cpg=cpg,
                          motifs=motifs, extra_args=extra_args,
                          log_path=outdir / f"{prefix}.modkit.log")
            with open(raw, "rb") as src, gzip.open(out_path, "wb") as dst:
                shutil.copyfileobj(src, dst)
            os.unlink(raw)
        else:
            modkit_pileup(ready, out_path, exe, fasta=fasta, threads=threads,
                          min_mapq=min_mapq, filter_threshold=filter_threshold,
                          mod_thresholds=mod_thresholds,
                          no_filtering=no_filtering, region=region,
                          combine_strands=combine_strands, cpg=cpg,
                          motifs=motifs, extra_args=extra_args,
                          log_path=outdir / f"{prefix}.modkit.log")
        info["summary"] = summarise_bedmethyl(out_path)
    else:
        for unsupported, name in ((combine_strands, "--combine-strands"),
                                  (cpg, "--cpg"), (motifs, "--motif"),
                                  (extra_args, "--modkit-arg")):
            if unsupported:
                raise SystemExit(
                    f"[FATAL] {name} is a modkit feature and the internal "
                    f"backend does not implement it. Install modkit, or drop "
                    f"the flag — motif restriction can be applied afterwards "
                    f"with 'merlin mematch'.")
        thresholds = {}
        for spec in (mod_thresholds or []):
            code, _, value = spec.partition(":")
            if not value:
                raise SystemExit(f"[FATAL] --mod-thresholds takes 'code:value', "
                                 f"got {spec!r}.")
            thresholds[code] = float(value)
        thr = 0.0 if no_filtering else (
            DEFAULT_FILTER_THRESHOLD if filter_threshold is None else filter_threshold)
        _, summary = internal_pileup(
            ready, out_path, min_mapq=min_mapq, filter_threshold=thr,
            mod_thresholds=thresholds, region=region, keep_codes=keep_codes,
            max_reads=max_reads, gzip_output=gzip_output)
        info["summary"] = summarise_bedmethyl(out_path)
        info["counts"] = summary
        info["filter_threshold"] = thr
    return info
