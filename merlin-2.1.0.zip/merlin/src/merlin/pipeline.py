"""``merlin run`` — the modular orchestrator.

The rule is simple and is the whole point of the design: **a module runs when
its inputs are present, and is skipped with a stated reason when they are not.**
A methylation-only project runs xam and spacem and stops; adding a second
condition switches dixam on; adding a DESeq2 table switches diem on; adding a
contact matrix switches hicam on.  Nothing has to be commented out or rerun.

Dependency graph
----------------
    modbam (and no bedMethyl)                    -> pileup -> methylation
    annotation + methylation                     -> xam
    annotation + methylation x2 (or replicates)  -> dixam
    annotation + reference + methylation         -> spacem
    reference + methylation                      -> discover  (when no motif list)
    annotation + reference + methylation + motifs-> mematch
    annotation + reference + motifs              -> mtase
    modbam                                       -> phase
    expression + xam output [+ dixam output]     -> diem
    hi-c [+ any other layer]                     -> hicam
    reference + annotation + methylation + R     -> roundtable.R
    any module output                            -> harmonise -> evidence -> report
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from .logging_utils import get_logger, reset_ledger

logger = get_logger("run")


@dataclass
class Step:
    name: str
    reason_skipped: str = ""
    argv: list[str] = field(default_factory=list)
    status: str = "pending"
    seconds: float = 0.0
    error: str = ""


def load_config(path: str | Path) -> dict:
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in (".yaml", ".yml"):
        try:
            import yaml
        except ImportError:
            raise SystemExit("[FATAL] reading a YAML config needs PyYAML "
                             "(`pip install pyyaml`), or use a JSON config.") from None
        cfg = yaml.safe_load(text)
    else:
        cfg = json.loads(text)
    if not isinstance(cfg, dict):
        raise SystemExit(f"[FATAL] {path}: config must be a mapping.")
    base = path.parent

    def fix(value):
        if isinstance(value, str) and value and not value.startswith("-"):
            p = (base / value)
            return str(p) if p.exists() else value
        if isinstance(value, dict):
            return {k: fix(v) for k, v in value.items()}
        if isinstance(value, list):
            return [fix(v) for v in value]
        return value

    for key in ("annotation", "reference", "methylation", "motifs", "expression",
                "hic", "hic_bins", "hic2", "modbam", "seqid_map", "dm_table"):
        if key in cfg:
            cfg[key] = fix(cfg[key])
    return cfg


def _opts(cfg: dict, tool: str) -> list[str]:
    """Extra CLI flags for one tool, from ``options: {tool: {...}}``."""
    out: list[str] = []
    for k, v in (cfg.get("options", {}) or {}).get(tool, {}).items():
        flag = "--" + str(k).replace("_", "-")
        if isinstance(v, bool):
            if v:
                out.append(flag)
        elif isinstance(v, (list, tuple)):
            out.append(flag); out += [str(x) for x in v]
        else:
            out += [flag, str(v)]
    return out


def _methylation_entries(cfg: dict) -> list[tuple[str, list[str]]]:
    """(condition label, replicate paths). A list under one label is replicates."""
    m = cfg.get("methylation")
    if not m:
        return []
    if isinstance(m, str):
        return [("sample", [m])]
    if isinstance(m, list):
        return [(f"cond{i + 1}", [str(v)]) for i, v in enumerate(m)]
    out = []
    for k, v in m.items():
        paths = [str(x) for x in v] if isinstance(v, (list, tuple)) else [str(v)]
        out.append((str(k), paths))
    return out


def _modbam_entries(cfg: dict) -> list[tuple[str, list[str]]]:
    """(condition label, BAM paths). Same shape as ``methylation``."""
    m = cfg.get("modbam")
    if not m:
        return []
    if isinstance(m, str):
        return [("sample", [m])]
    if isinstance(m, list):
        return [(f"cond{i + 1}", [str(v)]) for i, v in enumerate(m)]
    out = []
    for k, v in m.items():
        paths = [str(x) for x in v] if isinstance(v, (list, tuple)) else [str(v)]
        out.append((str(k), paths))
    return out


def _pileup_outputs(outdir: Path, prefix: str, bams: list[str],
                    gzipped: bool = False) -> list[str]:
    """Where ``merlin pileup`` will put its bedMethyl, computed before it runs.

    The planner has to name these paths so the downstream steps can be built in
    one pass; keeping the rule here and in ``tools/pileup.py`` identical is what
    makes ``--dry-run`` an honest preview.
    """
    suffix = "bedmethyl.bed.gz" if gzipped else "bedmethyl.bed"
    base = outdir / "pileup"
    if len(bams) == 1:
        return [str(base / f"{prefix}.{suffix}")]
    return [str(base / f"{prefix}.{Path(b).stem}.{suffix}") for b in bams]


def plan(cfg: dict) -> list[Step]:
    outdir = Path(cfg.get("outdir", "merlin_results"))
    prefix = str(cfg.get("prefix", "sample"))
    ann = cfg.get("annotation")
    ref = cfg.get("reference")
    motifs = cfg.get("motifs")
    expr = cfg.get("expression")
    hic = cfg.get("hic")
    meths = _methylation_entries(cfg)

    shared: list[str] = []
    if cfg.get("seqid_map"):
        shared += ["--seqid-map", str(cfg["seqid_map"])]
    if cfg.get("strip_version"):
        shared.append("--strip-version")
    if cfg.get("mod_codes"):
        shared += ["--mod-codes", str(cfg["mod_codes"])]
    if cfg.get("min_coverage") is not None:
        shared += ["--min-coverage", str(cfg["min_coverage"])]
    if cfg.get("min_frac") is not None:
        shared += ["--min-frac", str(cfg["min_frac"])]

    steps: list[Step] = []

    # ---- pileup (modBAM -> bedMethyl, when no bedMethyl was supplied) -----
    modbams = _modbam_entries(cfg)
    gz = bool((cfg.get("options", {}) or {}).get("pileup", {}).get("gzip"))
    if modbams and not meths:
        for label, bams in modbams:
            pfx = f"{prefix}.{label}"
            produced = _pileup_outputs(outdir, pfx, bams, gzipped=gz)
            steps.append(Step(
                name=f"pileup[{label}]",
                argv=["--modbam", *bams, "-o", str(outdir / "pileup"),
                      "--prefix", pfx]
                     + (["--fasta", ref] if ref else [])
                     + _opts(cfg, "pileup")))
            meths.append((label, produced))
    elif modbams:
        steps.append(Step("pileup", reason_skipped=(
            "methylation calls were supplied, so the modBAM is used only by "
            "'phase'")))
    else:
        steps.append(Step("pileup", reason_skipped=(
            "needs a modBAM with MM/ML tags")))

    # ---- xam (once per condition) ---------------------------------------
    if ann and meths:
        for label, paths in meths:
            steps.append(Step(
                name=f"xam[{label}]",
                argv=["-g", ann, "--methylation", *paths,
                      "-o", str(outdir / "xam"), "--prefix", f"{prefix}.{label}",
                      "--include-zero", "--no-split"]
                     + (["--fasta", ref] if ref else []) + shared + _opts(cfg, "xam")))
    else:
        steps.append(Step("xam", reason_skipped="needs an annotation and methylation"))

    # ---- dixam -----------------------------------------------------------
    if ann and len(meths) >= 2:
        (c_lab, c_paths), (t_lab, t_paths) = meths[0], meths[1]
        steps.append(Step(
            name="dixam",
            argv=["-g", ann, "--methylation", *c_paths,
                  "--methylation2", *t_paths,
                  "--labels", c_lab, t_lab, "-o", str(outdir / "dixam"),
                  "--prefix", prefix, "--no-split"]
                 + (["--fasta", ref] if ref else []) + shared + _opts(cfg, "dixam")))
        if len(meths) > 2:
            logger.warning("dixam compares two conditions; %d were configured, using "
                           "'%s' vs '%s'.", len(meths), c_lab, t_lab)
    else:
        steps.append(Step("dixam", reason_skipped=(
            "needs two methylation inputs (a control and a treatment)")))

    # ---- spacem ----------------------------------------------------------
    if ann and ref and meths:
        steps.append(Step(
            name="spacem",
            argv=["-g", ann, "--fasta", ref, "--methylation", *meths[0][1],
                  "-o", str(outdir / "spacem"), "--prefix", prefix, "--plots"]
                 + (["--motifs", motifs] if motifs else [])
                 + shared + _opts(cfg, "spacem")))
    else:
        steps.append(Step("spacem", reason_skipped=(
            "needs an annotation, a reference FASTA and methylation")))

    # ---- discover (only when no motif list was supplied) -----------------
    discovered = outdir / "discover" / f"{prefix}.motifs.txt"
    if ref and meths and not motifs:
        steps.append(Step(
            name="discover",
            argv=["--fasta", ref, "--methylation", *meths[0][1],
                  "-o", str(outdir / "discover"), "--prefix", prefix, "--plots"]
                 + shared + _opts(cfg, "discover")))
        motifs_for_downstream = str(discovered)
    else:
        steps.append(Step("discover", reason_skipped=(
            "a motif list was supplied, so nothing needs discovering"
            if motifs else "needs a reference FASTA and methylation")))
        motifs_for_downstream = motifs

    # ---- mematch ---------------------------------------------------------
    motifs_planned = motifs_for_downstream
    if ann and ref and meths and motifs_planned:
        steps.append(Step(
            name="mematch",
            argv=["-g", ann, "--fasta", ref, "--methylation", meths[0][1][0],
                  "--motifs", motifs_planned, "-o", str(outdir / "mematch"),
                  "--prefix", prefix, "--plots", "--fisher"]
                 + shared + _opts(cfg, "mematch")))
    else:
        steps.append(Step("mematch", reason_skipped=(
            "needs an annotation, a reference FASTA, methylation and motifs "
            "(supplied or discoverable)")))

    # ---- diem ------------------------------------------------------------
    if expr and ann and meths:
        pooled = len(meths[0][1]) > 1
        xam_out = (outdir / "xam" /
                   (f"{prefix}.{meths[0][0]}.pooled.by_feature.tsv" if pooled
                    else f"{prefix}.{meths[0][0]}.by_feature.tsv"))
        argv = ["--geneexp", expr, "--methylation", str(xam_out),
                "--outdir", str(outdir / "diem"), "--prefix", prefix]
        if len(meths) >= 2:
            argv += ["--dm-table", str(outdir / "dixam" / f"{prefix}.differential.tsv")]
        steps.append(Step(name="diem", argv=argv + _opts(cfg, "diem")))
    else:
        steps.append(Step("diem", reason_skipped=(
            "needs a differential expression table plus xam output")))

    # ---- hicam -----------------------------------------------------------
    if hic:
        argv = ["--hic", str(hic), "-o", str(outdir / "hicam"), "--prefix", prefix,
                "--plots"]
        if cfg.get("hic_bins"):
            argv += ["--hic-bins", str(cfg["hic_bins"])]
        if cfg.get("resolution"):
            argv += ["--resolution", str(cfg["resolution"])]
        if ann:
            argv += ["-g", ann]
        if ref:
            argv += ["--fasta", ref]
        if meths:
            argv += ["--methylation", meths[0][1][0]]
        if expr:
            argv += ["--geneexp", expr]
        if len(meths) >= 2:
            argv += ["--dm-table", str(outdir / "dixam" / f"{prefix}.differential.tsv")]
        steps.append(Step(name="hicam", argv=argv + shared + _opts(cfg, "hicam")))
    else:
        steps.append(Step("hicam", reason_skipped="needs a Hi-C contact matrix"))

    # ---- mtase -----------------------------------------------------------
    if ann and ref and motifs_for_downstream:
        argv = ["-g", ann, "--fasta", ref, "--motifs", str(motifs_for_downstream),
                "-o", str(outdir / "mtase"), "--prefix", prefix]
        if meths:
            argv += ["--methylation", meths[0][1][0]]
        if len(meths) >= 2:
            argv += ["--methylation2", meths[1][1][0],
                     "--knockout-gene", str(cfg.get("knockout_gene", ""))]
        steps.append(Step(name="mtase", argv=argv + shared + _opts(cfg, "mtase")))
    else:
        steps.append(Step("mtase", reason_skipped=(
            "needs an annotation, a reference FASTA and a motif list")))

    # ---- phase (read level) ----------------------------------------------
    modbam = modbams[0][1][0] if modbams else None
    if modbam:
        argv = ["--modbam", str(modbam), "-o", str(outdir / "phase"),
                "--prefix", prefix, "--plots"]
        if ann:
            argv += ["-g", ann]
        if ref:
            argv += ["--fasta", ref]
        if motifs_for_downstream:
            argv += ["--motifs", str(motifs_for_downstream)]
        steps.append(Step(name="phase", argv=argv + _opts(cfg, "phase")))
    else:
        steps.append(Step("phase", reason_skipped=(
            "needs an aligned modBAM with MM/ML tags")))

    # ---- roundtable.R ----------------------------------------------------
    if ann and ref and meths and shutil.which("Rscript"):
        script = Path(__file__).resolve().parent.parent.parent / "scripts" / "roundtable.R"
        if script.exists():
            steps.append(Step(
                name="roundtable",
                argv=["--gff", ann, "--fasta", ref, "--methylation", meths[0][1][0],
                      "--out", str(outdir / "roundtable" / f"{prefix}.circos.pdf")]
                     + (["--motifs", motifs] if motifs else [])
                     + _opts(cfg, "roundtable")))
        else:
            steps.append(Step("roundtable", reason_skipped="roundtable.R not found"))
    elif not shutil.which("Rscript"):
        steps.append(Step("roundtable", reason_skipped="Rscript is not on PATH"))
    else:
        steps.append(Step("roundtable", reason_skipped=(
            "needs an annotation, a reference FASTA and methylation")))

    # ---- harmonise / evidence / report -----------------------------------
    if cfg.get("harmonise", True):
        argv = ["--results", str(outdir), "-o", str(outdir),
                "--prefix", prefix, "--export-tsv"]
        if ann:
            argv += ["--gff", ann]
        steps.append(Step(name="harmonise", argv=argv + _opts(cfg, "harmonise")))
        store = outdir / f"{prefix}.merlin_store.h5"
        # evidence needs at least one scoreable layer; without one it would only
        # re-rank a single column, so it is skipped with a reason rather than
        # failing the run.
        scoreable = [s.name for s in steps
                     if s.name in ("dixam", "diem", "mematch", "hicam")
                     and not s.reason_skipped]
        if scoreable:
            steps.append(Step(
                name="evidence",
                argv=["--store", str(store), "-o", str(outdir), "--prefix", prefix,
                      "--plots"] + _opts(cfg, "evidence")))
        else:
            steps.append(Step("evidence", reason_skipped=(
                "no scoreable layer: needs at least one of dixam, diem, mematch "
                "or hicam to have run")))
        steps.append(Step(
            name="report",
            argv=["--results", str(outdir), "--store", str(store),
                  "-o", str(outdir), "--prefix", prefix] + _opts(cfg, "report")))
    else:
        for name in ("harmonise", "evidence", "report"):
            steps.append(Step(name, reason_skipped="disabled in the config"))
    return steps


def execute(steps: list[Step], dry_run: bool = False,
            keep_going: bool = False) -> int:
    from .tools import (diem, discover, dixam, evidence, harmonise, hicam,
                        mematch, mtase, phase, pileup, report, spacem, xam)

    entry = {"pileup": pileup.main, "xam": xam.main, "dixam": dixam.main, "spacem": spacem.main,
             "mematch": mematch.main, "diem": diem.main, "hicam": hicam.main,
             "discover": discover.main, "mtase": mtase.main, "phase": phase.main,
             "harmonise": harmonise.main, "evidence": evidence.main,
             "report": report.main}
    failures = 0
    for step in steps:
        base = step.name.split("[")[0]
        if step.reason_skipped:
            step.status = "skipped"
            logger.info("SKIP  %-12s — %s", step.name, step.reason_skipped)
            continue
        if dry_run:
            step.status = "planned"
            logger.info("PLAN  %-12s %s", step.name,
                        " ".join(str(a) for a in step.argv))
            continue
        logger.info("RUN   %-12s", step.name)
        t0 = time.time()
        try:
            reset_ledger()
            if base == "roundtable":
                script = (Path(__file__).resolve().parent.parent.parent
                          / "scripts" / "roundtable.R")
                Path(step.argv[step.argv.index("--out") + 1]).parent.mkdir(
                    parents=True, exist_ok=True)
                proc = subprocess.run(["Rscript", str(script)] + step.argv,
                                      capture_output=True, text=True)
                if proc.returncode != 0:
                    raise RuntimeError(proc.stderr.strip()[-800:] or "Rscript failed")
            else:
                rc = entry[base]([str(a) for a in step.argv])
                if rc:
                    raise RuntimeError(f"exit code {rc}")
            step.status = "ok"
        except SystemExit as exc:
            step.status = "failed"
            step.error = str(exc.code)
            failures += 1
        except Exception as exc:                     # noqa: BLE001
            step.status = "failed"
            step.error = f"{type(exc).__name__}: {exc}"
            failures += 1
        step.seconds = time.time() - t0
        if step.status == "failed":
            logger.error("FAIL  %-12s — %s", step.name, step.error)
            if not keep_going:
                logger.error("Stopping. Rerun with --keep-going to continue past "
                             "a failed module.")
                break
        else:
            logger.info("DONE  %-12s (%.1fs)", step.name, step.seconds)
    return failures


def report(steps: list[Step], outdir: Path) -> Path:
    lines = ["MErlin run report", "=" * 60, ""]
    for s in steps:
        if s.status == "skipped":
            lines.append(f"  SKIPPED  {s.name:<14} {s.reason_skipped}")
        elif s.status == "ok":
            lines.append(f"  OK       {s.name:<14} {s.seconds:6.1f}s")
        elif s.status == "failed":
            lines.append(f"  FAILED   {s.name:<14} {s.error}")
        elif s.status == "planned":
            lines.append(f"  PLANNED  {s.name:<14} "
                         + " ".join(str(a) for a in s.argv))
        else:
            lines.append(f"  {s.status.upper():<8} {s.name}")
    lines += ["", "Skipped modules are not failures: MErlin runs whatever the "
                  "supplied inputs support."]
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "merlin_run_report.txt"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n" + "\n".join(lines) + "\n")
    return path


def run(config_path: str, dry_run: bool = False, keep_going: bool = False,
        only: list[str] | None = None) -> int:
    cfg = load_config(config_path)
    steps = plan(cfg)
    if only:
        wanted = set(only)
        for s in steps:
            if s.name.split("[")[0] not in wanted and not s.reason_skipped:
                s.reason_skipped = "not selected with --only"
    failures = execute(steps, dry_run=dry_run, keep_going=keep_going)
    report(steps, Path(cfg.get("outdir", "merlin_results")))
    return 1 if failures else 0
