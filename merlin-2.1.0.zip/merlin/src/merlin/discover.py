"""De novo motif discovery from methylation calls (ROADMAP 3.3).

Motifs were user-supplied, so MErlin could only confirm what you already
suspected.  A strain with an uncharacterised MTase — which is most strains —
would show nothing, and the absence would look like a result.

The method here is the one the data supports and no more: methylated positions
are aligned on their modified base, flanks are extracted strand-aware, and the
composition of the flanking positions is compared with a background of the same
canonical base that was assayed but not methylated.  Where an MTase recognises a
motif, that comparison is overwhelming and needs nothing cleverer.

Seeds first, consensus second.  Exact k-mers around the centre are ranked by
enrichment, non-redundant seeds are taken greedily, and each seed's flanks are
turned into an IUPAC consensus by thresholding per-position frequencies.  The
seeding step is what lets two MTases in one genome come out as two motifs rather
than as one smeared consensus.

Output is a motif file ``mematch`` and ``spacem`` can read directly, offsets
included.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("discover")

COMPLEMENT = str.maketrans("ACGTN", "TGCAN")

# Which canonical base each modification sits on, plus strand-aware complement
MOD_BASE = {"m": "C", "h": "C", "f": "C", "c": "C", "e": "C", "21839": "C",
            "a": "A", "g": "G", "b": "T"}

# IUPAC lookup: frozenset of bases -> code
_IUPAC = {
    frozenset("A"): "A", frozenset("C"): "C", frozenset("G"): "G",
    frozenset("T"): "T",
    frozenset("AG"): "R", frozenset("CT"): "Y", frozenset("GC"): "S",
    frozenset("AT"): "W", frozenset("GT"): "K", frozenset("AC"): "M",
    frozenset("CGT"): "B", frozenset("AGT"): "D", frozenset("ACT"): "H",
    frozenset("ACG"): "V", frozenset("ACGT"): "N",
}


@dataclass
class DiscoveredMotif:
    motif: str
    offset: int
    mod_code: str
    n_sites: int
    enrichment: float
    information_bits: float
    seed: str = ""
    pwm: np.ndarray | None = None
    note: str = ""

    def as_line(self) -> str:
        return f"{self.motif}\t{self.offset}"


# --------------------------------------------------------------------------- #
def _flanks(genome, seqid_arr, pos_arr, strand_arr, half: int):
    """Strand-aware sequence windows centred on each position, as byte codes."""
    out = []
    width = 2 * half + 1
    for seqid in np.unique(seqid_arr):
        seq = genome.get(seqid)
        if seq is None:
            continue
        L = len(seq)
        sel = np.flatnonzero(seqid_arr == seqid)
        for i in sel:
            p = int(pos_arr[i])
            s = p - half
            e = p + half + 1
            if s < 0 or e > L:                       # circular wrap
                idx = [(j % L) for j in range(s, e)]
                window = "".join(seq[j] for j in idx)
            else:
                window = seq[s:e]
            if len(window) != width or "N" in window:
                continue
            if strand_arr[i] == "-":
                window = window.translate(COMPLEMENT)[::-1]
            out.append(window)
    if not out:
        return np.empty((0, width), dtype="U1")
    return np.array([list(w) for w in out], dtype="U1")


def _background_positions(genome, base: str, n_wanted: int, exclude, rng):
    """Random genomic positions of the canonical base, avoiding the foreground."""
    seqids, positions, strands = [], [], []
    letters = {"+": base, "-": base.translate(COMPLEMENT)}
    total = sum(len(s) for s in genome.values()) or 1
    for seqid, seq in genome.items():
        arr = np.frombuffer(seq.encode("ascii", "ignore"), dtype=np.uint8)
        share = max(int(n_wanted * len(seq) / total), 1)
        for strand, letter in letters.items():
            cand = np.flatnonzero(arr == ord(letter))
            if cand.size == 0:
                continue
            banned = exclude.get((seqid, strand))
            if banned is not None and banned.size:
                cand = cand[~np.isin(cand, banned, assume_unique=False)]
            if cand.size == 0:
                continue
            take = min(share, cand.size)
            pick = rng.choice(cand, size=take, replace=False)
            seqids += [seqid] * take
            positions += pick.tolist()
            strands += [strand] * take
    return (np.array(seqids, dtype=object), np.array(positions, dtype=np.int64),
            np.array(strands, dtype=object))


def _kmer_counts(flanks: np.ndarray, k: int, centre: int) -> Counter:
    """Exact k-mers in every window that covers the centre position."""
    counts: Counter = Counter()
    width = flanks.shape[1]
    starts = range(max(0, centre - k + 1), min(centre + 1, width - k + 1))
    for s in starts:
        block = flanks[:, s:s + k]
        for row in block:
            counts["".join(row) + f"@{s - centre}"] += 1
    return counts


_IUPAC_SET = {code: set(bases) for bases, code in
              ((b, c) for b, c in ((("".join(sorted(k)), v))
                                   for k, v in _IUPAC.items()))}


def _matches_consensus(flanks: np.ndarray, motif: str, offset: int,
                       centre: int) -> np.ndarray:
    """Which flanks contain ``motif`` with its modified base at the centre."""
    start = centre - offset
    if start < 0 or start + len(motif) > flanks.shape[1]:
        return np.zeros(flanks.shape[0], dtype=bool)
    ok = np.ones(flanks.shape[0], dtype=bool)
    for j, code in enumerate(motif):
        allowed = _IUPAC_SET.get(code, {"A", "C", "G", "T"})
        col = flanks[:, start + j]
        hit = np.zeros(flanks.shape[0], dtype=bool)
        for b in allowed:
            hit |= (col == b)
        ok &= hit
    return ok


def _pwm_for(flanks: np.ndarray, motif: str, offset: int, centre: int):
    """Base frequencies over exactly the motif's span, so the logo matches it."""
    start = centre - offset
    bases = "ACGT"
    width = len(motif)
    pwm = np.full((width, 4), 0.25)
    if start < 0 or start + width > flanks.shape[1] or flanks.shape[0] == 0:
        return pwm
    block = flanks[:, start:start + width]
    for j, b in enumerate(bases):
        pwm[:, j] = (block == b).sum(axis=0)
    totals = pwm.sum(axis=1, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(totals > 0, pwm / np.maximum(totals, 1), 0.25)


def _score(fg, bg, motif, offset, centre):
    """(matching foreground flanks, enrichment over background) for one motif."""
    f = int(_matches_consensus(fg, motif, offset, centre).sum())
    b = int(_matches_consensus(bg, motif, offset, centre).sum())
    enr = ((f + 1) / (fg.shape[0] + 1)) / ((b + 1) / (bg.shape[0] + 1))
    return f, float(enr)


_SUPERSETS = {}
for _code, _bases in list(_IUPAC_SET.items()):
    _SUPERSETS[_code] = sorted(
        {c for c, bset in _IUPAC_SET.items()
         if _bases < bset and len(bset) == len(_bases) + 1})


def _refine(fg, bg, motif: str, offset: int, centre: int,
            enrichment_floor: float, max_steps: int = 12):
    """Grow the motif to explain as many calls as possible while staying enriched.

    A k-mer seed fixes its own flanking bases — they are conserved *because they
    were selected on*, not because the MTase cares — so consensus-from-the-seed
    returns GATCG for Dam and four separate motifs for GANTC.  Here the seed is
    instead relaxed greedily: at each step, try trimming an end or degenerating
    one position, and accept whichever change explains the most methylated sites
    while keeping enrichment above the floor.  GATCG loses its G; GAGTC, GATTC,
    GAATC and GACTC collapse into GANTC.
    """
    best_f, best_e = _score(fg, bg, motif, offset, centre)
    for _ in range(max_steps):
        candidates = []
        if offset > 0:                                   # trim the left end
            candidates.append((motif[1:], offset - 1))
        if len(motif) - 1 > offset:                      # trim the right end
            candidates.append((motif[:-1], offset))
        for i, code in enumerate(motif):                 # degenerate one position
            if i == offset:
                continue                                 # never blur the mod base
            for wider in _SUPERSETS.get(code, []):
                candidates.append((motif[:i] + wider + motif[i + 1:], offset))

        improved = None
        for cand, coff in candidates:
            if len(cand) < 2:
                continue
            f, e = _score(fg, bg, cand, coff, centre)
            if e < enrichment_floor or f <= best_f:
                continue
            if improved is None or f > improved[2]:
                improved = (cand, coff, f, e)
        if improved is None:
            break
        motif, offset, best_f, best_e = improved
    return motif, offset, best_f, best_e


def _consensus(flanks: np.ndarray, centre: int, min_freq: float,
               ic_threshold: float):
    """IUPAC consensus and its offset, trimmed to the informative window."""
    width = flanks.shape[1]
    bases = "ACGT"
    pwm = np.zeros((width, 4))
    for j, b in enumerate(bases):
        pwm[:, j] = (flanks == b).sum(axis=0)
    totals = pwm.sum(axis=1, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        freq = np.where(totals > 0, pwm / np.maximum(totals, 1), 0.25)
    with np.errstate(divide="ignore", invalid="ignore"):
        ic = 2.0 + np.sum(np.where(freq > 0, freq * np.log2(freq), 0.0), axis=1)

    informative = ic >= ic_threshold
    informative[centre] = True
    lo = centre
    while lo - 1 >= 0 and informative[lo - 1]:
        lo -= 1
    hi = centre
    while hi + 1 < width and informative[hi + 1]:
        hi += 1

    codes = []
    for i in range(lo, hi + 1):
        chosen = {bases[j] for j in range(4) if freq[i, j] >= min_freq}
        if not chosen:
            chosen = {bases[int(np.argmax(freq[i]))]}
        codes.append(_IUPAC.get(frozenset(chosen), "N"))
    return "".join(codes), centre - lo, float(ic[lo:hi + 1].sum()), freq[lo:hi + 1]


# --------------------------------------------------------------------------- #
def discover_motifs(genome, methyl, mod_code: str, half: int = 8,
                    seed_k: int = 5, max_motifs: int = 4,
                    min_enrichment: float = 10.0, min_sites: int = 50,
                    min_freq: float = 0.15, ic_threshold: float = 0.5,
                    background_multiple: int = 3, seed: int = 0
                    ) -> list[DiscoveredMotif]:
    """Find the motifs a modification actually sits in."""
    rng = np.random.default_rng(seed)
    sel = np.flatnonzero(methyl.mod == mod_code)
    if sel.size < min_sites:
        warn_once(logger, f"DISCOVER_FEW_{mod_code}",
                  f"Only {sel.size} call(s) for modification {mod_code!r}; "
                  f"{min_sites} are needed before a motif can be claimed.")
        return []

    fg = _flanks(genome, methyl.seqid[sel], methyl.pos[sel], methyl.strand[sel], half)
    if fg.shape[0] < min_sites:
        return []

    exclude: dict[tuple[str, str], np.ndarray] = {}
    for seqid in np.unique(methyl.seqid[sel]):
        for strand in ("+", "-"):
            m = sel[(methyl.seqid[sel] == seqid) & (methyl.strand[sel] == strand)]
            if m.size:
                exclude[(seqid, strand)] = np.unique(methyl.pos[m])

    base = MOD_BASE.get(mod_code, "A")
    bg_ids, bg_pos, bg_strand = _background_positions(
        genome, base, fg.shape[0] * background_multiple, exclude, rng)
    bg = _flanks(genome, bg_ids, bg_pos, bg_strand, half)
    if bg.shape[0] < 50:
        warn_once(logger, f"DISCOVER_NO_BG_{mod_code}",
                  f"Could not build a background of unmethylated {base} positions "
                  f"for {mod_code!r}; enrichment values are unreliable.")
        return []

    centre = half
    fg_counts = _kmer_counts(fg, seed_k, centre)
    bg_counts = _kmer_counts(bg, seed_k, centre)
    n_fg, n_bg = fg.shape[0], bg.shape[0]

    scored = []
    for key, c_fg in fg_counts.items():
        if c_fg < min_sites * 0.2:
            continue
        c_bg = bg_counts.get(key, 0)
        # Laplace pseudocount, not an epsilon: a k-mer absent from the background
        # must not produce an enrichment of 10^11, which is what dividing by
        # 1e-9 does and which makes the ranking meaningless.
        enr = ((c_fg + 1) / (n_fg + 1)) / ((c_bg + 1) / (n_bg + 1))
        scored.append((enr, c_fg, key))
    scored.sort(reverse=True)

    out: list[DiscoveredMotif] = []
    claimed = np.zeros(n_fg, dtype=bool)
    for enr, c_fg, key in scored:
        if len(out) >= max_motifs or enr < min_enrichment:
            break
        kmer, off = key.split("@")
        off = int(off)
        s = centre + off
        block = fg[:, s:s + seed_k]
        matches = np.ones(n_fg, dtype=bool)
        for j, b in enumerate(kmer):
            matches &= (block[:, j] == b)
        fresh = matches & ~claimed
        if fresh.sum() < min_sites:
            continue
        # Refine against the *unclaimed* foreground only. Scoring against all of
        # it lets a later, more degenerate motif win by re-absorbing an earlier
        # motif's sites — which is how GATC and GANTC collapse into "GABY".
        avail = fg[~claimed]
        if avail.shape[0] < min_sites:
            continue
        floor = max(min_enrichment, enr * 0.5)
        cons, cons_off, n_match, cons_enr = _refine(avail, bg, kmer, -off, centre,
                                                    enrichment_floor=floor)
        if not cons or len(cons) < 2 or set(cons) == {"N"}:
            continue
        refined = _matches_consensus(fg, cons, cons_off, centre)
        if refined.sum() < min_sites:
            continue
        if any(m.motif == cons for m in out):
            claimed |= refined
            continue
        pwm = _pwm_for(fg[refined], cons, cons_off, centre)
        with np.errstate(divide="ignore", invalid="ignore"):
            bits = float(np.sum(2.0 + np.sum(
                np.where(pwm > 0, pwm * np.log2(pwm), 0.0), axis=1)))
        claimed |= refined
        fresh = refined
        enr = cons_enr
        out.append(DiscoveredMotif(
            motif=cons, offset=cons_off, mod_code=mod_code,
            n_sites=int(fresh.sum()), enrichment=float(enr),
            information_bits=bits, seed=kmer, pwm=pwm))

    if not out:
        # No seed cleared the bar: fall back to one ungapped consensus over
        # everything, which is the honest answer for a diffuse signal.
        cons, cons_off, bits, pwm = _consensus(fg, centre, min_freq, ic_threshold)
        if len(cons) >= 3 and set(cons) != {"N"}:
            out.append(DiscoveredMotif(
                motif=cons, offset=cons_off, mod_code=mod_code, n_sites=n_fg,
                enrichment=float("nan"), information_bits=bits, seed="",
                pwm=pwm, note="no k-mer seed passed the enrichment threshold; "
                              "this is the consensus over all calls"))
    coverage = float(claimed.sum() / n_fg) if n_fg else 0.0
    logger.info("Modification %s: %d motif(s) from %d call(s) "
                "(%.0f%% of calls assigned).", mod_code, len(out), n_fg,
                100 * coverage)
    return out


def write_motif_file(motifs: list[DiscoveredMotif], path) -> None:
    lines = ["# discovered by 'merlin discover' — verify before trusting",
             "# motif<TAB>0-based offset of the modified base"]
    for m in motifs:
        note = f"  # {m.mod_code}, n={m.n_sites}"
        if np.isfinite(m.enrichment):
            note += f", enrichment {m.enrichment:.1f}x"
        lines.append(m.as_line() + note)
    from pathlib import Path
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")
