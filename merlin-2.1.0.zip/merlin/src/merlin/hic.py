"""Hi-C contact matrix IO and primitives.

Readers
-------
``.cool`` / ``.mcool``
    Read through :mod:`cooler` when it is installed, otherwise directly from the
    HDF5 layout with :mod:`h5py`.  The native reader keeps the module usable in
    environments where cooler's build dependencies are unavailable, which is
    common on clusters.
HiC-Pro
    ``<prefix>.matrix`` (sparse ``bin1 bin2 count``, 1-based bin ids) plus
    ``<prefix>_abs.bed`` (``chrom start end bin_id``).
dense text
    A square whitespace-delimited matrix plus a bins BED.

Primitives implemented here rather than pulled from a Hi-C package, so the
module has no heavy dependency: iterative correction (ICE), distance-expected
normalisation with circular distances, compartment eigenvector, insulation
score and boundary calling.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("hic")


@dataclass
class ContactMap:
    """One replicon's contact matrix at a fixed resolution."""

    seqid: str
    resolution: int
    starts: np.ndarray
    matrix: np.ndarray            # raw or balanced counts, symmetric
    weights: np.ndarray | None = None
    circular: bool = True
    meta: dict = field(default_factory=dict)

    @property
    def n(self) -> int:
        return int(self.matrix.shape[0])

    @property
    def centers(self) -> np.ndarray:
        return self.starts + self.resolution // 2

    def coverage(self) -> np.ndarray:
        return np.nansum(self.matrix, axis=1)


# --------------------------------------------------------------------------- #
# Readers
# --------------------------------------------------------------------------- #
def _read_cool_h5(path: str, resolution: int | None):
    import h5py

    with h5py.File(path, "r") as f:
        grp = f
        if "resolutions" in f:
            available = sorted(int(k) for k in f["resolutions"])
            if resolution is None:
                resolution = available[0]
                logger.info("mcool: choosing the finest resolution %d bp (available: %s).",
                            resolution, available)
            if resolution not in available:
                raise SystemExit(f"[FATAL] resolution {resolution} not in the mcool "
                                 f"(available: {available}).")
            grp = f["resolutions"][str(resolution)]
        chrom_names = [n.decode() if isinstance(n, bytes) else str(n)
                       for n in grp["chroms"]["name"][:]]
        chrom_len = grp["chroms"]["length"][:]
        bin_chrom = grp["bins"]["chrom"][:]
        bin_start = grp["bins"]["start"][:]
        bin_end = grp["bins"]["end"][:]
        weight = grp["bins"]["weight"][:] if "weight" in grp["bins"] else None
        b1 = grp["pixels"]["bin1_id"][:]
        b2 = grp["pixels"]["bin2_id"][:]
        cnt = grp["pixels"]["count"][:].astype(np.float64)
    res = int(np.median(bin_end - bin_start)) if resolution is None else resolution
    return chrom_names, chrom_len, bin_chrom, bin_start, weight, b1, b2, cnt, res


def _read_cool_cooler(path: str, resolution: int | None):
    import cooler

    uri = path
    if resolution is not None and "::" not in path:
        uri = f"{path}::resolutions/{resolution}"
    try:
        clr = cooler.Cooler(uri)
    except (KeyError, OSError):
        clr = cooler.Cooler(path)
    bins = clr.bins()[:]
    pix = clr.pixels()[:]
    chrom_names = list(clr.chromnames)
    chrom_len = np.asarray([clr.chromsizes[c] for c in chrom_names])
    code = {c: i for i, c in enumerate(chrom_names)}
    bin_chrom = bins["chrom"].map(code).to_numpy()
    weight = bins["weight"].to_numpy() if "weight" in bins else None
    return (chrom_names, chrom_len, bin_chrom, bins["start"].to_numpy(), weight,
            pix["bin1_id"].to_numpy(), pix["bin2_id"].to_numpy(),
            pix["count"].to_numpy().astype(np.float64), int(clr.binsize))


def read_cool(path: str, resolution: int | None = None,
              apply_weights: bool = True) -> dict[str, ContactMap]:
    try:
        import cooler  # noqa: F401
        parts = _read_cool_cooler(path, resolution)
        backend = "cooler"
    except ImportError:
        parts = _read_cool_h5(path, resolution)
        backend = "h5py (native .cool reader)"
    (chrom_names, chrom_len, bin_chrom, bin_start, weight, b1, b2, cnt, res) = parts
    logger.info("Hi-C %s: %d chrom(s), %d pixels at %d bp [%s].",
                Path(path).name, len(chrom_names), cnt.size, res, backend)

    maps: dict[str, ContactMap] = {}
    for ci, name in enumerate(chrom_names):
        idx = np.flatnonzero(bin_chrom == ci)
        if idx.size == 0:
            continue
        lo, hi = idx.min(), idx.max()
        n = idx.size
        sel = (b1 >= lo) & (b1 <= hi) & (b2 >= lo) & (b2 <= hi)
        m = np.zeros((n, n), dtype=np.float64)
        i = (b1[sel] - lo).astype(np.int64)
        j = (b2[sel] - lo).astype(np.int64)
        v = cnt[sel]
        w = None
        if weight is not None and apply_weights:
            w = np.asarray(weight[idx], dtype=float)
            if np.isfinite(w).any():
                v = v * np.nan_to_num(w[i], nan=0.0) * np.nan_to_num(w[j], nan=0.0)
        np.add.at(m, (i, j), v)
        m = m + m.T - np.diag(np.diag(m))
        maps[name] = ContactMap(seqid=name, resolution=res,
                                starts=bin_start[idx].astype(np.int64), matrix=m,
                                weights=w, meta={"length": int(chrom_len[ci])})
    return maps


def read_hicpro(matrix_path: str, bed_path: str) -> dict[str, ContactMap]:
    import pandas as pd

    bins = pd.read_csv(bed_path, sep="\t", header=None,
                       names=["chrom", "start", "end", "bin_id"])
    pix = pd.read_csv(matrix_path, sep="\t", header=None,
                      names=["b1", "b2", "count"])
    res = int((bins["end"] - bins["start"]).median())
    id_to_row = {int(b): i for i, b in enumerate(bins["bin_id"])}
    maps = {}
    for chrom, sub in bins.groupby("chrom", sort=False):
        rows = {int(b): k for k, b in enumerate(sub["bin_id"])}
        n = len(sub)
        m = np.zeros((n, n))
        sel = pix[pix["b1"].isin(rows) & pix["b2"].isin(rows)]
        i = sel["b1"].map(rows).to_numpy()
        j = sel["b2"].map(rows).to_numpy()
        np.add.at(m, (i, j), sel["count"].to_numpy(dtype=float))
        m = m + m.T - np.diag(np.diag(m))
        maps[str(chrom)] = ContactMap(seqid=str(chrom), resolution=res,
                                      starts=sub["start"].to_numpy(dtype=np.int64),
                                      matrix=m)
    logger.info("Hi-C HiC-Pro: %d chrom(s) at %d bp.", len(maps), res)
    return maps


def read_dense(matrix_path: str, bed_path: str | None,
               seqid: str = "chromosome", resolution: int | None = None
               ) -> dict[str, ContactMap]:
    m = np.loadtxt(matrix_path, dtype=float)
    if m.ndim != 2 or m.shape[0] != m.shape[1]:
        raise SystemExit(f"[FATAL] {matrix_path}: expected a square matrix, "
                         f"got shape {m.shape}.")
    if bed_path:
        import pandas as pd
        bins = pd.read_csv(bed_path, sep="\t", header=None, comment="#",
                           usecols=[0, 1, 2], names=["chrom", "start", "end"])
        if len(bins) != m.shape[0]:
            raise SystemExit(f"[FATAL] bins file has {len(bins)} rows but the matrix "
                             f"is {m.shape[0]}x{m.shape[0]}.")
        res = int((bins["end"] - bins["start"]).median())
        out = {}
        for chrom, sub in bins.groupby("chrom", sort=False):
            idx = sub.index.to_numpy()
            out[str(chrom)] = ContactMap(str(chrom), res,
                                         sub["start"].to_numpy(dtype=np.int64),
                                         m[np.ix_(idx, idx)])
        return out
    if resolution is None:
        raise SystemExit("[FATAL] a dense matrix without a bins file needs "
                         "--resolution.")
    starts = np.arange(m.shape[0], dtype=np.int64) * resolution
    return {seqid: ContactMap(seqid, resolution, starts, m)}


def load_contacts(args) -> dict[str, ContactMap]:
    if getattr(args, "hic", None):
        p = str(args.hic)
        if p.endswith((".cool", ".mcool")) or "::" in p:
            return read_cool(p, args.resolution, apply_weights=not args.no_balance)
        if p.endswith(".matrix"):
            bed = args.hic_bins or p.replace(".matrix", "_abs.bed")
            return read_hicpro(p, bed)
        return read_dense(p, args.hic_bins, resolution=args.resolution)
    raise SystemExit("[FATAL] --hic is required.")


# --------------------------------------------------------------------------- #
# Normalisation
# --------------------------------------------------------------------------- #
def ice(matrix: np.ndarray, n_iter: int = 50, min_marginal_quantile: float = 0.02,
        tol: float = 1e-5) -> tuple[np.ndarray, np.ndarray]:
    """Iterative correction to equal marginals.

    Bins whose raw marginal falls below ``min_marginal_quantile`` are masked
    (set to NaN) rather than being driven to extreme bias values, which is what
    makes ICE unstable on sparse bacterial maps.
    """
    m = np.array(matrix, dtype=float, copy=True)
    n = m.shape[0]
    raw_marg = np.nansum(m, axis=1)
    nz = raw_marg[raw_marg > 0]
    cut = np.quantile(nz, min_marginal_quantile) if nz.size else 0.0
    mask = raw_marg > max(cut, 0)
    bias = np.ones(n)
    m[~mask, :] = np.nan
    m[:, ~mask] = np.nan
    for _ in range(n_iter):
        marg = np.nansum(m, axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            scale = marg / np.nanmean(marg[mask])
        scale[~mask] = 1.0
        scale[scale == 0] = 1.0
        bias *= scale
        m /= scale[:, None]
        m /= scale[None, :]
        if np.nanmax(np.abs(scale[mask] - 1)) < tol:
            break
    return m, mask


def observed_over_expected(matrix: np.ndarray, circular: bool = True
                           ) -> tuple[np.ndarray, np.ndarray]:
    """Divide by the mean contact at the same genomic separation.

    On a circular replicon the separation between bins i and j is
    ``min(|i-j|, n-|i-j|)``; using the linear separation makes the two ends of
    the array look artificially distant and produces a spurious gradient in
    every downstream track.
    """
    m = np.array(matrix, dtype=float, copy=True)
    n = m.shape[0]
    ii = np.arange(n)
    d = np.abs(ii[:, None] - ii[None, :])
    if circular:
        d = np.minimum(d, n - d)
    max_d = int(d.max())
    expected = np.full(max_d + 1, np.nan)
    for k in range(max_d + 1):
        vals = m[d == k]
        vals = vals[np.isfinite(vals)]
        if vals.size:
            expected[k] = vals.mean()
    with np.errstate(invalid="ignore", divide="ignore"):
        oe = m / expected[d]
    return oe, expected


def compartment_eigenvector(oe: np.ndarray, orient_by: np.ndarray | None = None
                            ) -> tuple[np.ndarray, float]:
    """PC1 of the O/E correlation matrix, sign-oriented by a covariate.

    The eigenvector's sign is arbitrary, so "compartment A" is meaningless until
    it is anchored to something.  ``orient_by`` (GC content, or gene density when
    no reference is available) fixes it; the returned float is the correlation
    used, so a near-zero value warns that the orientation is a coin flip.
    """
    n = oe.shape[0]
    valid = np.isfinite(oe).sum(axis=1) > n * 0.5
    sub = oe[np.ix_(valid, valid)]
    sub = np.nan_to_num(sub, nan=1.0, posinf=1.0, neginf=1.0)
    with np.errstate(invalid="ignore"):
        corr = np.corrcoef(sub)
    corr = np.nan_to_num(corr, nan=0.0)
    corr -= corr.mean(axis=0, keepdims=True)
    try:
        _u, _s, vt = np.linalg.svd(corr, full_matrices=False)
        pc = vt[0]
    except np.linalg.LinAlgError:  # pragma: no cover
        return np.full(n, np.nan), float("nan")
    out = np.full(n, np.nan)
    out[valid] = pc
    r = float("nan")
    if orient_by is not None:
        ok = valid & np.isfinite(orient_by)
        if ok.sum() > 3 and np.std(orient_by[ok]) > 0 and np.std(out[ok]) > 0:
            r = float(np.corrcoef(out[ok], orient_by[ok])[0, 1])
            if r < 0:
                out = -out
                r = -r
    return out, r


def insulation_score(matrix: np.ndarray, window_bins: int = 5,
                     circular: bool = True) -> np.ndarray:
    """Log2 mean contact in a diamond of ``window_bins`` either side of each bin.

    Low values mark positions that few contacts cross — domain (CID) boundaries.
    """
    m = np.array(matrix, dtype=float)
    n = m.shape[0]
    w = max(1, min(window_bins, n // 4))
    out = np.full(n, np.nan)
    idx = np.arange(n)
    for i in range(n):
        left = idx[(i - w):i] if not circular else np.mod(np.arange(i - w, i), n)
        right = (idx[i + 1:i + 1 + w] if not circular
                 else np.mod(np.arange(i + 1, i + 1 + w), n))
        if left.size == 0 or right.size == 0:
            continue
        block = m[np.ix_(left, right)]
        vals = block[np.isfinite(block)]
        if vals.size:
            out[i] = vals.mean()
    with np.errstate(invalid="ignore", divide="ignore"):
        norm = out / np.nanmean(out)
        return np.log2(np.where(norm > 0, norm, np.nan))


def call_boundaries(insulation: np.ndarray, min_prominence: float = 0.1,
                    circular: bool = True) -> np.ndarray:
    """Indices of local insulation minima deeper than ``min_prominence``."""
    v = np.asarray(insulation, float)
    n = v.size
    out = []
    for i in range(n):
        l = v[(i - 1) % n] if circular or i > 0 else np.nan
        r = v[(i + 1) % n] if circular or i < n - 1 else np.nan
        if not np.isfinite(v[i]):
            continue
        if (np.isfinite(l) and v[i] > l) or (np.isfinite(r) and v[i] > r):
            continue
        lo = max(0, i - 5); hi = min(n, i + 6)
        local = v[lo:hi]
        local = local[np.isfinite(local)]
        if local.size and (local.max() - v[i]) >= min_prominence:
            out.append(i)
    return np.asarray(out, dtype=np.int64)


def distance_decay(matrix: np.ndarray, resolution: int, circular: bool = True):
    _oe, expected = observed_over_expected(matrix, circular)
    s = np.arange(expected.size) * resolution
    return s, expected


def saddle(oe: np.ndarray, pc1: np.ndarray, n_quantiles: int = 5):
    """Mean O/E between PC1 quantile groups — the compartmentalisation summary."""
    ok = np.isfinite(pc1)
    if ok.sum() < n_quantiles * 2:
        return None, None
    q = np.full(pc1.size, -1)
    edges = np.quantile(pc1[ok], np.linspace(0, 1, n_quantiles + 1))
    q[ok] = np.clip(np.digitize(pc1[ok], edges[1:-1]), 0, n_quantiles - 1)
    mat = np.full((n_quantiles, n_quantiles), np.nan)
    for a in range(n_quantiles):
        for b in range(n_quantiles):
            block = oe[np.ix_(q == a, q == b)]
            vals = block[np.isfinite(block)]
            if vals.size:
                mat[a, b] = vals.mean()
    strength = float("nan")
    if np.isfinite(mat[0, 0]) and np.isfinite(mat[-1, -1]) and np.isfinite(mat[0, -1]):
        with np.errstate(invalid="ignore", divide="ignore"):
            strength = float((mat[0, 0] * mat[-1, -1]) / (mat[0, -1] ** 2))
    return mat, strength
