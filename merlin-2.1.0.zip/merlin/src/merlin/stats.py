"""Statistics shared by the MErlin tools.

Design notes
------------
* **Multiple testing** is one implementation (`benjamini_hochberg`), vectorised
  and monotonicity-enforcing.  Three near-identical hand-rolled copies existed.
* **Contingency testing** defaults to ``auto``: an exact Fisher test where the
  table is sparse enough to need one, a vectorised chi-square where it is not.
  ``dixam`` previously ran an exact test on ~10^4 tables whose "rest of genome"
  margin was ~10^6, which is both slow and pointless — the exact and asymptotic
  p-values agree to many digits there.
* **Permutation Spearman** ranks once and evaluates permutations as a matrix
  product.  The original called ``scipy.stats.spearmanr`` 5 000 times, re-ranking
  both vectors every iteration (~100x slower).
* Every test returns an **effect size next to the p-value**.  With n in the
  hundreds of thousands, a KS or binomial p-value is ~0 for any deviation, so
  the p-value alone carries no information about magnitude.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


def _scipy():
    try:
        import scipy.stats as st
        return st
    except ImportError:  # pragma: no cover
        return None


# --------------------------------------------------------------------------- #
# Multiple testing
# --------------------------------------------------------------------------- #
def benjamini_hochberg(pvals) -> np.ndarray:
    """BH-FDR adjusted p-values. NaN inputs are carried through as NaN."""
    p = np.asarray(pvals, dtype=float)
    out = np.full(p.shape, np.nan)
    finite = np.isfinite(p)
    m = int(finite.sum())
    if m == 0:
        return out
    pf = p[finite]
    order = np.argsort(pf, kind="stable")
    ranked = pf[order]
    q = ranked * m / np.arange(1, m + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.minimum(q, 1.0)
    res = np.empty(m)
    res[order] = q
    out[finite] = res
    return out


# --------------------------------------------------------------------------- #
# Contingency
# --------------------------------------------------------------------------- #
def odds_ratio(a, b, c, d, haldane: float = 0.5) -> np.ndarray:
    """Haldane-Anscombe corrected odds ratio, always finite and interpretable."""
    a = np.asarray(a, float); b = np.asarray(b, float)
    c = np.asarray(c, float); d = np.asarray(d, float)
    return ((a + haldane) * (d + haldane)) / ((b + haldane) * (c + haldane))


def _chi2_pvals(a, b, c, d) -> np.ndarray:
    st = _scipy()
    a, b, c, d = (np.asarray(x, float) for x in (a, b, c, d))
    n = a + b + c + d
    r1, r2 = a + b, c + d
    c1, c2 = a + c, b + d
    with np.errstate(invalid="ignore", divide="ignore"):
        num = n * (a * d - b * c) ** 2
        den = r1 * r2 * c1 * c2
        chi2 = np.where(den > 0, num / den, np.nan)
    if st is None:
        return np.full(a.shape, np.nan)
    return np.where(np.isfinite(chi2), st.chi2.sf(chi2, 1), np.nan)


def contingency_test(a, b, c, d, method: str = "auto",
                     min_expected: float = 5.0) -> tuple[np.ndarray, np.ndarray]:
    """Two-sided association test for many 2x2 tables.

    Returns ``(odds_ratio, p_value)``.  ``method='auto'`` uses the exact Fisher
    test only where an expected cell count falls below ``min_expected``.
    """
    a, b, c, d = (np.asarray(x, float) for x in (a, b, c, d))
    orr = odds_ratio(a, b, c, d)
    p = np.full(a.shape, np.nan)
    valid = (a + b > 0) & (c + d > 0) & (a + c > 0) & (b + d > 0)
    if not valid.any():
        return orr, p

    st = _scipy()
    if method == "chi2" or (st is None):
        p[valid] = _chi2_pvals(a[valid], b[valid], c[valid], d[valid])
        return orr, p

    if method == "fisher":
        need_exact = valid
    else:
        n = a + b + c + d
        with np.errstate(invalid="ignore", divide="ignore"):
            e_min = np.minimum.reduce([
                (a + b) * (a + c) / n, (a + b) * (b + d) / n,
                (c + d) * (a + c) / n, (c + d) * (b + d) / n])
        need_exact = valid & (~np.isfinite(e_min) | (e_min < min_expected))
        approx = valid & ~need_exact
        if approx.any():
            p[approx] = _chi2_pvals(a[approx], b[approx], c[approx], d[approx])

    idx = np.flatnonzero(need_exact)
    for i in idx:
        try:
            p[i] = st.fisher_exact([[int(a[i]), int(b[i])],
                                    [int(c[i]), int(d[i])]])[1]
        except (ValueError, OverflowError):
            p[i] = np.nan
    return orr, p


def log2_ratio(x, y, pseudocount: float) -> np.ndarray:
    x = np.asarray(x, float); y = np.asarray(y, float)
    return np.log2((x + pseudocount) / (y + pseudocount))


# --------------------------------------------------------------------------- #
# Correlation
# --------------------------------------------------------------------------- #
@dataclass
class CorrelationResult:
    n: int
    pearson_r: float = float("nan")
    pearson_p: float = float("nan")
    spearman_rho: float = float("nan")
    spearman_p: float = float("nan")
    perm_p: float = float("nan")
    n_perm: int = 0
    note: str = ""


def _rankdata(x: np.ndarray) -> np.ndarray:
    """Average ranks, ties handled (matches scipy's 'average' method)."""
    x = np.asarray(x, float)
    order = np.argsort(x, kind="stable")
    ranks = np.empty(x.size, dtype=float)
    sx = x[order]
    i = 0
    while i < x.size:
        j = i
        while j + 1 < x.size and sx[j + 1] == sx[i]:
            j += 1
        ranks[order[i:j + 1]] = 0.5 * (i + j) + 1.0
        i = j + 1
    return ranks


def permutation_spearman(x, y, n_perm: int = 5000, seed: int = 0,
                         chunk: int = 512) -> tuple[float, float]:
    """Spearman rho and its permutation p-value.

    Ranks are computed once; each permutation is then a dot product against the
    fixed y-ranks, evaluated in chunks so memory stays bounded regardless of
    ``n_perm``.
    """
    x = np.asarray(x, float); y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    n = x.size
    if n < 3:
        return float("nan"), float("nan")
    rx, ry = _rankdata(x), _rankdata(y)
    rxc = rx - rx.mean(); ryc = ry - ry.mean()
    denom = np.sqrt((rxc ** 2).sum() * (ryc ** 2).sum())
    if denom == 0:
        return float("nan"), float("nan")
    rho = float(rxc @ ryc / denom)
    if n_perm <= 0:
        return rho, float("nan")

    rng = np.random.default_rng(seed)
    sx = math.sqrt(float((rxc ** 2).sum()))
    sy = math.sqrt(float((ryc ** 2).sum()))
    extreme = 0
    done = 0
    while done < n_perm:
        k = min(chunk, n_perm - done)
        block = rng.permuted(np.broadcast_to(rxc, (k, n)), axis=1)
        rs = (block @ ryc) / (sx * sy)
        extreme += int(np.count_nonzero(np.abs(rs) >= abs(rho) - 1e-12))
        done += k
    # add-one correction: a permutation p-value is never exactly 0
    return rho, (extreme + 1) / (n_perm + 1)


def correlate(x, y, n_perm: int = 0, seed: int = 0) -> CorrelationResult:
    st = _scipy()
    x = np.asarray(x, float); y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    res = CorrelationResult(n=int(x.size))
    if x.size < 3:
        res.note = "fewer than 3 complete pairs"
        return res
    if np.all(x == x[0]) or np.all(y == y[0]):
        res.note = "a variable is constant"
        return res
    if st is not None:
        res.pearson_r, res.pearson_p = (float(v) for v in st.pearsonr(x, y))
        res.spearman_rho, res.spearman_p = (float(v) for v in st.spearmanr(x, y))
    else:
        rx, ry = _rankdata(x), _rankdata(y)
        res.spearman_rho = float(np.corrcoef(rx, ry)[0, 1])
        res.pearson_r = float(np.corrcoef(x, y)[0, 1])
    if n_perm:
        rho, p = permutation_spearman(x, y, n_perm=n_perm, seed=seed)
        res.perm_p, res.n_perm = p, n_perm
        if not np.isfinite(res.spearman_rho):
            res.spearman_rho = rho
    return res


# --------------------------------------------------------------------------- #
# Location / uniformity, with effect sizes
# --------------------------------------------------------------------------- #
@dataclass
class UniformityResult:
    n: int = 0
    mean: float = float("nan")
    ks_D: float = float("nan")
    ks_p: float = float("nan")
    bias: str = ""
    note: str = ""


def uniformity(values, low: float = 0.0, high: float = 1.0) -> UniformityResult:
    """KS test of ``values`` against Uniform(low, high), reported with D.

    D is the effect size: with n in the hundreds of thousands the p-value is
    ~0 for a deviation far too small to mean anything biologically, so a
    significant p with D = 0.004 should be read as "uniform".
    """
    v = np.asarray(values, float)
    v = v[np.isfinite(v)]
    res = UniformityResult(n=int(v.size))
    if v.size < 3:
        res.note = "fewer than 3 values"
        return res
    res.mean = float(v.mean())
    st = _scipy()
    scaled = (v - low) / (high - low) if high > low else v
    if st is not None:
        r = st.kstest(scaled, "uniform")
        res.ks_D, res.ks_p = float(r.statistic), float(r.pvalue)
    else:
        s = np.sort(scaled)
        n = s.size
        emp = np.arange(1, n + 1) / n
        res.ks_D = float(np.max(np.abs(emp - s)))
    mid = (low + high) / 2
    res.bias = "origin-proximal" if res.mean < mid else "terminus-proximal"
    return res


@dataclass
class ProportionResult:
    k: int = 0
    n: int = 0
    frac: float = float("nan")
    p: float = float("nan")
    ci_low: float = float("nan")
    ci_high: float = float("nan")


def proportion_test(k: int, n: int, p0: float = 0.5) -> ProportionResult:
    """Binomial test with a Wilson 95% interval as the effect size."""
    res = ProportionResult(k=int(k), n=int(n))
    if n <= 0:
        return res
    res.frac = k / n
    st = _scipy()
    if st is not None:
        res.p = float(st.binomtest(int(k), int(n), p0).pvalue)
    z = 1.959963984540054
    phat = res.frac
    denom = 1 + z * z / n
    centre = (phat + z * z / (2 * n)) / denom
    half = z * math.sqrt(phat * (1 - phat) / n + z * z / (4 * n * n)) / denom
    res.ci_low, res.ci_high = max(0.0, centre - half), min(1.0, centre + half)
    return res


# --------------------------------------------------------------------------- #
# Reporting helper
# --------------------------------------------------------------------------- #
@dataclass
class StatTable:
    """Accumulates named statistics for a tidy ``*.stats.tsv`` output."""

    rows: list[dict] = field(default_factory=list)

    def add(self, **kwargs) -> None:
        self.rows.append(kwargs)

    def to_frame(self):
        import pandas as pd
        return pd.DataFrame(self.rows)

    def write(self, path) -> None:
        import pandas as pd
        df = pd.DataFrame(self.rows)
        df.to_csv(path, sep="\t", index=False, float_format="%.6g")


# --------------------------------------------------------------------------- #
# Structure-preserving nulls  (ROADMAP 1.2)
# --------------------------------------------------------------------------- #
def circular_shift_null(track_a, track_b, n_perm: int = 1000, seed: int = 0,
                        min_shift_frac: float = 0.05) -> tuple[float, float]:
    """Correlation of two positional tracks against a circular-shift null.

    Shuffling positions destroys spatial autocorrelation, so a label-permutation
    null for anything positional is far too narrow and returns p ~ 0 for tracks
    that merely share a smooth trend.  Rotating one track around the replicon
    preserves its autocorrelation exactly while destroying the alignment between
    the two, which is the null the question actually needs.

    Returns ``(observed_spearman, p_value)``.
    """
    a = np.asarray(track_a, float)
    b = np.asarray(track_b, float)
    n = a.size
    if n < 20 or b.size != n:
        return float("nan"), float("nan")
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 20:
        return float("nan"), float("nan")
    ra, rb = _rankdata(np.where(ok, a, np.nanmean(a[ok]))), \
        _rankdata(np.where(ok, b, np.nanmean(b[ok])))
    ra = ra - ra.mean(); rb = rb - rb.mean()
    denom = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    if denom == 0:
        return float("nan"), float("nan")
    obs = float(ra @ rb / denom)

    rng = np.random.default_rng(seed)
    lo = max(1, int(min_shift_frac * n))
    shifts = rng.integers(lo, n - lo, size=n_perm) if n - lo > lo else \
        rng.integers(1, n, size=n_perm)
    idx = (np.arange(n)[None, :] + shifts[:, None]) % n
    null = (ra[idx] @ rb) / denom
    p = (int(np.count_nonzero(np.abs(null) >= abs(obs) - 1e-12)) + 1) / (n_perm + 1)
    return obs, float(p)


def block_bootstrap_ci(track_a, track_b, block_size: int | None = None,
                       n_boot: int = 1000, seed: int = 0,
                       alpha: float = 0.05) -> tuple[float, float, float]:
    """Percentile CI for a correlation between autocorrelated tracks.

    Neighbouring bins are not independent, so the parametric interval is far too
    narrow.  Resampling contiguous blocks keeps the local dependence inside each
    block.  Returns ``(rho, lo, hi)``.
    """
    a = np.asarray(track_a, float); b = np.asarray(track_b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    n = a.size
    if n < 20:
        return float("nan"), float("nan"), float("nan")
    if block_size is None:
        block_size = max(2, int(round(n ** (1 / 3))))
    ra, rb = _rankdata(a), _rankdata(b)
    rho = float(np.corrcoef(ra, rb)[0, 1])

    rng = np.random.default_rng(seed)
    n_blocks = int(np.ceil(n / block_size))
    starts = rng.integers(0, max(n - block_size, 1), size=(n_boot, n_blocks))
    offs = np.arange(block_size)
    boot = np.empty(n_boot)
    for i in range(n_boot):
        idx = (starts[i][:, None] + offs[None, :]).ravel()[:n] % n
        x, y = _rankdata(a[idx]), _rankdata(b[idx])
        boot[i] = np.corrcoef(x, y)[0, 1] if np.std(x) and np.std(y) else np.nan
    boot = boot[np.isfinite(boot)]
    if boot.size < 20:
        return rho, float("nan"), float("nan")
    lo, hi = np.quantile(boot, [alpha / 2, 1 - alpha / 2])
    return rho, float(lo), float(hi)


def stouffer(z_scores, weights=None) -> tuple[float, float]:
    """Weighted Stouffer combination of signed z-scores. Returns (Z, p)."""
    z = np.asarray(z_scores, float)
    ok = np.isfinite(z)
    if not ok.any():
        return float("nan"), float("nan")
    w = np.ones_like(z) if weights is None else np.asarray(weights, float)
    w = np.where(np.isfinite(w), w, 0.0)
    denom = np.sqrt(np.sum(w[ok] ** 2))
    if denom == 0:
        return float("nan"), float("nan")
    Z = float(np.sum(w[ok] * z[ok]) / denom)
    st = _scipy()
    p = float(2 * st.norm.sf(abs(Z))) if st is not None else float("nan")
    return Z, p


def p_to_z(p, sign=None) -> np.ndarray:
    """Two-sided p-values to signed z-scores (for Stouffer combination)."""
    st = _scipy()
    p = np.clip(np.asarray(p, float), 1e-300, 1.0)
    if st is None:
        return np.full(p.shape, np.nan)
    z = st.norm.isf(p / 2.0)
    if sign is not None:
        s = np.sign(np.asarray(sign, float))
        s = np.where(s == 0, 1.0, s)
        z = z * s
    return z


def robust_rank_aggregation(rank_lists, n_items: int) -> np.ndarray:
    """Robust rank aggregation (Kolde et al.): beta-order-statistic p per item.

    Used when the layers are not on a comparable scale, so combining z-scores
    would be combining apples and pears. ``rank_lists`` is a list of arrays of
    normalised ranks in [0, 1] (NaN where the item is absent from that layer).
    """
    st = _scipy()
    R = np.vstack([np.asarray(r, float) for r in rank_lists])   # layers x items
    out = np.ones(n_items)
    for i in range(n_items):
        col = R[:, i]
        col = np.sort(col[np.isfinite(col)])
        k = col.size
        if k == 0:
            continue
        if st is None:
            out[i] = float(col.min())
            continue
        betas = st.beta.cdf(col, np.arange(1, k + 1), k - np.arange(1, k + 1) + 1)
        out[i] = float(min(1.0, betas.min() * k))
    return out
