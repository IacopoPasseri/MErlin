"""Methyltransferase attribution (ROADMAP 3.2).

``mematch`` finds which motifs are methylated.  The missing step was saying
*which enzyme does it* — and with a knockout in hand, that is the strongest
statement MErlin can make, using data that is already on disk.

Three lines of evidence, combined in :func:`attribute`:

1. **Annotation** — genes whose product names them as a methyltransferase or a
   restriction enzyme, with their specificity subunit partners.
2. **A reference table of canonical prokaryotic systems** — Dam/GATC,
   Dcm/CCWGG, CcrM/GANTC and friends.  Small, offline and explicitly
   incomplete: REBASE is the authority and cannot be bundled.
3. **A knockout or comparison condition** — the motif whose methylation
   collapses when a gene is deleted is attributed to that gene.  This is the
   only one of the three that is evidence rather than annotation transfer, and
   the output labels it as such.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("mtase")

# Product-name patterns. Deliberately broad: a missed MTase is worse than a
# false candidate the user can dismiss by looking at the name.
MTASE_PATTERNS = [
    (re.compile(r"\b(dna\s+)?(adenine|cytosine)[- ]specific\s+methyl", re.I), "MTase"),
    (re.compile(r"\bmethyltransferase\b", re.I), "MTase"),
    (re.compile(r"\bmethylase\b", re.I), "MTase"),
    (re.compile(r"\bm\.[a-z]{3}\w*\b", re.I), "MTase"),
    (re.compile(r"\bdam\b", re.I), "MTase"),
    (re.compile(r"\bdcm\b", re.I), "MTase"),
    (re.compile(r"\bccrm\b", re.I), "MTase"),
    (re.compile(r"\bmod(ification)?\s+(protein|subunit)", re.I), "MTase"),
    (re.compile(r"\brestriction\s+(endonuclease|enzyme)", re.I), "REase"),
    (re.compile(r"\bendonuclease\s+(subunit\s+)?r\b", re.I), "REase"),
    (re.compile(r"\btype\s+i+v?\s+restriction", re.I), "REase"),
    (re.compile(r"\bspecificity\s+(subunit|determinant|protein)", re.I), "S subunit"),
    (re.compile(r"\bhsds\b", re.I), "S subunit"),
]

# Canonical systems. motif -> (enzyme, modification, offset of the modified base)
KNOWN_SYSTEMS: dict[str, tuple[str, str, int | None, str]] = {
    "GATC":   ("Dam", "6mA", 1, "gamma-proteobacterial adenine MTase"),
    "CCWGG":  ("Dcm", "5mC", 1, "E. coli cytosine MTase"),
    "GANTC":  ("CcrM", "6mA", 1, "alphaproteobacterial cell-cycle MTase"),
    "CTGCAG": ("M.PstI-like", "6mA", None, "type II system"),
    "GGATCC": ("M.BamHI-like", "5mC", None, "type II system"),
    "GCGC":   ("M.HhaI-like", "5mC", 1, "type II system"),
    "CCGG":   ("M.HpaII-like", "5mC", 1, "type II system"),
    "AACNNNNNNGTGC": ("EcoKI-like", "6mA", 2, "type I system, bipartite"),
    "GAAGNNNNNNTAC": ("type I-like", "6mA", None, "type I system, bipartite"),
    "CACNNNNNNGTT": ("EcoKI-like (rc)", "6mA", None, "type I system, bipartite"),
}


@dataclass
class MTaseGene:
    locus_tag: str
    gene: str
    product: str
    replicon: str
    start: int
    end: int
    strand: str
    role: str

    @property
    def label(self) -> str:
        return self.gene or self.locus_tag


@dataclass
class Attribution:
    motif: str
    known_enzyme: str = ""
    known_modification: str = ""
    known_note: str = ""
    candidate_genes: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    knockout_effect: float = float("nan")
    knockout_gene: str = ""
    confidence: str = "none"

    def summarise(self) -> str:
        return (f"{self.motif}: {self.confidence} — "
                f"{', '.join(self.evidence) if self.evidence else 'no evidence'}")


# --------------------------------------------------------------------------- #
def find_mtase_genes(annotation) -> list[MTaseGene]:
    """Genes whose product names them as part of a restriction-modification system."""
    out: list[MTaseGene] = []
    seen: set[str] = set()
    for f in getattr(annotation, "features", annotation):
        text = f"{f.gene} {f.product}".strip()
        if not text:
            continue
        for pattern, role in MTASE_PATTERNS:
            if pattern.search(text):
                if f.locus_tag in seen:
                    break
                seen.add(f.locus_tag)
                out.append(MTaseGene(f.locus_tag, f.gene, f.product, f.seqid,
                                     f.start, f.end, f.strand, role))
                break
    n_mt = sum(1 for g in out if g.role == "MTase")
    logger.info("Annotation scan: %d restriction-modification gene(s) "
                "(%d methyltransferase(s)).", len(out), n_mt)
    if not out:
        warn_once(logger, "MTASE_NONE_ANNOTATED",
                  "No methyltransferase is named in the annotation's product "
                  "fields. Attribution falls back to the canonical-motif table, "
                  "which is annotation transfer rather than evidence from this "
                  "genome.")
    return out


def neighbours(gene: MTaseGene, mtases: list[MTaseGene], window: int = 5000
               ) -> list[str]:
    """Other RM genes within ``window`` — RM systems are usually adjacent."""
    return [g.label for g in mtases
            if g.locus_tag != gene.locus_tag and g.replicon == gene.replicon
            and abs(g.start - gene.start) <= window]


def known_system(motif: str):
    """Exact or reverse-complement match against the canonical table."""
    from .motifs import reverse_complement
    m = motif.upper()
    if m in KNOWN_SYSTEMS:
        return KNOWN_SYSTEMS[m]
    rc = reverse_complement(m)
    if rc in KNOWN_SYSTEMS:
        return KNOWN_SYSTEMS[rc]
    return None


def attribute(motifs, annotation, knockout_effects: dict[str, float] | None = None,
              knockout_gene: str = "") -> list[Attribution]:
    """Combine annotation, the canonical table and a knockout into one call."""
    mtases = find_mtase_genes(annotation)
    mt_only = [g for g in mtases if g.role == "MTase"]
    out: list[Attribution] = []
    for motif in motifs:
        att = Attribution(motif=motif)
        known = known_system(motif)
        if known:
            att.known_enzyme, att.known_modification, _off, att.known_note = known
            att.evidence.append(f"canonical system {att.known_enzyme}")
        named = [g.label for g in mt_only
                 if att.known_enzyme
                 and att.known_enzyme.split("-")[0].lower() in
                 f"{g.gene} {g.product}".lower()]
        if named:
            att.candidate_genes = named
            att.evidence.append(f"annotation names {', '.join(named)}")
        elif mt_only:
            att.candidate_genes = [g.label for g in mt_only]
            att.evidence.append(f"{len(mt_only)} annotated MTase(s) in the genome, "
                                f"none name-matched")

        if knockout_effects and motif in knockout_effects:
            eff = knockout_effects[motif]
            att.knockout_effect = eff
            att.knockout_gene = knockout_gene
            if np.isfinite(eff) and eff <= -0.2:
                where = knockout_gene or "the second condition"
                att.evidence.append(
                    f"methylation drops {abs(eff):.2f} in {where}")

        strong_ko = np.isfinite(att.knockout_effect) and att.knockout_effect <= -0.2
        if strong_ko and named:
            att.confidence = "strong (knockout + annotation)"
        elif strong_ko:
            att.confidence = "moderate (knockout, gene not identified)"
        elif named:
            att.confidence = "weak (annotation only)"
        elif known:
            att.confidence = "weak (canonical motif table only)"
        else:
            att.confidence = "none"
        out.append(att)
    return out


def motif_methylation_level(methyl, motif_hits, motif: str, genome) -> float:
    """Mean methylation level over a motif's modified bases, or the call rate."""
    hits = motif_hits.get(motif)
    if hits is None or len(hits) == 0 or len(methyl) == 0:
        return float("nan")
    total_num = total_den = 0.0
    presence_num = presence_den = 0.0
    for seqid, seq in genome.items():
        L = len(seq)
        mask = (hits.modbase_mask(seqid, L) if hits.has_offset
                else hits.covered_mask(seqid, L))
        if not mask.any():
            continue
        sel = np.flatnonzero(methyl.seqid == seqid)
        if sel.size == 0:
            continue
        pos = methyl.pos[sel]
        inside = pos < L
        on = np.zeros(sel.size, dtype=bool)
        on[inside] = mask[pos[inside]]
        if not on.any():
            continue
        frac = methyl.frac[sel][on]
        good = np.isfinite(frac)
        if good.any():
            total_num += float(frac[good].sum())
            total_den += float(good.sum())
        presence_num += float(on.sum())
        presence_den += float(mask.sum())
    if total_den > 0:
        return total_num / total_den
    if presence_den > 0:
        return presence_num / presence_den
    return float("nan")
