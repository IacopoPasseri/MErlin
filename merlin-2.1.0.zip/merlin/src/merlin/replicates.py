"""Replicate-aware differential testing (ROADMAP 1.1).

With one sample per condition there is no way to separate a real difference from
within-condition variation, which is why 2.0's ``dixam`` printed a caveat instead
of a result: on the synthetic data a genome-wide shift of 0.90 -> 0.88 made 58 %
of features "significant". Everything here exists to put a dispersion term in
the model so that stops happening.

Two models, chosen by what the input carries:

**beta-binomial** (coverage + fraction available, i.e. real bedMethyl)
    Per feature, modified and total reads per replicate.  Dispersion is
    estimated per feature by method of moments and then shrunk towards a
    mean-dependent trend — the same empirical-Bayes idea DSS uses, because a
    per-feature dispersion from three replicates is far too noisy to use raw.
    The test is a likelihood-ratio test of "one methylation level" against "one
    per condition", with the shrunken dispersion held fixed.

**quasi-Poisson** (presence-only input)
    Per feature, call counts per replicate with a library-size offset.  A
    Poisson LRT scaled by a dispersion estimated from Pearson residuals, so
    replicate-to-replicate scatter widens the null rather than being ignored.

Both return the effect size first (a methylation-level difference, or a log2
ratio) and the p-value second, and both report the dispersion they used so a
result driven by a shrinkage decision is visible.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("replicates")

_EPS = 1e-9


def _gammaln(x):
    from scipy.special import gammaln
    return gammaln(x)


def _digamma(x):
    from scipy.special import digamma
    return digamma(x)


def _chi2_sf(x, df):
    try:
        from scipy.stats import chi2
        return chi2.sf(x, df)
    except ImportError:  # pragma: no cover
        return np.full(np.shape(x), np.nan)


def _f_sf(x, dfn, dfd):
    try:
        from scipy.stats import f
        return f.sf(x, dfn, dfd)
    except ImportError:  # pragma: no cover
        return np.full(np.shape(x), np.nan)


# --------------------------------------------------------------------------- #
# Design
# --------------------------------------------------------------------------- #
@dataclass
class Design:
    """Which columns of the replicate matrices belong to which condition."""

    labels: tuple[str, str]
    groups: np.ndarray            # 0 for the control replicates, 1 for treatment
    sample_names: list[str] = field(default_factory=list)

    @property
    def n_control(self) -> int:
        return int((self.groups == 0).sum())

    @property
    def n_treatment(self) -> int:
        return int((self.groups == 1).sum())

    @property
    def replicated(self) -> bool:
        return self.n_control >= 2 and self.n_treatment >= 2

    def describe(self) -> str:
        return (f"{self.labels[0]} n={self.n_control}, "
                f"{self.labels[1]} n={self.n_treatment}")


# --------------------------------------------------------------------------- #
# Beta-binomial
# --------------------------------------------------------------------------- #
def moment_dispersion(m: np.ndarray, n: np.ndarray, groups: np.ndarray
                      ) -> np.ndarray:
    """Per-feature beta-binomial dispersion phi in [0, 1) by method of moments.

    phi is the intra-class correlation: 0 is pure binomial sampling, larger
    values mean replicates disagree more than counting noise allows.  Computed
    within condition and pooled, so a genuine between-condition difference does
    not inflate it.
    """
    m = np.asarray(m, float)
    n = np.asarray(n, float)
    num = np.zeros(m.shape[0])
    den = np.zeros(m.shape[0])
    for g in (0, 1):
        cols = np.flatnonzero(groups == g)
        if cols.size < 2:
            continue
        mg, ng = m[:, cols], n[:, cols]
        tot = ng.sum(axis=1)
        with np.errstate(invalid="ignore", divide="ignore"):
            p = np.where(tot > 0, mg.sum(axis=1) / np.maximum(tot, 1), np.nan)
            var_bin = p * (1 - p)
            # Pearson chi-square of replicates against the pooled proportion
            exp = ng * p[:, None]
            resid = (mg - exp) ** 2 / np.maximum(ng * var_bin[:, None], _EPS)
            chi = np.nansum(resid, axis=1)
        df = np.maximum(cols.size - 1, 1)
        # E[chi2] = df * (1 + phi * (nbar - 1)) for equal n; solve for phi
        nbar = np.where(cols.size > 0, ng.mean(axis=1), 1.0)
        with np.errstate(invalid="ignore", divide="ignore"):
            phi_g = (chi / df - 1.0) / np.maximum(nbar - 1.0, _EPS)
        ok = np.isfinite(phi_g) & (tot > 0)
        num[ok] += np.clip(phi_g[ok], 0.0, 0.95) * df
        den[ok] += df
    with np.errstate(invalid="ignore", divide="ignore"):
        phi = np.where(den > 0, num / np.maximum(den, _EPS), np.nan)
    return np.clip(phi, 0.0, 0.95)


def shrink_dispersion(phi: np.ndarray, weight: np.ndarray,
                      mean_level: np.ndarray | None = None,
                      n_bins: int = 20, prior_weight: float = 5.0
                      ) -> tuple[np.ndarray, np.ndarray]:
    """Empirical-Bayes shrinkage of per-feature dispersion towards a trend.

    A dispersion estimated from three replicates has enormous variance; using it
    raw makes some features untestable and others spuriously significant.  The
    trend is the median dispersion of features with a similar methylation level
    (dispersion is level-dependent — a locus at 0.99 cannot vary much), and each
    feature is pulled towards it in proportion to how little information it has.

    Returns ``(phi_shrunk, phi_trend)``.
    """
    phi = np.asarray(phi, float)
    w = np.asarray(weight, float)
    ok = np.isfinite(phi)
    if not ok.any():
        return np.full_like(phi, 0.01), np.full_like(phi, 0.01)

    trend = np.full_like(phi, np.nan)
    if mean_level is not None and np.isfinite(mean_level).sum() > n_bins * 3:
        lv = np.asarray(mean_level, float)
        good = ok & np.isfinite(lv)
        edges = np.quantile(lv[good], np.linspace(0, 1, n_bins + 1))
        edges = np.unique(edges)
        if edges.size >= 3:
            idx = np.clip(np.digitize(lv, edges[1:-1]), 0, edges.size - 2)
            for b in range(edges.size - 1):
                sel = good & (idx == b)
                if sel.sum() >= 5:
                    trend[idx == b] = np.median(phi[sel])
    fallback = float(np.median(phi[ok])) if ok.any() else 0.01
    trend = np.where(np.isfinite(trend), trend, fallback)

    lam = w / (w + prior_weight)
    out = np.where(ok, lam * phi + (1 - lam) * trend, trend)
    return np.clip(out, 1e-6, 0.95), trend


def _bb_loglik(m, n, p, s):
    """Beta-binomial log-likelihood summed over replicates (constant dropped)."""
    a = np.maximum(p * s, _EPS)
    b = np.maximum((1 - p) * s, _EPS)
    a = a[:, None] if a.ndim == 1 else a
    b = b[:, None] if b.ndim == 1 else b
    return np.sum(_gammaln(m + a) + _gammaln(n - m + b) - _gammaln(n + a + b)
                  - _gammaln(a) - _gammaln(b) + _gammaln(a + b), axis=1)


def _bb_mle_p(m, n, s, iters: int = 40):
    """ML proportion under a beta-binomial with fixed dispersion, by bisection.

    The score is monotone decreasing in p, so bisection is both safe and
    vectorisable — Newton would need per-feature step control.
    """
    lo = np.full(m.shape[0], 1e-6)
    hi = np.full(m.shape[0], 1 - 1e-6)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        a = np.maximum(mid * s, _EPS)[:, None]
        b = np.maximum((1 - mid) * s, _EPS)[:, None]
        score = np.sum(_digamma(m + a) - _digamma(a)
                       - _digamma(n - m + b) + _digamma(b), axis=1)
        pos = score > 0
        lo = np.where(pos, mid, lo)
        hi = np.where(pos, hi, mid)
    return 0.5 * (lo + hi)


@dataclass
class ReplicateResult:
    effect: np.ndarray            # treatment level - control level
    level_control: np.ndarray
    level_treatment: np.ndarray
    pvalue: np.ndarray
    dispersion: np.ndarray
    dispersion_trend: np.ndarray
    statistic: np.ndarray
    model: str
    n_control: int
    n_treatment: int
    per_replicate: dict[str, np.ndarray] = field(default_factory=dict)


def betabinomial_test(m: np.ndarray, n: np.ndarray, design: Design,
                      prior_weight: float = 5.0, dist: str = "chi2"
                      ) -> ReplicateResult:
    """Likelihood-ratio test of a per-condition methylation level.

    ``m`` and ``n`` are (features x samples) modified and total read counts.

    ``dist`` selects the reference distribution for the LR statistic.  Measured
    null calibration on simulated beta-binomial data (nominal 5 %):

    ======  ==============  ==================
    design  chi2(1)         F(1, n_samples-2)
    ======  ==============  ==================
    2 v 2   10.6 %          0.1 %
    3 v 3    6.0 %          1.0 %
    5 v 5    7.8 %          4.1 %
    ======  ==============  ==================

    chi2 is mildly anti-conservative at small n and F is far too conservative,
    so chi2 is the default and the anti-conservatism is warned about rather than
    hidden.  ``--lrt-dist f`` is there for anyone who wants the conservative end.
    """
    m = np.asarray(m, float)
    n = np.asarray(n, float)
    g = design.groups
    c_cols = np.flatnonzero(g == 0)
    t_cols = np.flatnonzero(g == 1)

    tot = n.sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        lvl_all = np.where(tot > 0, m.sum(axis=1) / np.maximum(tot, 1), np.nan)
        lvl_c = np.where(n[:, c_cols].sum(axis=1) > 0,
                         m[:, c_cols].sum(axis=1)
                         / np.maximum(n[:, c_cols].sum(axis=1), 1), np.nan)
        lvl_t = np.where(n[:, t_cols].sum(axis=1) > 0,
                         m[:, t_cols].sum(axis=1)
                         / np.maximum(n[:, t_cols].sum(axis=1), 1), np.nan)

    phi_raw = moment_dispersion(m, n, g)
    weight = np.log1p(tot)
    phi, trend = shrink_dispersion(phi_raw, weight, lvl_all,
                                   prior_weight=prior_weight)
    s = (1.0 - phi) / np.maximum(phi, 1e-6)          # beta-binomial precision

    p_null = _bb_mle_p(m, n, s)
    p_c = _bb_mle_p(m[:, c_cols], n[:, c_cols], s)
    p_t = _bb_mle_p(m[:, t_cols], n[:, t_cols], s)

    ll0 = _bb_loglik(m, n, p_null, s)
    ll1 = (_bb_loglik(m[:, c_cols], n[:, c_cols], p_c, s)
           + _bb_loglik(m[:, t_cols], n[:, t_cols], p_t, s))
    stat = np.maximum(2.0 * (ll1 - ll0), 0.0)
    if dist == "f":
        pval = _f_sf(stat, 1, max(c_cols.size + t_cols.size - 2, 1))
    else:
        pval = _chi2_sf(stat, 1)
    bad = ~np.isfinite(tot) | (tot <= 0) | (n[:, c_cols].sum(axis=1) <= 0) \
        | (n[:, t_cols].sum(axis=1) <= 0)
    pval = np.where(bad, np.nan, pval)

    return ReplicateResult(
        effect=lvl_t - lvl_c, level_control=lvl_c, level_treatment=lvl_t,
        pvalue=pval, dispersion=phi, dispersion_trend=trend, statistic=stat,
        model="beta-binomial LRT", n_control=c_cols.size, n_treatment=t_cols.size,
        per_replicate={"levels": np.divide(m, np.maximum(n, 1),
                                           out=np.full_like(m, np.nan),
                                           where=n > 0)})


# --------------------------------------------------------------------------- #
# Quasi-Poisson (presence-only replicates)
# --------------------------------------------------------------------------- #
def quasipoisson_test(counts: np.ndarray, lib_sizes: np.ndarray, design: Design,
                      pseudocount: float = 0.5) -> ReplicateResult:
    """LRT on call counts with a library-size offset and a scaled dispersion.

    Presence-only input has no reads to model, only how many positions were
    called.  Replicate scatter is turned into a dispersion factor from the
    Pearson residuals of the null fit and used to scale the deviance — the
    quasi-likelihood construction, so an F test rather than chi-square.
    """
    y = np.asarray(counts, float)
    lib = np.asarray(lib_sizes, float)
    g = design.groups
    c_cols, t_cols = np.flatnonzero(g == 0), np.flatnonzero(g == 1)
    lib = lib / np.maximum(lib.mean(), _EPS)

    def rate(cols):
        tot_lib = lib[cols].sum()
        return y[:, cols].sum(axis=1) / max(tot_lib, _EPS)

    mu0 = rate(np.arange(y.shape[1]))[:, None] * lib[None, :]
    mu1 = np.empty_like(y)
    r_c, r_t = rate(c_cols), rate(t_cols)
    mu1[:, c_cols] = r_c[:, None] * lib[None, c_cols]
    mu1[:, t_cols] = r_t[:, None] * lib[None, t_cols]

    def dev(mu):
        with np.errstate(invalid="ignore", divide="ignore"):
            term = np.where(y > 0, y * np.log(np.maximum(y, _EPS)
                                              / np.maximum(mu, _EPS)), 0.0)
        return 2.0 * np.sum(term - (y - mu), axis=1)

    d0, d1 = dev(mu0), dev(mu1)
    resid_df = max(y.shape[1] - 2, 1)
    with np.errstate(invalid="ignore", divide="ignore"):
        pearson = np.sum((y - mu1) ** 2 / np.maximum(mu1, _EPS), axis=1)
    phi = np.maximum(pearson / resid_df, 1.0)          # never below Poisson
    phi_shrunk, trend = shrink_dispersion(
        phi - 1.0, np.log1p(y.sum(axis=1)), y.mean(axis=1))
    phi_used = 1.0 + phi_shrunk

    with np.errstate(invalid="ignore", divide="ignore"):
        stat = np.maximum(d0 - d1, 0.0) / np.maximum(phi_used, _EPS)
    pval = _f_sf(stat, 1, resid_df)
    pval = np.where(np.isfinite(stat) & (y.sum(axis=1) > 0), pval, np.nan)

    lvl_c = r_c / np.maximum(r_c + r_t, _EPS)
    return ReplicateResult(
        effect=np.log2((r_t + pseudocount) / (r_c + pseudocount)),
        level_control=r_c, level_treatment=r_t, pvalue=pval,
        dispersion=phi_used, dispersion_trend=1.0 + trend, statistic=stat,
        model="quasi-Poisson LRT (call counts)",
        n_control=c_cols.size, n_treatment=t_cols.size,
        per_replicate={"counts": y})


# --------------------------------------------------------------------------- #
def parse_condition_files(values, label: str) -> list[str]:
    """``--methylation a.bed b.bed c.bed`` or a single comma-separated string."""
    if values is None:
        return []
    if isinstance(values, str):
        values = [values]
    out: list[str] = []
    for v in values:
        out += [x for x in str(v).split(",") if x]
    if not out:
        warn_once(logger, f"REPL_EMPTY_{label}", f"No files given for {label}.")
    return out


def check_design(design: Design) -> None:
    if design.replicated:
        logger.info("Replicated design: %s — dispersion is estimable.",
                    design.describe())
        if min(design.n_control, design.n_treatment) < 3:
            warn_once(
                logger, "REPL_SMALL_N",
                f"Only {min(design.n_control, design.n_treatment)} replicate(s) in "
                f"the smaller condition. The likelihood-ratio test is "
                f"anti-conservative at that size — on simulated null data a 2v2 "
                f"design rejects ~10 % of features at a nominal 5 %, so the "
                f"q-values are optimistic. Three or more per condition brings it "
                f"close to nominal; --lrt-dist f errs the other way.")
        return
    warn_once(
        logger, "NO_REPLICATION",
        f"Design has {design.describe()}: with fewer than two replicates in a "
        f"condition there is no within-condition variance to estimate, so the "
        f"test cannot separate a real difference from sampling scatter. The "
        f"single-sample test still runs and its q-values screen candidates; they "
        f"do not establish differential methylation.")
