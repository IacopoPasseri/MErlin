"""Shared plotting scaffolding: one palette, one lazy import, one save path.

Colours are fixed package-wide so that a modification, a condition or a
replicon keeps the same colour across every figure MErlin produces — the
standalone scripts each defined their own palette, so 6mA was orange in one
figure and blue in the next.
"""

from __future__ import annotations

import re
from pathlib import Path

from .logging_utils import get_logger

logger = get_logger("viz")

# Condition / class palette
PAL = {
    "control": "#2c7fb8",
    "treatment": "#de2d26",
    "DE": "#e74c3c",
    "nonDE": "#3498db",
    "DM": "#f39c12",
    "dual": "#9b59b6",
    "neutral": "#95a5a6",
    "gain": "#1a9850",
    "loss": "#762a83",
    "meth": "#c0392b",
    "motif": "#3a6ea5",
    "gene_plus": "#d62728",
    "gene_minus": "#1f77b4",
    "skew_pos": "#27ae60",
    "skew_neg": "#8e44ad",
    "ori": "#1e8449",
    "ter": "#c0392b",
    "grid": "#cccccc",
}

# Stable colour per modification code
MOD_COLORS = {
    "a": "#e67e22",   # 6mA
    "m": "#2980b9",   # 5mC
    "h": "#16a085",   # 5hmC
    "21839": "#8e44ad",  # 4mC
}
_FALLBACK_CYCLE = ["#7f8c8d", "#c0392b", "#2c3e50", "#d35400", "#27ae60"]


def mod_color(code: str, seen: list[str] | None = None) -> str:
    if code in MOD_COLORS:
        return MOD_COLORS[code]
    seen = seen or []
    i = seen.index(code) if code in seen else len(MOD_COLORS)
    return _FALLBACK_CYCLE[i % len(_FALLBACK_CYCLE)]


def lazy_pyplot():
    """Import matplotlib with the Agg backend, or return ``None`` with advice."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        return plt
    except ImportError as exc:  # pragma: no cover
        logger.error("Plotting needs matplotlib (%s). Install it, or rerun with "
                     "--no-plot.", exc)
        return None


_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_name(text: str, fallback: str = "unnamed") -> str:
    """Filesystem-safe token for use in an output filename."""
    out = _UNSAFE.sub("_", str(text)).strip("._-")
    return out or fallback


def savefig(fig, path: str | Path, dpi: int = 150, tight: bool = True) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight" if tight else None)
    try:
        import matplotlib.pyplot as plt
        plt.close(fig)
    except ImportError:  # pragma: no cover
        pass
    logger.info("  [plot] %s", path.name)
    return path


def coord_unit(max_len: int) -> tuple[float, str]:
    if max_len >= 1_000_000:
        return 1_000_000.0, "Mb"
    if max_len >= 10_000:
        return 1_000.0, "kb"
    return 1.0, "bp"


def annotate_empty(ax, message: str = "no data") -> None:
    ax.text(0.5, 0.5, message, ha="center", va="center",
            transform=ax.transAxes, color="grey", fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])


def significance_stars(q: float) -> str:
    if q != q:      # NaN
        return "n/a"
    if q < 1e-3:
        return "***"
    if q < 1e-2:
        return "**"
    if q < 0.05:
        return "*"
    return "ns"
