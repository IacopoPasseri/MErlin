"""Regulatory geometry: promoter windows, operons, intergenic space (ROADMAP 1.3).

Everything in 2.0 was scored over whole features.  The canonical prokaryotic
mechanism — Dam sites in a promoter blocking or recruiting a regulator (*pap*,
*agn43*, *traJ*) — happens in the ~200 bp upstream of a gene, and a whole-CDS
average dilutes it to nothing.  MErlin could not see the place where the biology
is.

This module derives scoreable windows from an annotation:

``upstream:-300..50``   relative to the translation start, strand-aware
``body``                the feature itself
``downstream:0..200``   past the stop
``intergenic``          the gaps, as first-class features rather than absences

and infers operons from intergenic distance and strand runs, so that a promoter
is scored once for the whole transcription unit instead of once per gene — which
also stops each co-transcribed gene being counted as an independent observation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .logging_utils import get_logger, warn_once
from .model import Annotation, Feature

logger = get_logger("regions")

_SPEC_RE = re.compile(r"^(?P<kind>[a-z]+)(?::(?P<a>-?\d+)\.\.(?P<b>-?\d+))?$")

DEFAULT_SPECS = ("upstream:-300..50", "body")


@dataclass(slots=True)
class RegionSpec:
    kind: str                 # upstream | body | downstream | intergenic
    start_off: int = 0
    end_off: int = 0

    @property
    def name(self) -> str:
        if self.kind in ("body", "intergenic"):
            return self.kind
        return f"{self.kind}{self.start_off:+d}..{self.end_off:+d}"


def parse_region_specs(values) -> list[RegionSpec]:
    """``upstream:-300..50 body downstream:0..200`` -> RegionSpec list."""
    if values is None:
        return []
    if isinstance(values, str):
        values = [values]
    tokens: list[str] = []
    for v in values:
        tokens += [t for t in str(v).replace(";", ",").split(",") if t.strip()]
    specs: list[RegionSpec] = []
    for tok in tokens:
        tok = tok.strip().lower()
        m = _SPEC_RE.match(tok)
        if not m or m.group("kind") not in ("upstream", "body", "downstream",
                                            "intergenic"):
            raise SystemExit(
                f"[FATAL] cannot parse --regions token {tok!r}. Expected one of: "
                f"body, intergenic, upstream:-300..50, downstream:0..200")
        kind = m.group("kind")
        if kind in ("body", "intergenic"):
            specs.append(RegionSpec(kind))
            continue
        a, b = int(m.group("a") or 0), int(m.group("b") or 0)
        if b <= a:
            raise SystemExit(f"[FATAL] --regions {tok!r}: the window end must be "
                             f"greater than its start.")
        specs.append(RegionSpec(kind, a, b))
    return specs


# --------------------------------------------------------------------------- #
# Window derivation
# --------------------------------------------------------------------------- #
def _clamp(start: int, end: int, length: int | None) -> tuple[int, int]:
    if length is None:
        return max(start, 0), max(end, 0)
    start = max(0, min(start, length))
    end = max(0, min(end, length))
    return start, end


def derive_regions(annotation: Annotation, specs: list[RegionSpec],
                   lengths: dict[str, int] | None = None,
                   min_length: int = 1) -> Annotation:
    """Expand each feature into the requested windows.

    The returned features keep the parent's ``locus_tag`` so every downstream
    join still works; ``ftype`` becomes the region name and ``fid`` becomes
    ``<locus_tag>:<region>``.  Coordinates are clamped to the replicon and
    windows are strand-aware: ``upstream`` is upstream of the *translation
    start*, which for a minus-strand gene is its high coordinate.
    """
    lengths = lengths or {}
    out = Annotation(seq_regions=dict(annotation.seq_regions),
                     embedded_fasta=annotation.embedded_fasta)
    n_clamped = 0
    for f in annotation.features:
        L = lengths.get(f.seqid)
        for spec in specs:
            if spec.kind == "intergenic":
                continue
            if spec.kind == "body":
                s, e = f.start, f.end
            elif spec.kind == "upstream":
                if f.strand == "-":
                    s, e = f.end - spec.end_off, f.end - spec.start_off
                else:
                    s, e = f.start + spec.start_off, f.start + spec.end_off
            else:                                     # downstream
                if f.strand == "-":
                    s, e = f.start - spec.end_off, f.start - spec.start_off
                else:
                    s, e = f.end + spec.start_off, f.end + spec.end_off
            s2, e2 = _clamp(s, e, L)
            if (s2, e2) != (s, e):
                n_clamped += 1
            if e2 - s2 < min_length:
                continue
            out.features.append(Feature(
                seqid=f.seqid, ftype=spec.name, start=s2, end=e2, strand=f.strand,
                fid=f"{f.key}:{spec.name}", locus_tag=f.locus_tag,
                gene=f.gene, product=f.product))
    if any(s.kind == "intergenic" for s in specs):
        out.features += intergenic_regions(annotation, lengths).features
    logger.info("Regions: %d window(s) from %d feature(s) [%s]",
                len(out.features), len(annotation.features),
                ", ".join(s.name for s in specs))
    if n_clamped:
        warn_once(logger, "REGION_CLAMPED",
                  f"{n_clamped} region window(s) ran past a replicon end and were "
                  f"clamped. Replicons are circular, so a window at the origin is "
                  f"truncated rather than wrapped.")
    return out


def intergenic_regions(annotation: Annotation, lengths: dict[str, int] | None = None,
                       min_length: int = 30) -> Annotation:
    """The gaps between annotated features, as features in their own right."""
    lengths = lengths or {}
    out = Annotation()
    by_seq: dict[str, list[Feature]] = {}
    for f in annotation.features:
        by_seq.setdefault(f.seqid, []).append(f)
    for seqid, feats in by_seq.items():
        feats = sorted(feats, key=lambda f: (f.start, f.end))
        cursor = 0
        prev = None
        for f in feats:
            if f.start - cursor >= min_length:
                out.features.append(Feature(
                    seqid=seqid, ftype="intergenic", start=cursor, end=f.start,
                    strand=".", fid=f"IG:{seqid}:{cursor}-{f.start}",
                    locus_tag=f"IG_{seqid}_{cursor}",
                    gene="", product=(f"between {prev.key if prev else 'start'} "
                                      f"and {f.key}")))
            cursor = max(cursor, f.end)
            prev = f
        L = lengths.get(seqid)
        if L and L - cursor >= min_length:
            out.features.append(Feature(
                seqid=seqid, ftype="intergenic", start=cursor, end=L, strand=".",
                fid=f"IG:{seqid}:{cursor}-{L}", locus_tag=f"IG_{seqid}_{cursor}",
                gene="", product=f"after {prev.key if prev else 'start'}"))
    logger.info("Intergenic: %d region(s).", len(out.features))
    return out


# --------------------------------------------------------------------------- #
# Operons
# --------------------------------------------------------------------------- #
@dataclass(slots=True)
class Operon:
    operon_id: str
    seqid: str
    strand: str
    start: int
    end: int
    members: list[str]

    @property
    def leader(self) -> str:
        return self.members[0]

    @property
    def size(self) -> int:
        return len(self.members)


def infer_operons(annotation: Annotation, max_gap: int = 50,
                  feature_types: set[str] | None = None) -> list[Operon]:
    """Group co-oriented, closely spaced genes into transcription units.

    A crude but standard heuristic: a run of same-strand features separated by
    no more than ``max_gap`` bp.  It exists so that a promoter is scored once per
    operon and so that co-transcribed genes stop being treated as independent
    observations — both of which change the effective n, not just the labelling.
    """
    feature_types = feature_types or {"CDS"}
    by_seq: dict[str, list[Feature]] = {}
    for f in annotation.features:
        if f.ftype in feature_types and f.strand in ("+", "-"):
            by_seq.setdefault(f.seqid, []).append(f)

    operons: list[Operon] = []
    for seqid, feats in by_seq.items():
        feats.sort(key=lambda f: f.start)
        run: list[Feature] = []
        for f in feats:
            if run and f.strand == run[-1].strand and (f.start - run[-1].end) <= max_gap:
                run.append(f)
                continue
            if run:
                operons.append(_make_operon(run, len(operons)))
            run = [f]
        if run:
            operons.append(_make_operon(run, len(operons)))

    multi = sum(1 for o in operons if o.size > 1)
    logger.info("Operons: %d transcription unit(s) from %d gene(s); %d are "
                "multi-gene (max gap %d bp).",
                len(operons), sum(o.size for o in operons), multi, max_gap)
    if operons and multi == 0:
        warn_once(logger, "OPERON_NONE",
                  f"No multi-gene operon was inferred at --operon-max-gap {max_gap}. "
                  f"Either the annotation is sparse or the gap is too tight; the "
                  f"operon layer adds nothing to this run.")
    return operons


def _make_operon(run: list[Feature], n: int) -> Operon:
    ordered = run if run[0].strand == "+" else list(reversed(run))
    return Operon(operon_id=f"OP_{n + 1:05d}", seqid=run[0].seqid,
                  strand=run[0].strand, start=min(f.start for f in run),
                  end=max(f.end for f in run),
                  members=[f.key for f in ordered])


def operon_map(operons: list[Operon]) -> dict[str, tuple[str, int, str]]:
    """locus_tag -> (operon_id, position in the operon, leader locus_tag)."""
    out: dict[str, tuple[str, int, str]] = {}
    for op in operons:
        for i, member in enumerate(op.members):
            out[member] = (op.operon_id, i + 1, op.leader)
    return out


def operon_features(operons: list[Operon], annotation: Annotation) -> Annotation:
    """One feature per operon, spanning the whole transcription unit."""
    lut = {f.key: f for f in annotation.features}
    out = Annotation(seq_regions=dict(annotation.seq_regions))
    for op in operons:
        lead = lut.get(op.leader)
        out.features.append(Feature(
            seqid=op.seqid, ftype="operon", start=op.start, end=op.end,
            strand=op.strand, fid=op.operon_id, locus_tag=op.operon_id,
            gene=(lead.gene if lead else ""),
            product=f"{op.size}-gene operon: {','.join(op.members)}"))
    return out


def add_region_args(parser) -> None:
    g = parser.add_argument_group("regulatory geometry")
    g.add_argument("--regions", nargs="+", default=None, metavar="SPEC",
                   help="Score windows instead of whole features, e.g. "
                        "'upstream:-300..50 body downstream:0..200 intergenic'. "
                        "Windows are strand-aware and relative to the "
                        "translation start.")
    g.add_argument("--operons", action="store_true",
                   help="Infer operons and annotate each feature with its "
                        "transcription unit; scores the leader's upstream window "
                        "for every member.")
    g.add_argument("--operon-max-gap", type=int, default=50, metavar="BP",
                   help="Maximum same-strand gap joining two genes into one operon.")
