"""Single implementation of every file format MErlin reads.

The standalone scripts each carried their own GFF3, FASTA, bedMethyl and motif
parsers.  They had drifted: ``xam``/``dixam`` could not read gzip and never
stripped seqid version suffixes, ``mematch``/``spacem`` could do both, and
``roundtable.R`` accepted only bedMethyl.  Consolidating them here means a file
that one tool can read is readable by all of them, and a parsing fix lands
everywhere at once.

Formats supported
-----------------
annotation   GFF3 (Prokka/Bakta/NCBI), optionally with an embedded ``##FASTA``
sequence     FASTA, plain or gzipped
methylation  modkit bedMethyl (>=11 columns), 6-column BED, GFF3 modification
             calls; auto-detected from content, not just from the extension
motifs       newline-delimited IUPAC, optional modified-base offset column
expression   DESeq2 / edgeR / limma result tables, CSV or TSV
"""

from __future__ import annotations

import bz2
import gzip
import io as _io
import re
from pathlib import Path
from urllib.parse import unquote

import numpy as np

from .logging_utils import get_logger, warn_once
from .model import (Annotation, Feature, GFF_META_TYPES, MethylSet,
                    empty_methylset, resolve_mod_code)

logger = get_logger("io")

__all__ = [
    "smart_open", "parse_attributes", "read_annotation", "read_fasta",
    "read_fasta_labels", "sniff_methylation_format", "read_methylation",
    "read_motifs", "read_geneexp", "read_seqid_map",
]


# --------------------------------------------------------------------------- #
# Low level
# --------------------------------------------------------------------------- #
def smart_open(path: str | Path, mode: str = "rt"):
    """Open plain, gzip or bzip2 text transparently."""
    p = str(path)
    if p.endswith(".gz"):
        return gzip.open(p, mode, encoding="utf-8" if "t" in mode else None)
    if p.endswith(".bz2"):
        return bz2.open(p, mode, encoding="utf-8" if "t" in mode else None)
    return open(p, mode, encoding="utf-8" if "t" in mode else None)


def parse_attributes(attr_str: str) -> dict[str, str]:
    """Parse a GFF3 column-9 attribute string.

    Percent-encoding is decoded (GFF3 requires ``,;=`` and friends to be escaped,
    so ``product=Fe%2FS+cluster`` must not reach the output as-is).  ``key value``
    pairs are tolerated so GTF-ish files do not silently lose their attributes.
    """
    attrs: dict[str, str] = {}
    for part in attr_str.strip().rstrip(";").split(";"):
        part = part.strip()
        if not part:
            continue
        if "=" in part:
            key, _, val = part.partition("=")
        elif " " in part:
            key, _, val = part.partition(" ")
            val = val.strip('"')
        else:
            continue
        attrs[unquote(key.strip())] = unquote(val.strip())
    return attrs


def _split_gff_line(raw: str) -> list[str] | None:
    cols = raw.split("\t")
    if len(cols) < 9:
        cols = raw.split()
    return cols if len(cols) >= 9 else None


def _first_data_lines(path, n: int = 20) -> list[str]:
    out: list[str] = []
    with smart_open(path) as fh:
        for line in fh:
            if line.startswith(("#", "track", "browser")) or not line.strip():
                continue
            out.append(line.rstrip("\n"))
            if len(out) >= n:
                break
    return out


# --------------------------------------------------------------------------- #
# Annotation
# --------------------------------------------------------------------------- #
def read_annotation(
    path: str | Path,
    feature_types: set[str] | None = None,
    id_attr: str = "ID",
    keep_embedded_fasta: bool = True,
) -> Annotation:
    """Read a GFF3 annotation into 0-based half-open features.

    Parameters
    ----------
    feature_types
        Restrict to these column-3 types.  ``None`` keeps everything except
        the meta types (``region``, ``biological_region`` ...).
    id_attr
        Attribute preferred as the feature id; falls back to ``locus_tag``,
        ``Name`` and finally a synthesised, deterministic id.
    """
    path = Path(path)
    ann = Annotation()
    in_fasta = False
    cur_id: str | None = None
    cur_seq: list[str] = []
    auto_n = 0

    with smart_open(path) as fh:
        for line_no, line in enumerate(fh, start=1):
            raw = line.rstrip("\n")

            if in_fasta:
                if not keep_embedded_fasta:
                    break
                if raw.startswith(">"):
                    if cur_id is not None:
                        ann.embedded_fasta[cur_id] = "".join(cur_seq).upper()
                    cur_id = raw[1:].strip().split()[0] if raw[1:].strip() else ""
                    cur_seq = []
                else:
                    cur_seq.append(raw.strip())
                continue

            if raw.startswith("##FASTA"):
                in_fasta = True
                continue
            if raw.startswith("##sequence-region"):
                parts = raw.split()
                if len(parts) >= 4:
                    try:
                        ann.seq_regions[parts[1]] = int(parts[3])
                    except ValueError:
                        pass
                continue
            if raw.startswith("#") or not raw.strip():
                continue

            cols = _split_gff_line(raw)
            if cols is None:
                ann.n_malformed += 1
                continue

            ftype = cols[2]
            if feature_types is not None:
                if ftype not in feature_types:
                    ann.n_skipped_type += 1
                    continue
            elif ftype in GFF_META_TYPES:
                ann.n_skipped_type += 1
                continue

            try:
                start0 = int(cols[3]) - 1     # GFF3 1-based inclusive
                end0 = int(cols[4])           # -> 0-based half-open
            except ValueError:
                ann.n_malformed += 1
                continue
            if end0 <= start0:
                ann.n_malformed += 1
                continue

            attrs = parse_attributes(cols[8])
            locus_tag = attrs.get("locus_tag", "")
            fid = attrs.get(id_attr) or locus_tag or attrs.get("Name", "")
            if not fid:
                auto_n += 1
                fid = f"{ftype}:{cols[0]}:{start0 + 1}-{end0}:{auto_n}"
            strand = cols[6] if cols[6] in ("+", "-", ".") else "."

            ann.features.append(Feature(
                seqid=cols[0], ftype=ftype, start=start0, end=end0,
                strand=strand, fid=fid, locus_tag=locus_tag or fid,
                gene=attrs.get("gene", ""), product=attrs.get("product", ""),
            ))

    if in_fasta and cur_id:
        ann.embedded_fasta[cur_id] = "".join(cur_seq).upper()

    logger.info("Annotation %s: %d feature(s), %d skipped by type, %d malformed.",
                path.name, len(ann.features), ann.n_skipped_type, ann.n_malformed)
    if ann.n_malformed:
        warn_once(logger, "GFF_MALFORMED",
                  f"{path.name}: {ann.n_malformed} annotation line(s) could not be "
                  f"parsed and were skipped.")
    if not ann.features:
        warn_once(logger, "GFF_EMPTY",
                  f"{path.name}: no features loaded — check --feature-types and the file.")
    return ann


# --------------------------------------------------------------------------- #
# FASTA
# --------------------------------------------------------------------------- #
def read_fasta(path: str | Path) -> dict[str, str]:
    genome: dict[str, str] = {}
    cur: str | None = None
    buf: list[str] = []
    with smart_open(path) as fh:
        for line in fh:
            if line.startswith(">"):
                if cur is not None:
                    genome[cur] = "".join(buf).upper()
                cur = line[1:].strip().split()[0] if line[1:].strip() else ""
                buf = []
            else:
                buf.append(line.strip())
    if cur is not None:
        genome[cur] = "".join(buf).upper()
    return genome


_PLASMID_RE = re.compile(r"plasmid\s+([^\s,;]+)", re.IGNORECASE)


def read_fasta_labels(path: str | Path | None, strip_version_fn=None) -> dict[str, str]:
    """Short human-readable replicon labels taken from FASTA descriptions.

    Labels are made filesystem-safe and unique, because they are used in output
    filenames; two records both described as "plasmid" used to overwrite each
    other's figures.
    """
    labels: dict[str, str] = {}
    if not path:
        return labels
    used: dict[str, int] = {}
    try:
        with smart_open(path) as fh:
            for line in fh:
                if not line.startswith(">"):
                    continue
                header = line[1:].strip()
                if not header:
                    continue
                sid = header.split()[0]
                if strip_version_fn is not None:
                    sid = strip_version_fn(sid)
                low = header.lower()
                if "chromosome" in low:
                    lab = "chromosome"
                elif "plasmid" in low:
                    m = _PLASMID_RE.search(header)
                    lab = m.group(1) if m else "plasmid"
                else:
                    lab = sid
                lab = re.sub(r"[^A-Za-z0-9._-]+", "_", lab).strip("_") or sid
                if lab in used:
                    used[lab] += 1
                    lab = f"{lab}_{used[lab]}"
                else:
                    used[lab] = 1
                labels[sid] = lab
    except OSError:
        pass
    return labels


# --------------------------------------------------------------------------- #
# Methylation
# --------------------------------------------------------------------------- #
def _looks_like_gff(cols: list[str]) -> bool:
    if len(cols) < 8:
        return False
    try:
        int(cols[3]); int(cols[4])
    except ValueError:
        return False
    return cols[6] in ("+", "-", ".")


def _looks_like_bed(cols: list[str]) -> bool:
    if len(cols) < 4:
        return False
    try:
        int(cols[1]); int(cols[2])
    except ValueError:
        return False
    return True


def sniff_methylation_format(path: str | Path) -> tuple[str, int]:
    """Detect ``("bedmethyl"|"bed6"|"gff", n_columns)`` from file content.

    Extension-only detection was the previous behaviour and it mislabels the
    common case of a modkit bedMethyl written as ``.txt`` or a GFF3 of
    modification calls named ``.bed``.
    """
    lines = _first_data_lines(path, 5)
    if not lines:
        raise ValueError(f"{path}: no data lines found.")
    first = lines[0]
    cols = first.split("\t")
    if len(cols) < 4:
        cols = first.split()
    n = len(cols)

    if n >= 11 and _looks_like_bed(cols):
        return "bedmethyl", n
    if _looks_like_gff(cols) and not (n >= 11 and _looks_like_bed(cols)):
        # 9-column GFF3 vs 9-column BED: GFF has integer start/end in 3/4.
        if not _looks_like_bed(cols) or n == 9:
            return "gff", n
    if _looks_like_bed(cols):
        # ENCODE bedMethyl keeps fields 10/11 space-separated after a BED9 block
        if n == 9:
            tail = cols[8].split()
            if len(tail) >= 2:
                return "bedmethyl", 11
        return ("bedmethyl", n) if n >= 11 else ("bed6", n)
    raise ValueError(f"{path}: cannot determine methylation format from content; "
                     f"pass --meth-format explicitly.")


def _norm_frac(v: float) -> float:
    return v / 100.0 if v > 1.0 else v


def read_methylation(
    path: str | Path,
    fmt: str = "auto",
    keep_codes: set[str] | None = None,
    min_coverage: float = 0.0,
    min_frac: float | None = None,
) -> MethylSet:
    """Read methylation calls of any supported flavour into a :class:`MethylSet`.

    ``min_frac`` is applied here rather than in each tool so that "assayed" and
    "methylated" cannot drift apart between modules.  Passing ``None`` keeps
    every assayed position, which is what the level-gradient and enrichment
    statistics need.
    """
    path = Path(path)
    if fmt == "auto":
        fmt, ncols = sniff_methylation_format(path)
        logger.info("Methylation %s: detected format=%s (%d columns).",
                    path.name, fmt, ncols)
    else:
        _f, ncols = sniff_methylation_format(path)
        if _f != fmt:
            warn_once(logger, "METH_FORMAT_OVERRIDE",
                      f"{path.name}: content looks like '{_f}' but --meth-format "
                      f"says '{fmt}'; using '{fmt}' as instructed.")

    if fmt == "gff":
        ms = _read_meth_gff(path, keep_codes)
    else:
        ms = _read_meth_bed(path, keep_codes, bedmethyl=(fmt == "bedmethyl"))
    ms.source = str(path)
    ms.fmt = fmt

    n_raw = len(ms)
    ms = ms.filter(min_cov=min_coverage, min_frac=min_frac)
    logger.info("Methylation %s: %d call(s) loaded, %d retained after filters "
                "(min_cov=%g, min_frac=%s).",
                path.name, n_raw, len(ms), min_coverage,
                "off" if min_frac is None else f"{min_frac:g}")

    if ms.presence_only:
        warn_once(logger, "METH_PRESENCE_ONLY",
                  f"{path.name} carries no fraction-modified column: every record is "
                  f"treated as a methylated position. Statistics that need "
                  f"methylated-vs-assayed contrasts (mematch site-level enrichment, "
                  f"spacem level gradient) switch to their presence-only variants.")
    if len(ms) == 0:
        warn_once(logger, "METH_EMPTY",
                  f"{path.name}: no methylation calls survived parsing/filtering.")
    return ms


CHUNK_ROWS = 2_000_000


def _read_meth_bed(path: Path, keep_codes: set[str] | None, bedmethyl: bool,
                   chunksize: int | None = CHUNK_ROWS) -> MethylSet:
    """Parse a BED/bedMethyl, in chunks so peak memory does not track file size.

    A full modkit bedMethyl for a high-coverage bacterial genome is tens of
    millions of rows; holding the string DataFrame and the converted arrays at
    once roughly doubles peak memory for no benefit.  Chunks are converted and
    the strings released before the next block is read.
    """
    import pandas as pd

    lines = _first_data_lines(path, 1)
    ncols = len(lines[0].split("\t")) if lines else 0
    space_tail = bedmethyl and ncols == 9

    reader = pd.read_csv(path, sep="\t", header=None, comment="#", dtype=str,
                         na_filter=False, names=list(range(max(ncols, 6))),
                         engine="c", on_bad_lines="skip",
                         chunksize=chunksize)
    parts = []
    for block in (reader if chunksize else [reader]):
        piece = _convert_bed_block(block, keep_codes, bedmethyl, space_tail)
        if piece is not None:
            parts.append(piece)
    if not parts:
        return empty_methylset()
    cols = [np.concatenate([p[i] for p in parts]) for i in range(6)]
    return MethylSet(*cols)


def _convert_bed_block(df, keep_codes, bedmethyl, space_tail):
    import pandas as pd
    if space_tail and 8 in df.columns:
        tail = df[8].str.split(expand=True)
        tail.columns = [8 + i for i in range(tail.shape[1])]
        df = pd.concat([df.drop(columns=[8]), tail], axis=1)

    df = df[df[0].astype(str).str.startswith(("#", "track", "browser")) == False]  # noqa: E712
    if df.empty:
        return None

    chrom = df[0].to_numpy(dtype=object)
    pos = pd.to_numeric(df[1], errors="coerce").to_numpy()
    mod = (df[3].to_numpy(dtype=object) if df.shape[1] > 3
           else np.full(len(df), ".", dtype=object))
    strand = (df[5].to_numpy(dtype=object) if df.shape[1] > 5
              else np.full(len(df), ".", dtype=object))
    strand = np.array([s if s in ("+", "-", ".") else "." for s in strand], dtype=object)

    n = len(df)
    cov = np.full(n, np.nan)
    frac = np.full(n, np.nan)
    if bedmethyl and df.shape[1] >= 11:
        cov = pd.to_numeric(df[9], errors="coerce").to_numpy(dtype=float)
        raw_frac = pd.to_numeric(df[10], errors="coerce").to_numpy(dtype=float)
        with np.errstate(invalid="ignore"):
            frac = np.where(raw_frac > 1.0, raw_frac / 100.0, raw_frac)

    good = ~np.isnan(pos)
    if keep_codes:
        good &= np.isin(mod, list(keep_codes))
    if not good.any():
        return None
    return (chrom[good], pos[good].astype(np.int64), mod[good],
            strand[good], cov[good], frac[good])


_COV_KEYS = ("coverage", "cov", "Nvalid_cov", "valid_coverage", "Ncov", "depth")
_FRAC_KEYS = ("frac", "frac_modified", "fraction", "fraction_modified",
              "percent_modified", "percentage", "methylation")


def _read_meth_gff(path: Path, keep_codes: set[str] | None) -> MethylSet:
    chrom_l, pos_l, mod_l, strand_l, cov_l, frac_l = [], [], [], [], [], []
    n_bad = 0
    with smart_open(path) as fh:
        for line in fh:
            raw = line.rstrip("\n")
            if raw.startswith("##FASTA"):
                break
            if raw.startswith("#") or not raw.strip():
                continue
            cols = raw.split("\t")
            if len(cols) < 8:
                cols = raw.split()
            if len(cols) < 8:
                n_bad += 1
                continue
            ftype = cols[2]
            if ftype in GFF_META_TYPES:
                continue
            try:
                pos = int(cols[3]) - 1
            except ValueError:
                n_bad += 1
                continue
            attrs = parse_attributes(cols[8]) if len(cols) >= 9 else {}
            code = resolve_mod_code(ftype, attrs)
            if keep_codes and code not in keep_codes:
                continue
            cov = np.nan
            for k in _COV_KEYS:
                if k in attrs:
                    try:
                        cov = float(attrs[k]); break
                    except ValueError:
                        pass
            frac = np.nan
            for k in _FRAC_KEYS:
                if k in attrs:
                    try:
                        frac = _norm_frac(float(attrs[k])); break
                    except ValueError:
                        pass
            chrom_l.append(cols[0])
            pos_l.append(pos)
            mod_l.append(code)
            strand_l.append(cols[6] if cols[6] in ("+", "-", ".") else ".")
            cov_l.append(cov)
            frac_l.append(frac)

    if n_bad:
        warn_once(logger, "METH_GFF_MALFORMED",
                  f"{path.name}: {n_bad} methylation line(s) skipped as malformed.")
    if not pos_l:
        return empty_methylset()
    return MethylSet(np.array(chrom_l, dtype=object), np.array(pos_l, dtype=np.int64),
                     np.array(mod_l, dtype=object), np.array(strand_l, dtype=object),
                     np.array(cov_l, dtype=float), np.array(frac_l, dtype=float))


# --------------------------------------------------------------------------- #
# Motifs
# --------------------------------------------------------------------------- #
IUPAC_TO_REGEX = {
    "A": "A", "C": "C", "G": "G", "T": "T", "U": "T",
    "R": "[AG]", "Y": "[CT]", "S": "[GC]", "W": "[AT]",
    "K": "[GT]", "M": "[AC]",
    "B": "[CGT]", "D": "[AGT]", "H": "[ACT]", "V": "[ACG]", "N": "[ACGT]",
}


def read_motifs(path: str | Path) -> list[tuple[str, int | None]]:
    """Parse a motif list: ``MOTIF[<whitespace>offset]`` per line."""
    motifs: list[tuple[str, int | None]] = []
    seen: set[str] = set()
    with smart_open(path) as fh:
        for lineno, raw in enumerate(fh, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            motif = parts[0].upper()
            for b in motif:
                if b not in IUPAC_TO_REGEX:
                    raise ValueError(
                        f"{path}:{lineno}: illegal IUPAC base {b!r} in motif {motif!r}")
            offset: int | None = None
            if len(parts) > 1:
                try:
                    offset = int(parts[1])
                except ValueError:
                    raise ValueError(
                        f"{path}:{lineno}: modified-base offset must be an integer, "
                        f"got {parts[1]!r}") from None
                if not (0 <= offset < len(motif)):
                    raise ValueError(
                        f"{path}:{lineno}: offset {offset} outside motif "
                        f"{motif!r} (allowed 0..{len(motif) - 1})")
            if motif in seen:
                warn_once(logger, "MOTIF_DUPLICATE",
                          f"Motif {motif!r} listed more than once; keeping the first entry.")
                continue
            seen.add(motif)
            motifs.append((motif, offset))
    if not motifs:
        raise ValueError(f"{path}: no motifs parsed.")
    return motifs


# --------------------------------------------------------------------------- #
# Expression
# --------------------------------------------------------------------------- #
_GENE_COL_CANDIDATES = ("deg", "locus_tag", "gene_id", "geneid", "gene", "id",
                        "row.names", "rowname", "name", "unnamed: 0", "")
_LFC_CANDIDATES = ("log2foldchange", "log2fc", "logfc", "log2_fold_change", "lfc")
_PADJ_CANDIDATES = ("padj", "fdr", "qvalue", "adj.p.val", "q_value", "padj_bh",
                    "adjusted_pvalue", "p_adj")
_PVAL_CANDIDATES = ("pvalue", "p_value", "pval", "p.value", "pvalues")


def _pick(colmap: dict[str, str], candidates) -> str | None:
    for c in candidates:
        if c in colmap:
            return colmap[c]
    return None


def read_geneexp(path: str | Path, gene_col: str | None = None,
                 lfc_col: str | None = None, padj_col: str | None = None):
    """Read a differential-expression result table (DESeq2, edgeR or limma).

    The original ``diem`` required exactly DESeq2's columns plus a ``deg`` id
    column.  Column names are now resolved case-insensitively across the three
    common tools, and the gene id is taken from the unnamed index column when no
    explicit id column exists — the shape ``write.csv(res)`` actually produces.
    """
    import pandas as pd

    path = Path(path)
    sep = "," if path.suffix.lower() in (".csv", ".csv.gz") else "\t"
    if path.suffix.lower() not in (".csv", ".tsv", ".txt", ".gz"):
        sep = ","
    df = pd.read_csv(path, sep=sep, comment="#")
    if df.shape[1] == 1:  # wrong guess
        df = pd.read_csv(path, sep="\t" if sep == "," else ",", comment="#")

    colmap = {str(c).strip().lower(): c for c in df.columns}

    gcol = gene_col or _pick(colmap, _GENE_COL_CANDIDATES)
    if gcol is None or gcol not in df.columns:
        gcol = df.columns[0]
        warn_once(logger, "GE_GENE_COL",
                  f"{path.name}: no recognised gene-id column; using the first "
                  f"column {gcol!r} as the locus identifier.")
    lcol = lfc_col or _pick(colmap, _LFC_CANDIDATES)
    pcol = padj_col or _pick(colmap, _PADJ_CANDIDATES)
    if lcol is None:
        raise ValueError(f"{path}: no log2 fold-change column found "
                         f"(looked for {_LFC_CANDIDATES}).")
    if pcol is None:
        raw_p = _pick(colmap, _PVAL_CANDIDATES)
        if raw_p is None:
            raise ValueError(f"{path}: no adjusted p-value column found "
                             f"(looked for {_PADJ_CANDIDATES}).")
        warn_once(logger, "GE_NO_PADJ",
                  f"{path.name}: no adjusted p-value column; applying "
                  f"Benjamini-Hochberg to {raw_p!r} inside MErlin.")
        from .stats import benjamini_hochberg
        df["padj__merlin"] = benjamini_hochberg(
            df[raw_p].fillna(1.0).to_numpy(dtype=float))
        pcol = "padj__merlin"

    out = df.rename(columns={gcol: "locus_tag", lcol: "log2FoldChange", pcol: "padj"})
    out["locus_tag"] = out["locus_tag"].astype(str).str.strip()
    out["log2FoldChange"] = pd.to_numeric(out["log2FoldChange"], errors="coerce")
    out["padj"] = pd.to_numeric(out["padj"], errors="coerce")
    logger.info("Expression %s: %d row(s); id=%r, lfc=%r, padj=%r.",
                path.name, len(out), gcol, lcol, pcol)
    return out


# --------------------------------------------------------------------------- #
# Misc
# --------------------------------------------------------------------------- #
def read_seqid_map(path: str | Path) -> dict[str, str]:
    mapping: dict[str, str] = {}
    with smart_open(path) as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t") if "\t" in line else line.split()
            if len(parts) >= 2:
                mapping[parts[0]] = parts[1]
    return mapping
