"""Read-level methylation from modBAM (ROADMAP 3.1).

Per-position fractions average over reads and destroy exactly the phenomena
prokaryotic methylation is known for.  A GATC at 50 % is either *half the cells*
or *one strand*, and a bedMethyl cannot tell you which:

**hemimethylation**
    a site methylated on one strand only — the transient state after replication
    and the switch in phase variation.  Visible as strand asymmetry at a
    palindromic motif, which needs the two strands to be compared site by site
    rather than merged.

**epigenetic bistability**
    a locus methylated in some cells and unmethylated in others.  Invisible at a
    single site (binary reads at one position are Bernoulli either way), but
    visible in the distribution of *per-read* methylation fractions across a
    region: a bistable locus gives a bimodal distribution, a uniformly
    intermediate one gives a unimodal distribution around the mean.

**cis co-methylation**
    whether nearby sites on the *same molecule* agree.  This is the within-DNA
    version of the contact-conditioned co-methylation ``hicam`` measures between
    distant loci, and needs single reads by definition.

The data for all three is almost certainly already on disk: dorado and modkit
write ``MM``/``ML`` tags into the aligned BAM, and this module reads them
directly through :mod:`pysam`.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("reads")

# ML qualities are 0-255 probabilities of the modification being present
DEFAULT_HIGH = 0.8
DEFAULT_LOW = 0.2


def _pysam():
    try:
        import pysam
        return pysam
    except ImportError:  # pragma: no cover
        raise SystemExit(
            "[FATAL] read-level analysis needs pysam (`pip install pysam`). "
            "Everything else in MErlin works without it.") from None


@dataclass
class ReadCalls:
    """Sparse read x site matrix of ternary calls: 1 methylated, 0 not, -1 unknown."""

    read_names: list[str] = field(default_factory=list)
    sites: dict[tuple[str, int, str, str], int] = field(default_factory=dict)
    rows: list[int] = field(default_factory=list)
    cols: list[int] = field(default_factory=list)
    vals: list[int] = field(default_factory=list)
    site_keys: list[tuple[str, int, str, str]] = field(default_factory=list)

    def site_index(self, key) -> int:
        idx = self.sites.get(key)
        if idx is None:
            idx = len(self.site_keys)
            self.sites[key] = idx
            self.site_keys.append(key)
        return idx

    def add(self, read_row: int, key, value: int) -> None:
        self.rows.append(read_row)
        self.cols.append(self.site_index(key))
        self.vals.append(value)

    def to_arrays(self):
        return (np.asarray(self.rows, dtype=np.int64),
                np.asarray(self.cols, dtype=np.int64),
                np.asarray(self.vals, dtype=np.int8))

    @property
    def n_reads(self) -> int:
        return len(self.read_names)

    @property
    def n_sites(self) -> int:
        return len(self.site_keys)


def read_modbam(path: str, region: str | None = None, min_mapq: int = 20,
                high: float = DEFAULT_HIGH, low: float = DEFAULT_LOW,
                max_reads: int | None = None,
                keep_codes: set[str] | None = None) -> ReadCalls:
    """Extract per-read modification calls from an aligned modBAM.

    A call is *methylated* when its ML probability is at or above ``high``,
    *unmethylated* at or below ``low``, and *unknown* in between — the ambiguous
    middle is dropped rather than being forced to a side, because forcing it is
    what turns a bimodal population into an intermediate average.
    """
    pysam = _pysam()
    out = ReadCalls()
    n_skipped_nomod = 0
    with pysam.AlignmentFile(path, "rb", check_sq=False) as bam:
        it = bam.fetch(region=region) if region else bam.fetch(until_eof=True)
        for read in it:
            if read.is_unmapped or read.is_secondary or read.is_supplementary:
                continue
            if read.mapping_quality < min_mapq:
                continue
            mods = None
            try:
                mods = read.modified_bases
            except (AttributeError, ValueError):
                mods = None
            if not mods:
                n_skipped_nomod += 1
                continue
            pairs = read.get_aligned_pairs(matches_only=True)
            q2r = {q: r for q, r in pairs}
            row = len(out.read_names)
            out.read_names.append(read.query_name)
            read_strand = "-" if read.is_reverse else "+"
            chrom = read.reference_name
            added = False
            for (_canon, mod_strand, code), calls in mods.items():
                code = str(code)
                # MM key strand: 0 = same strand as the read, 1 = the opposite one.
                # Taking the read's own strand for every call would put every
                # 'G-m'/'T-a' record on the wrong strand, which is precisely the
                # distinction the hemimethylation analysis rests on.
                if int(mod_strand) == 1:
                    strand = "+" if read_strand == "-" else "-"
                else:
                    strand = read_strand
                if keep_codes and code not in keep_codes:
                    continue
                for qpos, qual in calls:
                    ref = q2r.get(qpos)
                    if ref is None:
                        continue
                    p = qual / 255.0
                    if p >= high:
                        value = 1
                    elif p <= low:
                        value = 0
                    else:
                        continue
                    out.add(row, (chrom, int(ref), strand, code), value)
                    added = True
            if not added:
                out.read_names.pop()
            if max_reads and len(out.read_names) >= max_reads:
                break
    if n_skipped_nomod:
        warn_once(logger, "MODBAM_NO_TAGS",
                  f"{n_skipped_nomod} read(s) carried no MM/ML modification tags "
                  f"and were skipped. If that is most of the file, the BAM was "
                  f"not produced by a modification-aware basecaller.")
    logger.info("modBAM %s: %d read(s), %d site(s), %d call(s).",
                path, out.n_reads, out.n_sites, len(out.vals))
    return out


# --------------------------------------------------------------------------- #
# Site-level summaries
# --------------------------------------------------------------------------- #
def site_table(calls: ReadCalls):
    """Per (chrom, pos, strand, mod): reads, methylated reads, fraction."""
    import pandas as pd
    rows, cols, vals = calls.to_arrays()
    if cols.size == 0:
        return pd.DataFrame(columns=["replicon", "pos", "strand", "mod_code",
                                     "n_reads", "n_meth", "frac"])
    n_sites = calls.n_sites
    n_reads = np.bincount(cols, minlength=n_sites)
    n_meth = np.bincount(cols, weights=(vals == 1).astype(float), minlength=n_sites)
    keys = calls.site_keys
    with np.errstate(invalid="ignore", divide="ignore"):
        frac = np.where(n_reads > 0, n_meth / np.maximum(n_reads, 1), np.nan)
    return pd.DataFrame({
        "replicon": [k[0] for k in keys],
        "pos": [k[1] for k in keys],
        "strand": [k[2] for k in keys],
        "mod_code": [k[3] for k in keys],
        "n_reads": n_reads.astype(int),
        "n_meth": n_meth.astype(int),
        "frac": frac})


def hemimethylation(sites, motif_pairs, min_reads: int = 10):
    """Strand asymmetry at paired motif positions.

    ``motif_pairs`` maps ``(replicon, plus_pos) -> minus_pos`` for a palindromic
    motif — for Dam, the A of GATC on each strand.  A site whose two strands
    disagree is hemimethylated *in the population*; a single short read covers
    one strand only, so per-molecule hemimethylation needs duplex data and this
    is explicitly the population proxy.
    """
    import pandas as pd
    if sites.empty:
        return pd.DataFrame()
    idx = {(r.replicon, r.pos, r.strand): r for r in sites.itertuples()}
    rows = []
    for (rep, ppos), mpos in motif_pairs.items():
        a = idx.get((rep, ppos, "+"))
        b = idx.get((rep, mpos, "-"))
        if a is None or b is None:
            continue
        if a.n_reads < min_reads or b.n_reads < min_reads:
            continue
        rows.append(dict(replicon=rep, plus_pos=ppos, minus_pos=mpos,
                         plus_reads=a.n_reads, minus_reads=b.n_reads,
                         plus_frac=a.frac, minus_frac=b.frac,
                         asymmetry=abs(a.frac - b.frac),
                         both_high=int(a.frac >= 0.8 and b.frac >= 0.8),
                         hemi_like=int(abs(a.frac - b.frac) >= 0.5)))
    df = pd.DataFrame(rows)
    if len(df):
        logger.info("Hemimethylation: %d paired site(s); %d with strand asymmetry "
                    ">= 0.5.", len(df), int(df["hemi_like"].sum()))
    return df


# --------------------------------------------------------------------------- #
# Per-region read-level heterogeneity
# --------------------------------------------------------------------------- #
def bimodality_coefficient(x) -> float:
    """Sarle's bimodality coefficient. > 5/9 is the conventional flag.

    Cheap, distribution-free and interpretable; unlike a mixture-model
    likelihood it cannot mistake a heavy tail for a second component, and unlike
    a dip test it needs no tabulated critical values.
    """
    v = np.asarray(x, float)
    v = v[np.isfinite(v)]
    n = v.size
    if n < 8 or np.std(v) == 0:
        return float("nan")
    m = v.mean(); s = v.std(ddof=1)
    g = float(np.mean(((v - m) / s) ** 3))
    k = float(np.mean(((v - m) / s) ** 4) - 3.0)
    denom = k + 3.0 * (n - 1) ** 2 / ((n - 2) * (n - 3))
    return float((g ** 2 + 1.0) / denom) if denom > 0 else float("nan")


def read_fraction_per_region(calls: ReadCalls, regions, min_sites: int = 3):
    """For each region, the per-read fraction of its sites that are methylated.

    ``regions`` is an iterable of ``Feature``.  A bistable locus gives a bimodal
    distribution here; a uniformly half-methylated one gives a unimodal
    distribution centred on 0.5.  That distinction is the entire point of going
    back to reads.
    """
    rows, cols, vals = calls.to_arrays()
    if cols.size == 0:
        return {}
    keys = calls.site_keys
    site_rep = np.array([k[0] for k in keys], dtype=object)
    site_pos = np.array([k[1] for k in keys], dtype=np.int64)

    out: dict[str, np.ndarray] = {}
    for feat in regions:
        sel_sites = np.flatnonzero((site_rep == feat.seqid)
                                   & (site_pos >= feat.start)
                                   & (site_pos < feat.end))
        if sel_sites.size < min_sites:
            continue
        member = np.zeros(len(keys), dtype=bool)
        member[sel_sites] = True
        pick = member[cols]
        if not pick.any():
            continue
        r = rows[pick]; v = vals[pick]
        order = np.argsort(r, kind="stable")
        r, v = r[order], v[order]
        bounds = np.flatnonzero(np.r_[True, r[1:] != r[:-1]])
        bounds = np.r_[bounds, r.size]
        fracs, ns = [], []
        for i in range(bounds.size - 1):
            lo, hi = bounds[i], bounds[i + 1]
            seg = v[lo:hi]
            if seg.size >= min_sites:
                fracs.append(float((seg == 1).sum() / seg.size))
                ns.append(seg.size)
        if len(fracs) >= 8:
            out[feat.key] = np.asarray(fracs)
    return out


def bistability_table(region_fracs: dict[str, np.ndarray], bc_threshold=5 / 9):
    import pandas as pd
    rows = []
    for key, fr in region_fracs.items():
        bc = bimodality_coefficient(fr)
        rows.append(dict(feature=key, n_reads=int(fr.size), mean_frac=float(fr.mean()),
                         sd_frac=float(fr.std(ddof=1)) if fr.size > 1 else np.nan,
                         frac_reads_high=float((fr >= 0.8).mean()),
                         frac_reads_low=float((fr <= 0.2).mean()),
                         bimodality_coefficient=bc,
                         bimodal=int(np.isfinite(bc) and bc > bc_threshold)))
    df = pd.DataFrame(rows)
    if len(df):
        df = df.sort_values("bimodality_coefficient", ascending=False,
                            kind="stable").reset_index(drop=True)
        logger.info("Bistability: %d region(s) scored, %d flagged bimodal "
                    "(BC > %.3f).", len(df), int(df["bimodal"].sum()), bc_threshold)
    return df


# --------------------------------------------------------------------------- #
# Cis co-methylation
# --------------------------------------------------------------------------- #
def cis_comethylation(calls: ReadCalls, max_distance: int = 2000,
                      n_bins: int = 10, min_pairs: int = 30, max_reads: int = 20000):
    """Phi coefficient between site pairs on the same read, binned by distance.

    Positive phi at short range means a molecule methylated at one site tends to
    be methylated at the next — the signature of a cell-level state rather than
    independent stochastic modification at each position.
    """
    import pandas as pd
    rows, cols, vals = calls.to_arrays()
    if cols.size == 0:
        return pd.DataFrame()
    keys = calls.site_keys
    site_rep = np.array([k[0] for k in keys], dtype=object)
    site_pos = np.array([k[1] for k in keys], dtype=np.int64)

    order = np.argsort(rows, kind="stable")
    rows, cols, vals = rows[order], cols[order], vals[order]
    bounds = np.flatnonzero(np.r_[True, rows[1:] != rows[:-1]])
    bounds = np.r_[bounds, rows.size]

    acc: dict[int, list[int]] = defaultdict(lambda: [0, 0, 0, 0])
    edges = np.unique(np.geomspace(20, max(max_distance, 40), n_bins + 1).astype(int))
    n_used = 0
    for i in range(bounds.size - 1):
        if n_used >= max_reads:
            break
        lo, hi = bounds[i], bounds[i + 1]
        c = cols[lo:hi]; v = vals[lo:hi]
        if c.size < 2:
            continue
        n_used += 1
        p = site_pos[c]
        srt = np.argsort(p, kind="stable")
        p, v, c = p[srt], v[srt], c[srt]
        rep = site_rep[c]
        for a in range(p.size - 1):
            for b in range(a + 1, p.size):
                d = int(p[b] - p[a])
                if d > max_distance:
                    break
                if rep[a] != rep[b]:
                    continue
                k = int(np.searchsorted(edges, d, side="right") - 1)
                if k < 0 or k >= edges.size - 1:
                    continue
                cell = (1 if v[a] == 1 else 0) * 2 + (1 if v[b] == 1 else 0)
                acc[k][cell] += 1

    out = []
    for k in sorted(acc):
        n00, n01, n10, n11 = acc[k][0], acc[k][1], acc[k][2], acc[k][3]
        total = n00 + n01 + n10 + n11
        if total < min_pairs:
            continue
        num = n11 * n00 - n10 * n01
        den = np.sqrt(float((n11 + n10) * (n01 + n00) * (n11 + n01) * (n10 + n00)))
        phi = float(num / den) if den > 0 else np.nan
        out.append(dict(dist_min=int(edges[k]), dist_max=int(edges[k + 1]),
                        n_pairs=total, phi=phi,
                        both_meth=n11, both_unmeth=n00, discordant=n01 + n10))
    df = pd.DataFrame(out)
    if len(df):
        logger.info("Cis co-methylation: %d distance bin(s) over %d read(s).",
                    len(df), n_used)
    return df


def motif_strand_pairs(motif_hits, motif: str) -> dict[tuple[str, int], int]:
    """(replicon, plus modified base) -> minus-strand modified base of the same site."""
    hits = motif_hits.get(motif)
    pairs: dict[tuple[str, int], int] = {}
    if hits is None or not hits.has_offset:
        return pairs
    by_start: dict[tuple[str, int, str], int] = {}
    for i in range(len(hits)):
        by_start[(hits.seqid[i], int(hits.start[i]), hits.strand[i])] = \
            int(hits.mod_pos[i])
    for (rep, start, strand), mod_pos in by_start.items():
        if strand != "+":
            continue
        minus = by_start.get((rep, start, "-"))
        if minus is not None:
            pairs[(rep, mod_pos)] = minus
    return pairs
