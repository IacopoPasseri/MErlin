"""Replicon geometry: GC skew, oriC/ter, and the ori->ter coordinate system.

``spacem`` and ``roundtable.R`` each carried their own copy of this and could
disagree about where the origin was on the same genome.  Here there is one
implementation, vectorised over the sequence rather than looping windows in
Python, and it reports how *confident* the origin call is instead of silently
returning the argmin of a flat curve.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .logging_utils import get_logger, warn_once

logger = get_logger("genome")

_G, _C, _A, _T = 71, 67, 65, 84


def as_bytes(seq: str) -> np.ndarray:
    return np.frombuffer(seq.encode("ascii", "ignore"), dtype=np.uint8)


def base_cumsums(seq: str) -> dict[str, np.ndarray]:
    arr = as_bytes(seq)
    return {
        "G": np.r_[0, np.cumsum(arr == _G)],
        "C": np.r_[0, np.cumsum(arr == _C)],
        "A": np.r_[0, np.cumsum(arr == _A)],
        "T": np.r_[0, np.cumsum(arr == _T)],
    }


def window_counts(cum: np.ndarray, starts: np.ndarray, ends: np.ndarray) -> np.ndarray:
    return cum[ends] - cum[starts]


@dataclass(slots=True)
class SkewProfile:
    centers: np.ndarray
    cumulative: np.ndarray
    oric: int
    ter: int
    amplitude: float
    relative_amplitude: float
    weak: bool
    source: str = "gc-skew"

    @property
    def confident(self) -> bool:
        return not self.weak


def gc_skew(seq: str, window: int = 10000,
            min_relative_amplitude: float = 0.02) -> SkewProfile:
    """Locate oriC and ter from the cumulative GC skew of a circular replicon.

    oriC is the global minimum of the cumulative ``(G - C)`` curve.  ter is the
    maximum of the same curve *re-started at the origin* and walked around the
    circle — taking the linear argmax instead locks onto the arbitrary contig
    start rather than the true antipodal terminus.

    ``relative_amplitude`` is the skew swing divided by replicon length, and is
    what makes a weak call detectable: plasmids and recently rearranged
    replicons often have no usable skew, in which case the returned oriC is an
    artefact of noise and every downstream ori->ter statistic is meaningless.
    """
    L = len(seq)
    if L == 0:
        return SkewProfile(np.zeros(0), np.zeros(0), 0, 0, 0.0, 0.0, True)
    window = max(1, min(window, max(1, L // 4)))
    starts = np.arange(0, L, window)
    ends = np.minimum(starts + window, L)
    cums = base_cumsums(seq)
    g = window_counts(cums["G"], starts, ends).astype(np.int64)
    c = window_counts(cums["C"], starts, ends).astype(np.int64)
    delta = g - c
    cum = np.cumsum(delta)
    centers = (starts + ends) // 2
    n = delta.size
    if n < 4:
        return SkewProfile(centers, cum, int(centers[0]), int(centers[-1]),
                           0.0, 0.0, True)

    oi = int(np.argmin(cum))
    rot = np.cumsum(np.r_[delta[oi:], delta[:oi]])
    ti = int((oi + int(np.argmax(rot))) % n)
    amplitude = float(rot.max() - rot.min())
    rel = amplitude / L
    weak = rel < min_relative_amplitude
    return SkewProfile(centers, cum, int(centers[oi]), int(centers[ti]),
                       amplitude, rel, weak)


def resolve_origins(genome: dict[str, str], window: int,
                    oric_override: dict[str, int] | None = None,
                    ter_override: dict[str, int] | None = None,
                    min_relative_amplitude: float = 0.02,
                    ) -> dict[str, SkewProfile]:
    """Per-replicon oriC/ter, honouring overrides and flagging weak calls."""
    oric_override = oric_override or {}
    ter_override = ter_override or {}
    out: dict[str, SkewProfile] = {}
    for seqid, seq in genome.items():
        sp = gc_skew(seq, window, min_relative_amplitude)
        src = sp.source
        if seqid in oric_override:
            sp.oric = int(oric_override[seqid]); src = "user"
        if seqid in ter_override:
            sp.ter = int(ter_override[seqid]); src = "user"
        if src == "user":
            sp.weak = False
            sp.source = "user-supplied"
        elif sp.weak:
            warn_once(logger, f"SKEW_WEAK_{seqid}",
                      f"{seqid}: cumulative GC-skew amplitude is {sp.relative_amplitude:.4f} "
                      f"of replicon length — too flat to place oriC/ter reliably. "
                      f"Every ori->ter statistic for this replicon should be treated "
                      f"as undefined, or supply --oric/--ter.")
        out[seqid] = sp
    return out


# --------------------------------------------------------------------------- #
# ori -> ter coordinate
# --------------------------------------------------------------------------- #
def ori_ter_coordinate(pos, oric: int, ter: int, L: int):
    """Map genomic positions onto the replication axis.

    Returns ``(signed, folded, arm)``: ``signed`` in [-1, 1] keeps the two
    replichores distinguishable, ``folded`` in [0, 1] is the distance from oriC
    (0 = oriC, 1 = ter), ``arm`` is ``+1`` for the clockwise replichore and
    ``-1`` for the counter-clockwise one.
    """
    pos = np.asarray(pos, dtype=np.int64)
    d = np.mod(pos - oric, L)
    T = int((ter - oric) % L) or L // 2
    on_plus = d <= T
    folded = np.where(on_plus,
                      d / max(T, 1),
                      (L - d) / max(L - T, 1))
    folded = np.clip(folded, 0.0, 1.0)
    signed = np.where(on_plus, folded, -folded)
    arm = np.where(on_plus, 1, -1)
    return signed, folded, arm


def co_oriented(strand, arm) -> np.ndarray:
    """True where a gene is on the leading strand for its replichore.

    Leading is ``+`` on the clockwise arm and ``-`` on the counter-clockwise
    one.  Unstranded features return NaN (as a float mask) and must be excluded
    from the binomial test rather than counted as half.
    """
    strand = np.asarray(strand, dtype=object)
    arm = np.asarray(arm)
    lead = np.where(arm > 0, "+", "-")
    known = (strand == "+") | (strand == "-")
    out = np.full(strand.shape, np.nan)
    out[known] = (strand[known] == lead[known]).astype(float)
    return out


# --------------------------------------------------------------------------- #
# Binning
# --------------------------------------------------------------------------- #
def bin_edges(length: int, binsize: int) -> np.ndarray:
    nb = max(1, int(np.ceil(length / binsize)))
    return np.minimum(np.arange(nb + 1) * binsize, length)


def bin_counts(positions, length: int, binsize: int) -> np.ndarray:
    edges = bin_edges(length, binsize)
    if len(positions) == 0:
        return np.zeros(edges.size - 1, dtype=np.int64)
    counts, _ = np.histogram(np.asarray(positions, dtype=np.int64), bins=edges)
    return counts.astype(np.int64)


def bin_centers(length: int, binsize: int) -> np.ndarray:
    edges = bin_edges(length, binsize)
    return (edges[:-1] + edges[1:]) / 2.0


def gc_skew_bins(seq: str, binsize: int) -> np.ndarray:
    """Per-bin (G-C)/(G+C)."""
    L = len(seq)
    edges = bin_edges(L, binsize)
    cums = base_cumsums(seq)
    g = window_counts(cums["G"], edges[:-1], edges[1:]).astype(float)
    c = window_counts(cums["C"], edges[:-1], edges[1:]).astype(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where((g + c) > 0, (g - c) / np.maximum(g + c, 1), 0.0)


def gc_content_bins(seq: str, binsize: int) -> np.ndarray:
    L = len(seq)
    edges = bin_edges(L, binsize)
    cums = base_cumsums(seq)
    g = window_counts(cums["G"], edges[:-1], edges[1:]).astype(float)
    c = window_counts(cums["C"], edges[:-1], edges[1:]).astype(float)
    width = (edges[1:] - edges[:-1]).astype(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(width > 0, (g + c) / np.maximum(width, 1), np.nan)


def replicon_lengths(genome: dict[str, str] | None,
                     seq_regions: dict[str, int] | None = None,
                     features=None, methyl=None) -> dict[str, int]:
    """Best available length per replicon: FASTA > ##sequence-region > observed max."""
    lengths: dict[str, int] = {}
    if genome:
        lengths.update({k: len(v) for k, v in genome.items()})
    for k, v in (seq_regions or {}).items():
        lengths.setdefault(k, int(v))
    observed: dict[str, int] = {}
    for f in (features or []):
        observed[f.seqid] = max(observed.get(f.seqid, 0), f.end)
    if methyl is not None and len(methyl):
        for seqid in methyl.seqids:
            sel = methyl.seqid == seqid
            observed[seqid] = max(observed.get(seqid, 0), int(methyl.pos[sel].max()) + 1)
    for k, v in observed.items():
        lengths.setdefault(k, v)
    return lengths
