"""Interval arithmetic shared by the cross-referencing tools.

Two operations dominate MErlin's runtime:

``count_per_feature``
    how many calls of each modification fall inside each annotated feature.
    The original scripts binary-searched for the window start and then walked
    ``positions[lo:]`` — which *copies the tail of the list* once per feature
    per modification.  With 6 000 features and 10^6 calls that is ~10^10 element
    copies.  Here it is one vectorised ``searchsorted`` per (replicon, strand,
    mod) group: O((F + n) log n).

``points_in_intervals``
    which features/motif occurrences contain each call.  Returned in CSR form
    (``offsets``/``values``) rather than a dict of Python lists, which for a
    million calls is the difference between ~40 MB and ~500 MB.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .model import Annotation, Feature, MethylSet


# --------------------------------------------------------------------------- #
# Feature index
# --------------------------------------------------------------------------- #
@dataclass(slots=True)
class SeqFeatures:
    """Array view of the features on one replicon (original order preserved)."""

    idx: np.ndarray      # index into the global feature list
    start: np.ndarray
    end: np.ndarray
    strand: np.ndarray   # object array of '+', '-', '.'


class FeatureIndex:
    __slots__ = ("features", "by_seq")

    def __init__(self, features: list[Feature] | Annotation):
        if isinstance(features, Annotation):
            features = features.features
        self.features = features
        by_seq: dict[str, list[int]] = {}
        for i, f in enumerate(features):
            by_seq.setdefault(f.seqid, []).append(i)
        self.by_seq: dict[str, SeqFeatures] = {}
        for seqid, idxs in by_seq.items():
            arr = np.asarray(idxs, dtype=np.int64)
            self.by_seq[seqid] = SeqFeatures(
                idx=arr,
                start=np.array([features[i].start for i in idxs], dtype=np.int64),
                end=np.array([features[i].end for i in idxs], dtype=np.int64),
                strand=np.array([features[i].strand for i in idxs], dtype=object),
            )

    @property
    def seqids(self) -> set[str]:
        return set(self.by_seq)

    def __len__(self) -> int:
        return len(self.features)


def strands_for(feature_strand: str, ignore_strand: bool,
                unstranded_calls_count: bool = True) -> list[str]:
    """Which methylation strands contribute to a feature.

    ``'.'`` (unknown strand) calls are always included.  The original scripts
    dropped them whenever the feature was stranded, so a methylation GFF3 whose
    strand column is ``.`` — which several basecallers emit — produced all-zero
    counts with no error.
    """
    if ignore_strand or feature_strand not in ("+", "-"):
        return ["+", "-", "."]
    return [feature_strand, "."] if unstranded_calls_count else [feature_strand]


def count_per_feature(
    index: FeatureIndex,
    methyl: MethylSet,
    mod_codes: list[str] | None = None,
    ignore_strand: bool = False,
) -> np.ndarray:
    """Counts of methylated positions per (feature, modification).

    Returns an ``(n_features, n_mods)`` int64 array aligned with
    ``index.features`` and ``mod_codes``.
    """
    mods = list(mod_codes) if mod_codes is not None else sorted(methyl.mod_codes)
    out = np.zeros((len(index), len(mods)), dtype=np.int64)
    if not mods or len(methyl) == 0:
        return out

    for seqid, sf in index.by_seq.items():
        # Group features by the strand-set they need, so each set is one pass.
        if ignore_strand:
            buckets = {("+", "-", "."): np.arange(len(sf.idx))}
        else:
            buckets = {}
            for tag in ("+", "-", "."):
                sel = np.flatnonzero(sf.strand == tag)
                if sel.size:
                    key = tuple(strands_for(tag, False))
                    buckets.setdefault(key, []).append(sel)
            buckets = {k: np.concatenate(v) for k, v in buckets.items()}

        for strand_set, sel in buckets.items():
            if sel.size == 0:
                continue
            starts, ends = sf.start[sel], sf.end[sel]
            rows = sf.idx[sel]
            for j, mod in enumerate(mods):
                counts = methyl.count_in_windows(seqid, mod, starts, ends,
                                                 list(strand_set))
                if counts.any():
                    out[rows, j] += counts
    return out


def mean_frac_per_feature(
    index: FeatureIndex,
    methyl: MethylSet,
    mod: str | None = None,
    ignore_strand: bool = False,
) -> np.ndarray:
    """Mean fraction-modified per feature (NaN when the source has no fractions)."""
    out = np.full(len(index), np.nan)
    for seqid, sf in index.by_seq.items():
        strand_sets: dict[tuple, np.ndarray] = {}
        if ignore_strand:
            strand_sets[("+", "-", ".")] = np.arange(len(sf.idx))
        else:
            for tag in ("+", "-", "."):
                sel = np.flatnonzero(sf.strand == tag)
                if sel.size:
                    strand_sets.setdefault(tuple(strands_for(tag, False)), []).append(sel)
            strand_sets = {k: np.concatenate(v) for k, v in strand_sets.items()}
        for strand_set, sel in strand_sets.items():
            vals = methyl.mean_frac_in_windows(seqid, mod, sf.start[sel],
                                               sf.end[sel], list(strand_set))
            out[sf.idx[sel]] = vals
    return out


# --------------------------------------------------------------------------- #
# Point-in-interval (CSR)
# --------------------------------------------------------------------------- #
@dataclass(slots=True)
class CSR:
    """Ragged point -> interval assignment. ``values[offsets[i]:offsets[i+1]]``."""

    offsets: np.ndarray
    values: np.ndarray

    def get(self, i: int) -> np.ndarray:
        return self.values[self.offsets[i]:self.offsets[i + 1]]

    @property
    def counts(self) -> np.ndarray:
        return np.diff(self.offsets)

    @property
    def any(self) -> np.ndarray:
        return self.counts > 0


def _disjoint(starts: np.ndarray, ends: np.ndarray) -> bool:
    if starts.size < 2:
        return True
    order = np.argsort(starts, kind="stable")
    s, e = starts[order], ends[order]
    return bool(np.all(s[1:] >= np.maximum.accumulate(e)[:-1]))


def points_in_intervals(points: np.ndarray, starts: np.ndarray, ends: np.ndarray,
                        ids: np.ndarray | None = None) -> CSR:
    """For each point, the ids of intervals ``[start, end)`` containing it.

    Points need not be sorted; the result is in input order.  Non-overlapping
    interval sets take a fully vectorised path, which is the usual case for
    prokaryotic CDS annotations and for motif occurrences of length < spacing.
    """
    n_pts = points.size
    if ids is None:
        ids = np.arange(starts.size, dtype=np.int64)
    if n_pts == 0 or starts.size == 0:
        return CSR(np.zeros(n_pts + 1, dtype=np.int64), np.empty(0, dtype=np.int64))

    order = np.argsort(starts, kind="stable")
    s, e, iid = starts[order], ends[order], ids[order]

    if _disjoint(s, e):
        j = np.searchsorted(s, points, side="right") - 1
        ok = (j >= 0)
        j_clip = np.where(ok, j, 0)
        ok &= points < e[j_clip]
        offsets = np.zeros(n_pts + 1, dtype=np.int64)
        np.cumsum(ok.astype(np.int64), out=offsets[1:])
        return CSR(offsets, iid[j_clip[ok]])

    # Overlapping intervals: sweep with an active set.
    import heapq

    p_order = np.argsort(points, kind="stable")
    p_sorted = points[p_order]
    active: list[tuple[int, int]] = []
    per_point: list[np.ndarray] = [None] * n_pts  # type: ignore[list-item]
    k, n_iv = 0, s.size
    for pi in range(n_pts):
        pos = p_sorted[pi]
        while k < n_iv and s[k] <= pos:
            heapq.heappush(active, (int(e[k]), int(iid[k])))
            k += 1
        while active and active[0][0] <= pos:
            heapq.heappop(active)
        per_point[p_order[pi]] = (np.fromiter((idx for _end, idx in active),
                                              dtype=np.int64, count=len(active))
                                  if active else np.empty(0, dtype=np.int64))
    counts = np.fromiter((a.size for a in per_point), dtype=np.int64, count=n_pts)
    offsets = np.zeros(n_pts + 1, dtype=np.int64)
    np.cumsum(counts, out=offsets[1:])
    values = (np.concatenate(per_point) if offsets[-1] else np.empty(0, dtype=np.int64))
    return CSR(offsets, values)


def assign_calls_to_features(methyl: MethylSet, index: FeatureIndex) -> CSR:
    """Feature membership for every methylation call, in call order."""
    n = len(methyl)
    offsets = np.zeros(n + 1, dtype=np.int64)
    chunks: list[np.ndarray] = []
    counts = np.zeros(n, dtype=np.int64)
    for seqid in np.unique(methyl.seqid):
        sel = np.flatnonzero(methyl.seqid == seqid)
        sf = index.by_seq.get(seqid)
        if sf is None:
            continue
        csr = points_in_intervals(methyl.pos[sel], sf.start, sf.end, sf.idx)
        counts[sel] = csr.counts
        chunks.append((sel, csr))
    np.cumsum(counts, out=offsets[1:])
    values = np.empty(int(offsets[-1]), dtype=np.int64)
    for sel, csr in chunks:
        for local, global_i in enumerate(sel):
            lo, hi = csr.offsets[local], csr.offsets[local + 1]
            if hi > lo:
                values[offsets[global_i]:offsets[global_i] + (hi - lo)] = csr.values[lo:hi]
    return CSR(offsets, values)
