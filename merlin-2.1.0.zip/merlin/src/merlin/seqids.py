"""Reconcile sequence identifiers across annotation, reference and methylation.

Every MErlin join is keyed on either a seqid or a locus_tag, and a seqid
mismatch never raises: it returns zero overlaps, which in the output is
indistinguishable from a genome with no methylation.  This module is the single
place that decides how the three namespaces are aligned, and it refuses to
proceed silently when they cannot be.

Resolution order
----------------
1. explicit ``--seqid-map`` (two-column TSV), if supplied;
2. identity, when the namespaces already intersect;
3. version-suffix stripping (``NZ_CP012345.1`` vs ``NZ_CP012345``) when that
   makes them intersect — the common Prokka/GbkToGff case;
4. prefix/accession containment (``gi|123|ref|NZ_X.1|`` vs ``NZ_X.1``);
5. rank-order pairing — *only* when explicitly enabled, since guessing that the
   n-th name in one file means the n-th in another silently produces plausible,
   wrong results.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .logging_utils import get_logger, warn_once

logger = get_logger("seqids")

_VERSION_RE = re.compile(r"\.\d+$")
_ACC_RE = re.compile(r"\b([A-Z]{1,4}_?[A-Z]{0,2}\d{4,}(?:\.\d+)?)\b")


def strip_version(seqid: str) -> str:
    return _VERSION_RE.sub("", seqid)


def _accession(seqid: str) -> str | None:
    m = _ACC_RE.search(seqid)
    return m.group(1) if m else None


@dataclass
class SeqidResolution:
    """The mapping decided for a run, plus how it was decided."""

    mapping: dict[str, str] = field(default_factory=dict)   # source id -> canonical id
    method: str = "identity"
    stripped: bool = False
    canonical: set[str] = field(default_factory=set)
    unmatched: dict[str, list[str]] = field(default_factory=dict)

    def apply(self, seqid: str) -> str:
        return self.mapping.get(seqid, seqid)

    def describe(self) -> str:
        return (f"seqid reconciliation: method={self.method}, "
                f"version-suffix-stripped={self.stripped}, "
                f"{len(self.canonical)} canonical replicon(s)")


def _fmt(ids) -> str:
    ids = sorted(ids)
    return ", ".join(ids[:4]) + (" ..." if len(ids) > 4 else "")


def reconcile(
    namespaces: dict[str, set[str]],
    canonical_key: str,
    explicit_map: dict[str, str] | None = None,
    force_strip: bool = False,
    allow_rank_map: bool = False,
) -> SeqidResolution:
    """Align every namespace onto ``namespaces[canonical_key]``.

    Parameters
    ----------
    namespaces
        e.g. ``{"annotation": {...}, "reference": {...}, "methylation": {...}}``.
        Empty namespaces are ignored, which is what makes the tool modular: a
        run without a reference simply has one fewer namespace to align.
    canonical_key
        Whose identifiers win.  Motif search runs on reference coordinates, so
        when a reference is present it must be canonical.
    """
    explicit_map = explicit_map or {}
    present = {k: v for k, v in namespaces.items() if v}
    if canonical_key not in present:
        canonical_key = next(iter(present)) if present else canonical_key
    canon = set(present.get(canonical_key, set()))
    res = SeqidResolution(canonical=canon)

    if not canon:
        return res

    # --- 1. explicit map ---------------------------------------------------
    if explicit_map:
        res.mapping.update(explicit_map)
        res.method = "explicit"
        logger.info("Applying %d explicit seqid mapping(s).", len(explicit_map))

    def mapped(ids: set[str]) -> set[str]:
        return {res.mapping.get(i, i) for i in ids}

    others = {k: v for k, v in present.items() if k != canonical_key}
    unresolved = {k: v for k, v in others.items() if not (mapped(v) & canon)}

    # --- 2/3. version suffix ----------------------------------------------
    if force_strip or unresolved:
        strip_helps = force_strip
        if not strip_helps:
            for ids in unresolved.values():
                if {strip_version(i) for i in ids} & {strip_version(c) for c in canon}:
                    strip_helps = True
                    break
        if strip_helps:
            res.stripped = True
            res.canonical = {strip_version(c) for c in canon}
            canon = res.canonical
            for ids in present.values():
                for i in ids:
                    res.mapping[i] = strip_version(res.mapping.get(i, i))
            if res.method == "identity":
                res.method = "version-strip"
            elif res.method == "explicit":
                res.method = "explicit+version-strip"
            if not force_strip:
                warn_once(logger, "SEQID_VERSION_STRIP",
                          "Sequence identifiers differed only by a trailing '.N' "
                          "version suffix; it was stripped from every layer to "
                          "reconcile them. This is expected for Prokka/GbkToGff "
                          "annotations of an NCBI reference.")
            unresolved = {k: v for k, v in others.items() if not (mapped(v) & canon)}

    # --- 4. accession containment -----------------------------------------
    if unresolved:
        canon_acc = {}
        for c in canon:
            a = _accession(c)
            if a:
                canon_acc.setdefault(a, c)
                canon_acc.setdefault(strip_version(a), c)
        still: dict[str, set[str]] = {}
        for name, ids in unresolved.items():
            hits = 0
            for i in ids:
                a = _accession(res.mapping.get(i, i))
                target = canon_acc.get(a) or canon_acc.get(strip_version(a or ""))
                if target:
                    res.mapping[i] = target
                    hits += 1
            if hits:
                res.method = "accession-match"
                warn_once(logger, "SEQID_ACCESSION_MATCH",
                          f"{name}: {hits} identifier(s) matched to the reference by "
                          f"embedded accession (e.g. 'gi|..|ref|NZ_X.1|' -> 'NZ_X.1').")
            else:
                still[name] = ids
        unresolved = still

    # --- 5. rank order (opt-in) -------------------------------------------
    if unresolved and allow_rank_map:
        canon_sorted = sorted(canon)
        for name, ids in list(unresolved.items()):
            src = sorted(res.mapping.get(i, i) for i in ids)
            if len(src) != len(canon_sorted):
                continue
            for a, b in zip(src, canon_sorted):
                res.mapping[a] = b
                for orig in ids:
                    if res.mapping.get(orig, orig) == a:
                        res.mapping[orig] = b
            res.method = "rank-order"
            warn_once(logger, "SEQID_RANK_MAP",
                      f"{name}: identifiers were paired with the reference by sorted "
                      f"rank order because nothing else matched. This is a guess — "
                      f"verify it, or supply --seqid-map.")
            unresolved.pop(name, None)

    # --- report ------------------------------------------------------------
    for name, ids in present.items():
        if name == canonical_key:
            continue
        missing = sorted(i for i in mapped(ids) if i not in canon)
        if missing:
            res.unmatched[name] = missing
            frac = len(missing) / max(len(ids), 1)
            code = "SEQID_UNMATCHED_ALL" if frac >= 0.999 else "SEQID_UNMATCHED_SOME"
            warn_once(logger, f"{code}_{name}",
                      f"{name}: {len(missing)}/{len(ids)} identifier(s) do not match "
                      f"any {canonical_key} identifier and their records will be "
                      f"ignored ({_fmt(missing)}).")
    logger.info("%s | %s: [%s]", res.describe(), canonical_key, _fmt(canon))
    return res


def require_overlap(res: SeqidResolution, namespaces: dict[str, set[str]],
                    canonical_key: str, hard: tuple[str, ...] = ()) -> None:
    """Abort when a namespace that must intersect the canonical one does not.

    ``hard`` names the layers whose failure makes the run meaningless — without
    an annotation/reference overlap every per-feature count is zero, and
    reporting that as "no methylation" is the specific failure mode this whole
    module exists to prevent.
    """
    problems = []
    for name in hard:
        ids = namespaces.get(name) or set()
        if not ids:
            continue
        if not ({res.apply(i) for i in ids} & res.canonical):
            problems.append(
                f"  - {name}: none of {len(ids)} identifier(s) [{_fmt(ids)}] match "
                f"{canonical_key} [{_fmt(res.canonical)}]")
    if problems:
        raise SystemExit(
            "[FATAL] sequence identifiers cannot be reconciled:\n"
            + "\n".join(problems)
            + "\n\nEvery per-feature count would be zero, which is indistinguishable "
              "in the output from a genome with no methylation.\n"
              "Fix with --seqid-map <tsv>, or --strip-version if the ids differ only "
              "by a '.N' suffix. Do not edit the input files."
        )
