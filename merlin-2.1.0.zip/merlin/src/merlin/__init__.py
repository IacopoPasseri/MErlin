"""MErlin — Methylation-driven Expression & Regulation Linkage in Interacting
Nuclear-domains.

A modular prokaryotic multi-omics toolkit. Every module runs on the layers it
needs and no more, so a methylation-only project uses the same code path as a
methylation + expression + Hi-C one.

    from merlin import io, intervals, stats
    from merlin.tools import xam
"""

__version__ = "2.1.0"

__all__ = ["__version__"]
