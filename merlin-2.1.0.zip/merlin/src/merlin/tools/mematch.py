"""mematch — is methylation associated with the presence of a DNA motif?

Changes from the original ``mematch.py``
----------------------------------------
* **The site-level test is no longer degenerate on presence-only input.**  With
  a methylation GFF3 (no fraction column) every call was "methylated", so the
  original 2x2 table had ``b = d = 0`` and its odds ratio was an artefact of the
  Haldane correction rather than a measurement.  Presence-only input now uses a
  genomic background: on-motif *candidate bases* (A positions for 6mA, C for
  5mC, both strands) that carry a call versus those that do not.  Which variant
  ran is written into the output.
* Motif membership is a boolean array per replicon, tested by indexing, instead
  of a ``set[(seqid, pos)]``; and motif search is circular-aware.
* Per-call annotation is vectorised over numpy arrays rather than a Python loop
  over every call, and the per-call table can be gzipped (``--gzip-calls``) —
  for a bacterial bedMethyl it is by far the largest output.
* Replicon labels for figures come from the FASTA only when version stripping
  actually happened, so the label lookup no longer silently misses.

Caveat kept from the original, unchanged: this is a cross-tabulation.  A motif
whose sites are methylated is consistent with an MTase recognising it, and also
with the motif simply being where the assayed bases are.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import numpy as np

from .. import viz
from ..intervals import FeatureIndex, assign_calls_to_features, points_in_intervals
from ..io import read_motifs
from ..logging_utils import get_logger, warn_once
from ..model import mod_label
from ..motifs import find_motifs
from ..stats import benjamini_hochberg, contingency_test
from . import _common as C

logger = get_logger("mematch")

# Canonical base carrying each modification, on the plus strand
MOD_BASE = {"m": "C", "h": "C", "f": "C", "c": "C", "e": "C", "21839": "C",
            "a": "A", "g": "G", "b": "T"}
COMPLEMENT = {"A": "T", "C": "G", "G": "C", "T": "A"}


def _base_mask(seq_bytes: np.ndarray, base: str) -> np.ndarray:
    return seq_bytes == ord(base)


def motif_site_masks(hits, seqid: str, length: int, use_modbase: bool):
    """Boolean arrays of motif site positions, per strand."""
    out = {}
    sel = hits.for_seqid(seqid)
    for strand in ("+", "-"):
        mask = np.zeros(length, dtype=bool)
        s_sel = sel[hits.strand[sel] == strand]
        if s_sel.size:
            if use_modbase:
                mp = hits.mod_pos[s_sel]
                mp = mp[mp >= 0]
                if mp.size:
                    mask[mp % length] = True
            else:
                L = len(hits.motif)
                idx = (hits.start[s_sel][:, None] + np.arange(L)[None, :]) % length
                mask[idx.ravel()] = True
        out[strand] = mask
    return out


# --------------------------------------------------------------------------- #
def annotate(inp: C.Inputs, motif_hits, args):
    """Per-call motif membership (n_calls x n_motifs boolean) and feature CSR."""
    methyl = inp.methyl
    index = FeatureIndex(inp.annotation)
    call_feats = assign_calls_to_features(methyl, index)

    motif_list = list(motif_hits)
    on_motif = np.zeros((len(methyl), len(motif_list)), dtype=bool)
    on_modbase = np.zeros((len(methyl), len(motif_list)), dtype=bool)

    for seqid, seq in inp.genome.items():
        sel = np.flatnonzero(methyl.seqid == seqid)
        if sel.size == 0:
            continue
        L = len(seq)
        pos = methyl.pos[sel]
        inside = pos < L
        strand = methyl.strand[sel]
        for j, m in enumerate(motif_list):
            hits = motif_hits[m]
            cover = motif_site_masks(hits, seqid, L, use_modbase=False)
            mb = (motif_site_masks(hits, seqid, L, use_modbase=True)
                  if hits.has_offset else None)
            for st in ("+", "-"):
                pick = inside & ((strand == st) if not args.ignore_motif_strand
                                 else np.ones(sel.size, dtype=bool))
                if not pick.any():
                    continue
                p = pos[pick]
                on_motif[sel[pick], j] |= cover[st][p]
                if mb is not None:
                    on_modbase[sel[pick], j] |= mb[st][p]
    return index, call_feats, motif_list, on_motif, on_modbase


def feature_motif_counts(motif_hits, index: FeatureIndex):
    """feature_idx x motif matrix of occurrence counts (anchor inside the feature)."""
    motif_list = list(motif_hits)
    out = np.zeros((len(index), len(motif_list)), dtype=np.int64)
    for j, m in enumerate(motif_list):
        hits = motif_hits[m]
        anchors = hits.anchor()
        for seqid, sf in index.by_seq.items():
            sel = hits.for_seqid(seqid)
            if sel.size == 0:
                continue
            csr = points_in_intervals(anchors[sel], sf.start, sf.end, sf.idx)
            if csr.values.size:
                np.add.at(out[:, j], csr.values, 1)
    return motif_list, out


# --------------------------------------------------------------------------- #
def site_level_enrichment(inp, motif_list, on_motif, on_modbase, methylated,
                          considered, offsets_known, motif_hits, method):
    """2x2 tables for 'is a methylated position more likely to be on this motif?'.

    Two regimes, reported in the ``basis`` column:

    ``assayed``       the input distinguishes assayed from methylated, so the
                      contrast is methylated vs unmethylated among on-motif and
                      off-motif assayed positions.
    ``genomic``       presence-only input: the contrast is called vs not-called
                      among the *candidate bases* of the relevant modification
                      (all A positions for 6mA, all C for 5mC, both strands).
    """
    rows = []
    presence_only = inp.methyl.presence_only
    use_mb = offsets_known
    for j, m in enumerate(motif_list):
        hit = (on_modbase[:, j] if use_mb else on_motif[:, j])
        if presence_only:
            basis = "genomic"
            mods = sorted(inp.methyl.mod_codes)
            base_letters = {MOD_BASE.get(c) for c in mods} - {None}
            if not base_letters:
                base_letters = {"A", "C"}
            n_motif_cand = 0
            n_total_cand = 0
            for seqid, seq in inp.genome.items():
                arr = np.frombuffer(seq.encode("ascii", "ignore"), dtype=np.uint8)
                L = arr.size
                masks = motif_site_masks(motif_hits[m], seqid, L, use_modbase=use_mb)
                for letter in base_letters:
                    plus = _base_mask(arr, letter)
                    minus = _base_mask(arr, COMPLEMENT[letter])
                    n_total_cand += int(plus.sum() + minus.sum())
                    n_motif_cand += int((masks["+"] & plus).sum()
                                        + (masks["-"] & minus).sum())
            a = int((hit & considered).sum())
            c = int((~hit & considered).sum())
            b = max(n_motif_cand - a, 0)
            d = max((n_total_cand - n_motif_cand) - c, 0)
        else:
            basis = "assayed"
            a = int((hit & considered & methylated).sum())
            b = int((hit & considered & ~methylated).sum())
            c = int((~hit & considered & methylated).sum())
            d = int((~hit & considered & ~methylated).sum())
        rows.append(dict(level="site", basis=basis, motif=m,
                         a=a, b=b, c=c, d=d))
    if rows:
        orr, p = contingency_test([r["a"] for r in rows], [r["b"] for r in rows],
                                  [r["c"] for r in rows], [r["d"] for r in rows],
                                  method=method)
        for r, o, pv in zip(rows, orr, p):
            r["odds"], r["p"] = float(o), float(pv)
    return rows


def feature_level_enrichment(feat_motifs, motif_list, feat_meth_calls,
                             min_calls, method):
    rows = []
    meth_feat = feat_meth_calls >= min_calls
    for j, m in enumerate(motif_list):
        has = feat_motifs[:, j] > 0
        rows.append(dict(level="feature", basis="features", motif=m,
                         a=int((has & meth_feat).sum()),
                         b=int((has & ~meth_feat).sum()),
                         c=int((~has & meth_feat).sum()),
                         d=int((~has & ~meth_feat).sum())))
    if rows:
        orr, p = contingency_test([r["a"] for r in rows], [r["b"] for r in rows],
                                  [r["c"] for r in rows], [r["d"] for r in rows],
                                  method=method)
        for r, o, pv in zip(rows, orr, p):
            r["odds"], r["p"] = float(o), float(pv)
    return rows


# --------------------------------------------------------------------------- #
def write_outputs(inp, args, index, call_feats, motif_list, on_motif, on_modbase,
                  feat_motifs, methylated, considered, motif_hits, enrich_rows):
    import pandas as pd
    written: list[Path] = []
    methyl = inp.methyl
    feats = inp.annotation.features

    # ---- per call --------------------------------------------------------
    if not args.no_call_table:
        opener = gzip.open if args.gzip_calls else open
        suffix = "methylation_calls.tsv.gz" if args.gzip_calls else "methylation_calls.tsv"
        path = inp.out(suffix)
        n_feat = call_feats.counts
        motifs_hit_str = np.array(
            [",".join(m for j, m in enumerate(motif_list) if row.any() and row[j])
             for row in on_motif], dtype=object) if len(motif_list) else np.full(
            len(methyl), "", dtype=object)
        with opener(path, "wt") as fh:
            fh.write("\t".join([
                "replicon", "pos_0based", "pos_1based", "strand", "mod_code",
                "coverage", "frac_modified", "considered", "methylated",
                "n_features", "feature_ids", "feature_types",
                "on_motif", "on_mod_base", "motifs_hit"]) + "\n")
            any_motif = on_motif.any(axis=1) if len(motif_list) else np.zeros(len(methyl), bool)
            any_mb = on_modbase.any(axis=1) if len(motif_list) else np.zeros(len(methyl), bool)
            for i in range(len(methyl)):
                fidx = call_feats.get(i)
                fh.write("\t".join([
                    str(methyl.seqid[i]), str(methyl.pos[i]), str(methyl.pos[i] + 1),
                    str(methyl.strand[i]), str(methyl.mod[i]),
                    "" if np.isnan(methyl.cov[i]) else f"{methyl.cov[i]:g}",
                    "" if np.isnan(methyl.frac[i]) else f"{methyl.frac[i]:.4f}",
                    str(int(considered[i])), str(int(methylated[i])),
                    str(int(n_feat[i])),
                    ",".join(feats[k].fid for k in fidx),
                    ",".join(sorted({feats[k].ftype for k in fidx})),
                    str(int(any_motif[i])), str(int(any_mb[i])),
                    motifs_hit_str[i]]) + "\n")
        written.append(path)

    # ---- per feature -----------------------------------------------------
    n_f = len(feats)
    agg_calls = np.zeros(n_f, dtype=np.int64)
    agg_considered = np.zeros(n_f, dtype=np.int64)
    agg_meth = np.zeros(n_f, dtype=np.int64)
    agg_calls_motif = np.zeros(n_f, dtype=np.int64)
    agg_meth_motif = np.zeros(n_f, dtype=np.int64)
    agg_meth_modbase = np.zeros(n_f, dtype=np.int64)
    any_motif = on_motif.any(axis=1) if len(motif_list) else np.zeros(len(methyl), bool)
    any_mb = on_modbase.any(axis=1) if len(motif_list) else np.zeros(len(methyl), bool)
    vals = call_feats.values
    rep = np.repeat(np.arange(len(methyl)), call_feats.counts)
    if vals.size:
        np.add.at(agg_calls, vals, 1)
        np.add.at(agg_considered, vals, considered[rep].astype(np.int64))
        m_and_c = (considered & methylated)[rep]
        np.add.at(agg_meth, vals, m_and_c.astype(np.int64))
        np.add.at(agg_calls_motif, vals, (considered & any_motif)[rep].astype(np.int64))
        np.add.at(agg_meth_motif, vals, (m_and_c & any_motif[rep]).astype(np.int64))
        np.add.at(agg_meth_modbase, vals, (m_and_c & any_mb[rep]).astype(np.int64))

    n_occ = feat_motifs.sum(axis=1)
    present = [",".join(m for j, m in enumerate(motif_list) if feat_motifs[i, j] > 0)
               for i in range(n_f)]
    with np.errstate(invalid="ignore", divide="ignore"):
        frac_on = np.where(agg_meth > 0, agg_meth_motif / np.maximum(agg_meth, 1), 0.0)
    per_feature = pd.DataFrame({
        "feature_id": [f.fid for f in feats],
        "locus_tag": [f.locus_tag for f in feats],
        "replicon": [f.seqid for f in feats],
        "type": [f.ftype for f in feats],
        "strand": [f.strand for f in feats],
        "start_1based": [f.start + 1 for f in feats],
        "end_1based": [f.end for f in feats],
        "length": [f.length for f in feats],
        "n_motif_occurrences": n_occ,
        "motifs_present": present,
        "has_motif": (n_occ > 0).astype(int),
        "n_calls": agg_calls, "n_considered": agg_considered,
        "n_methylated": agg_meth,
        "n_calls_on_motif": agg_calls_motif,
        "n_methylated_on_motif": agg_meth_motif,
        "n_methylated_on_modbase": agg_meth_modbase,
        "n_methylated_off_motif": agg_meth - agg_meth_motif,
        "frac_methylated_on_motif": frac_on,
        "is_methylated_feature": (agg_meth > 0).astype(int),
        "methylation_on_motif": (agg_meth_motif > 0).astype(int),
    })
    path = inp.out("per_feature.tsv")
    per_feature.to_csv(path, sep="\t", index=False, float_format="%.6g")
    written.append(path)

    # ---- per feature x motif --------------------------------------------
    rows = []
    for j, m in enumerate(motif_list):
        occ = feat_motifs[:, j]
        mm = np.zeros(n_f, dtype=np.int64)
        if vals.size:
            hit_j = (considered & methylated & on_motif[:, j])[rep]
            np.add.at(mm, vals, hit_j.astype(np.int64))
        keep = (occ > 0) | (mm > 0)
        if keep.any():
            rows.append(pd.DataFrame({
                "feature_id": [feats[i].fid for i in np.flatnonzero(keep)],
                "locus_tag": [feats[i].locus_tag for i in np.flatnonzero(keep)],
                "replicon": [feats[i].seqid for i in np.flatnonzero(keep)],
                "type": [feats[i].ftype for i in np.flatnonzero(keep)],
                "motif": m,
                "n_motif_occurrences": occ[keep],
                "n_methylated_calls_on_motif": mm[keep]}))
    path = inp.out("per_feature_motif.tsv")
    (pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(
        columns=["feature_id", "locus_tag", "replicon", "type", "motif",
                 "n_motif_occurrences", "n_methylated_calls_on_motif"])
     ).to_csv(path, sep="\t", index=False)
    written.append(path)

    # ---- motif summary ---------------------------------------------------
    summary = []
    for j, m in enumerate(motif_list):
        on = on_motif[:, j] & considered
        summary.append(dict(
            motif=m, offset=("" if motif_hits[m].offset is None else motif_hits[m].offset),
            n_occurrences_both_strands=len(motif_hits[m]),
            n_assayed_calls_on_motif=int(on.sum()),
            n_methylated_calls_on_motif=int((on & methylated).sum()),
            n_methylated_on_modbase=int((on_modbase[:, j] & considered & methylated).sum()),
            frac_assayed_on_motif_methylated=(float((on & methylated).sum() / on.sum())
                                              if on.sum() else 0.0)))
    path = inp.out("motif_summary.tsv")
    pd.DataFrame(summary).to_csv(path, sep="\t", index=False, float_format="%.6g")
    written.append(path)

    # ---- replicons + hits ------------------------------------------------
    path = inp.out("replicons.tsv")
    pd.DataFrame({"replicon": list(inp.genome),
                  "label": [inp.label(k) for k in inp.genome],
                  "length": [len(v) for v in inp.genome.values()]}
                 ).sort_values("length", ascending=False).to_csv(
        path, sep="\t", index=False)
    written.append(path)

    if not args.no_hit_table:
        path = inp.out("motif_hits.tsv.gz" if args.gzip_calls else "motif_hits.tsv")
        frames = [pd.DataFrame({
            "replicon": h.seqid, "start_0based": h.start, "end_0based": h.end - 1,
            "strand": h.strand, "motif": h.motif,
            "mod_pos_0based": np.where(h.mod_pos >= 0, h.mod_pos, -1)})
            for h in motif_hits.values() if len(h)]
        (pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
         ).to_csv(path, sep="\t", index=False)
        written.append(path)

    # ---- enrichment ------------------------------------------------------
    if enrich_rows:
        df = pd.DataFrame(enrich_rows)
        df["q"] = np.nan
        for level in df["level"].unique():
            m = df["level"] == level
            df.loc[m, "q"] = benjamini_hochberg(df.loc[m, "p"].to_numpy(dtype=float))
        df = df.rename(columns={"a": "a_onmotif_meth", "b": "b_onmotif_unmeth",
                                "c": "c_offmotif_meth", "d": "d_offmotif_unmeth",
                                "odds": "odds_ratio", "p": "p_value", "q": "q_value_BH"})
        path = inp.out("enrichment.tsv")
        df.to_csv(path, sep="\t", index=False, float_format="%.6g")
        written.append(path)
    return written, per_feature


# --------------------------------------------------------------------------- #
def make_plots(inp, args, motif_list, on_motif, methylated, considered,
               enrich_rows) -> list[Path]:
    plt = viz.lazy_pyplot()
    if plt is None or not motif_list:
        return []
    written = []
    methyl = inp.methyl
    x = np.arange(len(motif_list))
    site = {r["motif"]: r for r in enrich_rows if r["level"] == "site"}
    feat = {r["motif"]: r for r in enrich_rows if r["level"] == "feature"}

    on_assayed = np.array([int((on_motif[:, j] & considered).sum())
                           for j in range(len(motif_list))])
    on_meth = np.array([int((on_motif[:, j] & considered & methylated).sum())
                        for j in range(len(motif_list))])
    with np.errstate(invalid="ignore", divide="ignore"):
        rate = np.where(on_assayed > 0, on_meth / np.maximum(on_assayed, 1), 0.0)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    axes[0].bar(x, rate, color=viz.PAL["meth"])
    axes[0].set_xticks(x); axes[0].set_xticklabels(motif_list, rotation=30, ha="right")
    axes[0].set_ylabel("fraction methylated"); axes[0].set_ylim(0, 1.15)
    axes[0].set_title("Methylation rate of assayed on-motif sites")
    for xi, ra, n in zip(x, rate, on_assayed):
        axes[0].text(xi, ra + 0.02, f"{ra:.0%}\n(n={n})", ha="center", va="bottom",
                     fontsize=8)

    ors = np.array([site[m]["odds"] if m in site else np.nan for m in motif_list])
    qs = np.array([site[m].get("q", np.nan) if m in site else np.nan for m in motif_list])
    if np.isfinite(ors).any():
        axes[1].bar(x, np.where(np.isfinite(ors), ors, 0),
                    color=[viz.PAL["motif"] if (o == o and o >= 1) else viz.PAL["neutral"]
                           for o in ors])
        axes[1].axhline(1.0, color="black", lw=0.8, ls="--")
        axes[1].set_yscale("log")
        for xi, o, q in zip(x, ors, qs):
            if np.isfinite(o):
                axes[1].text(xi, o, f" {viz.significance_stars(q)}", ha="center",
                             va="bottom" if o >= 1 else "top", fontsize=9)
    else:
        viz.annotate_empty(axes[1], "no site-level test")
    axes[1].set_xticks(x); axes[1].set_xticklabels(motif_list, rotation=30, ha="right")
    axes[1].set_ylabel("odds ratio (log)")
    basis = site[motif_list[0]]["basis"] if motif_list and motif_list[0] in site else "?"
    axes[1].set_title(f"Site-level enrichment\n(basis: {basis})")

    ax = axes[2]
    if not methyl.presence_only:
        data, labels = [], []
        for j, m in enumerate(motif_list):
            v = methyl.frac[on_motif[:, j] & considered]
            v = v[np.isfinite(v)]
            if v.size:
                data.append(v); labels.append(m)
        off = methyl.frac[~on_motif.any(axis=1) & considered]
        off = off[np.isfinite(off)]
        if off.size:
            data.append(off); labels.append("off-motif")
        if data:
            box = ax.boxplot(data, showfliers=False, patch_artist=True,
                             medianprops=dict(color="black"))
            palette = [viz.PAL["meth"]] * (len(data) - 1) + ["#bdc3c7"]
            for patch, col in zip(box["boxes"], palette):
                patch.set_facecolor(col)
            ax.set_xticks(np.arange(1, len(labels) + 1))
            ax.set_xticklabels(labels, rotation=30, ha="right")
            if args.min_frac is not None:
                ax.axhline(args.min_frac, color="#888", lw=0.8, ls=":")
        else:
            viz.annotate_empty(ax, "no fraction values")
    else:
        viz.annotate_empty(ax, "presence-only input:\nno per-call fraction to compare")
    ax.set_ylabel("fraction modified per call")
    ax.set_title("On-motif vs background methylation")
    fig.tight_layout()
    written.append(viz.savefig(fig, inp.out(f"motif_methylation_summary.{args.plot_format}")))

    p_with, p_without, ors_f, qs_f = [], [], [], []
    for m in motif_list:
        r = feat.get(m)
        if r:
            a, b, c, d = r["a"], r["b"], r["c"], r["d"]
            p_with.append(a / (a + b) if (a + b) else 0.0)
            p_without.append(c / (c + d) if (c + d) else 0.0)
            ors_f.append(r["odds"]); qs_f.append(r.get("q", np.nan))
        else:
            p_with.append(0.0); p_without.append(0.0)
            ors_f.append(np.nan); qs_f.append(np.nan)
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    ax.bar(x - 0.19, p_with, 0.38, label="feature contains motif", color="#27ae60")
    ax.bar(x + 0.19, p_without, 0.38, label="feature lacks motif", color="#95a5a6")
    ax.set_xticks(x); ax.set_xticklabels(motif_list, rotation=20, ha="right")
    ax.set_ylabel("fraction of features methylated"); ax.set_ylim(0, 1.15)
    ax.set_title("Is feature methylation associated with motif presence?")
    for xi, pw, po, o, q in zip(x, p_with, p_without, ors_f, qs_f):
        if np.isfinite(o):
            ax.text(xi, max(pw, po) + 0.03, f"OR={o:.1f} {viz.significance_stars(q)}",
                    ha="center", fontsize=8)
    ax.legend(frameon=False)
    fig.tight_layout()
    written.append(viz.savefig(fig, inp.out(f"feature_motif_association.{args.plot_format}")))
    return written


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin mematch",
        description="Cross methylation calls, DNA motifs and a GFF3 annotation.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    C.add_annotation_args(p)
    C.add_reference_args(p, required=False)
    C.add_methylation_args(p)
    C.add_seqid_args(p)
    C.add_output_args(p, default_prefix="mematch")
    C.add_plot_args(p, default_on=False)
    g = p.add_argument_group("motif analysis")
    g.add_argument("--motifs", required=True, metavar="FILE",
                   help="Newline-delimited IUPAC motifs; optional 2nd column is the "
                        "0-based offset of the modified base.")
    g.add_argument("--ignore-motif-strand", action="store_true",
                   help="Match motifs irrespective of the call's strand.")
    g.add_argument("--linear", action="store_true",
                   help="Treat replicons as linear (default: circular, so motifs "
                        "spanning the origin are found).")
    g.add_argument("--feature-meth-min-calls", type=int, default=1, metavar="N",
                   help="Methylated calls needed for a feature to count as methylated.")
    g.add_argument("--fisher", action="store_true",
                   help="Write the enrichment table (always computed for figures).")
    g.add_argument("--test", default="auto", choices=["auto", "fisher", "chi2"],
                   help="Association test used for enrichment.")
    g.add_argument("--gzip-calls", action="store_true",
                   help="Gzip the per-call and motif-hit tables.")
    g.add_argument("--no-call-table", action="store_true",
                   help="Skip the per-call table (the largest output).")
    g.add_argument("--no-hit-table", action="store_true",
                   help="Skip the motif-occurrence table.")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    inp = C.load_inputs(args, need_reference=True)
    if inp.methyl is None or not len(inp.methyl):
        raise SystemExit("[FATAL] no methylation calls available.")

    motifs = read_motifs(args.motifs)
    offsets_known = all(off is not None for _m, off in motifs)
    if not offsets_known:
        warn_once(logger, "MOTIF_NO_OFFSETS",
                  "Not every motif carries a modified-base offset; site-level "
                  "statistics fall back to whole-motif coverage, which is coarser "
                  "(a call anywhere in the motif counts as on-motif).")
    motif_hits = find_motifs(inp.genome, motifs, circular=not args.linear)

    index, call_feats, motif_list, on_motif, on_modbase = annotate(inp, motif_hits, args)

    methyl = inp.methyl
    considered = (np.isnan(methyl.cov) | (methyl.cov >= args.min_coverage))
    min_frac = 0.5 if args.min_frac is None else args.min_frac
    methylated = (np.isnan(methyl.frac) | (methyl.frac >= min_frac))

    _ml, feat_motifs = feature_motif_counts(motif_hits, index)

    n_f = len(inp.annotation)
    feat_meth = np.zeros(n_f, dtype=np.int64)
    if call_feats.values.size:
        rep = np.repeat(np.arange(len(methyl)), call_feats.counts)
        np.add.at(feat_meth, call_feats.values,
                  (considered & methylated)[rep].astype(np.int64))

    enrich_rows = site_level_enrichment(inp, motif_list, on_motif, on_modbase,
                                        methylated, considered, offsets_known,
                                        motif_hits, args.test)
    enrich_rows += feature_level_enrichment(feat_motifs, motif_list, feat_meth,
                                            args.feature_meth_min_calls, args.test)
    for level in ("site", "feature"):
        idx = [i for i, r in enumerate(enrich_rows) if r["level"] == level]
        if idx:
            q = benjamini_hochberg([enrich_rows[i]["p"] for i in idx])
            for i, qq in zip(idx, q):
                enrich_rows[i]["q"] = float(qq)

    written, per_feature = write_outputs(
        inp, args, index, call_feats, motif_list, on_motif, on_modbase, feat_motifs,
        methylated, considered, motif_hits, enrich_rows if args.fisher else [])

    if args.plots:
        written += make_plots(inp, args, motif_list, on_motif, methylated,
                              considered, enrich_rows)

    n_considered = int(considered.sum())
    n_meth = int((considered & methylated).sum())
    n_meth_on = int((considered & methylated & on_motif.any(axis=1)).sum())
    n_feat_motif = int((feat_motifs.sum(axis=1) > 0).sum())
    n_feat_meth = int((feat_meth >= args.feature_meth_min_calls).sum())
    print("\n=== mematch summary ===")
    print(f"  input basis                 : "
          f"{'presence-only' if methyl.presence_only else 'assayed + fraction'}")
    print(f"  calls considered            : {n_considered:,}")
    print(f"  methylated                  : {n_meth:,}")
    print(f"  methylated AND on a motif   : {n_meth_on:,} "
          f"({100 * n_meth_on / n_meth if n_meth else 0:.1f}% of methylated)")
    print(f"  features with a motif       : {n_feat_motif:,}/{n_f:,}")
    print(f"  features methylated         : {n_feat_meth:,}/{n_f:,}")
    for r in enrich_rows:
        if r["level"] == "site":
            print(f"  [{r['motif']}] site OR={r['odds']:.3g} q={r.get('q', float('nan')):.3g} "
                  f"(basis: {r['basis']})")
    print()
    C.finalize(inp, written, args, "merlin mematch")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
