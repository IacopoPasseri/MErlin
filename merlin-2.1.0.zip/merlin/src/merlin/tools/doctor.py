"""doctor — environment check (ROADMAP 4).

``preflight`` checks the data. This checks the machine: which Python packages
are importable, whether R and its Bioconductor dependencies are present for
``roundtable.R``, and which MErlin modules are therefore usable.

Exit ``0`` when every module can run, ``1`` when an optional capability is
missing, ``2`` when a core dependency is absent.
"""

from __future__ import annotations

import argparse
import importlib
import shutil
import subprocess
import sys
from pathlib import Path

from .. import __version__

CORE = [("numpy", "arrays and all counting"),
        ("pandas", "tables and every output file"),
        ("scipy", "statistics: exact tests, distributions, correlation"),
        ("matplotlib", "every figure")]

OPTIONAL = [
    ("sklearn", "scikit-learn", "diem's classifier"),
    ("statsmodels", "statsmodels", "diem's logistic regression"),
    ("seaborn", "seaborn", "diem's boxplot and heatmap panels"),
    ("h5py", "h5py", "the merlin store, and .cool/.mcool Hi-C without cooler"),
    ("cooler", "cooler", "richer .cool/.mcool support (h5py is the fallback)"),
    ("pysam", "pysam", "read-level analysis (merlin phase)"),
    ("yaml", "pyyaml", "YAML run configs (JSON works without it)"),
]

R_PACKAGES = ["optparse", "data.table", "circlize", "Biostrings"]

# External binaries. modkit is the reference implementation of the modBAM
# pileup; MErlin has an internal fallback, so its absence degrades rather than
# blocks. minimap2 and samtools are only needed to align an unaligned modBAM.
EXTERNAL = [
    ("modkit", "modkit pileup: modBAM -> bedMethyl (MErlin has a slower "
               "internal fallback)"),
    ("samtools", "sorting/indexing a BAM and aligning an unaligned modBAM"),
    ("minimap2", "aligning an unaligned modBAM before a pileup"),
]

MODULE_NEEDS = {
    "pileup": ["pysam"],
    "xam": [], "dixam": [], "spacem": [], "mematch": [],
    "diem": ["sklearn", "statsmodels", "seaborn"],
    "hicam": ["h5py"],
    "phase": ["pysam"],
    "harmonise": ["h5py"], "evidence": ["h5py"], "report": [],
    "mtase": [], "discover": [], "preflight": [],
    "roundtable.R": ["_R"],
}


def _version(mod) -> str:
    return str(getattr(mod, "__version__", "") or "installed")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin doctor",
        description="Check that this machine can run every MErlin module.")
    p.add_argument("--check-r", action="store_true", default=True,
                   help="Check R and its packages (needs Rscript on PATH).")
    p.add_argument("--no-check-r", dest="check_r", action="store_false")
    p.add_argument("--out", default=None, metavar="FILE",
                   help="Also write the report here.")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    lines: list[str] = []
    status = 0

    def say(text=""):
        lines.append(text)
        print(text)

    say(f"MErlin {__version__} — environment check")
    say("=" * 68)
    say(f"  python   : {sys.version.split()[0]}  ({sys.executable})")

    missing_core = []
    for name, why in CORE:
        try:
            mod = importlib.import_module(name)
            say(f"  [  ok  ] {name:<14}{_version(mod):<12}{why}")
        except ImportError:
            missing_core.append(name)
            say(f"  [ FAIL ] {name:<14}{'missing':<12}{why}")
    if missing_core:
        status = 2

    say()
    present: set[str] = set()
    for import_name, pip_name, why in OPTIONAL:
        try:
            mod = importlib.import_module(import_name)
            present.add(import_name)
            say(f"  [  ok  ] {pip_name:<14}{_version(mod):<12}{why}")
        except ImportError:
            say(f"  [ warn ] {pip_name:<14}{'missing':<12}{why}")
            say(f"           pip install {pip_name}")
            status = max(status, 1)

    say()
    for exe, why in EXTERNAL:
        found = shutil.which(exe)
        if found:
            present.add(f"_{exe}")
            version = ""
            try:
                proc = subprocess.run([found, "--version"], capture_output=True,
                                      text=True, timeout=30)
                version = (proc.stdout or proc.stderr).strip().splitlines()[0][:24]
            except (subprocess.TimeoutExpired, OSError, IndexError):
                version = "installed"
            say(f"  [  ok  ] {exe:<14}{version:<12}{why}")
        else:
            say(f"  [ warn ] {exe:<14}{'missing':<12}{why}")
            status = max(status, 1)

    have_r = False
    if args.check_r:
        say()
        rscript = shutil.which("Rscript")
        if not rscript:
            say("  [ warn ] Rscript        missing     roundtable.R circos figure")
            status = max(status, 1)
        else:
            try:
                proc = subprocess.run(
                    [rscript, "-e",
                     "cat(paste(rownames(installed.packages()), collapse=' '))"],
                    capture_output=True, text=True, timeout=90)
                installed = set(proc.stdout.split())
                missing_r = [p for p in R_PACKAGES if p not in installed]
                if missing_r:
                    say(f"  [ warn ] R packages     missing     {', '.join(missing_r)}")
                    say("           Rscript scripts/roundtable.R --install-deps ...")
                    status = max(status, 1)
                else:
                    say(f"  [  ok  ] R              {rscript:<12}"
                        f"{', '.join(R_PACKAGES)}")
                    have_r = True
            except (subprocess.TimeoutExpired, OSError) as exc:
                say(f"  [ warn ] R              error       {exc}")
                status = max(status, 1)
    if have_r:
        present.add("_R")

    say()
    say("  module availability")
    say("  " + "-" * 64)
    for module, needs in MODULE_NEEDS.items():
        lacking = [n for n in needs if n not in present]
        if missing_core:
            mark, note = "unusable", "core dependency missing"
        elif lacking:
            mark, note = "degraded", "needs " + ", ".join(
                "R" if n == "_R" else n.lstrip("_") for n in lacking)
        else:
            mark, note = "ready", ""
        say(f"  {module:<14}{mark:<10}{note}")

    say()
    say({0: "Everything MErlin can do is available here.",
         1: "Core modules work; some optional capabilities are missing.",
         2: "A core dependency is missing — install it before running anything."
         }[status])

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return status


if __name__ == "__main__":
    raise SystemExit(main())
