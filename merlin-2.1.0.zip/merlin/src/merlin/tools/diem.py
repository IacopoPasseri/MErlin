"""diem — integrate differential expression with methylation.

Changes from the original ``diem.py``
-------------------------------------
* **"DM" now means differentially methylated.**  The original derived ``is_DM``
  from a threshold on absolute methylation in a single condition — that is
  *highly* methylated, not differentially methylated, and the "dual-hit" set
  inherited the mislabel.  Pass ``--dm-table`` (a ``dixam`` differential output)
  for the real contrast; without it the legacy threshold still runs but the
  column is named ``is_HM`` and aliased to ``is_DM`` for compatibility.
* **The expression/methylation join is a left join by default.**  The original
  inner-joined, so every gene with no methylation call was dropped from the
  correlation, the classifier and the odds ratios — conditioning every statistic
  on the presence of methylation.  ``--join inner`` restores the old behaviour.
* **No feature scaling outside cross-validation.**  Scaling was fitted on the
  full dataset before ``cross_val_predict``, leaking test-fold information into
  training.  Scaling now lives in a pipeline (and a random forest does not need
  it at all).
* **Permutation Spearman is ~100x faster** — ranks are computed once instead of
  re-ranking inside 5 000 ``spearmanr`` calls.
* Adds the question the tool is named for when ``--dm-table`` is supplied:
  Δmethylation versus log2 fold-change, per modification.
* Column resolution accepts DESeq2, edgeR and limma tables.
"""

from __future__ import annotations

import argparse
import warnings
from pathlib import Path

import numpy as np

from .. import viz
from ..covariates import (build_feature_covariates, covariate_screen,
                          partial_correlation)
from ..io import read_annotation, read_fasta, read_geneexp
from ..logging_utils import LEDGER, get_logger, warn_once
from ..stats import benjamini_hochberg, correlate
from . import _common as C

logger = get_logger("diem")

METH_PREFIXES = ("total_norm_count", "mean_norm_count", "raw_count_total",
                 "n_rows", "mean_frac", "total_cpm")


# --------------------------------------------------------------------------- #
def load_methylation_table(path: str):
    """Read an ``xam`` per-feature table and pivot it to one row per locus."""
    import pandas as pd

    df = pd.read_csv(path, sep=None, engine="python", comment="#")
    df.columns = [str(c).strip() for c in df.columns]
    key = "locus_tag" if "locus_tag" in df.columns else df.columns[0]
    if "mod_label" not in df.columns and "mod_code" in df.columns:
        df["mod_label"] = df["mod_code"]
    if "mod_label" not in df.columns:
        df["mod_label"] = "meth"
    if "norm_count" not in df.columns:
        raise SystemExit(f"[FATAL] {path}: expected a 'norm_count' column "
                         f"(an xam per-feature table).")
    for col in ("raw_count", "cpm", "mean_frac_modified"):
        if col not in df.columns:
            df[col] = np.nan

    agg = (df.groupby([key, "mod_label"], as_index=False)
             .agg(total_norm_count=("norm_count", "sum"),
                  mean_norm_count=("norm_count", "mean"),
                  raw_count_total=("raw_count", "sum"),
                  total_cpm=("cpm", "sum"),
                  mean_frac=("mean_frac_modified", "mean"),
                  n_rows=("norm_count", "size")))
    if (agg["n_rows"] <= 1).all():
        logger.info("Each locus has one row per modification in the xam table, so "
                    "'n_rows' and the mean/total pairs are redundant; the classifier "
                    "drops the duplicates.")
    wide = agg.pivot(index=key, columns="mod_label")
    wide.columns = [f"{a}_{b}" for a, b in wide.columns]
    wide = wide.reset_index().rename(columns={key: "locus_tag"})
    wide["locus_tag"] = wide["locus_tag"].astype(str).str.strip()
    return wide.fillna(0.0)


def load_dm_table(path: str, qthr: float, lfc_thr: float):
    """Read a ``dixam`` differential table and pivot it to one row per locus."""
    import pandas as pd

    df = pd.read_csv(path, sep=None, engine="python", comment="#")
    df.columns = [str(c).strip() for c in df.columns]
    if "locus_tag" not in df.columns:
        raise SystemExit(f"[FATAL] {path}: expected a 'locus_tag' column "
                         f"(a dixam differential table).")
    lfc_col = next((c for c in ("log2FC_cpm", "delta_meth_level", "delta_cpm")
                    if c in df.columns), None)
    if lfc_col is None:
        raise SystemExit(f"[FATAL] {path}: no differential methylation effect column.")
    q_col = "qvalue" if "qvalue" in df.columns else None
    label = df["mod_label"] if "mod_label" in df.columns else "meth"
    out = pd.DataFrame({"locus_tag": df["locus_tag"].astype(str).str.strip(),
                        "mod_label": label,
                        "meth_lfc": pd.to_numeric(df[lfc_col], errors="coerce"),
                        "meth_q": (pd.to_numeric(df[q_col], errors="coerce")
                                   if q_col else np.nan)})
    if "delta_meth_level" in df.columns:
        out["meth_delta_level"] = pd.to_numeric(df["delta_meth_level"], errors="coerce")
    wide = out.pivot_table(index="locus_tag", columns="mod_label",
                           values=[c for c in ("meth_lfc", "meth_q", "meth_delta_level")
                                   if c in out.columns], aggfunc="first")
    wide.columns = [f"{a}_{b}" for a, b in wide.columns]
    wide = wide.reset_index()
    qcols = [c for c in wide.columns if c.startswith("meth_q_")]
    lcols = [c for c in wide.columns if c.startswith("meth_lfc_")]
    sig = np.zeros(len(wide), dtype=bool)
    if qcols:
        sig = (wide[qcols].to_numpy(dtype=float) < qthr).any(axis=1)
    if lcols and lfc_thr > 0:
        sig &= (np.abs(wide[lcols].to_numpy(dtype=float)) >= lfc_thr).any(axis=1)
    wide["is_DM"] = sig.astype(int)
    return wide


# --------------------------------------------------------------------------- #
def define_groups(ge, meth_wide, dm_wide, args):
    import pandas as pd

    ge = ge.dropna(subset=["padj", "log2FoldChange"]).copy()
    before = len(ge)
    ge = (ge.sort_values("padj", kind="stable")
            .groupby("locus_tag", as_index=False).first())
    if len(ge) < before:
        logger.info("Collapsed %d duplicated gene id(s), keeping the lowest padj.",
                    before - len(ge))

    how = args.join
    merged = ge.merge(meth_wide, on="locus_tag", how=how)
    count_like = [c for c in merged.columns
                  if c.startswith(("total_norm_count", "raw_count_total",
                                   "total_cpm", "n_rows"))]
    n_meth_cols = [c for c in merged.columns
                   if any(c.startswith(p) for p in METH_PREFIXES)]
    if how == "left":
        # A gene absent from the methylation table has zero methylation: that is
        # information, not a missing value. A gene present but without a
        # fraction-modified value is genuinely missing and stays NaN.
        merged[count_like] = merged[count_like].fillna(0.0)
    n_with_meth = int((merged[n_meth_cols].sum(axis=1) > 0).sum()) if n_meth_cols else 0
    logger.info("Join '%s': %d gene(s) retained, %d carry methylation.",
                how, len(merged), n_with_meth)
    if how == "inner":
        warn_once(logger, "DIEM_INNER_JOIN",
                  "--join inner drops genes with no methylation call, so every "
                  "statistic below is conditioned on a gene being methylated.")
    if len(merged) == 0:
        raise SystemExit(
            "[FATAL] no gene identifier is shared between the expression table and "
            "the methylation table. Compare the first column of each: the expression "
            "table usually carries locus_tags, the xam table carries the GFF "
            "locus_tag attribute.")
    if n_with_meth == 0:
        raise SystemExit("[FATAL] no gene in the expression table carries any "
                         "methylation. Check the locus_tag namespaces.")

    merged["is_DE"] = ((merged["padj"] < args.padj_thr) &
                       (merged["log2FoldChange"].abs() >= args.lfc_thr)).astype(int)

    total_cols = [c for c in merged.columns if c.startswith("total_norm_count")]
    merged["max_meth"] = merged[total_cols].max(axis=1) if total_cols else 0.0
    merged["is_HM"] = (merged["max_meth"] > args.meth_thr).astype(int)

    if dm_wide is not None:
        merged = merged.merge(dm_wide, on="locus_tag", how="left")
        merged["is_DM"] = merged["is_DM"].fillna(0).astype(int)
        dm_source = "dixam differential table"
    else:
        merged["is_DM"] = merged["is_HM"]
        dm_source = "absolute methylation threshold (highly methylated)"
        warn_once(logger, "DIEM_DM_IS_HM",
                  "No --dm-table supplied: 'is_DM' here means HIGHLY methylated in "
                  "one condition, not differentially methylated between conditions. "
                  "Run dixam and pass its differential table for the real contrast.")
    merged["dual_hit"] = ((merged["is_DE"] == 1) & (merged["is_DM"] == 1)).astype(int)

    logger.info("Groups: n=%d | DE=%d | DM=%d (%s) | dual=%d",
                len(merged), int(merged["is_DE"].sum()), int(merged["is_DM"].sum()),
                dm_source, int(merged["dual_hit"].sum()))
    return merged, dm_source


# --------------------------------------------------------------------------- #
def correlation_analysis(df, n_perm, seed):
    res = {"overall": correlate(df["max_meth"], df["log2FoldChange"],
                                n_perm=n_perm, seed=seed)}
    per_mod = {}
    for col in [c for c in df.columns if c.startswith("total_norm_count_")]:
        per_mod[col.replace("total_norm_count_", "")] = correlate(
            df[col], df["log2FoldChange"])
    res["per_mod"] = per_mod
    # Prefer the methylation-level delta over the call-count log2FC: when dixam
    # ran on bedMethyl the call positions are identical between conditions, so
    # log2FC_cpm is structurally zero and correlating it is meaningless.
    level_cols = [c for c in df.columns if c.startswith("meth_delta_level_")]
    lfc_cols = [c for c in df.columns if c.startswith("meth_lfc_")]
    delta = {}
    for col in (level_cols or lfc_cols):
        key = col.replace("meth_lfc_", "dCPM ").replace("meth_delta_level_", "dlevel ")
        delta[key] = correlate(df[col], df["log2FoldChange"])
    for col in (lfc_cols if level_cols else []):
        v = df[col].to_numpy(dtype=float)
        if np.isfinite(v).sum() > 2 and np.nanstd(v) > 0:
            delta[col.replace("meth_lfc_", "dCPM ")] = correlate(
                df[col], df["log2FoldChange"])
    res["delta"] = delta
    if per_mod:
        q = benjamini_hochberg([r.spearman_p for r in per_mod.values()])
        for (k, r), qq in zip(per_mod.items(), q):
            r.note = f"BH q={qq:.3g}"
    return res


def attach_covariates(df, args):
    """Per-gene confounders, joined onto the integrated table (ROADMAP 1.2)."""
    if not args.gff or args.covariates == "none":
        return df, []
    import pandas as pd
    ann = read_annotation(args.gff, feature_types=(set(args.features)
                                                   if args.features else None))
    genome = read_fasta(args.fasta) if args.fasta else (ann.embedded_fasta or None)
    if genome:
        # diem is normally handed finished tables, so it never went through the
        # shared loader; reconcile here or the GC and oriC/ter covariates
        # silently come out all-NaN on a Prokka annotation of an NCBI reference.
        from ..seqids import reconcile
        res = reconcile({"reference": set(genome), "annotation": ann.seqids},
                        canonical_key="reference")
        if res.mapping or res.stripped:
            genome = {res.apply(k): v for k, v in genome.items()}
            for f in ann.features:
                f.seqid = res.apply(f.seqid)
    origins = None
    if genome:
        from ..genome import resolve_origins
        origins = resolve_origins(genome, 10000)
    block = build_feature_covariates(ann, genome=genome, origins=origins,
                                     expression=df)
    names = block.usable()
    if args.covariates not in ("auto", "none"):
        wanted = {c.strip() for c in args.covariates.split(",")}
        names = [n for n in names if n in wanted]
        missing = wanted - set(names)
        if missing:
            warn_once(logger, "DIEM_COVARIATE_MISSING",
                      f"Requested covariate(s) not available: {sorted(missing)}. "
                      f"Available: {block.usable()}")
    cov_df = block.to_frame([f.locus_tag for f in ann.features])
    cov_df = cov_df.drop_duplicates("locus_tag")
    keep = ["locus_tag"] + [n for n in names if n in cov_df.columns]
    merged = df.merge(cov_df[keep], on="locus_tag", how="left")
    logger.info("Covariates joined: %s", ", ".join(names) if names else "none")
    return merged, names


def adjusted_analysis(df, cov_names, target="max_meth"):
    """Marginal vs covariate-adjusted association, reported side by side."""
    if not cov_names or target not in df.columns:
        return None, []
    import numpy as _np
    Z = df[cov_names].to_numpy(dtype=float)
    res = partial_correlation(df[target].to_numpy(dtype=float),
                              df["log2FoldChange"].to_numpy(dtype=float),
                              Z, cov_names)
    screen = covariate_screen(df[target].to_numpy(dtype=float),
                              type("B", (), {"get": lambda _s, n: df[n].to_numpy(
                                  dtype=float), "usable": lambda _s: cov_names})(),
                              cov_names)
    return res, screen


def feature_columns(df):
    cols = [c for c in df.columns
            if any(c.startswith(p) for p in METH_PREFIXES)
            or c.startswith("meth_lfc_") or c.startswith("meth_delta_level_")]
    keep, seen = [], []
    n = max(len(df), 1)
    for c in cols:
        v = df[c].to_numpy(dtype=float)
        if not np.isfinite(v).any() or np.nanstd(v) == 0:
            continue
        missing = 1.0 - np.isfinite(v).sum() / n
        if missing > 0.2:
            logger.info("Dropping feature %s: %.0f%% missing.", c, 100 * missing)
            continue
        dup = False
        for prev in seen:
            a, b = df[prev].to_numpy(dtype=float), v
            ok = np.isfinite(a) & np.isfinite(b)
            if ok.sum() > 2 and np.allclose(a[ok], b[ok]):
                dup = True
                break
            if ok.sum() > 2 and np.std(a[ok]) and np.std(b[ok]):
                if abs(np.corrcoef(a[ok], b[ok])[0, 1]) > 0.999:
                    dup = True
                    break
        if not dup:
            keep.append(c); seen.append(c)
    dropped = len(cols) - len(keep)
    if dropped:
        logger.info("Dropped %d methylation feature(s) that were constant or "
                    "collinear with a retained one.", dropped)
    return keep


def logistic_regression_analysis(df, feature_cols):
    import pandas as pd
    import statsmodels.api as sm

    if df["is_DE"].nunique() < 2:
        warn_once(logger, "DIEM_ONE_CLASS",
                  "All genes fall in one DE class; logistic regression and the "
                  "classifier are undefined.")
        return pd.DataFrame()
    records = []
    y = df["is_DE"].to_numpy(dtype=float)
    for col in feature_cols:
        vals = df[col].astype(float)
        ok = np.isfinite(vals.to_numpy())
        if ok.sum() < 10 or vals[ok].std() == 0:
            continue
        X = sm.add_constant(vals[ok].to_frame())
        y_use = y[ok]
        if len(set(y_use.tolist())) < 2:
            continue
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                model = sm.Logit(y_use, X).fit(disp=0, maxiter=200)
            except Exception as exc:            # noqa: BLE001
                logger.warning("  logistic regression failed for %s: %s", col, exc)
                continue
        coef = float(model.params.iloc[1])
        ci = model.conf_int()
        records.append({
            "feature": col, "coef": coef, "OR": float(np.exp(coef)),
            "CI_low": float(np.exp(ci.iloc[1, 0])),
            "CI_high": float(np.exp(ci.iloc[1, 1])),
            "pvalue": float(model.pvalues.iloc[1]), "n": int(ok.sum()),
            "converged": bool(getattr(model, "mle_retvals", {}).get("converged", True)),
        })
    if not records:
        return pd.DataFrame()
    res = pd.DataFrame(records)
    res["qvalue"] = benjamini_hochberg(res["pvalue"].to_numpy(dtype=float))
    if (~res["converged"]).any() or (res["OR"] > 1e6).any():
        warn_once(logger, "DIEM_LR_SEPARATION",
                  "At least one logistic regression shows (quasi-)complete "
                  "separation: its odds ratio and interval are not interpretable.")
    return res.sort_values("pvalue").reset_index(drop=True)


def random_forest_cv(df, feature_cols, seed, n_perm_auc, cv_mode="auto",
                     n_trees=300):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.impute import SimpleImputer
    from sklearn.metrics import confusion_matrix, roc_auc_score
    from sklearn.model_selection import (LeaveOneOut, StratifiedKFold,
                                         cross_val_predict)
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    X = df[feature_cols].astype(float).to_numpy()
    y = df["is_DE"].to_numpy()
    if y.sum() < 5 or (y == 0).sum() < 5:
        warn_once(logger, "DIEM_RF_SKIPPED",
                  f"Random forest skipped: only {int(y.sum())} DE and "
                  f"{int((y == 0).sum())} non-DE genes — too few for a "
                  f"cross-validated estimate.")
        return {}

    # Imputation and scaling live inside the pipeline so they are refitted on
    # each training fold; fitting them on the full matrix first leaks test-fold
    # information into training and inflates the AUC.
    pipe = Pipeline([("impute", SimpleImputer(strategy="median")),
                     ("scale", StandardScaler()),
                     ("rf", RandomForestClassifier(
                         n_estimators=n_trees, min_samples_leaf=2,
                         class_weight="balanced", random_state=seed, n_jobs=1))])
    n = len(df)
    minority = int(min(y.sum(), (y == 0).sum()))
    if cv_mode == "loocv" or (cv_mode == "auto" and minority < 15):
        cv, cv_name = LeaveOneOut(), "LOOCV"
    else:
        k = int(min(5, minority))
        cv = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
        cv_name = f"{k}-fold stratified CV"
    logger.info("Random forest: %s on n=%d (%d DE, %d features).",
                cv_name, n, int(y.sum()), len(feature_cols))

    proba = cross_val_predict(pipe, X, y, cv=cv, method="predict_proba",
                              n_jobs=-1)[:, 1]
    pred = (proba >= 0.5).astype(int)
    try:
        auc = float(roc_auc_score(y, proba))
    except ValueError:
        auc = float("nan")

    perm_p = float("nan")
    if n_perm_auc:
        rng = np.random.default_rng(seed)
        null_cv = StratifiedKFold(n_splits=min(5, minority), shuffle=True,
                                  random_state=seed)
        nulls = []
        for _ in range(n_perm_auc):
            yp = rng.permutation(y)
            pp = cross_val_predict(pipe, X, yp, cv=null_cv, method="predict_proba",
                                   n_jobs=-1)[:, 1]
            try:
                nulls.append(roc_auc_score(yp, pp))
            except ValueError:
                pass
        if nulls:
            perm_p = (1 + sum(v >= auc for v in nulls)) / (1 + len(nulls))

    pipe.fit(X, y)
    import pandas as pd
    importances = pd.Series(pipe.named_steps["rf"].feature_importances_,
                            index=feature_cols).sort_values(ascending=False)
    prevalence = float(y.mean())
    if auc == auc and auc < 0.6:
        warn_once(logger, "DIEM_RF_WEAK",
                  f"Cross-validated AUC is {auc:.3f}: methylation features carry "
                  f"little information about DE status in this dataset. Feature "
                  f"importances of a model that does not predict should not be "
                  f"read as a ranking of biological relevance.")
    return {"cv_name": cv_name, "accuracy": float(np.mean(pred == y)), "auc": auc,
            "auc_perm_p": perm_p, "n_perm_auc": n_perm_auc, "prevalence": prevalence,
            "y_true": y, "y_pred": pred, "y_pred_proba": proba,
            "confusion_matrix": confusion_matrix(y, pred),
            "feature_importances": importances}


# --------------------------------------------------------------------------- #
def _short(col: str) -> str:
    return (col.replace("total_norm_count_", "Sum_")
               .replace("mean_norm_count_", "Mean_")
               .replace("raw_count_total_", "raw_")
               .replace("total_cpm_", "cpm_")
               .replace("mean_frac_", "frac_")
               .replace("meth_delta_level_", "dLevel_")
               .replace("meth_lfc_", "dMeth_")
               .replace("n_rows_", "rows_"))


def make_figure(df, corr, rf_res, lr_res, inp, args, dm_source):
    plt = viz.lazy_pyplot()
    if plt is None:
        return None
    import matplotlib.gridspec as gridspec
    from matplotlib.patches import Patch
    from sklearn.metrics import ConfusionMatrixDisplay, roc_curve
    import seaborn as sns
    from scipy import stats as sstats

    colours = np.where(df["dual_hit"] == 1, viz.PAL["dual"],
                       np.where(df["is_DE"] == 1, viz.PAL["DE"],
                                np.where(df["is_DM"] == 1, viz.PAL["DM"],
                                         viz.PAL["neutral"])))

    fig = plt.figure(figsize=(20, 15), facecolor="#fafafa")
    fig.suptitle("Methylation - Expression integrative analysis  "
                 f"(DM = {dm_source})", fontsize=15, fontweight="bold", y=0.995,
                 color="#2c3e50")
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.38)

    ax = fig.add_subplot(gs[0, 0])
    ax.scatter(df["log2FoldChange"], -np.log10(df["padj"].clip(lower=1e-300)),
               c=colours, s=8, alpha=0.6, linewidths=0)
    ax.axvline(0, lw=0.8, ls="--", color="#555")
    ax.axhline(-np.log10(args.padj_thr), lw=0.8, ls=":", color="#555")
    ax.set_xlabel("log2 fold change", fontsize=9); ax.set_ylabel("-log10 padj", fontsize=9)
    ax.set_title("A  Volcano (expression)", fontsize=10, fontweight="bold")
    ax.legend(handles=[Patch(facecolor=viz.PAL["DE"], label="DE only"),
                       Patch(facecolor=viz.PAL["DM"], label="DM only"),
                       Patch(facecolor=viz.PAL["dual"], label="dual-hit"),
                       Patch(facecolor=viz.PAL["neutral"], label="neither")],
              fontsize=6, loc="upper right")

    ax = fig.add_subplot(gs[0, 1])
    ax.scatter(df["max_meth"], df["log2FoldChange"], c=colours, s=8, alpha=0.5,
               linewidths=0)
    ov = corr["overall"]
    if np.isfinite(df["max_meth"]).sum() > 2 and df["max_meth"].std() > 0:
        m, b, *_ = sstats.linregress(df["max_meth"], df["log2FoldChange"])
        xl = np.linspace(df["max_meth"].min(), df["max_meth"].max(), 200)
        ax.plot(xl, m * xl + b, lw=1.8, color="#2c3e50", ls="--")
    ax.set_xlabel("max methylation density (calls/bp)", fontsize=9)
    ax.set_ylabel("log2 fold change", fontsize=9)
    ax.set_title(f"B  Methylation vs LFC\nPearson r={ov.pearson_r:+.3f} "
                 f"(p={ov.pearson_p:.1e})   Spearman rho={ov.spearman_rho:+.3f} "
                 f"(p={ov.spearman_p:.1e})", fontsize=9, fontweight="bold")

    ax = fig.add_subplot(gs[0, 2])
    cats = ["genes", "DE", "DM", "dual-hit"]
    counts = [len(df), int(df["is_DE"].sum()), int(df["is_DM"].sum()),
              int(df["dual_hit"].sum())]
    bars = ax.bar(cats, counts, color=[viz.PAL["neutral"], viz.PAL["DE"],
                                       viz.PAL["DM"], viz.PAL["dual"]],
                  edgecolor="white", lw=0.8)
    for b_, v in zip(bars, counts):
        ax.text(b_.get_x() + b_.get_width() / 2, v + max(counts) * 0.01, f"{v:,}",
                ha="center", va="bottom", fontsize=9, fontweight="bold")
    ax.set_ylabel("number of genes", fontsize=9)
    ax.set_ylim(0, max(counts) * 1.18)
    ax.set_title("C  Group sizes", fontsize=10, fontweight="bold")

    ax = fig.add_subplot(gs[1, 0])
    total_cols = [c for c in df.columns if c.startswith("total_norm_count")]
    if total_cols:
        melt = df[["is_DE"] + total_cols].melt(id_vars="is_DE", var_name="mod",
                                               value_name="norm_count")
        melt["mod"] = melt["mod"].str.replace("total_norm_count_", "", regex=False)
        melt["DE status"] = melt["is_DE"].map({1: "DE", 0: "non-DE"})
        sns.boxplot(data=melt, x="mod", y="norm_count", hue="DE status",
                    palette={"DE": viz.PAL["DE"], "non-DE": viz.PAL["nonDE"]},
                    ax=ax, linewidth=0.8, showfliers=False)
        for i, mod in enumerate(melt["mod"].unique()):
            sub = melt[melt["mod"] == mod]
            g0 = sub.loc[sub["DE status"] == "non-DE", "norm_count"]
            g1 = sub.loc[sub["DE status"] == "DE", "norm_count"]
            if len(g0) > 1 and len(g1) > 1:
                _, p = sstats.mannwhitneyu(g0, g1, alternative="two-sided")
                ax.text(i, sub["norm_count"].quantile(0.97) * 1.02, f"p={p:.1e}",
                        ha="center", fontsize=7, color="#333")
        ax.set_xlabel("modification", fontsize=9)
        ax.set_ylabel("methylation density per gene", fontsize=9)
        ax.legend(fontsize=7)
    else:
        viz.annotate_empty(ax)
    ax.set_title("D  Methylation by modification and DE status", fontsize=10,
                 fontweight="bold")

    ax = fig.add_subplot(gs[1, 1])
    if rf_res:
        fi = rf_res["feature_importances"]
        labels = [_short(i) for i in fi.index]
        cols = [viz.PAL["dual"] if v == fi.max() else viz.PAL["nonDE"] for v in fi.values]
        ax.barh(labels[::-1], fi.values[::-1], color=cols[::-1], edgecolor="white")
        ax.set_xlabel("mean decrease in impurity", fontsize=9)
        extra = ("" if not np.isfinite(rf_res["auc_perm_p"])
                 else f"  perm p={rf_res['auc_perm_p']:.3g}")
        ax.set_title(f"E  RF feature importances\n({rf_res['cv_name']}  "
                     f"AUC={rf_res['auc']:.3f}{extra})", fontsize=9, fontweight="bold")
    else:
        viz.annotate_empty(ax, "RF not fitted")
        ax.set_title("E  RF feature importances", fontsize=10, fontweight="bold")

    ax = fig.add_subplot(gs[1, 2])
    if rf_res:
        ConfusionMatrixDisplay(rf_res["confusion_matrix"],
                               display_labels=["non-DE", "DE"]).plot(
            ax=ax, colorbar=False, cmap="Blues")
        ax.set_title(f"F  Confusion matrix ({rf_res['cv_name']})", fontsize=10,
                     fontweight="bold")
    else:
        viz.annotate_empty(ax, "RF not fitted")
        ax.set_title("F  Confusion matrix", fontsize=10, fontweight="bold")

    ax = fig.add_subplot(gs[2, 0])
    if rf_res:
        fpr, tpr, _ = roc_curve(rf_res["y_true"], rf_res["y_pred_proba"])
        ax.plot(fpr, tpr, lw=2, color=viz.PAL["dual"], label=f"AUC = {rf_res['auc']:.3f}")
        ax.plot([0, 1], [0, 1], lw=1, ls="--", color="grey", label="chance")
        ax.set_xlabel("false positive rate", fontsize=9)
        ax.set_ylabel("true positive rate", fontsize=9)
        ax.legend(fontsize=9)
        ax.set_title(f"G  ROC ({rf_res['cv_name']})", fontsize=10, fontweight="bold")
    else:
        viz.annotate_empty(ax, "RF not fitted")
        ax.set_title("G  ROC", fontsize=10, fontweight="bold")

    ax = fig.add_subplot(gs[2, 1])
    if lr_res is not None and not lr_res.empty:
        y_pos = np.arange(len(lr_res))
        orv = lr_res["OR"].clip(1e-4, 1e4)
        ax.errorbar(orv, y_pos,
                    xerr=[(orv - lr_res["CI_low"].clip(1e-4, 1e4)).clip(0),
                          (lr_res["CI_high"].clip(1e-4, 1e4) - orv).clip(0)],
                    fmt="o", color=viz.PAL["DE"], ecolor="#aaa", capsize=4, ms=6, lw=1.2)
        ax.axvline(1.0, lw=1, ls="--", color="#555")
        ax.set_xscale("log")
        ax.set_yticks(y_pos)
        ax.set_yticklabels([_short(f) for f in lr_res["feature"]], fontsize=8)
        ax.set_xlabel("odds ratio for DE (95% CI, log scale)", fontsize=9)
        for i, q in enumerate(lr_res["qvalue"]):
            if q < 0.05:
                ax.text(orv.iloc[i] * 1.05, i, "*", fontsize=11, color=viz.PAL["DE"],
                        va="center")
        ax.set_title("H  Univariate logistic regression", fontsize=9, fontweight="bold")
    else:
        viz.annotate_empty(ax, "LR not fitted")
        ax.set_title("H  Logistic regression", fontsize=10, fontweight="bold")

    ax = fig.add_subplot(gs[2, 2])
    delta_cols = ([c for c in df.columns if c.startswith("meth_delta_level_")]
                  or [c for c in df.columns if c.startswith("meth_lfc_")])
    delta_cols = [c for c in delta_cols
                  if np.isfinite(df[c].to_numpy(dtype=float)).sum() > 2
                  and np.nanstd(df[c].to_numpy(dtype=float)) > 0]
    if delta_cols:
        col = delta_cols[0]
        ax.scatter(df[col], df["log2FoldChange"], c=colours, s=8, alpha=0.6,
                   linewidths=0)
        ax.axhline(0, lw=0.8, ls="--", color="#555"); ax.axvline(0, lw=0.8, ls="--",
                                                                 color="#555")
        r = corr["delta"].get(list(corr["delta"])[0]) if corr["delta"] else None
        sub = f"\nSpearman rho={r.spearman_rho:+.3f} (p={r.spearman_p:.1e})" if r else ""
        ax.set_xlabel(_short(col), fontsize=9)
        ax.set_ylabel("log2 fold change (expression)", fontsize=9)
        ax.set_title(f"I  Differential methylation vs differential expression{sub}",
                     fontsize=9, fontweight="bold")
    else:
        heat_cols = [c for c in df.columns if c.startswith("total_norm_count")
                     or c.startswith("mean_frac")]
        if heat_cols and len(df):
            plot_df = df[df["dual_hit"] == 1] if df["dual_hit"].sum() >= 5 else df
            plot_df = plot_df.set_index("locus_tag")[heat_cols]
            if len(plot_df) > 40:
                plot_df = plot_df.loc[plot_df.max(axis=1).nlargest(40).index]
            plot_df.columns = [_short(c) for c in plot_df.columns]
            sns.heatmap(plot_df, ax=ax, cmap="YlOrRd", linewidths=0.2,
                        linecolor="white", annot=len(plot_df) <= 25,
                        fmt=".3g", annot_kws={"size": 6}, cbar_kws={"shrink": 0.7})
            tag = "dual-hit" if df["dual_hit"].sum() >= 5 else "all"
            ax.set_title(f"I  Methylation heatmap (top {len(plot_df)} {tag} genes)",
                         fontsize=9, fontweight="bold")
            ax.tick_params(axis="x", rotation=30, labelsize=8)
            ax.tick_params(axis="y", rotation=0, labelsize=6)
        else:
            viz.annotate_empty(ax)
            ax.set_title("I  Methylation heatmap", fontsize=10, fontweight="bold")

    return viz.savefig(fig, inp_out(inp, f"integration.{args.plot_format}"),
                       args.plot_dpi)


def inp_out(inp, suffix):
    return Path(inp["outdir"]) / f"{inp['prefix']}.{suffix}"


# --------------------------------------------------------------------------- #
def save_summary(df, corr, rf_res, lr_res, inp, dm_source, args,
                 adjusted=None, screen=None, cov_names=None) -> list[Path]:
    written = []
    p = inp_out(inp, "integrated_table.tsv")
    df.to_csv(p, sep="\t", index=False, float_format="%.6g"); written.append(p)
    p = inp_out(inp, "dual_hit_genes.tsv")
    df[df["dual_hit"] == 1].to_csv(p, sep="\t", index=False, float_format="%.6g")
    written.append(p)

    ov = corr["overall"]
    lines = [
        "MErlin diem — expression / methylation integration",
        "=" * 60, "",
        f"genes analysed           : {len(df)}",
        f"join                     : {args.join}",
        f"DE definition            : padj < {args.padj_thr} and |log2FC| >= {args.lfc_thr}",
        f"DM definition            : {dm_source}",
        f"DE genes                 : {int(df['is_DE'].sum())}",
        f"DM genes                 : {int(df['is_DM'].sum())}",
        f"dual-hit genes           : {int(df['dual_hit'].sum())}",
        "",
        "Correlation: methylation density vs log2 fold change",
        f"  Pearson  r   = {ov.pearson_r:+.4f}  p = {ov.pearson_p:.4e}  (n={ov.n})",
        f"  Spearman rho = {ov.spearman_rho:+.4f}  p = {ov.spearman_p:.4e}",
    ]
    if ov.n_perm:
        lines.append(f"  permutation p ({ov.n_perm} shuffles) = {ov.perm_p:.4f}")
    if corr["per_mod"]:
        lines += ["", "Per modification (Spearman)"]
        for mod, r in corr["per_mod"].items():
            if np.isfinite(r.spearman_rho):
                lines.append(f"  [{mod}] rho={r.spearman_rho:+.4f}  "
                             f"p={r.spearman_p:.4e}  {r.note}")
            else:
                lines.append(f"  [{mod}] not computable ({r.note or 'no data'})")
    if corr["delta"]:
        lines += ["", "Differential methylation vs differential expression (Spearman)"]
        for k, r in corr["delta"].items():
            if np.isfinite(r.spearman_rho):
                lines.append(f"  [{k}] rho={r.spearman_rho:+.4f}  "
                             f"p={r.spearman_p:.4e}  (n={r.n})")
            else:
                lines.append(f"  [{k}] not computable ({r.note or 'no data'})")
    if adjusted is not None:
        lines += ["", "Confounder-adjusted association "
                      "(methylation density vs log2 fold change)",
                  f"  covariates    : {', '.join(cov_names or [])}",
                  f"  marginal  rho = {adjusted.marginal_rho:+.4f}  "
                  f"p = {adjusted.marginal_p:.4e}",
                  f"  partial   rho = {adjusted.partial_rho:+.4f}  "
                  f"p = {adjusted.partial_p:.4e}   (n={adjusted.n})",
                  f"  OLS coefficient = {adjusted.coef:+.4g} "
                  f"(SE {adjusted.coef_se:.3g}, p = {adjusted.coef_p:.4e})"]
        if adjusted.attenuated:
            lines.append("  The association loses more than half its strength once "
                         "the covariates are held")
            lines.append("  fixed: report the adjusted estimate, and say which "
                         "covariate absorbs it.")
        if screen:
            lines += ["", "  What the covariates themselves track "
                          "(Spearman vs methylation density)"]
            for row in screen[:6]:
                lines.append(f"    {row['covariate']:<22} rho="
                             f"{row['spearman_rho']:+.3f}  n={row['n']}")
    lines += ["", "Random forest"]
    if rf_res:
        lines += [f"  CV strategy    : {rf_res['cv_name']}",
                  f"  accuracy       : {rf_res['accuracy']:.4f}",
                  f"  DE prevalence  : {rf_res['prevalence']:.4f}  "
                  f"(accuracy of always predicting non-DE: "
                  f"{1 - rf_res['prevalence']:.4f})",
                  f"  AUC-ROC        : {rf_res['auc']:.4f}"]
        if np.isfinite(rf_res["auc_perm_p"]):
            lines.append(f"  AUC permutation p ({rf_res['n_perm_auc']}): "
                         f"{rf_res['auc_perm_p']:.4f}")
    else:
        lines.append("  not fitted")
    lines += ["", "Caveats",
              "  Association, not causation: these statistics quantify co-variation",
              "  between methylation and expression. Neither the correlation nor the",
              "  classifier distinguishes methylation acting on transcription from",
              "  both tracking a third variable (gene length, GC content, replication",
              "  timing, expression-dependent accessibility of the MTase substrate)."]
    if LEDGER:
        lines += ["", "Data-quality warnings", "  see the .warnings.txt file"]
    p = inp_out(inp, "statistics_summary.txt")
    p.write_text("\n".join(lines) + "\n", encoding="utf-8"); written.append(p)
    print("\n" + "\n".join(lines) + "\n")

    if lr_res is not None and not lr_res.empty:
        p = inp_out(inp, "logistic_regression.tsv")
        lr_res.to_csv(p, sep="\t", index=False, float_format="%.6g"); written.append(p)
    return written


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin diem",
        description="Integrate differential expression with methylation.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    req = p.add_argument_group("inputs")
    req.add_argument("--geneexp", required=True, metavar="FILE",
                     help="Differential expression table (DESeq2/edgeR/limma), CSV or TSV.")
    req.add_argument("--methylation", required=True, metavar="FILE",
                     help="xam per-feature table (run xam with --include-zero for "
                          "unbiased statistics).")
    req.add_argument("--dm-table", default=None, metavar="FILE",
                     help="dixam differential table; makes 'DM' mean differentially "
                          "methylated rather than highly methylated.")
    req.add_argument("--gff", default=None, metavar="FILE",
                     help="Annotation, used to build the confounder block "
                          "(gene length, GC, replication position, gene density).")
    req.add_argument("--fasta", default=None, metavar="FILE",
                     help="Reference FASTA, for the GC and oriC/ter covariates.")
    req.add_argument("--features", nargs="+", default=None, metavar="TYPE",
                     help="Feature types to read from --gff.")
    req.add_argument("--covariates", default="auto", metavar="LIST",
                     help="'auto' uses every usable covariate, 'none' disables "
                          "adjustment, or a comma-separated subset.")
    req.add_argument("--gene-col", default=None, help="Gene id column in --geneexp.")
    req.add_argument("--lfc-col", default=None, help="log2 fold-change column.")
    req.add_argument("--padj-col", default=None, help="Adjusted p-value column.")

    thr = p.add_argument_group("thresholds")
    thr.add_argument("--padj_thr", "--padj-thr", dest="padj_thr", type=float,
                     default=0.05, help="Adjusted p-value cut-off for DE.")
    thr.add_argument("--lfc_thr", "--lfc-thr", dest="lfc_thr", type=float, default=1.0,
                     help="|log2 fold change| cut-off for DE.")
    thr.add_argument("--meth_thr", "--meth-thr", dest="meth_thr", type=float,
                     default=0.004,
                     help="Methylation density cut-off for 'highly methylated' "
                          "(used only without --dm-table).")
    thr.add_argument("--dm-qvalue", type=float, default=0.05,
                     help="q-value cut-off applied to --dm-table.")
    thr.add_argument("--dm-lfc", type=float, default=0.0,
                     help="|log2FC| cut-off applied to --dm-table.")

    opt = p.add_argument_group("analysis")
    opt.add_argument("--join", default="left", choices=["left", "inner"],
                     help="'left' keeps genes with no methylation (recommended); "
                          "'inner' reproduces the original behaviour.")
    opt.add_argument("--n-perm", type=int, default=5000,
                     help="Permutations for the Spearman permutation p-value.")
    opt.add_argument("--n-perm-auc", type=int, default=0,
                     help="Label permutations for a null distribution of the CV AUC "
                          "(slow; 200 is usually enough).")
    opt.add_argument("--cv", default="auto", choices=["auto", "kfold", "loocv"],
                     help="Cross-validation for the classifier. 'auto' uses "
                          "stratified k-fold unless the minority class is tiny.")
    opt.add_argument("--n-trees", type=int, default=300,
                     help="Trees in the random forest.")
    opt.add_argument("--seed", type=int, default=42, help="Random seed.")
    opt.add_argument("--no-ml", action="store_true",
                     help="Skip the classifier and logistic regression.")

    out = p.add_argument_group("output")
    out.add_argument("--outdir", "-o", required=True, help="Output directory.")
    out.add_argument("--prefix", default="diem", help="Output filename prefix.")
    out.add_argument("--no-plot", action="store_true", help="Disable figures.")
    out.add_argument("--plot-format", default="png", choices=["png", "pdf", "svg"])
    out.add_argument("--plot-dpi", type=int, default=180)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    inp = {"outdir": outdir, "prefix": args.prefix}

    ge = read_geneexp(args.geneexp, args.gene_col, args.lfc_col, args.padj_col)
    meth_wide = load_methylation_table(args.methylation)
    dm_wide = (load_dm_table(args.dm_table, args.dm_qvalue, args.dm_lfc)
               if args.dm_table else None)

    df, dm_source = define_groups(ge, meth_wide, dm_wide, args)
    df, cov_names = attach_covariates(df, args)
    corr = correlation_analysis(df, args.n_perm, args.seed)
    adjusted, screen = adjusted_analysis(df, cov_names)
    feat_cols = feature_columns(df)
    logger.info("Methylation features used (%d): %s", len(feat_cols), feat_cols)

    lr_res, rf_res = None, {}
    if not args.no_ml and feat_cols:
        lr_res = logistic_regression_analysis(df, feat_cols)
        rf_res = random_forest_cv(df, feat_cols, args.seed, args.n_perm_auc,
                                  args.cv, args.n_trees)

    written = save_summary(df, corr, rf_res, lr_res, inp, dm_source, args,
                           adjusted, screen, cov_names)
    if not args.no_plot:
        p = make_figure(df, corr, rf_res, lr_res, inp, args, dm_source)
        if p:
            written.append(p)
    if LEDGER:
        p = inp_out(inp, "warnings.txt")
        LEDGER.write(p); written.append(p)
    logger.info("Files written (%d):", len(written))
    for p in written:
        logger.info("    %s", p)
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
