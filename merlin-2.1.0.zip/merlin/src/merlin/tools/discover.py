"""discover — find the motifs in the data instead of supplying them (ROADMAP 3.3).

    merlin discover --fasta ref.fasta --methylation calls.bed.gz \\
        -o results/ --plots

Writes ``<prefix>.motifs.txt`` in the format ``mematch`` and ``spacem`` read, so
the discovered motifs can go straight into the rest of the pipeline:

    merlin mematch --motifs results/<prefix>.motifs.txt ...

A discovered motif is a hypothesis. Check it against the occurrence count, the
fraction of calls it explains, and — if you can — a knockout, before treating it
as this strain's recognition sequence.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..discover import discover_motifs, write_motif_file
from ..logging_utils import get_logger, warn_once
from ..model import mod_label
from . import _common as C

logger = get_logger("discover")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin discover",
        description="Discover methylation motifs de novo from the calls.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    C.add_annotation_args(p, required=False)
    C.add_reference_args(p, required=True)
    C.add_methylation_args(p)
    C.add_seqid_args(p)
    g = p.add_argument_group("discovery")
    g.add_argument("--flank", type=int, default=8, metavar="BP",
                   help="Bases either side of the modified base to examine.")
    g.add_argument("--seed-k", type=int, default=5, metavar="K",
                   help="Exact k-mer length used to seed distinct motifs.")
    g.add_argument("--max-motifs", type=int, default=4, metavar="N",
                   help="Motifs reported per modification.")
    g.add_argument("--min-enrichment", type=float, default=10.0, metavar="X",
                   help="Fold enrichment a seed needs over the background.")
    g.add_argument("--min-sites", type=int, default=50, metavar="N",
                   help="Calls a motif must explain to be reported.")
    g.add_argument("--min-base-freq", type=float, default=0.15, metavar="X",
                   help="Frequency at which a base joins the IUPAC code.")
    g.add_argument("--ic-threshold", type=float, default=0.5, metavar="BITS",
                   help="Information content marking a position as informative.")
    g.add_argument("--background-multiple", type=int, default=3, metavar="N",
                   help="Background positions sampled per methylated position.")
    g.add_argument("--seed", type=int, default=0)
    C.add_output_args(p, default_prefix="discover")
    C.add_plot_args(p, default_on=False)
    return p


def main(argv=None) -> int:
    import pandas as pd
    args = build_parser().parse_args(argv)
    inp = C.load_inputs(args, need_reference=True, need_annotation=False)
    if inp.methyl is None or not len(inp.methyl):
        raise SystemExit("[FATAL] no methylation calls available.")

    methyl = inp.methyl
    if not methyl.presence_only:
        thr = 0.5 if args.min_frac is None else args.min_frac
        methyl = methyl.filter(min_frac=thr)
        logger.info("Discovery uses %d call(s) at or above fraction %.2f.",
                    len(methyl), thr)
    if not len(methyl):
        raise SystemExit("[FATAL] no methylated calls survived --min-frac.")

    all_motifs = []
    for mod in sorted(methyl.mod_codes):
        all_motifs += discover_motifs(
            inp.genome, methyl, mod, half=args.flank, seed_k=args.seed_k,
            max_motifs=args.max_motifs, min_enrichment=args.min_enrichment,
            min_sites=args.min_sites, min_freq=args.min_base_freq,
            ic_threshold=args.ic_threshold,
            background_multiple=args.background_multiple, seed=args.seed)

    if not all_motifs:
        warn_once(logger, "DISCOVER_NOTHING",
                  "No motif passed the thresholds. Either the modification is not "
                  "sequence-directed in this genome, or there are too few calls. "
                  "Lower --min-enrichment or --min-sites to see the near misses.")

    written: list[Path] = []
    rows = [dict(motif=m.motif, offset=m.offset, mod_code=m.mod_code,
                 mod_label=mod_label(m.mod_code), n_sites=m.n_sites,
                 enrichment=m.enrichment, information_bits=m.information_bits,
                 seed_kmer=m.seed, note=m.note) for m in all_motifs]
    path = inp.out("discovered_motifs.tsv")
    pd.DataFrame(rows).to_csv(path, sep="\t", index=False, float_format="%.6g")
    written.append(path)

    motif_path = inp.out("motifs.txt")
    write_motif_file(all_motifs, motif_path)
    written.append(motif_path)

    if args.plots and all_motifs:
        written += _plots(all_motifs, inp, args)

    print("\n=== discover ===")
    print(f"  calls examined : {len(methyl):,}")
    if all_motifs:
        print(f"  {'motif':<16}{'offset':>7}{'mod':>6}{'sites':>9}"
              f"{'enrichment':>12}{'bits':>7}")
        for m in all_motifs:
            enr = "n/a" if not np.isfinite(m.enrichment) else f"{m.enrichment:.1f}x"
            print(f"  {m.motif:<16}{m.offset:>7}{mod_label(m.mod_code):>6}"
                  f"{m.n_sites:>9,}{enr:>12}{m.information_bits:>7.1f}")
            if m.note:
                print(f"      note: {m.note}")
        print(f"\n  motif file -> {motif_path}")
        print("  Feed it to mematch/spacem, but treat each motif as a hypothesis "
              "until an\n  independent line of evidence agrees.")
    else:
        print("  no motif passed the thresholds")
    print()
    C.finalize(inp, written, args, "merlin discover")
    return 0


def _plots(motifs, inp, args):
    plt = viz.lazy_pyplot()
    if plt is None:
        return []
    n = len(motifs)
    fig, axes = plt.subplots(n, 1, figsize=(7, 2.4 * n), squeeze=False)
    bases = "ACGT"
    colours = {"A": "#27ae60", "C": "#2980b9", "G": "#f39c12", "T": "#c0392b"}
    for i, m in enumerate(motifs):
        ax = axes[i][0]
        if m.pwm is None:
            viz.annotate_empty(ax)
            continue
        pwm = np.asarray(m.pwm)
        with np.errstate(divide="ignore", invalid="ignore"):
            ic = 2.0 + np.sum(np.where(pwm > 0, pwm * np.log2(pwm), 0.0), axis=1)
        x = np.arange(pwm.shape[0])
        bottom = np.zeros(pwm.shape[0])
        for j, b in enumerate(bases):
            h = pwm[:, j] * ic
            ax.bar(x, h, bottom=bottom, color=colours[b], width=0.85,
                   label=b if i == 0 else None)
            bottom += h
        ax.axvline(m.offset, color="#2c3e50", lw=1.4, ls="--")
        ax.set_xticks(x)
        ax.set_xticklabels(list(m.motif))
        ax.set_ylabel("bits", fontsize=8)
        ax.set_ylim(0, 2.05)
        ax.set_title(f"{m.motif} (offset {m.offset}, {mod_label(m.mod_code)}, "
                     f"n={m.n_sites:,})", fontsize=10)
        if i == 0:
            ax.legend(fontsize=8, ncol=4, frameon=False)
    fig.tight_layout()
    return [viz.savefig(fig, inp.out(f"discovered_motifs.{args.plot_format}"),
                        args.plot_dpi)]


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
