"""harmonise — collapse every module's output into one canonical store.

    merlin harmonise --results results/ --gff ann.gff3 -o results/ --prefix run1

Discovers whatever the modules wrote, joins it on ``locus_tag`` for features and
on ``(replicon, bin)`` for Hi-C bins, stores the many-to-one feature->bin map so
either unit can answer a cross-layer question, and records provenance.

This is what makes the answers consistent by construction rather than by
discipline: after this step, "DM genes at Hi-C boundaries" and "DM genes that
are DE" are two filters on one table instead of two joins computed in two
modules.
"""

from __future__ import annotations

import argparse
import glob
import os
from pathlib import Path

import numpy as np

from ..io import read_annotation
from ..logging_utils import LEDGER, get_logger, warn_once
from ..store import (BINS, FEATURES, MAP_FEATURE_BIN, MerlinStore, Provenance,
                     assign_features_to_bins)

logger = get_logger("harmonise")

PATTERNS = {
    "xam": ("xam/*by_feature*.tsv", "*by_feature*.tsv"),
    "dixam": ("dixam/*differential*.tsv", "*differential*.tsv"),
    "diem": ("diem/*integrated_table.tsv", "*integrated_table.tsv"),
    "mematch": ("mematch/*per_feature.tsv", "*per_feature.tsv"),
    "spacem": ("spacem/*oriter_stats.tsv", "*oriter_stats.tsv"),
    "hicam_bins": ("hicam/*hic_bins.tsv", "*hic_bins.tsv"),
    "hicam_boundaries": ("hicam/*hic_boundaries.tsv", "*hic_boundaries.tsv"),
}


def _find(root: Path, key: str) -> list[Path]:
    hits: list[Path] = []
    for pat in PATTERNS[key]:
        hits += [Path(p) for p in glob.glob(str(root / "**" / pat), recursive=True)]
    # a pooled table beats per-replicate ones; a combined table beats per-mod
    uniq = sorted(set(hits))
    if key == "xam":
        pooled = [p for p in uniq if "pooled" in p.name]
        if pooled:
            uniq = pooled
    return uniq


def _read(path: Path):
    import pandas as pd
    return pd.read_csv(path, sep="\t", comment="#", low_memory=False)


# --------------------------------------------------------------------------- #
def features_from_annotation(gff: str, feature_types=None):
    import pandas as pd
    ann = read_annotation(gff, feature_types=feature_types)
    return pd.DataFrame({
        "locus_tag": [f.locus_tag for f in ann.features],
        "replicon": [f.seqid for f in ann.features],
        "start": [f.start for f in ann.features],
        "end": [f.end for f in ann.features],
        "strand": [f.strand for f in ann.features],
        "type": [f.ftype for f in ann.features],
        "gene": [f.gene for f in ann.features],
        "product": [f.product for f in ann.features],
        "length": [f.length for f in ann.features],
    }).drop_duplicates("locus_tag").reset_index(drop=True)


def features_from_xam(paths):
    """Base feature table plus one methylation column set per input file."""
    import pandas as pd
    base = None
    for path in paths:
        df = _read(path)
        if "locus_tag" not in df.columns:
            continue
        sample = path.name.split(".")[1] if path.name.count(".") > 2 else "meth"
        core = (df[["locus_tag", "replicon", "feat_start", "feat_end", "strand",
                    "feature_type", "gene", "product", "feat_length_bp"]]
                .drop_duplicates("locus_tag")
                .rename(columns={"feat_start": "start", "feat_end": "end",
                                 "feature_type": "type",
                                 "feat_length_bp": "length"}))
        base = core if base is None else pd.concat(
            [base, core[~core["locus_tag"].isin(base["locus_tag"])]],
            ignore_index=True)
        wide = df.pivot_table(index="locus_tag", columns="mod_label",
                              values=[c for c in ("raw_count", "norm_count", "cpm",
                                                  "mean_frac_modified")
                                      if c in df.columns],
                              aggfunc="sum")
        wide.columns = [f"meth_{sample}_{b}_{a}" for a, b in wide.columns]
        base = base.merge(wide.reset_index(), on="locus_tag", how="left")
    return base


def add_dixam(base, paths):
    import pandas as pd
    for path in paths:
        df = _read(path)
        if "locus_tag" not in df.columns:
            continue
        values = [c for c in ("effect", "qvalue", "pvalue", "dispersion",
                              "delta_meth_level", "log2FC_cpm")
                  if c in df.columns]
        if not values:
            continue
        wide = df.pivot_table(index="locus_tag",
                              columns="mod_label" if "mod_label" in df else None,
                              values=values, aggfunc="first")
        wide.columns = ([f"dmeth_{b}_{a}" for a, b in wide.columns]
                        if isinstance(wide.columns, pd.MultiIndex)
                        else [f"dmeth_{c}" for c in wide.columns])
        base = base.merge(wide.reset_index(), on="locus_tag", how="left")
    return base


def add_diem(base, paths):
    for path in paths:
        df = _read(path)
        if "locus_tag" not in df.columns:
            continue
        keep = {c: f"expr_{c}" for c in ("log2FoldChange", "padj", "baseMean",
                                         "is_DE", "is_DM", "is_HM", "dual_hit")
                if c in df.columns}
        if not keep:
            continue
        base = base.merge(df[["locus_tag"] + list(keep)].rename(columns=keep)
                          .drop_duplicates("locus_tag"), on="locus_tag", how="left")
    return base


def add_mematch(base, paths):
    for path in paths:
        df = _read(path)
        if "locus_tag" not in df.columns:
            continue
        keep = {c: f"motif_{c}" for c in
                ("n_motif_occurrences", "motifs_present", "has_motif",
                 "n_methylated_on_motif", "frac_methylated_on_motif")
                if c in df.columns}
        if not keep:
            continue
        base = base.merge(df[["locus_tag"] + list(keep)].rename(columns=keep)
                          .drop_duplicates("locus_tag"), on="locus_tag", how="left")
    return base


def bins_from_hicam(paths):
    import pandas as pd
    frames = [_read(p) for p in paths]
    frames = [f for f in frames if "replicon" in f.columns and "start" in f.columns]
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    rename = {"pc1": "hic_pc1", "insulation": "hic_insulation",
              "compartment": "hic_compartment", "is_boundary": "hic_is_boundary"}
    return df.rename(columns={k: v for k, v in rename.items() if k in df.columns})


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin harmonise",
        description="Join every module's output into one canonical store.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--results", default=None, metavar="DIR",
                   help="Directory produced by 'merlin run' (searched recursively).")
    p.add_argument("--gff", default=None, metavar="FILE",
                   help="Annotation, used for feature coordinates when no xam "
                        "table is present.")
    p.add_argument("--xam", nargs="*", default=None, metavar="TSV")
    p.add_argument("--dixam", nargs="*", default=None, metavar="TSV")
    p.add_argument("--diem", nargs="*", default=None, metavar="TSV")
    p.add_argument("--mematch", nargs="*", default=None, metavar="TSV")
    p.add_argument("--hic-bins", nargs="*", default=None, metavar="TSV")
    p.add_argument("-o", "--outdir", required=True, metavar="DIR")
    p.add_argument("--prefix", default="merlin", metavar="STR")
    p.add_argument("--export-tsv", action="store_true",
                   help="Also write the joined tables as TSV alongside the store.")
    return p


def main(argv=None) -> int:
    import pandas as pd
    args = build_parser().parse_args(argv)
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    root = Path(args.results).resolve() if args.results else None

    def resolve(key, explicit):
        if explicit:
            return [Path(p) for p in explicit]
        return _find(root, key) if root else []

    xam = resolve("xam", args.xam)
    dixam = resolve("dixam", args.dixam)
    diem = resolve("diem", args.diem)
    mematch = resolve("mematch", args.mematch)
    hic_bins = resolve("hicam_bins", args.hic_bins)

    found = {"xam": xam, "dixam": dixam, "diem": diem, "mematch": mematch,
             "hic bins": hic_bins}
    for name, paths in found.items():
        logger.info("%-9s : %s", name,
                    ", ".join(p.name for p in paths) if paths else "not found")

    base = features_from_xam(xam) if xam else None
    if base is None and args.gff:
        base = features_from_annotation(args.gff)
    if base is None:
        raise SystemExit(
            "[FATAL] nothing to harmonise: no xam table found under --results and "
            "no --gff given. Run at least one module first, or pass --gff so the "
            "store has feature coordinates.")

    n0 = len(base)
    base = add_dixam(base, dixam)
    base = add_diem(base, diem)
    base = add_mematch(base, mematch)
    bins = bins_from_hicam(hic_bins)

    if len(base) != n0:
        warn_once(logger, "HARMONISE_ROW_GROWTH",
                  f"The feature table grew from {n0} to {len(base)} rows during "
                  f"joining — a layer contains duplicate locus_tags, so some "
                  f"features are now represented more than once.")

    f2b = np.full(len(base), -1, dtype=np.int64)
    if len(bins):
        f2b = assign_features_to_bins(base, bins)
        for col in ("hic_pc1", "hic_insulation", "hic_compartment",
                    "hic_is_boundary"):
            if col in bins.columns:
                vals = bins[col].to_numpy()
                out = np.full(len(base), np.nan, dtype=object
                              if vals.dtype.kind in "OUS" else float)
                ok = f2b >= 0
                out[ok] = vals[f2b[ok]]
                base[col] = out
        base["hic_bin"] = f2b

    prov = Provenance(command="merlin harmonise",
                      modules=[k for k, v in found.items() if v])
    for key, paths in found.items():
        for i, path in enumerate(paths):
            prov.add_input(f"{key}[{i}]", path)
    if args.gff:
        prov.add_input("annotation", args.gff)
    prov.warnings = [f"[{c}] {m}" for c, m in LEDGER.entries]

    store_path = outdir / f"{args.prefix}.merlin_store.h5"
    with MerlinStore(store_path, "w") as st:
        st.write_table(FEATURES, base)
        if len(bins):
            st.write_table(BINS, bins)
        st.write_map(MAP_FEATURE_BIN, f2b)
        st.write_provenance(prov)

    written = [store_path]
    if args.export_tsv:
        p = outdir / f"{args.prefix}.features.tsv"
        base.to_csv(p, sep="\t", index=False, float_format="%.6g")
        written.append(p)
        if len(bins):
            p = outdir / f"{args.prefix}.bins.tsv"
            bins.to_csv(p, sep="\t", index=False, float_format="%.6g")
            written.append(p)

    layers = sorted({c.split("_")[0] for c in base.columns
                     if c.split("_")[0] in ("meth", "dmeth", "expr", "motif", "hic")})
    print(f"\n=== harmonise ===")
    print(f"  features : {len(base):,} rows x {base.shape[1]} columns")
    print(f"  bins     : {len(bins):,} rows"
          + (f" x {bins.shape[1]} columns" if len(bins) else ""))
    print(f"  layers   : {', '.join(layers) if layers else 'none'}")
    if len(bins):
        print(f"  mapped   : {int((f2b >= 0).sum()):,} feature(s) placed in a Hi-C bin")
    print(f"  store    : {store_path}")
    for c, m in LEDGER.entries:
        print(f"  [warn {c}]")
    print()
    for p in written:
        logger.info("    %s", p)
    return 0


if __name__ == "__main__":
    from ._common import run_tool
    raise SystemExit(run_tool(main))
