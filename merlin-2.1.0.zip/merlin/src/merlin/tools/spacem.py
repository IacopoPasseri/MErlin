"""spacem — spatial distribution of methylation and features relative to oriC/ter.

Changes from the original ``spacem.py``
---------------------------------------
* **Density and level are no longer computed from the same set.**  The original
  built the "methylation density" track from every *assayed* position, so on
  bedMethyl input the track showed where the assay had coverage, not where
  methylation was.  Density now uses calls passing ``--min-frac``; the level
  gradient still uses every assayed call, because that is the set the gradient
  question is about.
* **KS results carry their D statistic.**  With 10^5-10^6 calls a KS p-value is
  ~0 for a deviation of no biological size; D is the number that says whether
  the distribution is actually non-uniform.
* **Weak GC skew aborts the ori->ter statistics for that replicon** instead of
  reporting confident-looking numbers built on a noise-driven origin.
* Motif membership uses a boolean array per replicon rather than a
  ``set[(seqid, pos)]`` over every covered base.
* Replicon labels are made filesystem-safe and unique, so two records both
  described as "plasmid" no longer overwrite each other's figures.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..genome import (bin_centers, bin_counts, co_oriented, gc_skew_bins,
                      ori_ter_coordinate, resolve_origins)
from ..io import read_motifs
from ..logging_utils import get_logger, warn_once
from ..model import mod_label
from ..motifs import find_motifs
from ..stats import StatTable, correlate, proportion_test, uniformity
from . import _common as C

logger = get_logger("spacem")


def parse_locus_overrides(s: str | None) -> dict[str, int]:
    out: dict[str, int] = {}
    if not s:
        return out
    for tok in s.split(","):
        tok = tok.strip()
        if ":" in tok:
            k, v = tok.rsplit(":", 1)
            try:
                out[k.strip()] = int(v)
            except ValueError:
                raise SystemExit(f"[FATAL] cannot parse position in --oric/--ter "
                                 f"token {tok!r}; expected 'seqid:pos'.") from None
    return out


def fold_enrichment(signed, nbins):
    """Histogram over [-1, 1] normalised per replichore so uniform reads ~1.0."""
    counts, edges = np.histogram(np.asarray(signed, float), bins=nbins, range=(-1, 1))
    centers = (edges[:-1] + edges[1:]) / 2
    fold = counts.astype(float)
    for mask in (centers < 0, centers >= 0):
        mu = fold[mask].mean() if fold[mask].size else 0.0
        fold[mask] = fold[mask] / mu if mu else np.nan
    return centers, fold


# --------------------------------------------------------------------------- #
def make_replicon_figure(path, label, length, skew, g_signed, m_signed,
                         level_pairs, co_pairs, nbins, dpi):
    plt = viz.lazy_pyplot()
    if plt is None:
        return None
    fig, axes = plt.subplots(2, 2, figsize=(13, 9))
    fig.suptitle(f"{label}  ({length / 1e6:.2f} Mb)   spatial organisation vs oriC/ter",
                 fontsize=14, fontweight="bold")

    ax = axes[0, 0]
    ax.plot(np.asarray(skew.centers) / 1e6, skew.cumulative, color="#34495e", lw=1.2)
    ax.axvline(skew.oric / 1e6, color=viz.PAL["ori"], lw=1.6, label="oriC")
    ax.axvline(skew.ter / 1e6, color=viz.PAL["ter"], lw=1.6, label="ter")
    ax.set_xlabel("genomic position (Mb)"); ax.set_ylabel("cumulative (G-C)")
    ax.set_title(f"(a) Cumulative GC skew  [{skew.source}, "
                 f"rel. amplitude {skew.relative_amplitude:.3f}]")
    ax.legend(frameon=False, fontsize=9)

    ax = axes[0, 1]
    gc_, gf = fold_enrichment(g_signed, nbins)
    mc_, mf = fold_enrichment(m_signed, nbins)
    ax.plot(gc_, gf, color="#2c3e50", lw=1.6, label="gene density")
    ax.plot(mc_, mf, color=viz.PAL["meth"], lw=1.6, label="methylation density")
    ax.axhline(1.0, color="#999", ls="--", lw=0.8)
    ax.axvline(0, color=viz.PAL["ori"], lw=1.4)
    for xt in (-1, 1):
        ax.axvline(xt, color=viz.PAL["ter"], lw=1.2, ls=":")
    ax.set_xlabel("ori->ter coordinate (signed; replichores)")
    ax.set_ylabel("density / replichore mean")
    ax.set_title("(b) Spatial density vs replication axis")
    ax.legend(frameon=False, fontsize=9)

    ax = axes[1, 0]
    if len(level_pairs):
        a = np.asarray([x for x, _ in level_pairs]); fr = np.asarray([f for _, f in level_pairs])
        edges = np.linspace(0, 1, max(nbins // 2, 2) + 1)
        idx = np.clip(np.digitize(a, edges) - 1, 0, len(edges) - 2)
        cen = (edges[:-1] + edges[1:]) / 2
        means = np.array([fr[idx == b].mean() if np.any(idx == b) else np.nan
                          for b in range(len(cen))])
        sems = np.array([fr[idx == b].std(ddof=1) / max(1, np.sqrt((idx == b).sum()))
                         if (idx == b).sum() > 1 else np.nan for b in range(len(cen))])
        ax.errorbar(cen, means, yerr=sems, fmt="o-", color="#8e44ad", ms=4, lw=1.3, capsize=2)
        ax.set_ylim(0, 1)
    else:
        viz.annotate_empty(ax, "no fraction-modified values\n(presence-only input)")
    ax.set_xlabel("distance from oriC (0=oriC, 1=ter; replichores folded)")
    ax.set_ylabel("mean fraction modified")
    ax.set_title("(c) Methylation level gradient")

    ax = axes[1, 1]
    if len(co_pairs):
        a = np.asarray([x for x, _ in co_pairs]); co = np.asarray([c for _, c in co_pairs])
        edges = np.linspace(0, 1, max(nbins // 2, 2) + 1)
        idx = np.clip(np.digitize(a, edges) - 1, 0, len(edges) - 2)
        cen = (edges[:-1] + edges[1:]) / 2
        frac = np.array([co[idx == b].mean() if np.any(idx == b) else np.nan
                         for b in range(len(cen))])
        ax.bar(cen, frac, width=0.9 / len(cen), color="#16a085")
        ax.axhline(0.5, color="#999", ls="--", lw=0.8)
        ax.set_ylim(0, 1)
    else:
        viz.annotate_empty(ax, "no stranded features")
    ax.set_xlabel("distance from oriC (0=oriC, 1=ter; replichores folded)")
    ax.set_ylabel("fraction co-oriented (leading strand)")
    ax.set_title("(d) Gene orientation vs replication")

    fig.tight_layout(rect=(0, 0, 1, 0.96))
    return viz.savefig(fig, path, dpi)


def make_motif_figure(path, label, motif_signed, nbins, dpi):
    plt = viz.lazy_pyplot()
    if plt is None:
        return None
    fig, ax = plt.subplots(figsize=(9, 4.6))
    cmap = plt.get_cmap("tab10")
    drawn = False
    for i, (m, vals) in enumerate(motif_signed.items()):
        if not len(vals):
            continue
        c, f = fold_enrichment(vals, nbins)
        ax.plot(c, f, lw=1.6, color=cmap(i % 10), label=f"{m} (n={len(vals)})")
        drawn = True
    if not drawn:
        viz.annotate_empty(ax, "no methylated motif sites")
    ax.axhline(1.0, color="#999", ls="--", lw=0.8)
    ax.axvline(0, color=viz.PAL["ori"], lw=1.2)
    ax.set_xlabel("ori->ter coordinate (signed)")
    ax.set_ylabel("methylated-on-motif density / mean")
    ax.set_title(f"{label}: methylation-on-motif spatial distribution")
    if drawn:
        ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    return viz.savefig(fig, path, dpi)


def make_circular_genome(path, inp, origins, meth_density, motif_hits,
                         binbp, dpi, include_motifs):
    plt = viz.lazy_pyplot()
    if plt is None:
        return None
    import math
    genome = inp.genome
    order = sorted(genome, key=lambda k: -len(genome[k]))
    rep_len = {k: len(genome[k]) for k in order}
    total = sum(rep_len.values()) or 1
    rep_color = {k: plt.get_cmap("tab10")(i % 10) for i, k in enumerate(order)}
    gap = 2 * math.pi * 0.02
    usable = 2 * math.pi - len(order) * gap
    layout, cur = {}, math.pi / 2
    for k in order:
        span = usable * rep_len[k] / total
        layout[k] = (cur, cur - span)
        cur -= span + gap

    feats_by = inp.annotation.by_seqid()

    def bars(positions, k):
        L, (t0, t1) = rep_len[k], layout[k]
        nb = max(2, int(math.ceil(L / binbp)))
        counts, edges = np.histogram(np.asarray(positions, float), bins=nb, range=(0, L))
        te = t0 + (edges / L) * (t1 - t0)
        return (te[:-1] + te[1:]) / 2, np.abs(np.diff(te)), counts

    per, gene_max, meth_max = {}, 1, 1
    for k in order:
        fs = feats_by.get(k, [])
        plus = [f.mid for f in fs if f.strand == "+"]
        minus = [f.mid for f in fs if f.strand == "-"]
        per[k] = dict(plus=bars(plus, k), minus=bars(minus, k),
                      meth=bars(meth_density.get(k, []), k))
        gene_max = max(gene_max, per[k]["plus"][2].max(initial=0),
                       per[k]["minus"][2].max(initial=0))
        meth_max = max(meth_max, per[k]["meth"][2].max(initial=0))
        nb = per[k]["meth"][2].size
        per[k]["skew"] = (per[k]["meth"][0], per[k]["meth"][1],
                          gc_skew_bins(genome[k], max(1, rep_len[k] // nb)))
    skew_absmax = max((np.abs(per[k]["skew"][2]).max(initial=0) for k in order),
                      default=1) or 1

    motifs_used = list(motif_hits) if include_motifs else []
    motif_bars, motif_max = {}, {}
    for m in motifs_used:
        motif_bars[m] = {}
        mm = 1
        for k in order:
            sel = motif_hits[m].for_seqid(k)
            cb = bars(motif_hits[m].anchor()[sel], k)
            motif_bars[m][k] = cb
            mm = max(mm, cb[2].max(initial=0))
        motif_max[m] = mm

    fig = plt.figure(figsize=(10.5, 10.5))
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_zero_location("E"); ax.set_theta_direction(1); ax.axis("off")
    R_GC, GC_AMP = 0.32, 0.12
    R_METH, H_METH = 0.48, 0.18
    R_GMINUS, H_G, R_GPLUS = 0.70, 0.12, 0.84
    R_IDEO, W_IDEO = 0.98, 0.05
    R_MARK = R_IDEO + W_IDEO + 0.01
    R_MOTIF0, motif_h = R_IDEO + W_IDEO + 0.09, 0.085
    outer = R_MOTIF0 + len(motifs_used) * (motif_h + 0.02) + 0.10

    ax.plot(np.linspace(0, 2 * math.pi, 400), [R_GC] * 400, color=viz.PAL["grid"], lw=0.5)
    for k in order:
        t0, t1 = layout[k]; tc = (t0 + t1) / 2
        ax.bar(tc, W_IDEO, width=abs(t1 - t0), bottom=R_IDEO, color=rep_color[k],
               edgecolor="white", lw=0.6, zorder=5)
        c, w, vals = per[k]["skew"]
        n = min(c.size, vals.size)
        ax.bar(c[:n], (np.clip(vals[:n], 0, None) / skew_absmax) * GC_AMP,
               width=w[:n], bottom=R_GC, color=viz.PAL["skew_pos"], lw=0, zorder=2)
        negh = (np.clip(-vals[:n], 0, None) / skew_absmax) * GC_AMP
        ax.bar(c[:n], negh, width=w[:n], bottom=R_GC - negh,
               color=viz.PAL["skew_neg"], lw=0, zorder=2)
        for key, bottom, height, col in (("meth", R_METH, H_METH, viz.PAL["meth"]),
                                         ("minus", R_GMINUS, H_G, "#95a5a6"),
                                         ("plus", R_GPLUS, H_G, "#2c3e50")):
            c, w, cnt = per[k][key]
            denom = meth_max if key == "meth" else gene_max
            ax.bar(c, (cnt / denom) * height, width=w, bottom=bottom, color=col,
                   lw=0, zorder=2)
        sp = origins.get(k)
        if sp is not None:
            for posm, colm, labm in ((sp.oric, viz.PAL["ori"], "ori"),
                                     (sp.ter, viz.PAL["ter"], "ter")):
                th = t0 + (posm / rep_len[k]) * (t1 - t0)
                ax.plot([th, th], [R_IDEO - 0.015, R_MARK + 0.03], color=colm,
                        lw=2.2, zorder=6)
                ax.text(th, R_MARK + 0.06, labm, color=colm, ha="center",
                        va="center", fontsize=7, fontweight="bold", zorder=6)
        for mi, m in enumerate(motifs_used):
            c, w, cnt = motif_bars[m][k]
            ax.bar(c, (cnt / motif_max[m]) * motif_h, width=w,
                   bottom=R_MOTIF0 + mi * (motif_h + 0.02),
                   color=plt.get_cmap("Set2")(mi % 8), lw=0, zorder=2)
        deg = math.degrees(tc) % 360
        ax.text(tc, outer + 0.02, f"{inp.label(k)}\n{rep_len[k] / 1e6:.2f} Mb",
                ha="left" if (deg < 90 or deg > 270) else "right", va="center",
                fontsize=9, color=rep_color[k], fontweight="bold")

    from matplotlib.patches import Patch
    legend = [Patch(facecolor="#2c3e50", label="genes (+ strand)"),
              Patch(facecolor="#95a5a6", label="genes (- strand)"),
              Patch(facecolor=viz.PAL["meth"], label="methylation density"),
              Patch(facecolor=viz.PAL["skew_pos"], label="GC skew (+)"),
              Patch(facecolor=viz.PAL["skew_neg"], label="GC skew (-)")]
    for mi, m in enumerate(motifs_used):
        legend.append(Patch(facecolor=plt.get_cmap("Set2")(mi % 8), label=f"motif {m}"))
    ax.set_ylim(0, outer + 0.12)
    ax.legend(handles=legend, loc="upper center", bbox_to_anchor=(0.5, -0.02),
              ncol=3, frameon=False, fontsize=8)
    ax.set_title("Genome-wide distribution of genes, methylation"
                 + (", motifs" if motifs_used else "") + "  (oriC/ter marked)",
                 fontsize=13, fontweight="bold", pad=24)
    return viz.savefig(fig, path, dpi)


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin spacem",
        description="Spatial distribution of methylation and features vs oriC/ter.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    C.add_annotation_args(p)
    C.add_reference_args(p, required=False)
    C.add_methylation_args(p)
    C.add_seqid_args(p)
    C.add_output_args(p, default_prefix="spacem")
    C.add_plot_args(p, default_on=False)
    g = p.add_argument_group("replication geometry")
    g.add_argument("--motifs", default=None, metavar="FILE",
                   help="Optional motif list; adds per-motif spatial tracks.")
    g.add_argument("--skew-window", type=int, default=10000, metavar="BP",
                   help="Window for cumulative GC-skew oriC/ter detection.")
    g.add_argument("--oric", default=None, metavar="SPEC",
                   help="Override oriC as 'seqid:pos[,seqid:pos]' (0-based).")
    g.add_argument("--ter", default=None, metavar="SPEC",
                   help="Override ter as 'seqid:pos[,seqid:pos]' (0-based).")
    g.add_argument("--min-skew-amplitude", type=float, default=0.02, metavar="X",
                   help="Minimum cumulative-skew swing / replicon length for the "
                        "oriC/ter call to be trusted.")
    g.add_argument("--skip-weak-skew", action="store_true",
                   help="Omit ori->ter statistics for replicons with weak skew "
                        "instead of reporting them flagged.")
    g.add_argument("--circular", action="store_true",
                   help="Also render the whole-genome circular figure.")
    g.add_argument("--no-motif-rings", action="store_true",
                   help="Do not add motif rings to the circular figure.")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    inp = C.load_inputs(args, need_reference=True)
    if inp.methyl is None or not len(inp.methyl):
        raise SystemExit("[FATAL] no methylation calls available.")

    assayed = inp.methyl
    min_frac = 0.5 if args.min_frac is None else args.min_frac
    methylated = assayed if assayed.presence_only else assayed.filter(min_frac=min_frac)
    logger.info("Density track uses %d methylated call(s); level gradient uses "
                "%d assayed call(s).", len(methylated), len(assayed))

    origins = resolve_origins(inp.genome, args.skew_window,
                              parse_locus_overrides(args.oric),
                              parse_locus_overrides(args.ter),
                              args.min_skew_amplitude)

    motif_list = read_motifs(args.motifs) if args.motifs else []
    motif_hits = find_motifs(inp.genome, motif_list) if motif_list else {}

    feats_by = inp.annotation.by_seqid()
    rep_order = sorted(inp.genome, key=lambda k: -len(inp.genome[k]))

    stats = StatTable()
    bin_rows = []
    written: list[Path] = []
    G = dict(co_k=0, co_n=0, gene_abs=[], meth_abs=[], level=[])

    for seqid in rep_order:
        seq = inp.genome[seqid]
        L = len(seq)
        label = inp.label(seqid)
        sp = origins[seqid]
        skip = sp.weak and args.skip_weak_skew
        feats = feats_by.get(seqid, [])

        mids = np.array([f.mid for f in feats], dtype=np.int64)
        strands = np.array([f.strand for f in feats], dtype=object)
        g_signed, g_abs, g_arm = (ori_ter_coordinate(mids, sp.oric, sp.ter, L)
                                  if mids.size else (np.array([]),) * 3)
        co = co_oriented(strands, g_arm) if mids.size else np.array([])
        co_known = co[np.isfinite(co)] if co.size else np.array([])

        dens_pos = methylated.positions(seqid)
        m_signed, m_abs, _ = (ori_ter_coordinate(dens_pos, sp.oric, sp.ter, L)
                              if dens_pos.size else (np.array([]),) * 3)

        sel = assayed.seqid == seqid
        a_pos, a_frac = assayed.pos[sel], assayed.frac[sel]
        good = np.isfinite(a_frac)
        level_pairs = []
        if good.any():
            _s, lvl_abs, _a = ori_ter_coordinate(a_pos[good], sp.oric, sp.ter, L)
            level_pairs = list(zip(lvl_abs.tolist(), a_frac[good].tolist()))

        gene_u = uniformity(g_abs) if len(g_abs) else uniformity([])
        meth_u = uniformity(m_abs) if len(m_abs) else uniformity([])
        prop = proportion_test(int(co_known.sum()), int(co_known.size))
        level_corr = correlate([x for x, _ in level_pairs], [f for _, f in level_pairs]) \
            if len(level_pairs) > 10 else None

        if not skip:
            G["co_k"] += int(co_known.sum()); G["co_n"] += int(co_known.size)
            G["gene_abs"] += list(g_abs); G["meth_abs"] += list(m_abs)
            G["level"] += level_pairs

        stats.add(
            replicon=seqid, label=label, length=L,
            oriC=sp.oric, ter=sp.ter, oriter_source=sp.source,
            skew_rel_amplitude=round(sp.relative_amplitude, 5),
            weak_skew=int(sp.weak), used_in_genome_row=int(not skip),
            n_features=len(feats), n_calls_assayed=int(sel.sum()),
            n_calls_methylated=int(dens_pos.size),
            gene_co_oriented_frac=prop.frac, gene_co_oriented_n=prop.n,
            gene_co_ci_low=prop.ci_low, gene_co_ci_high=prop.ci_high,
            gene_co_binom_p=prop.p,
            gene_mean_oridist=gene_u.mean, gene_uniform_KS_D=gene_u.ks_D,
            gene_uniform_KS_p=gene_u.ks_p, gene_spatial_bias=gene_u.bias,
            meth_mean_oridist=meth_u.mean, meth_uniform_KS_D=meth_u.ks_D,
            meth_uniform_KS_p=meth_u.ks_p, meth_spatial_bias=meth_u.bias,
            meth_level_spearman_rho=(level_corr.spearman_rho if level_corr else np.nan),
            meth_level_spearman_p=(level_corr.spearman_p if level_corr else np.nan),
            meth_level_n=(level_corr.n if level_corr else 0),
        )

        edges = np.linspace(-1, 1, args.bins + 1)
        gc_h, _ = np.histogram(g_signed, bins=edges) if len(g_signed) else (
            np.zeros(args.bins, int), None)
        mc_h, _ = np.histogram(m_signed, bins=edges) if len(m_signed) else (
            np.zeros(args.bins, int), None)
        cen = (edges[:-1] + edges[1:]) / 2
        for b in range(args.bins):
            bin_rows.append(dict(replicon=seqid, label=label,
                                 signed_center=round(float(cen[b]), 4),
                                 n_genes=int(gc_h[b]), n_meth=int(mc_h[b])))

        if args.plots:
            fig_path = inp.out(f"{viz.safe_name(label)}.spatial.{args.plot_format}")
            p = make_replicon_figure(fig_path, label, L, sp, g_signed, m_signed,
                                     level_pairs, list(zip(g_abs[np.isfinite(co)],
                                                           co[np.isfinite(co)]))
                                     if co.size else [],
                                     args.bins, args.plot_dpi)
            if p:
                written.append(p)
            if motif_hits:
                motif_signed = {}
                for m, hits in motif_hits.items():
                    mask = hits.covered_mask(seqid, L)
                    on = dens_pos[mask[dens_pos]] if dens_pos.size else dens_pos
                    s, _a, _ar = (ori_ter_coordinate(on, sp.oric, sp.ter, L)
                                  if on.size else (np.array([]),) * 3)
                    motif_signed[m] = s
                p = make_motif_figure(
                    inp.out(f"{viz.safe_name(label)}.motif_spatial.{args.plot_format}"),
                    label, motif_signed, args.bins, args.plot_dpi)
                if p:
                    written.append(p)

    # genome-wide row
    prop = proportion_test(G["co_k"], G["co_n"])
    gu, mu = uniformity(G["gene_abs"]), uniformity(G["meth_abs"])
    lc = correlate([x for x, _ in G["level"]], [f for _, f in G["level"]]) \
        if len(G["level"]) > 10 else None
    if len(rep_order) > 1:
        warn_once(logger, "SPACEM_POOLED",
                  "The GENOME row pools replichore coordinates across replicons. "
                  "A chromosome and a megaplasmid have different replication "
                  "geometries, so a pooled gradient can be driven by between-replicon "
                  "differences rather than by position within any replicon.")
    stats.add(
        replicon="GENOME", label="all replicons",
        length=sum(len(s) for s in inp.genome.values()),
        oriC="", ter="", oriter_source="", skew_rel_amplitude="",
        weak_skew="", used_in_genome_row="",
        n_features=len(inp.annotation), n_calls_assayed=len(assayed),
        n_calls_methylated=len(methylated),
        gene_co_oriented_frac=prop.frac, gene_co_oriented_n=prop.n,
        gene_co_ci_low=prop.ci_low, gene_co_ci_high=prop.ci_high,
        gene_co_binom_p=prop.p,
        gene_mean_oridist=gu.mean, gene_uniform_KS_D=gu.ks_D,
        gene_uniform_KS_p=gu.ks_p, gene_spatial_bias=gu.bias,
        meth_mean_oridist=mu.mean, meth_uniform_KS_D=mu.ks_D,
        meth_uniform_KS_p=mu.ks_p, meth_spatial_bias=mu.bias,
        meth_level_spearman_rho=(lc.spearman_rho if lc else np.nan),
        meth_level_spearman_p=(lc.spearman_p if lc else np.nan),
        meth_level_n=(lc.n if lc else 0))

    import pandas as pd
    spath = inp.out("oriter_stats.tsv")
    stats.write(spath); written.append(spath)
    bpath = inp.out("spatial_bins.tsv")
    pd.DataFrame(bin_rows).to_csv(bpath, sep="\t", index=False); written.append(bpath)

    if args.plots or args.circular:
        binbp = max(2000, sum(len(s) for s in inp.genome.values()) // 1500)
        dens = {k: methylated.positions(k) for k in rep_order}
        p = make_circular_genome(
            inp.out(f"circular_genome.{args.plot_format}"), inp, origins, dens,
            motif_hits, binbp, args.plot_dpi,
            include_motifs=bool(motif_hits) and not args.no_motif_rings)
        if p:
            written.append(p)

    print("\n=== spacem — oriC/ter spatial summary ===")
    print("  (KS D is the effect size; with 10^5 calls a small p means little)")
    for r in stats.rows:
        if r["replicon"] == "GENOME":
            continue
        rho = r["meth_level_spearman_rho"]
        rho_txt = f"{rho:+.3f}" if np.isfinite(rho) else "  n/a"
        co = r["gene_co_oriented_frac"]
        co_txt = (f"{co * 100:5.1f}% [{r['gene_co_ci_low'] * 100:.1f}-"
                  f"{r['gene_co_ci_high'] * 100:.1f}%]" if np.isfinite(co) else "n/a")
        print(f"  {r['label']:<14} oriC={r['oriC']:>9} ter={r['ter']:>9} | "
              f"co-oriented {co_txt} | meth KS D={r['meth_uniform_KS_D']:.3f} "
              f"(mean ori-dist {r['meth_mean_oridist']:.3f}) | level rho={rho_txt}")
        if r["weak_skew"]:
            print("                 [WEAK GC SKEW] the ori->ter statistics on this "
                  "row rest on an unreliable origin call")
    print(f"  stats -> {spath}\n")
    C.finalize(inp, written, args, "merlin spacem")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
