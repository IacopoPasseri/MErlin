"""mtase — which methyltransferase explains which motif (ROADMAP 3.2).

    # annotation + canonical table only
    merlin mtase -g ann.gff3 --fasta ref.fasta --motifs motifs.txt -o results/

    # with a knockout: the strongest statement MErlin can make
    merlin mtase -g ann.gff3 --fasta ref.fasta --motifs motifs.txt \\
        --methylation WT.bed --methylation2 dam_KO.bed \\
        --knockout-gene dam -o results/

Confidence is reported, not implied: "weak (canonical motif table only)" is
annotation transfer, "strong (knockout + annotation)" is evidence from this
genome.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..io import read_motifs
from ..logging_utils import get_logger
from ..motifs import find_motifs
from ..mtase import attribute, find_mtase_genes, motif_methylation_level, neighbours
from . import _common as C

logger = get_logger("mtase")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin mtase",
        description="Attribute motifs to methyltransferase genes.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    C.add_annotation_args(p)
    C.add_reference_args(p)
    C.add_methylation_args(p, required=False, second=True)
    C.add_seqid_args(p)
    g = p.add_argument_group("attribution")
    g.add_argument("--motifs", default=None, metavar="FILE",
                   help="Motif list. Without it, only the RM gene inventory is "
                        "produced.")
    g.add_argument("--knockout-gene", default="", metavar="NAME",
                   help="Gene deleted in the second condition, for the report.")
    g.add_argument("--loss-threshold", type=float, default=0.2, metavar="X",
                   help="Methylation drop that counts as loss in the knockout.")
    g.add_argument("--neighbour-window", type=int, default=5000, metavar="BP",
                   help="Window for reporting adjacent RM genes (systems cluster).")
    C.add_output_args(p, default_prefix="mtase")
    return p


def main(argv=None) -> int:
    import pandas as pd
    args = build_parser().parse_args(argv)
    inp = C.load_inputs(args, need_reference=bool(args.motifs),
                        second_methylation=True)

    mtases = find_mtase_genes(inp.annotation)
    gene_rows = [dict(locus_tag=g.locus_tag, gene=g.gene, role=g.role,
                      replicon=g.replicon, start=g.start, end=g.end,
                      strand=g.strand, product=g.product,
                      adjacent_rm_genes=",".join(
                          neighbours(g, mtases, args.neighbour_window)))
                 for g in mtases]
    written: list[Path] = []
    path = inp.out("rm_genes.tsv")
    pd.DataFrame(gene_rows).to_csv(path, sep="\t", index=False)
    written.append(path)

    attributions = []
    if args.motifs and inp.genome:
        motifs = read_motifs(args.motifs)
        names = [m for m, _ in motifs]
        hits = find_motifs(inp.genome, motifs)

        effects: dict[str, float] = {}
        levels: dict[str, tuple[float, float]] = {}
        if inp.methyl is not None and inp.methyl2 is not None:
            for m in names:
                a = motif_methylation_level(inp.methyl, hits, m, inp.genome)
                b = motif_methylation_level(inp.methyl2, hits, m, inp.genome)
                levels[m] = (a, b)
                effects[m] = b - a
        attributions = attribute(names, inp.annotation, effects or None,
                                 args.knockout_gene)

        rows = []
        for att in attributions:
            a, b = levels.get(att.motif, (np.nan, np.nan))
            rows.append(dict(
                motif=att.motif, confidence=att.confidence,
                known_enzyme=att.known_enzyme,
                known_modification=att.known_modification,
                known_note=att.known_note,
                candidate_genes=",".join(att.candidate_genes),
                n_occurrences=len(hits.get(att.motif, [])),
                level_condition1=a, level_condition2=b,
                knockout_effect=att.knockout_effect,
                knockout_gene=att.knockout_gene,
                evidence="; ".join(att.evidence)))
        path = inp.out("motif_attribution.tsv")
        pd.DataFrame(rows).to_csv(path, sep="\t", index=False, float_format="%.6g")
        written.append(path)

    print("\n=== mtase ===")
    print(f"  restriction-modification genes : {len(mtases)}")
    for g in mtases[:12]:
        print(f"    {g.locus_tag:<14}{g.role:<11}{(g.gene or '-'):<8}"
              f"{g.product[:52]}")
    if len(mtases) > 12:
        print(f"    ... {len(mtases) - 12} more in rm_genes.tsv")
    if attributions:
        print("\n  motif attribution")
        for att in attributions:
            ko = ("" if not np.isfinite(att.knockout_effect)
                  else f"  [knockout effect {att.knockout_effect:+.3f}]")
            print(f"    {att.motif:<16}{att.confidence}{ko}")
            for line in att.evidence:
                print(f"        - {line}")
        print("\n  'weak' means the call rests on a name in an annotation or on a "
              "canonical motif table.\n  Only a knockout makes it evidence from "
              "this genome.")
    print()
    C.finalize(inp, written, args, "merlin mtase")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
