"""phase — read-level methylation: hemimethylation and epigenetic bistability.

    merlin phase --modbam calls.bam -g ann.gff3 --fasta ref.fasta \\
        --motifs motifs.txt -o results/ --plots

Answers the three questions a per-position bedMethyl cannot:

* is this GATC methylated on one strand only (hemimethylated)?
* is this locus methylated in *some cells* rather than half-methylated in all
  of them (bistable)?
* do nearby sites on the same molecule agree (cis co-methylation)?

Requires an aligned BAM with ``MM``/``ML`` tags — what dorado and modkit already
produce on the way to a bedMethyl.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..io import read_motifs
from ..logging_utils import get_logger, warn_once
from ..motifs import find_motifs
from ..reads import (bistability_table, cis_comethylation, motif_strand_pairs,
                     read_fraction_per_region, read_modbam, site_table,
                     hemimethylation)
from . import _common as C

logger = get_logger("phase")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin phase",
        description="Read-level methylation from a modBAM.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    g = p.add_argument_group("read input")
    g.add_argument("--modbam", required=True, metavar="FILE",
                   help="Aligned BAM with MM/ML modification tags.")
    g.add_argument("--region", default=None, metavar="STR",
                   help="Restrict to a region, e.g. 'chr:1-100000'.")
    g.add_argument("--min-mapq", type=int, default=20)
    g.add_argument("--high", type=float, default=0.8, metavar="P",
                   help="ML probability at or above which a call is methylated.")
    g.add_argument("--low", type=float, default=0.2, metavar="P",
                   help="ML probability at or below which a call is unmethylated. "
                        "Calls in between are dropped, not forced to a side.")
    g.add_argument("--max-reads", type=int, default=None)
    g.add_argument("--min-reads", type=int, default=10, metavar="N",
                   help="Reads needed at a site before it is reported.")

    C.add_annotation_args(p, required=False)
    C.add_reference_args(p, required=False)
    C.add_seqid_args(p)
    a = p.add_argument_group("analysis")
    a.add_argument("--motifs", default=None, metavar="FILE",
                   help="Motif list; palindromic motifs with an offset enable the "
                        "hemimethylation analysis.")
    a.add_argument("--mod-codes", default=None, metavar="CODES")
    a.add_argument("--max-distance", type=int, default=2000, metavar="BP",
                   help="Maximum separation for the cis co-methylation analysis.")
    a.add_argument("--min-sites-per-read", type=int, default=3, metavar="N",
                   help="Sites a read must cover in a region to contribute a "
                        "per-read fraction.")
    C.add_output_args(p, default_prefix="phase")
    C.add_plot_args(p, default_on=False)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    import pandas as pd

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    prefix = C.resolve_prefix(args)

    def out(suffix):
        return outdir / f"{prefix}.{suffix}"

    keep = set(args.mod_codes.split(",")) if args.mod_codes else None
    calls = read_modbam(args.modbam, region=args.region, min_mapq=args.min_mapq,
                        high=args.high, low=args.low, max_reads=args.max_reads,
                        keep_codes=keep)
    if calls.n_reads == 0:
        raise SystemExit(
            "[FATAL] no usable reads. Check that the BAM is aligned, carries "
            "MM/ML tags, and that --min-mapq is not excluding everything.")

    written: list[Path] = []
    sites = site_table(calls)
    sites = sites[sites["n_reads"] >= args.min_reads].reset_index(drop=True)
    path = out("read_sites.tsv")
    sites.to_csv(path, sep="\t", index=False, float_format="%.6g")
    written.append(path)

    # ---- hemimethylation ------------------------------------------------
    hemi = pd.DataFrame()
    genome = None
    if args.motifs and (args.fasta or args.gff):
        inp = C.load_inputs(args, need_annotation=bool(args.gff),
                            need_reference=False)
        genome = inp.genome
        if genome:
            motifs = read_motifs(args.motifs)
            hits = find_motifs(genome, motifs)
            for motif, _off in motifs:
                pairs = motif_strand_pairs(hits, motif)
                if not pairs:
                    continue
                sub = hemimethylation(sites, pairs, min_reads=args.min_reads)
                if len(sub):
                    sub.insert(0, "motif", motif)
                    hemi = pd.concat([hemi, sub], ignore_index=True)
        if hemi.empty:
            warn_once(logger, "PHASE_NO_HEMI",
                      "No palindromic motif with a modified-base offset produced "
                      "paired strand positions with enough coverage, so the "
                      "hemimethylation analysis is empty. Give the motif an offset "
                      "(e.g. 'GATC<TAB>1') and check coverage.")
    if len(hemi):
        path = out("hemimethylation.tsv")
        hemi.to_csv(path, sep="\t", index=False, float_format="%.6g")
        written.append(path)

    # ---- bistability ----------------------------------------------------
    bist = pd.DataFrame()
    if args.gff:
        inp2 = C.load_inputs(args, need_annotation=True, need_reference=False)
        fracs = read_fraction_per_region(calls, inp2.annotation.features,
                                         min_sites=args.min_sites_per_read)
        bist = bistability_table(fracs)
        if len(bist):
            path = out("bistability.tsv")
            bist.to_csv(path, sep="\t", index=False, float_format="%.6g")
            written.append(path)
        else:
            warn_once(logger, "PHASE_NO_BISTABILITY",
                      "No region had at least 8 reads covering "
                      f"{args.min_sites_per_read}+ sites, so no bistability could "
                      f"be scored. This needs long reads spanning several sites.")

    # ---- cis co-methylation ---------------------------------------------
    cis = cis_comethylation(calls, max_distance=args.max_distance)
    if len(cis):
        path = out("cis_comethylation.tsv")
        cis.to_csv(path, sep="\t", index=False, float_format="%.6g")
        written.append(path)

    if args.plots:
        written += _plots(sites, hemi, bist, cis, outdir, prefix, args)

    print("\n=== phase (read-level) ===")
    print(f"  reads used            : {calls.n_reads:,}")
    print(f"  sites with >= {args.min_reads} reads : {len(sites):,}")
    if len(sites):
        print(f"  median site fraction  : {np.nanmedian(sites['frac']):.3f}")
    if len(hemi):
        n_hemi = int(hemi["hemi_like"].sum())
        print(f"  paired motif sites    : {len(hemi):,}  "
              f"({n_hemi:,} with strand asymmetry >= 0.5)")
        print(f"  median asymmetry      : {np.nanmedian(hemi['asymmetry']):.3f}")
        print("  Strand asymmetry here is a POPULATION measure: a short read "
              "covers one strand, so\n  per-molecule hemimethylation needs duplex "
              "data.")
    if len(bist):
        print(f"  regions scored        : {len(bist):,}  "
              f"({int(bist['bimodal'].sum()):,} bimodal at BC > 0.556)")
        top = bist.head(5)
        for _, r in top.iterrows():
            print(f"    {r['feature']:<18} BC={r['bimodality_coefficient']:.3f}  "
                  f"mean={r['mean_frac']:.2f}  reads={int(r['n_reads'])}")
    if len(cis):
        near = cis.iloc[0]
        print(f"  cis co-methylation    : phi={near['phi']:+.3f} at "
              f"{int(near['dist_min'])}-{int(near['dist_max'])} bp "
              f"({int(near['n_pairs']):,} pairs)")
    print()
    for p in written:
        logger.info("    %s", p)
    return 0


def _plots(sites, hemi, bist, cis, outdir, prefix, args):
    plt = viz.lazy_pyplot()
    if plt is None:
        return []
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
    ax = axes[0]
    if len(sites):
        ax.hist(sites["frac"].to_numpy(dtype=float), bins=40,
                color=viz.PAL["meth"], alpha=0.85)
        ax.set_xlabel("per-site methylated fraction"); ax.set_ylabel("sites")
        ax.set_title("Site-level methylation")
    else:
        viz.annotate_empty(ax)

    ax = axes[1]
    if len(hemi):
        ax.scatter(hemi["plus_frac"], hemi["minus_frac"], s=10,
                   c=hemi["asymmetry"], cmap="magma_r", alpha=0.8, linewidths=0)
        ax.plot([0, 1], [0, 1], ls="--", lw=0.8, color="#555")
        ax.set_xlabel("+ strand fraction"); ax.set_ylabel("- strand fraction")
        ax.set_title("Strand symmetry at paired motif sites\n"
                     "(off-diagonal = hemimethylated population)", fontsize=10)
    else:
        viz.annotate_empty(ax, "no paired motif sites")

    ax = axes[2]
    if len(cis):
        mid = (cis["dist_min"] + cis["dist_max"]) / 2
        ax.semilogx(mid, cis["phi"], "o-", color=viz.PAL["dual"], lw=1.4)
        ax.axhline(0, color="#555", lw=0.6, ls="--")
        ax.set_xlabel("separation on the same read (bp)")
        ax.set_ylabel("phi (agreement between sites)")
        ax.set_title("Cis co-methylation")
    else:
        viz.annotate_empty(ax, "not enough site pairs per read")
    fig.tight_layout()
    written = [viz.savefig(fig, outdir / f"{prefix}.read_level.{args.plot_format}",
                           args.plot_dpi)]

    if len(bist):
        fig, ax = plt.subplots(figsize=(7, 4.6))
        bc = bist["bimodality_coefficient"].to_numpy(dtype=float)
        ax.hist(bc[np.isfinite(bc)], bins=30, color=viz.PAL["dual"], alpha=0.85)
        ax.axvline(5 / 9, color=viz.PAL["DE"], ls="--", lw=1.2,
                   label="bimodality threshold (5/9)")
        ax.set_xlabel("Sarle bimodality coefficient of per-read fractions")
        ax.set_ylabel("regions"); ax.legend(frameon=False, fontsize=9)
        ax.set_title("Epigenetic bistability across regions")
        fig.tight_layout()
        written.append(viz.savefig(
            fig, outdir / f"{prefix}.bistability.{args.plot_format}", args.plot_dpi))
    return written


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
