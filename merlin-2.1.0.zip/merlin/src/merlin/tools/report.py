"""report — one self-contained HTML report for a whole MErlin run (ROADMAP 2.3).

    merlin report --results results/ -o results/ --prefix run1

A 2.0 run left ~30 files across seven directories and the reader assembled the
story.  This walks the results directory, embeds every figure as a data URI,
renders the key tables, and puts the warning ledger and the provenance block
where they cannot be skipped: at the top, before any number.

The output is a single HTML file with no external assets, so it survives being
emailed, attached to a thesis chapter, or opened on a machine with no network.
"""

from __future__ import annotations

import argparse
import base64
import glob
import html
import json
from pathlib import Path

from ..logging_utils import get_logger
from ..store import FEATURES, MerlinStore

logger = get_logger("report")

MODULE_ORDER = ["preflight", "xam", "dixam", "spacem", "mematch", "diem",
                "hicam", "harmonise", "evidence", "phase", "mtase", "discover",
                "roundtable"]

MODULE_BLURB = {
    "xam": "Methylation per annotated feature.",
    "dixam": "Differential methylation between conditions.",
    "spacem": "Spatial distribution relative to oriC and ter.",
    "mematch": "Association between methylation and DNA motifs.",
    "diem": "Expression crossed with methylation.",
    "hicam": "3D genome organisation crossed with the other layers.",
    "evidence": "Genes ranked by combined evidence across layers.",
    "phase": "Read-level methylation: hemimethylation and bistability.",
    "mtase": "Which methyltransferase explains which motif.",
    "discover": "Motifs discovered from the data rather than supplied.",
    "roundtable": "Circular genome overview.",
}

CSS = """
:root{--fg:#1d2733;--muted:#6b7785;--line:#e3e8ee;--bg:#fbfcfd;--accent:#2c6fbb;
--warn:#b7791f;--warnbg:#fffaf0;--ok:#1e8449}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif}
.wrap{max-width:1100px;margin:0 auto;padding:40px 28px 80px}
h1{font-size:30px;margin:0 0 4px;letter-spacing:-.02em}
h2{font-size:21px;margin:44px 0 6px;padding-bottom:6px;border-bottom:1px solid var(--line)}
h3{font-size:16px;margin:26px 0 6px;color:var(--muted);font-weight:600}
.sub{color:var(--muted);margin:0 0 28px}
.card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:18px 20px;margin:14px 0}
.warn{background:var(--warnbg);border-color:#f0e0c0}
.warn h2,.warn h3{border:0;color:var(--warn)}
.code{font:12.5px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;
white-space:pre-wrap;color:#33404d;background:#f6f8fa;border-radius:6px;padding:12px;overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{text-align:left;padding:6px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
th{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.04em}
tbody tr:hover{background:#f6f9fc}
.scroll{overflow-x:auto;max-height:460px;overflow-y:auto}
img{max-width:100%;height:auto;border:1px solid var(--line);border-radius:8px;background:#fff}
.figs{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px}
.cap{color:var(--muted);font-size:12.5px;margin:6px 0 0}
.pill{display:inline-block;padding:2px 9px;border-radius:999px;font-size:12px;
background:#eef3f9;color:var(--accent);margin-right:6px}
.pill.warn{background:#fdf1dc;color:var(--warn)}
.pill.ok{background:#e8f6ee;color:var(--ok)}
.kv{display:grid;grid-template-columns:180px 1fr;gap:4px 14px;font-size:13.5px}
.kv div:nth-child(odd){color:var(--muted)}
nav a{color:var(--accent);text-decoration:none;margin-right:14px;font-size:13.5px}
footer{color:var(--muted);font-size:12.5px;margin-top:50px;border-top:1px solid var(--line);padding-top:14px}
"""


def _b64(path: Path) -> str:
    mime = {"png": "image/png", "svg": "image/svg+xml", "jpg": "image/jpeg",
            "jpeg": "image/jpeg", "gif": "image/gif"}.get(
        path.suffix.lstrip(".").lower())
    if mime is None:
        return ""
    return (f"data:{mime};base64,"
            + base64.b64encode(path.read_bytes()).decode("ascii"))


def _table_html(path: Path, max_rows: int = 60) -> str:
    import pandas as pd
    try:
        df = pd.read_csv(path, sep="\t", comment="#", nrows=max_rows + 1,
                         low_memory=False)
    except Exception:                              # noqa: BLE001
        return ""
    if df.empty:
        return "<p class='cap'>empty table</p>"
    truncated = len(df) > max_rows
    df = df.head(max_rows)
    body = df.to_html(index=False, float_format=lambda v: f"{v:.4g}",
                      border=0, na_rep="")
    note = (f"<p class='cap'>first {max_rows} rows of {path.name}</p>"
            if truncated else f"<p class='cap'>{path.name}</p>")
    return f"<div class='scroll'>{body}</div>{note}"


def _module_of(path: Path, root: Path) -> str:
    rel = path.relative_to(root)
    if len(rel.parts) > 1 and rel.parts[0] in MODULE_ORDER:
        return rel.parts[0]
    for name in MODULE_ORDER:
        if name in path.name:
            return name
    return "other"


def collect(root: Path) -> dict[str, dict[str, list[Path]]]:
    out: dict[str, dict[str, list[Path]]] = {}
    for pattern, kind in ((["*.png", "*.svg"], "figures"),
                          (["*.tsv"], "tables"),
                          (["*.txt"], "text")):
        for pat in pattern:
            for p in sorted(glob.glob(str(root / "**" / pat), recursive=True)):
                path = Path(p)
                mod = _module_of(path, root)
                out.setdefault(mod, {}).setdefault(kind, []).append(path)
    return out


# --------------------------------------------------------------------------- #
def render(root: Path, title: str, store_path: Path | None,
           max_figures: int, max_rows: int) -> str:
    found = collect(root)
    order = [m for m in MODULE_ORDER if m in found] + \
            [m for m in sorted(found) if m not in MODULE_ORDER]

    parts = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'>",
             f"<meta name='viewport' content='width=device-width,initial-scale=1'>",
             f"<title>{html.escape(title)}</title><style>{CSS}</style></head><body>",
             "<div class='wrap'>",
             f"<h1>{html.escape(title)}</h1>",
             "<p class='sub'>MErlin — methylation, expression and 3D genome "
             "organisation. Every number below comes from a module output file; "
             "the file is named next to it.</p>",
             "<nav>" + " ".join(f"<a href='#{m}'>{m}</a>" for m in order) + "</nav>"]

    # ---- warnings first -------------------------------------------------
    warn_files = sorted(glob.glob(str(root / "**" / "*warnings.txt"), recursive=True))
    entries: list[str] = []
    for wf in warn_files:
        text = Path(wf).read_text(encoding="utf-8", errors="replace")
        for line in text.splitlines():
            if line.startswith("[") and line not in entries:
                entries.append(line)
    if entries:
        parts.append("<div class='card warn'><h3>Data-quality warnings "
                     f"({len(entries)})</h3><div class='code'>"
                     + html.escape("\n".join(entries)) + "</div>"
                     "<p class='cap'>Read these before the results. Each one "
                     "describes a condition that changes what the numbers can "
                     "support.</p></div>")
    else:
        parts.append("<div class='card'><span class='pill ok'>no data-quality "
                     "warnings recorded</span></div>")

    # ---- provenance -----------------------------------------------------
    if store_path and Path(store_path).exists():
        try:
            with MerlinStore(store_path, "r") as st:
                prov = st.provenance
                feat = st.read_table(FEATURES)
            kv = ["<div class='kv'>",
                  f"<div>MErlin version</div><div>{html.escape(prov.merlin_version)}</div>",
                  f"<div>store</div><div>{html.escape(str(store_path))}</div>",
                  f"<div>features</div><div>{len(feat):,} rows x {feat.shape[1]} columns</div>"]
            for role, path in list(prov.inputs.items())[:12]:
                digest = prov.checksums.get(role, "")
                kv.append(f"<div>{html.escape(role)}</div><div>{html.escape(path)}"
                          + (f" <span class='pill'>sha256:{digest}</span>" if digest
                             else "") + "</div>")
            if prov.thresholds:
                kv.append("<div>thresholds</div><div>"
                          + html.escape(json.dumps(prov.thresholds)) + "</div>")
            kv.append("</div>")
            parts.append("<div class='card'><h3>Provenance</h3>" + "".join(kv)
                         + "</div>")
        except Exception as exc:                    # noqa: BLE001
            logger.warning("could not read the store: %s", exc)

    # ---- run plan -------------------------------------------------------
    plan = root / "merlin_run_report.txt"
    if plan.exists():
        parts.append("<div class='card'><h3>What ran</h3><div class='code'>"
                     + html.escape(plan.read_text(encoding="utf-8")) + "</div></div>")

    # ---- per module -----------------------------------------------------
    for mod in order:
        blurb = MODULE_BLURB.get(mod, "")
        parts.append(f"<h2 id='{mod}'>{html.escape(mod)}</h2>")
        if blurb:
            parts.append(f"<p class='sub'>{html.escape(blurb)}</p>")
        block = found[mod]

        for txt in block.get("text", []):
            if "warnings" in txt.name:
                continue
            content = txt.read_text(encoding="utf-8", errors="replace")
            if content.strip():
                parts.append("<div class='card'><h3>"
                             + html.escape(txt.name) + "</h3><div class='code'>"
                             + html.escape(content[:20000]) + "</div></div>")

        figs = block.get("figures", [])[:max_figures]
        if figs:
            parts.append("<div class='figs'>")
            for fig in figs:
                src = _b64(fig)
                if not src:
                    continue
                parts.append(f"<figure style='margin:0'><img src='{src}' "
                             f"alt='{html.escape(fig.name)}'>"
                             f"<figcaption class='cap'>{html.escape(fig.name)}"
                             f"</figcaption></figure>")
            parts.append("</div>")
            if len(block.get("figures", [])) > max_figures:
                parts.append(f"<p class='cap'>{len(block['figures']) - max_figures} "
                             f"further figure(s) not embedded (--max-figures).</p>")

        for tbl in block.get("tables", [])[:6]:
            rendered = _table_html(tbl, max_rows)
            if rendered:
                parts.append(f"<div class='card'><h3>{html.escape(tbl.name)}</h3>"
                             + rendered + "</div>")

    parts.append("<footer>Association, not causation: MErlin quantifies "
                 "co-variation between layers. Narrowing a hypothesis is not "
                 "testing it — a knockout, a point mutation of the methylation "
                 "site, or an MTase complementation does that.</footer>")
    parts.append("</div></body></html>")
    return "\n".join(parts)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin report",
        description="Render one self-contained HTML report for a run.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--results", required=True, metavar="DIR",
                   help="Directory produced by 'merlin run' (searched recursively).")
    p.add_argument("--store", default=None, metavar="FILE",
                   help="Merlin store, for the provenance block.")
    p.add_argument("--title", default=None)
    p.add_argument("--max-figures", type=int, default=8,
                   help="Figures embedded per module.")
    p.add_argument("--max-rows", type=int, default=40,
                   help="Table rows rendered per file.")
    p.add_argument("-o", "--outdir", required=True, metavar="DIR")
    p.add_argument("--prefix", default="merlin", metavar="STR")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    root = Path(args.results).resolve()
    if not root.is_dir():
        raise SystemExit(f"[FATAL] --results {root} is not a directory.")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    store = args.store
    if store is None:
        hits = glob.glob(str(root / "**" / "*merlin_store.h5"), recursive=True)
        store = hits[0] if hits else None

    title = args.title or f"MErlin report — {root.name}"
    html_text = render(root, title, Path(store) if store else None,
                       args.max_figures, args.max_rows)
    path = outdir / f"{args.prefix}.report.html"
    path.write_text(html_text, encoding="utf-8")
    size_kb = path.stat().st_size / 1024
    print(f"\n=== report ===\n  {path}  ({size_kb:,.0f} kB, self-contained)\n")
    logger.info("    %s", path)
    return 0


if __name__ == "__main__":
    from ._common import run_tool
    raise SystemExit(run_tool(main))
