"""xam — cross-reference methylation basecalling with a genome annotation.

For every annotated feature and every modification type, report how many
methylated positions fall inside it and how that normalises to feature length
and to library size.

Changes from the original ``xam.py``
------------------------------------
* Overlap counting is vectorised (see :mod:`merlin.intervals`); the old inner
  loop copied the tail of the position list once per feature per modification.
* Unstranded (``.``) calls now count towards stranded features instead of being
  silently dropped — a methylation GFF3 with a ``.`` strand column used to yield
  all-zero counts with no error.
* Full modkit bedMethyl is accepted directly, with ``--min-frac`` applied here
  rather than assumed to have happened upstream.  Feeding an unfiltered
  bedMethyl to the old tool counted every *assayed* position, including 0 %
  modified ones, as methylated.
* ``--include-zero`` emits features with no methylation, which downstream
  ``diem`` needs in order to avoid conditioning its statistics on the presence
  of methylation.
* Adds ``cpm`` (library-size normalised) and ``mean_frac_modified`` columns.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..genome import replicon_lengths
from ..intervals import FeatureIndex, count_per_feature, mean_frac_per_feature
from ..logging_utils import get_logger
from ..model import mod_description, mod_label
from ..regions import (add_region_args, derive_regions, infer_operons,
                       operon_map, parse_region_specs)
from . import _common as C

logger = get_logger("xam")

def _pool(samples):
    """Concatenate replicate call sets for a pooled per-feature table."""
    if len(samples) == 1:
        return samples[0]
    import numpy as _np
    from ..model import MethylSet
    return MethylSet(
        _np.concatenate([s.seqid for s in samples]),
        _np.concatenate([s.pos for s in samples]),
        _np.concatenate([s.mod for s in samples]),
        _np.concatenate([s.strand for s in samples]),
        _np.concatenate([s.cov for s in samples]),
        _np.concatenate([s.frac for s in samples]),
        source="+".join(s.source for s in samples), fmt=samples[0].fmt)


COLUMNS = ["replicon", "feature_type", "feat_start", "feat_end", "strand",
           "feat_length_bp", "locus_tag", "gene", "product",
           "mod_code", "mod_label", "mod_description",
           "raw_count", "norm_count", "calls_per_kb", "cpm", "mean_frac_modified"]


# --------------------------------------------------------------------------- #
def build_table(inp: C.Inputs, ignore_strand: bool, include_zero: bool,
                min_frac: float | None, methyl=None, operons=None):
    import pandas as pd

    ann = inp.annotation
    methyl = methyl if methyl is not None else inp.methyl
    meth_for_counts = methyl if min_frac is None else methyl.filter(min_frac=min_frac)
    index = FeatureIndex(ann)
    mods = sorted(meth_for_counts.mod_codes or methyl.mod_codes)

    counts = count_per_feature(index, meth_for_counts, mods, ignore_strand)
    lib_total = max(len(meth_for_counts), 1)

    feats = ann.features
    base = pd.DataFrame({
        "replicon": [f.seqid for f in feats],
        "feature_type": [f.ftype for f in feats],
        "feat_start": [f.start for f in feats],
        "feat_end": [f.end for f in feats],
        "strand": [f.strand for f in feats],
        "feat_length_bp": [f.length for f in feats],
        "locus_tag": [f.locus_tag for f in feats],
        "gene": [f.gene for f in feats],
        "product": [f.product for f in feats],
    })
    if operons:
        base["operon"] = [operons.get(f.locus_tag, ("", 0, ""))[0] for f in feats]
        base["operon_position"] = [operons.get(f.locus_tag, ("", 0, ""))[1]
                                   for f in feats]
        base["operon_leader"] = [operons.get(f.locus_tag, ("", 0, ""))[2]
                                 for f in feats]
    length = base["feat_length_bp"].to_numpy(dtype=float)

    frames = []
    for j, mod in enumerate(mods):
        raw = counts[:, j]
        keep = np.ones(len(raw), dtype=bool) if include_zero else raw > 0
        if not keep.any():
            continue
        sub = base.loc[keep].copy()
        r = raw[keep].astype(float)
        ln = np.maximum(length[keep], 1.0)
        sub["mod_code"] = mod
        sub["mod_label"] = mod_label(mod)
        sub["mod_description"] = mod_description(mod)
        sub["raw_count"] = raw[keep]
        sub["norm_count"] = r / ln
        sub["calls_per_kb"] = 1000.0 * r / ln
        sub["cpm"] = 1e6 * r / lib_total
        mf = mean_frac_per_feature(index, meth_for_counts, mod, ignore_strand)
        sub["mean_frac_modified"] = mf[keep]
        frames.append(sub)

    if not frames:
        return pd.DataFrame(columns=COLUMNS), mods, index, meth_for_counts
    extra = [c for c in ("operon", "operon_position", "operon_leader")
             if c in frames[0].columns]
    table = pd.concat(frames, ignore_index=True)[COLUMNS + extra]
    table = table.sort_values(["replicon", "feat_start", "mod_code"],
                              kind="stable").reset_index(drop=True)
    return table, mods, index, meth_for_counts


def write_tables(table, mods, inp: C.Inputs, split: bool, tag: str = "") -> list[Path]:
    written = []
    stem = f"{tag}." if tag else ""
    if split:
        for mod in mods:
            sub = table[table["mod_code"] == mod]
            path = inp.out(f"{stem}by_feature.{mod_label(mod)}.tsv")
            sub.to_csv(path, sep="\t", index=False, float_format="%.8g")
            logger.info("  [%s] %d row(s) -> %s", mod_label(mod), len(sub), path.name)
            written.append(path)
    else:
        path = inp.out(f"{stem}by_feature.tsv")
        table.to_csv(path, sep="\t", index=False, float_format="%.8g")
        logger.info("  [combined] %d row(s) -> %s", len(table), path.name)
        written.append(path)
    return written


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def plot_along_replicons(inp, mods, lengths, fmt, bins, dpi) -> Path | None:
    plt = viz.lazy_pyplot()
    if plt is None:
        return None
    methyl = inp.methyl
    reps = sorted(r for r in lengths if (methyl.seqid == r).any())
    if not reps:
        return None
    scale, unit = viz.coord_unit(max(lengths[r] for r in reps))
    fig, axes = plt.subplots(len(reps), len(mods), squeeze=False,
                             figsize=(max(4.5 * len(mods), 6), max(2.2 * len(reps), 3)))
    for i, rep in enumerate(reps):
        edges = np.linspace(0, lengths[rep], bins + 1)
        centres = (edges[:-1] + edges[1:]) / 2.0 / scale
        for j, mod in enumerate(mods):
            ax = axes[i][j]
            pos = methyl.positions(rep, mod)
            if pos.size:
                counts, _ = np.histogram(pos, bins=edges)
                col = viz.mod_color(mod, mods)
                ax.fill_between(centres, counts, step="mid", color=col,
                                alpha=0.85, linewidth=0)
                ax.plot(centres, counts, drawstyle="steps-mid", color=col, lw=0.6)
            else:
                viz.annotate_empty(ax, "no calls")
            if i == 0:
                ax.set_title(f"{mod_label(mod)} ({mod})", fontsize=10)
            if j == 0:
                ax.set_ylabel(f"{inp.label(rep)}\ncalls / bin", fontsize=8)
            if i == len(reps) - 1:
                ax.set_xlabel(f"position ({unit})", fontsize=8)
            ax.tick_params(labelsize=7)
            ax.margins(x=0)
    fig.suptitle("Methylation distribution along replicon(s)", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    return viz.savefig(fig, inp.out(f"along_replicons.{fmt}"), dpi)


def plot_per_feature(table, mods, inp, fmt, dpi) -> Path | None:
    plt = viz.lazy_pyplot()
    if plt is None or table.empty:
        return None
    agg = table.groupby(["replicon", "feature_type", "mod_code"])["raw_count"].sum()
    reps = sorted(table["replicon"].unique())
    feats = sorted(table["feature_type"].unique())
    if len(feats) < 2:
        logger.info("  [plot] per-feature plot skipped — a single feature type "
                    "carries methylation.")
        return None
    fig, axes = plt.subplots(len(reps), 1, squeeze=False, sharex=True,
                             figsize=(max(1.4 * len(feats) * max(len(mods), 1), 7),
                                      3.0 * len(reps)))
    x = np.arange(len(feats))
    width = 0.8 / max(len(mods), 1)
    for i, rep in enumerate(reps):
        ax = axes[i][0]
        for k, mod in enumerate(mods):
            heights = [float(agg.get((rep, ft, mod), 0)) for ft in feats]
            ax.bar(x + (k - (len(mods) - 1) / 2) * width, heights, width=width,
                   color=viz.mod_color(mod, mods), label=f"{mod_label(mod)} ({mod})")
        ax.set_ylabel("methylated\npositions", fontsize=8)
        ax.set_title(inp.label(rep), fontsize=10)
        ax.set_xticks(x); ax.set_xticklabels(feats, rotation=30, ha="right", fontsize=8)
        ax.tick_params(axis="y", labelsize=7)
        if i == 0:
            ax.legend(fontsize=8, title="modification", title_fontsize=8)
    fig.suptitle("Methylation per replicon and feature type", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    return viz.savefig(fig, inp.out(f"per_replicon_feature.{fmt}"), dpi)


# --------------------------------------------------------------------------- #
def print_summary(inp, table, mods) -> None:
    ann = inp.annotation
    sep, sep2 = "=" * 72, "-" * 72
    print(f"\n{sep}\n  xam — methylation x annotation cross-reference\n"
          f"  methylation: {inp.methyl.source} [{inp.methyl.fmt}]\n{sep}")
    from collections import Counter
    rep_feat = Counter(f.seqid for f in ann.features)
    ftypes = Counter(f.ftype for f in ann.features)
    print(f"\n  Replicons: {len(rep_feat)}\n  {sep2}")
    for rep, cnt in sorted(rep_feat.items()):
        print(f"  {inp.label(rep):<36} {cnt:>10,} features")
    print(f"\n  Feature types: {len(ftypes)}\n  {sep2}")
    for ft, cnt in ftypes.most_common():
        print(f"  {ft:<28} {cnt:>10,}")
    print(f"\n  Modifications\n  {sep2}")
    print(f"  {'code':<7}{'label':<8}{'in features':>14}{'total calls':>14}{'% in feat':>11}")
    totals = inp.methyl.totals_per_mod()
    for mod in mods:
        infeat = int(table.loc[table["mod_code"] == mod, "raw_count"].sum()) if len(table) else 0
        tot = totals.get(mod, 0)
        pct = 100 * infeat / tot if tot else float("nan")
        print(f"  {mod:<7}{mod_label(mod):<8}{infeat:>14,}{tot:>14,}{pct:>10.1f}%")
    print(f"\n{sep}\n")


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin xam",
        description="Cross-reference methylation calls with a GFF3 annotation.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    C.add_annotation_args(p)
    C.add_reference_args(p)
    C.add_methylation_args(p)
    C.add_seqid_args(p)
    add_region_args(p)
    C.add_output_args(p, default_prefix="xam")
    C.add_plot_args(p)
    g = p.add_argument_group("counting")
    g.add_argument("--ignore-strand", action="store_true",
                   help="Count methylation on both strands for every feature.")
    g.add_argument("--include-zero", action="store_true",
                   help="Emit features with no methylation (needed by diem for "
                        "unbiased expression/methylation statistics).")
    g.add_argument("--no-split", action="store_true",
                   help="Write one combined TSV instead of one file per modification.")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    inp = C.load_inputs(args)
    if inp.methyl is None or not len(inp.methyl):
        raise SystemExit("[FATAL] no methylation calls available.")

    lengths0 = replicon_lengths(inp.genome, inp.annotation.seq_regions,
                                inp.annotation.features, inp.methyl)
    op_map = None
    if args.operons:
        op_map = operon_map(infer_operons(inp.annotation, args.operon_max_gap))
    if args.regions:
        inp.annotation = derive_regions(inp.annotation,
                                        parse_region_specs(args.regions), lengths0)

    written: list[Path] = []
    samples = inp.methyl_reps or [inp.methyl]
    names = inp.methyl_names or [""]
    if len(samples) > 1:
        logger.info("%d sample(s) given: writing one table each plus a pooled "
                    "table.", len(samples))
        for ms, name in zip(samples, names):
            tbl, mods, _idx, _used = build_table(
                inp, args.ignore_strand, args.include_zero, args.min_frac,
                methyl=ms, operons=op_map)
            written += write_tables(tbl, mods, inp, split=not args.no_split,
                                    tag=viz.safe_name(name))

    table, mods, index, used = build_table(
        inp, args.ignore_strand, args.include_zero, args.min_frac,
        methyl=_pool(samples), operons=op_map)
    written += write_tables(table, mods, inp, split=not args.no_split,
                            tag="pooled" if len(samples) > 1 else "")

    if not args.no_plot:
        lengths = replicon_lengths(inp.genome, inp.annotation.seq_regions,
                                   inp.annotation.features, used)
        inp.methyl = used
        for path in (plot_along_replicons(inp, mods, lengths, args.plot_format,
                                          args.bins, args.plot_dpi),
                     plot_per_feature(table, mods, inp, args.plot_format, args.plot_dpi)):
            if path:
                written.append(path)

    print_summary(inp, table, mods)
    C.finalize(inp, written, args, "merlin xam")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
