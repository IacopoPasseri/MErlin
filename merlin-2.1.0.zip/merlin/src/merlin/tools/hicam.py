"""hicam — Hi-C and methylation: 3D genome organisation as MErlin's third layer.

This is the module the README promised and the toolkit did not have.  It reads a
contact matrix, derives the standard organisational tracks, and then asks the
questions that need more than one omic at a time — but only those for which the
inputs were actually supplied.

What it computes
----------------
Always (Hi-C alone)
    distance decay P(s); iterative correction; observed/expected with circular
    separations; compartment/CID eigenvector with a sign anchored to GC content
    or gene density; insulation score and domain boundaries; saddle strength.

With ``--gff``
    per-bin gene density and orientation, boundary versus interior comparisons.

With ``--methylation``
    per-bin methylation density and level; correlation with insulation and with
    the compartment eigenvector; methylation at boundaries versus domain
    interiors; and **distance-controlled contact/co-methylation** — whether bins
    that touch in 3D carry similar methylation once genomic separation is held
    fixed, which is the only form of the question that is not simply restating
    the distance decay.

With ``--geneexp`` (and optionally ``--dm-table``)
    per-bin differential expression, enrichment of DE and of differentially
    methylated genes at boundaries, and the three-layer table joining
    compartment, methylation and expression per bin.

With ``--fasta``
    oriC/ter placement, so boundaries can be reported on the replication axis
    that ``spacem`` uses.

Every statistic is written with its effect size and its n.  A bacterial Hi-C map
usually has a few hundred bins per replicon, so a correlation over bins has far
less power than the number of reads suggests, and the bins are spatially
autocorrelated — the reported p-values are anti-conservative and the output says
so.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..genome import (bin_counts, gc_content_bins, gc_skew_bins,
                      ori_ter_coordinate, resolve_origins)
from ..hic import (ContactMap, call_boundaries, compartment_eigenvector,
                   distance_decay, ice, insulation_score, load_contacts,
                   observed_over_expected, saddle)
from ..logging_utils import get_logger, warn_once
from ..stats import (StatTable, benjamini_hochberg, block_bootstrap_ci,
                     circular_shift_null, contingency_test, correlate)
from . import _common as C

logger = get_logger("hicam")


# --------------------------------------------------------------------------- #
def bin_assign(positions: np.ndarray, starts: np.ndarray, resolution: int,
               n: int) -> np.ndarray:
    if positions.size == 0:
        return np.empty(0, dtype=np.int64)
    return np.clip((positions - starts[0]) // resolution, 0, n - 1).astype(np.int64)


def per_bin_covariates(cm: ContactMap, inp: C.Inputs, args, expr_by_locus,
                       dm_loci) -> dict[str, np.ndarray]:
    """Everything known about each Hi-C bin, from whichever layers were supplied."""
    n, res = cm.n, cm.resolution
    cov: dict[str, np.ndarray] = {}
    seq = (inp.genome or {}).get(cm.seqid)

    if seq is not None:
        gcc = gc_content_bins(seq, res)
        skew = gc_skew_bins(seq, res)
        cov["gc_content"] = _fit(gcc, n)
        cov["gc_skew"] = _fit(skew, n)

    if inp.annotation is not None:
        feats = [f for f in inp.annotation.features if f.seqid == cm.seqid]
        if feats:
            mids = np.array([f.mid for f in feats], dtype=np.int64)
            b = bin_assign(mids, cm.starts, res, n)
            cov["n_genes"] = np.bincount(b, minlength=n).astype(float)
            plus = np.array([f.strand == "+" for f in feats])
            cov["n_genes_plus"] = np.bincount(b[plus], minlength=n).astype(float)
            cov["n_genes_minus"] = np.bincount(b[~plus], minlength=n).astype(float)
            if expr_by_locus is not None:
                lfc = np.full(len(feats), np.nan)
                de = np.zeros(len(feats))
                for i, f in enumerate(feats):
                    rec = expr_by_locus.get(f.locus_tag)
                    if rec is not None:
                        lfc[i], de[i] = rec
                ok = np.isfinite(lfc)
                sums = np.bincount(b[ok], weights=lfc[ok], minlength=n)
                cnts = np.bincount(b[ok], minlength=n)
                with np.errstate(invalid="ignore", divide="ignore"):
                    cov["mean_log2FC"] = np.where(cnts > 0, sums / np.maximum(cnts, 1),
                                                  np.nan)
                cov["n_genes_measured"] = cnts.astype(float)
                cov["n_DE"] = np.bincount(b[ok], weights=de[ok], minlength=n)
                mx = np.zeros(n)
                np.maximum.at(mx, b[ok], np.abs(lfc[ok]))
                cov["expr_max_abs_lfc"] = np.where(cnts > 0, mx, np.nan)
                with np.errstate(invalid="ignore", divide="ignore"):
                    cov["frac_DE"] = np.where(cnts > 0, cov["n_DE"] / np.maximum(cnts, 1),
                                              np.nan)
            if dm_loci is not None:
                isdm = np.array([f.locus_tag in dm_loci for f in feats], dtype=float)
                cov["n_DM"] = np.bincount(b, weights=isdm, minlength=n)

    if inp.methyl is not None and len(inp.methyl):
        assayed = inp.methyl
        min_frac = 0.5 if args.min_frac is None else args.min_frac
        methylated = assayed if assayed.presence_only else assayed.filter(min_frac=min_frac)
        pos = methylated.positions(cm.seqid)
        cov["meth_density"] = _fit(bin_counts(pos, cm.starts[-1] + res, res).astype(float), n)
        sel = assayed.seqid == cm.seqid
        cov["assayed_density"] = _fit(
            bin_counts(assayed.pos[sel], cm.starts[-1] + res, res).astype(float), n)
        fr = assayed.frac[sel]
        if np.isfinite(fr).any():
            b = bin_assign(assayed.pos[sel][np.isfinite(fr)], cm.starts, res, n)
            vals = fr[np.isfinite(fr)]
            sums = np.bincount(b, weights=vals, minlength=n)
            cnts = np.bincount(b, minlength=n)
            with np.errstate(invalid="ignore", divide="ignore"):
                cov["mean_frac_modified"] = np.where(cnts > 0,
                                                     sums / np.maximum(cnts, 1), np.nan)
    return cov


def _fit(arr: np.ndarray, n: int) -> np.ndarray:
    out = np.full(n, np.nan)
    k = min(n, arr.size)
    out[:k] = arr[:k]
    return out


# --------------------------------------------------------------------------- #
def contact_vs_similarity(oe: np.ndarray, track: np.ndarray, circular: bool,
                          n_strata: int, max_pairs: int, seed: int):
    """Does contact frequency predict similarity of ``track``, at fixed distance?

    Genomic separation drives both contact frequency and the similarity of almost
    any genomic track, so the unconditioned correlation is guaranteed and
    uninformative.  Stratifying by separation and combining the within-stratum
    correlations (Fisher z, weighted by stratum size) removes that confound.
    """
    n = oe.shape[0]
    ok = np.isfinite(track)
    if ok.sum() < 20:
        return None
    ii, jj = np.triu_indices(n, k=1)
    d = np.abs(ii - jj)
    if circular:
        d = np.minimum(d, n - d)
    valid = ok[ii] & ok[jj] & np.isfinite(oe[ii, jj]) & (d > 0)
    ii, jj, d = ii[valid], jj[valid], d[valid]
    if ii.size == 0:
        return None
    if ii.size > max_pairs:
        rng = np.random.default_rng(seed)
        pick = rng.choice(ii.size, size=max_pairs, replace=False)
        ii, jj, d = ii[pick], jj[pick], d[pick]
    contact = oe[ii, jj]
    sim = -np.abs(track[ii] - track[jj])

    edges = np.unique(np.quantile(d, np.linspace(0, 1, n_strata + 1)).astype(int))
    if edges.size < 3:
        return None
    strata = np.clip(np.digitize(d, edges[1:-1]), 0, edges.size - 2)
    zs, ws, rows = [], [], []
    for s in range(edges.size - 1):
        m = strata == s
        if m.sum() < 25:
            continue
        r = correlate(contact[m], sim[m])
        rho = r.spearman_rho
        if not np.isfinite(rho) or abs(rho) >= 1:
            continue
        z = np.arctanh(rho)
        w = max(m.sum() - 3, 1)
        zs.append(z); ws.append(w)
        rows.append(dict(stratum=s, sep_min_bins=int(edges[s]),
                         sep_max_bins=int(edges[s + 1]), n_pairs=int(m.sum()),
                         spearman_rho=rho, p=r.spearman_p))
    if not zs:
        return None
    zs, ws = np.asarray(zs), np.asarray(ws, dtype=float)
    z_bar = float(np.sum(zs * ws) / np.sum(ws))
    se = float(np.sqrt(1.0 / np.sum(ws)))
    rho_bar = float(np.tanh(z_bar))
    try:
        from scipy.stats import norm
        p_bar = float(2 * norm.sf(abs(z_bar / se)))
    except ImportError:
        p_bar = float("nan")
    return dict(rho_combined=rho_bar, p_combined=p_bar, n_strata=len(zs),
                n_pairs=int(sum(r["n_pairs"] for r in rows)), per_stratum=rows)


def boundary_contrast(cov: dict[str, np.ndarray], boundaries: np.ndarray, n: int,
                      flank: int):
    """Boundary bins (plus a flank) versus domain interiors, per covariate."""
    is_boundary = np.zeros(n, dtype=bool)
    for b in boundaries:
        for k in range(-flank, flank + 1):
            is_boundary[(b + k) % n] = True
    rows = []
    for name, vals in cov.items():
        v = np.asarray(vals, float)
        a, b_ = v[is_boundary], v[~is_boundary]
        a, b_ = a[np.isfinite(a)], b_[np.isfinite(b_)]
        if a.size < 3 or b_.size < 3:
            continue
        p = np.nan
        try:
            from scipy.stats import mannwhitneyu
            p = float(mannwhitneyu(a, b_, alternative="two-sided").pvalue)
        except ImportError:
            pass
        pooled = np.sqrt((a.var(ddof=1) * (a.size - 1) + b_.var(ddof=1) * (b_.size - 1))
                         / max(a.size + b_.size - 2, 1))
        d = float((a.mean() - b_.mean()) / pooled) if pooled > 0 else np.nan
        rows.append(dict(covariate=name, boundary_mean=float(a.mean()),
                         interior_mean=float(b_.mean()), cohens_d=d,
                         n_boundary=int(a.size), n_interior=int(b_.size),
                         mannwhitney_p=p))
    if rows:
        q = benjamini_hochberg([r["mannwhitney_p"] for r in rows])
        for r, qq in zip(rows, q):
            r["q_BH"] = float(qq)
    return rows, is_boundary


# --------------------------------------------------------------------------- #
def differential_maps(cm_a, cm_b, args, labels, orient_a=None):
    """Compare two contact maps of the same replicon (ROADMAP 3.4).

    One map describes an organisation; two enable the question that matters —
    which boundaries strengthen or weaken, and which bins change compartment.
    Bins must share a resolution and a length; anything else is refused rather
    than silently trimmed, because a one-bin offset would shift every boundary.
    """
    if cm_a.n != cm_b.n or cm_a.resolution != cm_b.resolution:
        warn_once(logger, f"HIC_DIFF_SHAPE_{cm_a.seqid}",
                  f"{cm_a.seqid}: the two contact maps differ in shape "
                  f"({cm_a.n}x{cm_a.resolution} vs {cm_b.n}x{cm_b.resolution}); "
                  f"no differential comparison is possible. Re-bin both at the "
                  f"same resolution.")
        return None
    circular = not args.linear
    out = {}
    tracks = {}
    for tag, cm in ((labels[0], cm_a), (labels[1], cm_b)):
        mat = cm.matrix
        if not args.no_balance and cm.weights is None:
            mat, _mask = ice(mat)
        oe, _e = observed_over_expected(mat, circular=circular)
        ins = insulation_score(mat, args.insulation_window, circular=circular)
        bnd = call_boundaries(ins, args.boundary_prominence, circular=circular)
        pc1, _r = compartment_eigenvector(oe, orient_a)
        tracks[tag] = dict(oe=oe, ins=ins, boundaries=bnd, pc1=pc1)
    a, b = tracks[labels[0]], tracks[labels[1]]

    delta_ins = b["ins"] - a["ins"]
    # A boundary "moves" if it is called in one map and not within +/-1 bin of
    # any boundary in the other; +/-1 absorbs the jitter of the local minimum.
    def _near(x, others):
        if others.size == 0:
            return False
        d = np.abs(others - x)
        if circular:
            d = np.minimum(d, cm_a.n - d)
        return bool(d.min() <= 1)

    only_a = [int(x) for x in a["boundaries"] if not _near(x, b["boundaries"])]
    only_b = [int(x) for x in b["boundaries"] if not _near(x, a["boundaries"])]
    shared = [int(x) for x in a["boundaries"] if _near(x, b["boundaries"])]

    flips = np.zeros(cm_a.n, dtype=bool)
    ok = np.isfinite(a["pc1"]) & np.isfinite(b["pc1"])
    flips[ok] = np.sign(a["pc1"][ok]) != np.sign(b["pc1"][ok])

    out.update(delta_insulation=delta_ins, boundaries_a=a["boundaries"],
               boundaries_b=b["boundaries"], only_a=only_a, only_b=only_b,
               shared=shared, compartment_flip=flips, tracks=tracks)
    logger.info("%s: %d shared boundary(ies), %d only in %s, %d only in %s, "
                "%d bin(s) flip compartment.", cm_a.seqid, len(shared),
                len(only_a), labels[0], len(only_b), labels[1], int(flips.sum()))
    return out


def plot_differential(inp, cm, diff, labels, args):
    plt = viz.lazy_pyplot()
    if plt is None or diff is None:
        return []
    tag = viz.safe_name(inp.label(cm.seqid))
    scale, unit = viz.coord_unit(int(cm.starts[-1] + cm.resolution))
    x = cm.centers / scale
    fig, axes = plt.subplots(2, 1, figsize=(11, 6), sharex=True,
                             gridspec_kw={"height_ratios": [2, 1]})
    ax = axes[0]
    ax.plot(x, diff["tracks"][labels[0]]["ins"], lw=1.1,
            color=viz.PAL["control"], label=labels[0])
    ax.plot(x, diff["tracks"][labels[1]]["ins"], lw=1.1,
            color=viz.PAL["treatment"], label=labels[1])
    for b in diff["only_a"]:
        ax.axvline(x[b], color=viz.PAL["control"], lw=0.6, alpha=0.5)
    for b in diff["only_b"]:
        ax.axvline(x[b], color=viz.PAL["treatment"], lw=0.6, alpha=0.5)
    ax.set_ylabel("insulation"); ax.legend(fontsize=8, frameon=False)
    ax.set_title(f"{inp.label(cm.seqid)} — domain organisation: "
                 f"{len(diff['shared'])} shared boundaries, "
                 f"{len(diff['only_a'])} only in {labels[0]}, "
                 f"{len(diff['only_b'])} only in {labels[1]}", fontsize=11)
    ax = axes[1]
    d = diff["delta_insulation"]
    ax.fill_between(x, np.clip(d, 0, None), color=viz.PAL["gain"], step="mid")
    ax.fill_between(x, np.clip(d, None, 0), color=viz.PAL["loss"], step="mid")
    ax.axhline(0, color="k", lw=0.5)
    ax.set_ylabel(f"d insulation\n({labels[1]} - {labels[0]})", fontsize=8)
    ax.set_xlabel(f"position ({unit})")
    fig.tight_layout()
    return [viz.savefig(fig, inp.out(f"{tag}.hic_differential.{args.plot_format}"),
                        args.plot_dpi)]


# --------------------------------------------------------------------------- #
def make_figures(inp, cm, oe, ins, boundaries, cov, sd, strength, decay,
                 cvs, args) -> list[Path]:
    plt = viz.lazy_pyplot()
    if plt is None:
        return []
    written = []
    label = inp.label(cm.seqid)
    tag = viz.safe_name(label)
    scale, unit = viz.coord_unit(int(cm.starts[-1] + cm.resolution))
    x = cm.centers / scale

    # --- contact map + tracks --------------------------------------------
    fig = plt.figure(figsize=(11, 12))
    gs = fig.add_gridspec(5, 1, height_ratios=[4, 1, 1, 1, 1], hspace=0.35)
    ax = fig.add_subplot(gs[0])
    with np.errstate(invalid="ignore", divide="ignore"):
        img = np.log2(np.where(oe > 0, oe, np.nan))
    lim = np.nanpercentile(np.abs(img), 98) if np.isfinite(img).any() else 1
    im = ax.imshow(img, cmap="RdBu_r", vmin=-lim, vmax=lim, origin="lower",
                   extent=[x[0], x[-1], x[0], x[-1]], interpolation="nearest")
    for b in boundaries:
        ax.axvline(x[b], color="k", lw=0.4, alpha=0.35)
    fig.colorbar(im, ax=ax, shrink=0.7, label="log2 observed / expected")
    ax.set_title(f"{label} — Hi-C at {cm.resolution:,} bp "
                 f"({cm.n} bins, saddle strength "
                 f"{strength:.2f})" if np.isfinite(strength) else
                 f"{label} — Hi-C at {cm.resolution:,} bp ({cm.n} bins)",
                 fontsize=12, fontweight="bold")
    ax.set_ylabel(f"position ({unit})")

    ax = fig.add_subplot(gs[1])
    ax.plot(x, ins, color="#2c3e50", lw=1.0)
    ax.scatter(x[boundaries], ins[boundaries], s=14, color=viz.PAL["dual"], zorder=3,
               label=f"{len(boundaries)} boundaries")
    ax.set_ylabel("insulation", fontsize=8); ax.legend(fontsize=7, frameon=False)
    ax.margins(x=0)

    ax = fig.add_subplot(gs[2])
    pc = cov.get("pc1")
    if pc is not None and np.isfinite(pc).any():
        ax.fill_between(x, np.clip(pc, 0, None), color="#c0392b", step="mid")
        ax.fill_between(x, np.clip(pc, None, 0), color="#2980b9", step="mid")
        ax.axhline(0, color="k", lw=0.4)
    else:
        viz.annotate_empty(ax, "no eigenvector")
    ax.set_ylabel("PC1\n(A / B)", fontsize=8); ax.margins(x=0)

    ax = fig.add_subplot(gs[3])
    if "meth_density" in cov:
        ax.fill_between(x, cov["meth_density"], color=viz.PAL["meth"], step="mid",
                        alpha=0.85)
        ax.set_ylabel("methylated\ncalls / bin", fontsize=8)
    else:
        viz.annotate_empty(ax, "no methylation supplied")
    ax.margins(x=0)

    ax = fig.add_subplot(gs[4])
    if "mean_log2FC" in cov:
        ax.plot(x, cov["mean_log2FC"], color="#8e44ad", lw=1.0)
        ax.axhline(0, color="k", lw=0.4)
        ax.set_ylabel("mean log2FC\n(expression)", fontsize=8)
    elif "n_genes" in cov:
        ax.fill_between(x, cov["n_genes"], color="#7f8c8d", step="mid")
        ax.set_ylabel("genes / bin", fontsize=8)
    else:
        viz.annotate_empty(ax, "no annotation supplied")
    ax.set_xlabel(f"position ({unit})"); ax.margins(x=0)
    written.append(viz.savefig(fig, inp.out(f"{tag}.hic_tracks.{args.plot_format}"),
                               args.plot_dpi))

    # --- P(s) + saddle ----------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    s, exp = decay
    ok = np.isfinite(exp) & (s > 0) & (exp > 0)
    if ok.sum() > 2:
        axes[0].loglog(s[ok], exp[ok], color="#2c3e50", lw=1.4)
    axes[0].set_xlabel("genomic separation (bp)")
    axes[0].set_ylabel("mean contact")
    axes[0].set_title("Distance decay P(s)")
    if sd is not None:
        im = axes[1].imshow(np.log2(sd), cmap="RdBu_r", origin="lower")
        fig.colorbar(im, ax=axes[1], shrink=0.8, label="log2 O/E")
        axes[1].set_xlabel("PC1 quantile"); axes[1].set_ylabel("PC1 quantile")
        axes[1].set_title(f"Saddle (strength {strength:.2f})"
                          if np.isfinite(strength) else "Saddle")
    else:
        viz.annotate_empty(axes[1], "saddle not computable")
    fig.tight_layout()
    written.append(viz.savefig(fig, inp.out(f"{tag}.hic_decay_saddle.{args.plot_format}"),
                               args.plot_dpi))

    # --- contact vs co-methylation ---------------------------------------
    if cvs:
        fig, ax = plt.subplots(figsize=(7.5, 4.8))
        rows = cvs["per_stratum"]
        mids = [(r["sep_min_bins"] + r["sep_max_bins"]) / 2 * cm.resolution
                for r in rows]
        rhos = [r["spearman_rho"] for r in rows]
        ax.plot(mids, rhos, "o-", color=viz.PAL["dual"], lw=1.4)
        ax.axhline(0, color="k", lw=0.6, ls="--")
        ax.set_xscale("log")
        ax.set_xlabel("genomic separation (bp)")
        ax.set_ylabel("Spearman(contact O/E, methylation similarity)")
        ax.set_title(f"{label} — co-methylation of contacting bins,\n"
                     f"stratified by separation "
                     f"(combined rho={cvs['rho_combined']:+.3f}, "
                     f"p={cvs['p_combined']:.2g})", fontsize=10)
        fig.tight_layout()
        written.append(viz.savefig(
            fig, inp.out(f"{tag}.hic_comethylation.{args.plot_format}"), args.plot_dpi))
    return written


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin hicam",
        description="Hi-C 3D organisation integrated with methylation and expression.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    hi = p.add_argument_group("Hi-C input")
    hi.add_argument("--hic", required=True, metavar="FILE",
                    help=".cool/.mcool, HiC-Pro .matrix, or a dense text matrix.")
    hi.add_argument("--hic-bins", default=None, metavar="FILE",
                    help="Bins BED for HiC-Pro/dense input.")
    hi.add_argument("--resolution", type=int, default=None, metavar="BP",
                    help="Resolution to read from an .mcool, or bin size for a "
                         "dense matrix without a bins file.")
    hi.add_argument("--no-balance", action="store_true",
                    help="Do not apply cooler weights and do not run ICE.")
    hi.add_argument("--linear", action="store_true",
                    help="Treat replicons as linear (default: circular, which is "
                         "what makes the distance-expected normalisation correct "
                         "for bacteria).")
    hi.add_argument("--insulation-window", type=int, default=5, metavar="BINS",
                    help="Diamond half-width for the insulation score.")
    hi.add_argument("--boundary-prominence", type=float, default=0.1, metavar="X",
                    help="Minimum insulation drop for a boundary call.")
    hi.add_argument("--boundary-flank", type=int, default=1, metavar="BINS",
                    help="Bins either side of a boundary treated as boundary.")
    hi.add_argument("--saddle-quantiles", type=int, default=5)
    hi.add_argument("--strata", type=int, default=12, metavar="N",
                    help="Separation strata for the contact/co-methylation test.")
    hi.add_argument("--max-pairs", type=int, default=2_000_000, metavar="N",
                    help="Cap on bin pairs used in the co-methylation test.")
    hi.add_argument("--hic2", default=None, metavar="FILE",
                    help="Second-condition contact matrix. Enables differential "
                         "insulation, boundary changes and compartment flips.")
    hi.add_argument("--hic2-bins", default=None, metavar="FILE")
    hi.add_argument("--labels", nargs=2, default=["condition1", "condition2"],
                    metavar=("A", "B"), help="Labels for the two contact maps.")
    hi.add_argument("--n-bootstrap", type=int, default=500, metavar="N",
                    help="Block-bootstrap resamples for bin-correlation intervals.")
    hi.add_argument("--n-shift", type=int, default=1000, metavar="N",
                    help="Circular shifts for the autocorrelation-aware null.")
    hi.add_argument("--seed", type=int, default=42)

    C.add_annotation_args(p, required=False)
    C.add_reference_args(p, required=False)
    C.add_methylation_args(p, required=False)
    C.add_seqid_args(p)

    other = p.add_argument_group("other layers")
    other.add_argument("--geneexp", default=None, metavar="FILE",
                       help="Differential expression table (DESeq2/edgeR/limma).")
    other.add_argument("--dm-table", default=None, metavar="FILE",
                       help="dixam differential table, to place DM genes on the map.")
    other.add_argument("--padj-thr", type=float, default=0.05)
    other.add_argument("--lfc-thr", type=float, default=1.0)
    other.add_argument("--dm-qvalue", type=float, default=0.05)
    other.add_argument("--skew-window", type=int, default=10000)
    other.add_argument("--oric", default=None)
    other.add_argument("--ter", default=None)

    C.add_output_args(p, default_prefix="hicam")
    C.add_plot_args(p, default_on=False)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    contacts = load_contacts(args)
    if not contacts:
        raise SystemExit("[FATAL] no contact data could be read.")
    contacts2 = {}
    hic_labels = (viz.safe_name(args.labels[0]), viz.safe_name(args.labels[1]))
    if args.hic2:
        from argparse import Namespace
        contacts2 = load_contacts(Namespace(
            hic=args.hic2, hic_bins=args.hic2_bins, resolution=args.resolution,
            no_balance=args.no_balance))
        logger.info("Second contact map: %d chromosome(s).", len(contacts2))

    inp = C.load_inputs(args, need_annotation=False)

    # Hi-C seqids are their own namespace; reconcile them against the canonical one.
    canon = set()
    if inp.genome:
        canon = set(inp.genome)
    elif inp.annotation is not None:
        canon = inp.annotation.seqids
    if canon:
        from ..seqids import reconcile
        res = reconcile({"canonical": canon, "hic": set(contacts)},
                        canonical_key="canonical",
                        force_strip=args.strip_version,
                        allow_rank_map=args.allow_rank_map)
        contacts = {res.apply(k): v for k, v in contacts.items()}
        for k, v in contacts.items():
            v.seqid = k
        if contacts2:
            contacts2 = {res.apply(k): v for k, v in contacts2.items()}
            for k, v in contacts2.items():
                v.seqid = k
        shared = set(contacts) & canon
        if not shared:
            raise SystemExit(
                "[FATAL] no Hi-C chromosome name matches the annotation/reference "
                f"({sorted(contacts)[:3]} vs {sorted(canon)[:3]}). Use --seqid-map "
                "or --strip-version.")
        skipped = set(contacts) - canon
        if skipped:
            warn_once(logger, "HIC_ORPHAN_CHROM",
                      f"{len(skipped)} Hi-C chromosome(s) have no annotation/reference "
                      f"counterpart and are skipped: {sorted(skipped)[:3]}.")
        contacts = {k: v for k, v in contacts.items() if k in canon}

    expr_by_locus = None
    if args.geneexp:
        from ..io import read_geneexp
        ge = read_geneexp(args.geneexp)
        de = ((ge["padj"] < args.padj_thr) &
              (ge["log2FoldChange"].abs() >= args.lfc_thr)).astype(float)
        expr_by_locus = {str(k): (float(v), float(d)) for k, v, d
                         in zip(ge["locus_tag"], ge["log2FoldChange"], de)}
    dm_loci = None
    if args.dm_table:
        import pandas as pd
        dm = pd.read_csv(args.dm_table, sep=None, engine="python")
        if "locus_tag" in dm.columns and "qvalue" in dm.columns:
            dm_loci = set(dm.loc[pd.to_numeric(dm["qvalue"], errors="coerce")
                                 < args.dm_qvalue, "locus_tag"].astype(str))
            logger.info("Differentially methylated loci from --dm-table: %d",
                        len(dm_loci))

    origins = {}
    if inp.genome:
        from .spacem import parse_locus_overrides
        origins = resolve_origins(inp.genome, args.skew_window,
                                  parse_locus_overrides(args.oric),
                                  parse_locus_overrides(args.ter))

    circular = not args.linear
    stats = StatTable()
    bin_rows, boundary_rows, contrast_rows, stratum_rows = [], [], [], []
    written: list[Path] = []

    for seqid, cm in sorted(contacts.items(), key=lambda kv: -kv[1].n):
        cm.circular = circular
        if cm.n < 10:
            warn_once(logger, f"HIC_TINY_{seqid}",
                      f"{seqid}: only {cm.n} Hi-C bins — too few for insulation or "
                      f"compartment analysis; skipped.")
            continue
        logger.info("Replicon %s: %d bins at %d bp.", seqid, cm.n, cm.resolution)

        mat = cm.matrix
        if not args.no_balance and cm.weights is None:
            mat, _mask = ice(mat)
        oe, _exp = observed_over_expected(mat, circular=circular)
        decay = distance_decay(mat, cm.resolution, circular=circular)

        cov = per_bin_covariates(cm, inp, args, expr_by_locus, dm_loci)
        orient = cov.get("gc_content")
        if orient is None:
            orient = cov.get("n_genes")
        pc1, orient_r = compartment_eigenvector(oe, orient)
        cov["pc1"] = pc1
        if not np.isfinite(orient_r) or abs(orient_r) < 0.1:
            warn_once(logger, f"HIC_PC1_SIGN_{seqid}",
                      f"{seqid}: the compartment eigenvector could not be oriented "
                      f"(|r| with GC/gene density = {orient_r:.3f}). Which side is "
                      f"'A' is arbitrary here; do not read a direction into it.")
        ins = insulation_score(mat, args.insulation_window, circular=circular)
        cov["insulation"] = ins
        boundaries = call_boundaries(ins, args.boundary_prominence, circular=circular)
        sd, strength = saddle(oe, pc1, args.saddle_quantiles)

        if inp.genome and seqid in origins:
            sp = origins[seqid]
            signed, folded, _arm = ori_ter_coordinate(cm.centers, sp.oric, sp.ter,
                                                      len(inp.genome[seqid]))
            cov["oriter_signed"] = signed
            cov["oriter_folded"] = folded

        # ---- per-bin table ---------------------------------------------
        import pandas as pd
        row = {"replicon": seqid, "label": inp.label(seqid),
               "bin": np.arange(cm.n), "start": cm.starts,
               "end": cm.starts + cm.resolution,
               "compartment": np.where(np.isnan(pc1), "NA",
                                       np.where(pc1 >= 0, "A", "B")),
               "is_boundary": np.isin(np.arange(cm.n), boundaries).astype(int)}
        row.update({k: v for k, v in cov.items()})
        bin_rows.append(pd.DataFrame(row))

        for b in boundaries:
            boundary_rows.append(dict(
                replicon=seqid, label=inp.label(seqid), bin=int(b),
                start=int(cm.starts[b]), end=int(cm.starts[b] + cm.resolution),
                insulation=float(ins[b]),
                oriter_folded=float(cov["oriter_folded"][b])
                if "oriter_folded" in cov else np.nan))

        # ---- correlations ----------------------------------------------
        pairs = [("insulation", "meth_density"), ("insulation", "mean_frac_modified"),
                 ("pc1", "meth_density"), ("pc1", "mean_frac_modified"),
                 ("pc1", "gc_content"), ("pc1", "n_genes"),
                 ("insulation", "n_genes"), ("insulation", "frac_DE"),
                 ("pc1", "mean_log2FC"), ("pc1", "frac_DE"),
                 ("meth_density", "mean_log2FC")]
        for a, b in pairs:
            if a in cov and b in cov:
                r = correlate(cov[a], cov[b])
                if r.n < 10:
                    continue
                # Neighbouring bins are not independent: the naive p-value is
                # anti-conservative, so report a block-bootstrap interval and a
                # circular-shift p-value that preserve the autocorrelation.
                rho_b, lo, hi = block_bootstrap_ci(cov[a], cov[b],
                                                   n_boot=args.n_bootstrap,
                                                   seed=args.seed)
                _obs, shift_p = circular_shift_null(cov[a], cov[b],
                                                    n_perm=args.n_shift,
                                                    seed=args.seed)
                stats.add(replicon=seqid, label=inp.label(seqid),
                          analysis="bin_correlation", term_a=a, term_b=b,
                          n=r.n, spearman_rho=r.spearman_rho,
                          spearman_p=r.spearman_p,
                          bootstrap_ci_low=lo, bootstrap_ci_high=hi,
                          circular_shift_p=shift_p,
                          pearson_r=r.pearson_r, pearson_p=r.pearson_p)

        # ---- boundary contrast -----------------------------------------
        rows, _is_b = boundary_contrast(
            {k: v for k, v in cov.items() if k not in ("insulation",)},
            boundaries, cm.n, args.boundary_flank)
        for r in rows:
            r.update(replicon=seqid, label=inp.label(seqid))
        contrast_rows += rows

        # ---- DE / DM enrichment at boundaries --------------------------
        if "n_DE" in cov and "n_genes_measured" in cov:
            isb = np.isin(np.arange(cm.n), boundaries)
            a = float(np.nansum(cov["n_DE"][isb]))
            b_ = float(np.nansum(cov["n_genes_measured"][isb]) - a)
            c = float(np.nansum(cov["n_DE"][~isb]))
            d = float(np.nansum(cov["n_genes_measured"][~isb]) - c)
            orr, p = contingency_test([a], [b_], [c], [d])
            stats.add(replicon=seqid, label=inp.label(seqid),
                      analysis="boundary_enrichment", term_a="DE_genes",
                      term_b="boundary_vs_interior", n=int(a + b_ + c + d),
                      odds_ratio=float(orr[0]), p=float(p[0]),
                      a=a, b=b_, c=c, d=d)
        if "n_DM" in cov and "n_genes" in cov:
            isb = np.isin(np.arange(cm.n), boundaries)
            a = float(np.nansum(cov["n_DM"][isb]))
            b_ = float(np.nansum(cov["n_genes"][isb]) - a)
            c = float(np.nansum(cov["n_DM"][~isb]))
            d = float(np.nansum(cov["n_genes"][~isb]) - c)
            orr, p = contingency_test([a], [b_], [c], [d])
            stats.add(replicon=seqid, label=inp.label(seqid),
                      analysis="boundary_enrichment", term_a="DM_genes",
                      term_b="boundary_vs_interior", n=int(a + b_ + c + d),
                      odds_ratio=float(orr[0]), p=float(p[0]),
                      a=a, b=b_, c=c, d=d)

        # ---- highly expressed genes at boundaries -----------------------
        # Le et al. (2013): bacterial CID boundaries coincide with highly
        # expressed genes. This is the direct expression<->3D test and needs
        # only what hicam already loaded.
        if "mean_log2FC" in cov and expr_by_locus is not None and "n_genes" in cov:
            expr_track = cov.get("expr_max_abs_lfc")
            if expr_track is not None and np.isfinite(expr_track).sum() > 10:
                isb = np.isin(np.arange(cm.n), boundaries)
                a_vals = expr_track[isb]; b_vals = expr_track[~isb]
                a_vals = a_vals[np.isfinite(a_vals)]
                b_vals = b_vals[np.isfinite(b_vals)]
                if a_vals.size >= 3 and b_vals.size >= 3:
                    p = np.nan
                    try:
                        from scipy.stats import mannwhitneyu
                        p = float(mannwhitneyu(a_vals, b_vals,
                                               alternative="greater").pvalue)
                    except ImportError:
                        pass
                    stats.add(replicon=seqid, label=inp.label(seqid),
                              analysis="boundary_expression",
                              term_a="max_abs_log2FC", term_b="boundary_vs_interior",
                              n=int(a_vals.size + b_vals.size),
                              boundary_mean=float(a_vals.mean()),
                              interior_mean=float(b_vals.mean()), p=p)

        # ---- contact vs co-methylation ---------------------------------
        cvs = None
        track = cov.get("mean_frac_modified")
        track_name = "mean_frac_modified"
        if track is None or not np.isfinite(track).sum() > 20:
            track = cov.get("meth_density")
            track_name = "meth_density"
        if track is not None:
            cvs = contact_vs_similarity(oe, track, circular, args.strata,
                                        args.max_pairs, args.seed)
        if cvs:
            stats.add(replicon=seqid, label=inp.label(seqid),
                      analysis="contact_vs_comethylation", term_a="contact_OE",
                      term_b=track_name, n=cvs["n_pairs"],
                      spearman_rho=cvs["rho_combined"], spearman_p=cvs["p_combined"],
                      n_strata=cvs["n_strata"])
            for r in cvs["per_stratum"]:
                r.update(replicon=seqid, label=inp.label(seqid), track=track_name)
            stratum_rows += cvs["per_stratum"]

        stats.add(replicon=seqid, label=inp.label(seqid), analysis="summary",
                  term_a="n_bins", term_b="", n=cm.n,
                  resolution=cm.resolution, n_boundaries=len(boundaries),
                  mean_domain_size_bp=(cm.n * cm.resolution / len(boundaries)
                                       if len(boundaries) else np.nan),
                  saddle_strength=strength, pc1_orientation_r=orient_r)

        # ---- differential organisation (two contact maps) ---------------
        diff = None
        if contacts2 and seqid in contacts2:
            diff = differential_maps(cm, contacts2[seqid], args, hic_labels, orient)
        if diff is not None:
            cov["delta_insulation"] = diff["delta_insulation"]
            cov["compartment_flip"] = diff["compartment_flip"].astype(float)
            stats.add(replicon=seqid, label=inp.label(seqid),
                      analysis="differential_hic", term_a="boundaries",
                      term_b=f"{hic_labels[0]}_vs_{hic_labels[1]}",
                      n=cm.n, n_shared=len(diff["shared"]),
                      n_only_a=len(diff["only_a"]), n_only_b=len(diff["only_b"]),
                      n_compartment_flips=int(diff["compartment_flip"].sum()),
                      mean_abs_delta_insulation=float(
                          np.nanmean(np.abs(diff["delta_insulation"]))))
            for name in ("meth_density", "mean_frac_modified", "frac_DE",
                         "expr_max_abs_lfc"):
                if name in cov:
                    r = correlate(cov["delta_insulation"], cov[name])
                    if r.n >= 10:
                        _o, sp = circular_shift_null(cov["delta_insulation"],
                                                     cov[name],
                                                     n_perm=args.n_shift,
                                                     seed=args.seed)
                        stats.add(replicon=seqid, label=inp.label(seqid),
                                  analysis="differential_hic_correlation",
                                  term_a="delta_insulation", term_b=name, n=r.n,
                                  spearman_rho=r.spearman_rho,
                                  spearman_p=r.spearman_p, circular_shift_p=sp)
            for b in diff["only_a"]:
                boundary_rows.append(dict(
                    replicon=seqid, label=inp.label(seqid), bin=int(b),
                    start=int(cm.starts[b]), end=int(cm.starts[b] + cm.resolution),
                    insulation=float(ins[b]), oriter_folded=np.nan,
                    condition=f"only_{hic_labels[0]}"))
            for b in diff["only_b"]:
                boundary_rows.append(dict(
                    replicon=seqid, label=inp.label(seqid), bin=int(b),
                    start=int(cm.starts[b]), end=int(cm.starts[b] + cm.resolution),
                    insulation=np.nan, oriter_folded=np.nan,
                    condition=f"only_{hic_labels[1]}"))

        if args.plots:
            written += make_figures(inp, cm, oe, ins, boundaries, cov, sd, strength,
                                    decay, cvs, args)
            if diff is not None:
                written += plot_differential(inp, cm, diff, hic_labels, args)

    import pandas as pd
    if bin_rows:
        p = inp.out("hic_bins.tsv")
        pd.concat(bin_rows, ignore_index=True).to_csv(p, sep="\t", index=False,
                                                      float_format="%.6g")
        written.append(p)
    if boundary_rows:
        p = inp.out("hic_boundaries.tsv")
        pd.DataFrame(boundary_rows).to_csv(p, sep="\t", index=False, float_format="%.6g")
        written.append(p)
        p = inp.out("hic_boundaries.bed")
        pd.DataFrame(boundary_rows)[["replicon", "start", "end"]].to_csv(
            p, sep="\t", index=False, header=False)
        written.append(p)
    if contrast_rows:
        p = inp.out("hic_boundary_contrast.tsv")
        pd.DataFrame(contrast_rows).to_csv(p, sep="\t", index=False, float_format="%.6g")
        written.append(p)
    if stratum_rows:
        p = inp.out("hic_comethylation_strata.tsv")
        pd.DataFrame(stratum_rows).to_csv(p, sep="\t", index=False, float_format="%.6g")
        written.append(p)
    p = inp.out("hic_integration.tsv")
    stats.write(p); written.append(p)

    warn_once(logger, "HIC_BIN_AUTOCORRELATION",
              "Correlations over Hi-C bins are computed on spatially autocorrelated "
              "data: neighbouring bins are not independent, so the p-values are "
              "anti-conservative. Read the rho, and treat the p-value as a rough "
              "screen.")

    print("\n=== hicam summary ===")
    for r in stats.rows:
        if r.get("analysis") == "summary":
            dom = r.get("mean_domain_size_bp", float("nan"))
            print(f"  {r['label']:<14} {r['n']:>5} bins @ {r['resolution']:,} bp | "
                  f"{r['n_boundaries']:>3} boundaries | mean domain "
                  f"{dom / 1000:.0f} kb | saddle {r.get('saddle_strength', float('nan')):.2f}")
    for r in stats.rows:
        if r.get("analysis") == "differential_hic":
            print(f"  {r['label']:<14} differential: {r['n_shared']} shared "
                  f"boundaries, {r['n_only_a']} only {hic_labels[0]}, "
                  f"{r['n_only_b']} only {hic_labels[1]}, "
                  f"{r['n_compartment_flips']} compartment flip(s)")
    for r in stats.rows:
        if r.get("analysis") == "contact_vs_comethylation":
            print(f"  {r['label']:<14} contact vs co-methylation ({r['term_b']}): "
                  f"rho={r['spearman_rho']:+.3f} p={r['spearman_p']:.2g} "
                  f"over {r['n_strata']} separation strata")
    print()
    C.finalize(inp, written, args, "merlin hicam")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
