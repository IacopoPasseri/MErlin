"""Command-line modules. Each exposes ``main(argv)`` and is runnable standalone."""

__all__ = ["xam", "dixam", "spacem", "mematch", "diem", "hicam", "phase",
           "discover", "mtase", "harmonise", "evidence", "report", "preflight",
           "doctor"]
