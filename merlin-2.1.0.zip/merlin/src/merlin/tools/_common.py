"""Shared CLI surface and input loading for every MErlin tool.

`load_inputs` is where modularity actually lives: it loads whichever layers were
supplied, reconciles their sequence identifiers against one canonical namespace,
and refuses to continue only when a layer that *was* supplied cannot be joined.
A methylation-only run and a methylation+expression+Hi-C run take the same code
path; the difference is which attributes of :class:`Inputs` are ``None``.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

from .. import io as mio
from ..logging_utils import LEDGER, get_logger, warn_once
from ..model import Annotation, MethylSet, mod_label
from ..seqids import SeqidResolution, reconcile, require_overlap, strip_version

logger = get_logger("cli")


# --------------------------------------------------------------------------- #
# Argument groups
# --------------------------------------------------------------------------- #
def add_annotation_args(p: argparse.ArgumentParser, required: bool = True) -> None:
    g = p.add_argument_group("annotation")
    g.add_argument("-g", "--gff", required=required, metavar="FILE",
                   help="GFF3 annotation (Prokka/Bakta/NCBI; may embed ##FASTA).")
    g.add_argument("--features", "--feature-types", dest="features", nargs="+",
                   default=None, metavar="TYPE",
                   help="GFF feature types to keep (default: all non-meta types).")
    g.add_argument("--id-attr", default="ID", metavar="ATTR",
                   help="GFF attribute used as the feature id "
                        "(falls back to locus_tag, then Name).")


def add_reference_args(p: argparse.ArgumentParser, required: bool = False) -> None:
    g = p.add_argument_group("reference sequence")
    g.add_argument("--fasta", required=required, default=None, metavar="FILE",
                   help="Reference FASTA. If omitted, an embedded ##FASTA block in "
                        "the GFF3 is used when present.")


def add_methylation_args(p: argparse.ArgumentParser, required: bool = True,
                         second: bool = False, replicates: bool = True) -> None:
    g = p.add_argument_group("methylation input")
    ex = g.add_mutually_exclusive_group(required=required)
    nargs = "+" if replicates else None
    ex.add_argument("--methylation", metavar="FILE", nargs=nargs,
                    help="Methylation calls: modkit bedMethyl, 6-column BED or "
                         "GFF3 modification calls (format auto-detected). "
                         + ("Several files are biological replicates of one "
                            "condition." if replicates else ""))
    ex.add_argument("-b", "--bed", metavar="FILE", nargs=nargs,
                    help="Alias for --methylation (kept for compatibility).")
    ex.add_argument("-m", "--methyl-gff", metavar="FILE", nargs=nargs,
                    help="Alias for --methylation (kept for compatibility).")
    if second:
        ex2 = p.add_argument_group("treatment methylation input").add_mutually_exclusive_group(
            required=required)
        ex2.add_argument("--methylation2", metavar="FILE", nargs=nargs,
                         help="Second-condition (treatment) replicates.")
        ex2.add_argument("-B", "--bed2", metavar="FILE", nargs=nargs,
                         help="Alias for --methylation2.")
        ex2.add_argument("-M", "--methyl-gff2", metavar="FILE", nargs=nargs,
                         help="Alias for --methylation2.")
    g.add_argument("--meth-format", default="auto",
                   choices=["auto", "bedmethyl", "bed6", "gff"],
                   help="Override methylation format detection.")
    g.add_argument("--mod-codes", default=None, metavar="CODES",
                   help="Comma-separated modification codes to keep (e.g. 'a,m').")
    g.add_argument("--min-coverage", type=float, default=0.0, metavar="X",
                   help="Minimum valid coverage for a call to be used.")
    g.add_argument("--min-frac", type=float, default=None, metavar="X",
                   help="Fraction-modified threshold for calling a position "
                        "methylated. Ignored for presence-only inputs.")


def add_seqid_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("sequence-id reconciliation")
    g.add_argument("--seqid-map", default=None, metavar="FILE",
                   help="Two-column TSV mapping input seqids to annotation/reference "
                        "seqids.")
    g.add_argument("--strip-version", action="store_true",
                   help="Strip a trailing '.N' version suffix from all seqids "
                        "(applied automatically when it reconciles the layers).")
    g.add_argument("--allow-rank-map", action="store_true",
                   help="Last-resort pairing of seqids by sorted rank order. This "
                        "is a guess; verify the reported mapping.")


def add_output_args(p: argparse.ArgumentParser, default_prefix: str = "sample") -> None:
    g = p.add_argument_group("output")
    g.add_argument("-o", "--outdir", "--output-dir", dest="outdir", required=True,
                   metavar="DIR", help="Output directory.")
    g.add_argument("--prefix", default=default_prefix, metavar="STR",
                   help="Prefix for output filenames.")
    g.add_argument("-n", "--name", default=None, metavar="FILENAME",
                   help="Base output name (compatibility alias for --prefix).")
    g.add_argument("--quiet", action="store_true", help="Reduce log verbosity.")
    g.add_argument("--provenance", action="store_true",
                   help="Also prefix every output table with commented provenance "
                        "lines. Off by default because it breaks readers that do "
                        "not skip '#'; a <prefix>.provenance.txt sidecar is always "
                        "written either way.")


def add_plot_args(p: argparse.ArgumentParser, default_on: bool = True) -> None:
    g = p.add_argument_group("plotting")
    if default_on:
        g.add_argument("--no-plot", action="store_true", help="Disable figures.")
    else:
        g.add_argument("--plots", action="store_true", help="Generate figures.")
    g.add_argument("--plot-format", default="png", choices=["png", "pdf", "svg"],
                   help="Figure format.")
    g.add_argument("--plot-dpi", type=int, default=150, metavar="DPI",
                   help="Raster resolution.")
    g.add_argument("--bins", type=int, default=200, metavar="N",
                   help="Positional bins for along-replicon figures.")


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
@dataclass
class Inputs:
    annotation: Annotation | None = None
    genome: dict[str, str] | None = None
    methyl: MethylSet | None = None
    methyl2: MethylSet | None = None
    methyl_reps: list = field(default_factory=list)
    methyl2_reps: list = field(default_factory=list)
    methyl_names: list = field(default_factory=list)
    methyl2_names: list = field(default_factory=list)
    covariates: object | None = None
    origins: dict | None = None
    resolution: SeqidResolution | None = None
    labels: dict[str, str] | None = None
    outdir: Path = Path(".")
    prefix: str = "sample"

    @property
    def has_reference(self) -> bool:
        return bool(self.genome)

    @property
    def mod_codes(self) -> list[str]:
        codes: set[str] = set()
        for ms in (self.methyl, self.methyl2):
            if ms is not None:
                codes |= ms.mod_codes
        return sorted(codes)

    def label(self, seqid: str) -> str:
        return (self.labels or {}).get(seqid, seqid)

    def out(self, suffix: str) -> Path:
        return self.outdir / f"{self.prefix}.{suffix}"


def methylation_paths(args, second: bool = False) -> list[str]:
    """Every file given for one condition, in order. Replicates are a list."""
    if second:
        raw = (getattr(args, "methylation2", None) or getattr(args, "bed2", None)
               or getattr(args, "methyl_gff2", None))
    else:
        raw = (getattr(args, "methylation", None) or getattr(args, "bed", None)
               or getattr(args, "methyl_gff", None))
    if raw is None:
        return []
    if isinstance(raw, str):
        raw = [raw]
    out: list[str] = []
    for item in raw:
        out += [x for x in str(item).split(",") if x]
    return out


def methylation_path(args, second: bool = False) -> str | None:
    paths = methylation_paths(args, second)
    return paths[0] if paths else None


def resolve_prefix(args) -> str:
    """``--name results.tsv`` (old style) and ``--prefix results`` mean the same."""
    name = getattr(args, "name", None)
    if name:
        return Path(name).stem
    return getattr(args, "prefix", "sample") or "sample"


def load_inputs(args, *, need_reference: bool = False,
                need_annotation: bool = True, second_methylation: bool = False,
                canonical: str | None = None) -> Inputs:
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    inp = Inputs(outdir=outdir, prefix=resolve_prefix(args))

    feature_types = set(args.features) if getattr(args, "features", None) else None
    if feature_types and len(feature_types) == 1:
        only = next(iter(feature_types))
        if "," in only:
            feature_types = set(only.split(","))
    keep_codes = (set(args.mod_codes.split(","))
                  if getattr(args, "mod_codes", None) else None)

    # -- annotation --------------------------------------------------------
    if getattr(args, "gff", None):
        inp.annotation = mio.read_annotation(
            args.gff, feature_types=feature_types,
            id_attr=getattr(args, "id_attr", "ID"))
    elif need_annotation:
        raise SystemExit("[FATAL] --gff is required.")

    # -- reference ---------------------------------------------------------
    fasta = getattr(args, "fasta", None)
    if fasta:
        inp.genome = mio.read_fasta(fasta)
        logger.info("Reference %s: %d replicon(s), %d bp.", Path(fasta).name,
                    len(inp.genome), sum(len(s) for s in inp.genome.values()))
    elif inp.annotation is not None and inp.annotation.embedded_fasta:
        inp.genome = inp.annotation.embedded_fasta
        logger.info("Using the FASTA block embedded in the annotation "
                    "(%d replicon(s)).", len(inp.genome))
    if need_reference and not inp.genome:
        raise SystemExit("[FATAL] a reference sequence is required: pass --fasta, "
                         "or use a GFF3 with an embedded ##FASTA block.")

    # -- methylation (one or more replicates per condition) ----------------
    def _load(paths):
        sets, names = [], []
        for path in paths:
            sets.append(mio.read_methylation(
                path, fmt=getattr(args, "meth_format", "auto"), keep_codes=keep_codes,
                min_coverage=getattr(args, "min_coverage", 0.0), min_frac=None))
            names.append(Path(path).name.split(".")[0])
        return sets, names

    inp.methyl_reps, inp.methyl_names = _load(methylation_paths(args))
    if inp.methyl_reps:
        inp.methyl = inp.methyl_reps[0]
        if len(inp.methyl_reps) > 1:
            logger.info("Condition 1: %d replicate(s) [%s].",
                        len(inp.methyl_reps), ", ".join(inp.methyl_names))
    if second_methylation:
        inp.methyl2_reps, inp.methyl2_names = _load(methylation_paths(args, True))
        if inp.methyl2_reps:
            inp.methyl2 = inp.methyl2_reps[0]
            if len(inp.methyl2_reps) > 1:
                logger.info("Condition 2: %d replicate(s) [%s].",
                            len(inp.methyl2_reps), ", ".join(inp.methyl2_names))

    # -- seqid reconciliation ---------------------------------------------
    namespaces: dict[str, set[str]] = {}
    if inp.genome:
        namespaces["reference"] = set(inp.genome)
    if inp.annotation is not None:
        namespaces["annotation"] = inp.annotation.seqids
    if inp.methyl_reps:
        namespaces["methylation"] = set().union(*(m.seqids for m in inp.methyl_reps))
    if inp.methyl2_reps:
        namespaces["methylation2"] = set().union(*(m.seqids for m in inp.methyl2_reps))

    canonical = canonical or ("reference" if inp.genome else "annotation")
    explicit = (mio.read_seqid_map(args.seqid_map)
                if getattr(args, "seqid_map", None) else None)
    res = reconcile(namespaces, canonical_key=canonical, explicit_map=explicit,
                    force_strip=getattr(args, "strip_version", False),
                    allow_rank_map=getattr(args, "allow_rank_map", False))
    inp.resolution = res

    if res.mapping or res.stripped:
        if inp.annotation is not None:
            for f in inp.annotation.features:
                f.seqid = res.apply(f.seqid)
            inp.annotation.seq_regions = {res.apply(k): v
                                          for k, v in inp.annotation.seq_regions.items()}
        if inp.genome:
            inp.genome = {res.apply(k): v for k, v in inp.genome.items()}
        inp.methyl_reps = [m.rename_seqids(res.mapping) for m in inp.methyl_reps]
        inp.methyl2_reps = [m.rename_seqids(res.mapping) for m in inp.methyl2_reps]
        inp.methyl = inp.methyl_reps[0] if inp.methyl_reps else None
        inp.methyl2 = inp.methyl2_reps[0] if inp.methyl2_reps else None

    hard = tuple(k for k in ("annotation", "methylation", "methylation2")
                 if k in namespaces)
    require_overlap(res, namespaces, canonical, hard=hard)

    inp.labels = mio.read_fasta_labels(fasta, strip_version if res.stripped else None)
    if not inp.labels and inp.genome:
        inp.labels = {k: k for k in inp.genome}

    # -- post-load sanity --------------------------------------------------
    if inp.methyl is not None and inp.annotation is not None:
        _warn_if_no_overlap(inp)
    return inp


def _warn_if_no_overlap(inp: Inputs) -> None:
    ann_ids = inp.annotation.seqids
    meth_ids = inp.methyl.seqids
    shared = ann_ids & meth_ids
    if not shared:
        return  # already fatal upstream
    only_meth = meth_ids - ann_ids
    if only_meth:
        n = int(sum(inp.methyl.seqid == s for s in only_meth).sum())
        warn_once(logger, "METH_ORPHAN_REPLICONS",
                  f"{len(only_meth)} replicon(s) carry methylation but have no "
                  f"annotated features ({', '.join(sorted(only_meth)[:3])}); "
                  f"{n} call(s) contribute to genome-wide totals but to no feature.")
    strands = inp.methyl.strands
    if strands == {"."}:
        warn_once(logger, "METH_UNSTRANDED",
                  "All methylation calls are unstranded ('.'): per-feature counts "
                  "are effectively strand-agnostic regardless of --ignore-strand.")


def build_provenance(args, inp: "Inputs", command: str):
    """Version, inputs with checksums, and every threshold that shaped the run."""
    from ..store import Provenance
    import sys as _sys
    argv = list(_sys.argv[1:])
    tool = command.split()[-1] if command else ""
    if argv and argv[0] == tool:
        argv = argv[1:]
    prov = Provenance(command=(command + " " + " ".join(argv)).strip())
    prov.add_input("annotation", getattr(args, "gff", None))
    prov.add_input("reference", getattr(args, "fasta", None))
    for i, path in enumerate(methylation_paths(args)):
        prov.add_input(f"methylation[{i}]", path)
    for i, path in enumerate(methylation_paths(args, True)):
        prov.add_input(f"methylation2[{i}]", path)
    for role in ("motifs", "geneexp", "dm_table", "hic", "modbam"):
        val = getattr(args, role, None)
        if isinstance(val, (list, tuple)):
            for i, path in enumerate(val):
                prov.add_input(f"{role}[{i}]", path)
        else:
            prov.add_input(role, val)
    for key in ("min_frac", "min_coverage", "ignore_strand", "padj_thr", "lfc_thr",
                "qvalue", "min_effect", "test", "test_on", "resolution",
                "insulation_window", "boundary_prominence", "regions", "operons"):
        val = getattr(args, key, None)
        if val is not None and val is not False:
            prov.thresholds[key] = val
    if inp is not None and inp.resolution is not None:
        prov.seqid_mapping = dict(list(inp.resolution.mapping.items())[:20])
    from ..logging_utils import LEDGER as _L
    prov.warnings = [f"[{c}] {m}" for c, m in _L.entries]
    return prov


def stamp_outputs(args, inp: "Inputs", written: list[Path], command: str) -> None:
    """Record provenance: always as a sidecar, inline only when asked.

    A rerun is only reproducible if the command line was saved, so every run
    writes one. Inline headers are opt-in because prefixing a TSV with '#' lines
    breaks any reader that does not skip them — gratuitously, for a record that
    fits in its own file.
    """
    from ..store import write_provenance_header
    prov = build_provenance(args, inp, command)
    try:
        side = (inp.out("provenance.txt") if inp is not None and hasattr(inp, "out")
                else None)
        if side is not None:
            side.write_text("\n".join(prov.header_lines("")) + "\n"
                            + ("\nwarnings:\n  " + "\n  ".join(prov.warnings)
                               if prov.warnings else ""), encoding="utf-8")
            written.append(side)
    except OSError:
        pass
    if not getattr(args, "provenance", False):
        return
    for path in written:
        if str(path).endswith((".tsv", ".bed")):
            try:
                write_provenance_header(path, prov)
            except OSError:
                pass


def finalize(inp: Inputs, written: list[Path], args=None, command: str = "") -> None:
    """Write the warning ledger next to the results and list what was produced."""
    if args is not None:
        stamp_outputs(args, inp, written, command)
    if LEDGER:
        path = inp.out("warnings.txt")
        LEDGER.write(path)
        written.append(path)
        logger.warning("%d data-quality warning(s) recorded -> %s",
                       len(LEDGER), path.name)
    logger.info("Files written (%d):", len(written))
    for p in written:
        logger.info("    %s", p)


def run_tool(main_fn, argv=None) -> int:
    """Uniform error handling for every tool entry point."""
    try:
        return main_fn(argv) or 0
    except SystemExit as exc:
        if isinstance(exc.code, str):
            print(exc.code, file=sys.stderr)
            return 3
        return int(exc.code or 0)
    except BrokenPipeError:  # pragma: no cover
        return 0
    except KeyboardInterrupt:  # pragma: no cover
        logger.error("Interrupted.")
        return 130


def mod_columns(codes) -> list[str]:
    return [mod_label(c) for c in codes]
