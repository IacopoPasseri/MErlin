"""evidence — one ranked, FDR-controlled score per gene across every layer.

    merlin evidence --store results/run1.merlin_store.h5 -o results/

2.0 left the reader with a per-layer FDR each and no way to combine them: a gene
significant in expression and a gene significant in methylation looked equally
important, and a gene significant in four layers looked no different from one
significant in one.

Two combinations are reported, because they answer different questions:

**Stouffer**  weighted sum of signed z-scores.  Uses the direction of each
    effect, so a gene that is up in expression and gains methylation scores
    differently from one that is up and loses it.  Requires the layers to be on
    a comparable evidential scale, which p-values roughly are.

**Robust rank aggregation**  the beta order-statistic p-value of a gene's
    normalised ranks.  Ignores direction and scale entirely, so it is the one to
    read when the layers are not comparable — a methylation-level difference and
    a log2 fold change are not.

Both get a BH FDR over genes.  The per-layer z-scores and ranks stay in the
output so a gene ranked highly for one strong reason is distinguishable from one
ranked highly for four weak ones — which the combined score alone cannot show.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from ..logging_utils import get_logger, warn_once
from ..stats import (benjamini_hochberg, p_to_z, robust_rank_aggregation,
                     stouffer)
from ..store import FEATURES, MerlinStore

logger = get_logger("evidence")


@dataclass
class Layer:
    """One line of evidence: where its p-value and its direction come from."""

    name: str
    p_col: str
    sign_col: str | None = None
    weight: float = 1.0
    description: str = ""


def discover_layers(columns) -> list[Layer]:
    """Infer the available layers from the store's column names."""
    cols = set(columns)
    layers: list[Layer] = []
    if "expr_padj" in cols:
        layers.append(Layer("expression", "expr_padj",
                            "expr_log2FoldChange" if "expr_log2FoldChange" in cols
                            else None,
                            description="differential expression"))
    dm_q = sorted(c for c in cols
                  if c.startswith("dmeth_") and c.endswith("_qvalue"))
    for q in dm_q:
        mod = q[len("dmeth_"):-len("_qvalue")]
        sign = next((c for c in (f"dmeth_{mod}_effect",
                                 f"dmeth_{mod}_delta_meth_level",
                                 f"dmeth_{mod}_log2FC_cpm") if c in cols), None)
        layers.append(Layer(f"dmeth_{mod}", q, sign,
                            description=f"differential methylation ({mod})"))
    if not dm_q and "dmeth_qvalue" in cols:
        layers.append(Layer("dmeth", "dmeth_qvalue",
                            "dmeth_effect" if "dmeth_effect" in cols else None,
                            description="differential methylation"))
    return layers


def rank_layers(df, columns) -> list[tuple[str, np.ndarray]]:
    """Rank-only layers: quantities with no p-value but a meaningful ordering."""
    out = []
    for col, name in (("motif_n_motif_occurrences", "motif_density"),
                      ("hic_insulation", "hic_insulation"),
                      ("motif_frac_methylated_on_motif", "motif_methylation")):
        if col in columns:
            v = df[col].to_numpy(dtype=float)
            if np.isfinite(v).sum() > 10 and np.nanstd(v) > 0:
                out.append((name, v))
    return out


def normalised_ranks(values, descending: bool = True) -> np.ndarray:
    """Ranks in (0, 1]; NaN stays NaN so absent layers do not vote."""
    v = np.asarray(values, float)
    out = np.full(v.shape, np.nan)
    ok = np.isfinite(v)
    if ok.sum() == 0:
        return out
    x = -v[ok] if descending else v[ok]
    order = np.argsort(x, kind="stable")
    r = np.empty(order.size)
    r[order] = np.arange(1, order.size + 1)
    out[ok] = r / order.size
    return out


# --------------------------------------------------------------------------- #
def compute_evidence(df, layers: list[Layer], rank_only, weights=None):
    import pandas as pd

    n = len(df)
    z_cols: dict[str, np.ndarray] = {}
    rank_cols: dict[str, np.ndarray] = {}
    for layer in layers:
        p = pd.to_numeric(df[layer.p_col], errors="coerce").to_numpy(dtype=float)
        sign = (pd.to_numeric(df[layer.sign_col], errors="coerce").to_numpy(dtype=float)
                if layer.sign_col and layer.sign_col in df.columns else None)
        z = p_to_z(p, sign)
        z_cols[layer.name] = z
        rank_cols[layer.name] = normalised_ranks(-p, descending=True)
    for name, values in rank_only:
        rank_cols[name] = normalised_ranks(np.abs(values), descending=True)

    out = pd.DataFrame({"locus_tag": df["locus_tag"]})
    for c in ("replicon", "start", "end", "gene", "product"):
        if c in df.columns:
            out[c] = df[c]
    for name, z in z_cols.items():
        out[f"z_{name}"] = z
    for name, r in rank_cols.items():
        out[f"rank_{name}"] = r

    if z_cols:
        Z = np.vstack(list(z_cols.values()))
        w = np.array([(weights or {}).get(name, 1.0) for name in z_cols], float)
        combined = np.full(n, np.nan)
        pvals = np.full(n, np.nan)
        for i in range(n):
            zz, pp = stouffer(Z[:, i], w)
            combined[i], pvals[i] = zz, pp
        out["stouffer_Z"] = combined
        out["stouffer_p"] = pvals
        out["stouffer_q"] = benjamini_hochberg(pvals)
    if rank_cols:
        rra = robust_rank_aggregation(list(rank_cols.values()), n)
        out["rra_score"] = rra
        out["rra_q"] = benjamini_hochberg(rra)
    out["n_layers"] = np.sum(
        [np.isfinite(v).astype(int) for v in
         list(z_cols.values()) + list(rank_cols.values())], axis=0)

    concordant = np.full(n, np.nan)
    if len(z_cols) >= 2:
        Z = np.vstack(list(z_cols.values()))
        with np.errstate(invalid="ignore"):
            signs = np.sign(Z)
        finite = np.isfinite(Z)
        pos = np.nansum(np.where(finite, signs > 0, 0), axis=0)
        neg = np.nansum(np.where(finite, signs < 0, 0), axis=0)
        tot = pos + neg
        concordant = np.where(tot > 0, np.maximum(pos, neg) / np.maximum(tot, 1),
                              np.nan)
    out["direction_concordance"] = concordant
    return out


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin evidence",
        description="Rank genes by combined evidence across every layer.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--store", metavar="FILE",
                     help="A merlin store written by 'merlin harmonise'.")
    src.add_argument("--features", metavar="TSV",
                     help="A harmonised feature table (TSV) instead of a store.")
    p.add_argument("--weights", nargs="*", default=None, metavar="LAYER=W",
                   help="Stouffer weights, e.g. 'expression=2 dmeth_6mA=1'.")
    p.add_argument("--top", type=int, default=25,
                   help="Rows printed in the console summary.")
    p.add_argument("--qvalue", type=float, default=0.05)
    p.add_argument("-o", "--outdir", required=True, metavar="DIR")
    p.add_argument("--prefix", default="evidence", metavar="STR")
    p.add_argument("--plots", action="store_true", help="Generate figures.")
    p.add_argument("--plot-format", default="png", choices=["png", "pdf", "svg"])
    p.add_argument("--plot-dpi", type=int, default=150)
    return p


def main(argv=None) -> int:
    import pandas as pd
    args = build_parser().parse_args(argv)
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    if args.store:
        with MerlinStore(args.store, "r") as st:
            df = st.read_table(FEATURES)
            prov = st.provenance
    else:
        df = pd.read_csv(args.features, sep="\t", comment="#", low_memory=False)
        prov = None
    if df.empty or "locus_tag" not in df.columns:
        raise SystemExit("[FATAL] the feature table is empty or has no locus_tag.")

    layers = discover_layers(df.columns)
    rank_only = rank_layers(df, set(df.columns))
    if not layers and not rank_only:
        raise SystemExit(
            "[FATAL] no scoreable layer found. The store needs at least one of: "
            "expr_padj (diem), dmeth_*_qvalue (dixam), motif_* (mematch), "
            "hic_insulation (hicam).")
    logger.info("Layers: %s%s",
                ", ".join(f"{l.name}({l.description})" for l in layers) or "none",
                ("; rank-only: " + ", ".join(n for n, _ in rank_only))
                if rank_only else "")
    if len(layers) < 2:
        warn_once(logger, "EVIDENCE_ONE_LAYER",
                  "Fewer than two p-value layers are present, so the combined "
                  "score is a re-ranking of a single layer rather than an "
                  "integration of several.")

    weights = {}
    for spec in (args.weights or []):
        if "=" in spec:
            k, v = spec.split("=", 1)
            try:
                weights[k] = float(v)
            except ValueError:
                raise SystemExit(f"[FATAL] cannot parse --weights {spec!r}") from None

    ev = compute_evidence(df, layers, rank_only, weights)
    sort_col = "stouffer_q" if "stouffer_q" in ev.columns else "rra_q"
    ev = ev.sort_values(sort_col, kind="stable").reset_index(drop=True)

    path = outdir / f"{args.prefix}.evidence.tsv"
    ev.to_csv(path, sep="\t", index=False, float_format="%.6g")
    written = [path]
    if prov is not None:
        from ..store import write_provenance_header
        write_provenance_header(path, prov)

    if args.plots:
        written += _plots(ev, layers, rank_only, outdir, args)

    n_sig = int((ev[sort_col] < args.qvalue).sum()) if sort_col in ev else 0
    print(f"\n=== evidence ===")
    print(f"  genes            : {len(ev):,}")
    print(f"  layers combined  : {len(layers)} p-value, {len(rank_only)} rank-only")
    print(f"  {sort_col} < {args.qvalue}: {n_sig:,}")
    show = [c for c in ("locus_tag", "gene", "n_layers", "stouffer_Z", "stouffer_q",
                        "rra_q", "direction_concordance") if c in ev.columns]
    if len(ev):
        print("\n" + ev[show].head(args.top).to_string(index=False,
                                                       float_format="%.3g"))
    print("\n  A high combined score with n_layers = 1 is one strong signal, not "
          "converging evidence;\n  read n_layers and direction_concordance next to "
          "the rank.\n")
    for p in written:
        logger.info("    %s", p)
    return 0


def _plots(ev, layers, rank_only, outdir, args):
    from .. import viz
    plt = viz.lazy_pyplot()
    if plt is None:
        return []
    written = []
    z_cols = [c for c in ev.columns if c.startswith("z_")]
    fig, axes = plt.subplots(1, 2 if len(z_cols) >= 2 else 1,
                             figsize=(11 if len(z_cols) >= 2 else 6, 4.8),
                             squeeze=False)
    ax = axes[0][0]
    if "stouffer_Z" in ev.columns:
        vals = ev["stouffer_Z"].to_numpy(dtype=float)
        vals = vals[np.isfinite(vals)]
        ax.hist(vals, bins=40, color=viz.PAL["dual"], alpha=0.85)
        ax.set_xlabel("combined Stouffer Z"); ax.set_ylabel("genes")
        ax.set_title("Combined evidence")
    else:
        viz.annotate_empty(ax)
    if len(z_cols) >= 2:
        ax = axes[0][1]
        x = ev[z_cols[0]].to_numpy(dtype=float)
        y = ev[z_cols[1]].to_numpy(dtype=float)
        n = ev["n_layers"].to_numpy(dtype=float)
        sc = ax.scatter(x, y, c=n, s=10, cmap="viridis", alpha=0.7, linewidths=0)
        fig.colorbar(sc, ax=ax, label="layers with data")
        ax.axhline(0, color="#555", lw=0.6); ax.axvline(0, color="#555", lw=0.6)
        ax.set_xlabel(z_cols[0]); ax.set_ylabel(z_cols[1])
        ax.set_title("Layer agreement (signed z)")
    fig.tight_layout()
    written.append(viz.savefig(fig, outdir / f"{args.prefix}.evidence.{args.plot_format}",
                               args.plot_dpi))
    return written


if __name__ == "__main__":
    from ._common import run_tool
    raise SystemExit(run_tool(main))
