"""preflight — check that the inputs actually join, before anything is computed.

Every MErlin join is on a seqid or a locus_tag, and both fail *silently*: a
namespace mismatch returns zero overlaps, which in the output is
indistinguishable from a genome with no methylation or a gene set with no
expression.  Running this first is what makes "no signal" a finding rather than
an artefact.

Exit codes: ``0`` clean, ``1`` warnings, ``2`` blocking problems.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import io as mio
from ..genome import gc_skew
from ..logging_utils import get_logger
from ..seqids import reconcile, strip_version

logger = get_logger("preflight")

OK, WARN, FAIL = "OK", "WARN", "FAIL"


class Report:
    def __init__(self):
        self.rows: list[tuple[str, str, str]] = []

    def add(self, level, check, message):
        self.rows.append((level, check, message))

    @property
    def worst(self) -> int:
        if any(r[0] == FAIL for r in self.rows):
            return 2
        if any(r[0] == WARN for r in self.rows):
            return 1
        return 0

    def render(self) -> str:
        out = ["MErlin preflight", "=" * 72, ""]
        for level, check, msg in self.rows:
            mark = {OK: "  ok  ", WARN: " WARN ", FAIL: " FAIL "}[level]
            out.append(f"[{mark}] {check}")
            for line in msg.splitlines():
                out.append(f"          {line}")
        verdict = {0: "All checks passed.",
                   1: "Warnings only — the run will work but read them first.",
                   2: "BLOCKING problems — fix these before running any module."}
        out += ["", "=" * 72, verdict[self.worst]]
        return "\n".join(out)


def _fmt(ids, k=4):
    ids = sorted(ids)
    return ", ".join(ids[:k]) + (" ..." if len(ids) > k else "")


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        prog="merlin preflight",
        description="Verify that MErlin's inputs join before running anything.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--gff", default=None)
    p.add_argument("--fasta", default=None)
    p.add_argument("--methylation", nargs="+", default=None)
    p.add_argument("--motifs", default=None)
    p.add_argument("--geneexp", default=None)
    p.add_argument("--meth-table", default=None,
                   help="An xam per-feature table, to check the diem join.")
    p.add_argument("--hic", default=None)
    p.add_argument("--modbam", nargs="+", default=None,
                   help="Basecalled BAM(s) with MM/ML tags, checked for the "
                        "pileup step.")
    p.add_argument("--strip-version", action="store_true")
    p.add_argument("--out", default=None, help="Write the report here as well.")
    args = p.parse_args(argv)

    rep = Report()
    for label, path in (("annotation", args.gff), ("reference", args.fasta),
                        ("motifs", args.motifs), ("expression", args.geneexp),
                        ("xam table", args.meth_table), ("hi-c", args.hic)):
        if path and not Path(path).exists():
            rep.add(FAIL, f"{label} file", f"{path} does not exist.")
    for path in (args.methylation or []):
        if not Path(path).exists():
            rep.add(FAIL, "methylation file", f"{path} does not exist.")
    for path in (args.modbam or []):
        if not Path(path).exists():
            rep.add(FAIL, "modbam file", f"{path} does not exist.")
    if rep.worst == 2:
        print(rep.render())
        return 2

    ann = genome = None
    namespaces: dict[str, set[str]] = {}

    if args.gff:
        ann = mio.read_annotation(args.gff)
        namespaces["annotation"] = ann.seqids
        n_locus = sum(1 for f in ann.features if f.locus_tag)
        rep.add(OK if ann.features else FAIL, "annotation",
                f"{len(ann.features)} feature(s) across {len(ann.seqids)} replicon(s); "
                f"types: {_fmt(ann.feature_types, 6)}\n"
                f"{n_locus} feature(s) carry a locus_tag.")
        if ann.features and n_locus < len(ann.features) * 0.5:
            rep.add(WARN, "annotation locus_tag",
                    "Fewer than half the features carry a locus_tag; diem joins "
                    "expression on this attribute and will lose the rest.")

    if args.fasta:
        genome = mio.read_fasta(args.fasta)
        namespaces["reference"] = set(genome)
        rep.add(OK, "reference",
                f"{len(genome)} replicon(s), {sum(len(s) for s in genome.values()):,} bp.")
    elif ann is not None and ann.embedded_fasta:
        genome = ann.embedded_fasta
        namespaces["reference"] = set(genome)
        rep.add(OK, "reference", "using the FASTA embedded in the annotation.")

    meths = []
    for i, path in enumerate(args.methylation or []):
        fmt, ncols = mio.sniff_methylation_format(path)
        ms = mio.read_methylation(path, fmt=fmt)
        meths.append(ms)
        namespaces[f"methylation{i + 1}" if i else "methylation"] = ms.seqids
        basis = ("presence-only (no fraction column)" if ms.presence_only
                 else "assayed with fraction-modified")
        rep.add(OK, f"methylation [{Path(path).name}]",
                f"format={fmt} ({ncols} columns), {len(ms):,} call(s), "
                f"modifications {sorted(ms.mod_codes)}, strands {sorted(ms.strands)}\n"
                f"basis: {basis}")
        if ms.presence_only:
            rep.add(WARN, f"methylation basis [{Path(path).name}]",
                    "No fraction-modified column. Every record counts as a methylated\n"
                    "position, mematch's site-level test switches to its genomic-background\n"
                    "variant, and dixam can only compare call distributions, not levels.")
        elif np.isfinite(ms.frac).any():
            lo = float(np.nanmin(ms.frac)); hi = float(np.nanmax(ms.frac))
            zero = float(np.mean(np.nan_to_num(ms.frac, nan=1.0) < 0.01))
            rep.add(OK if zero < 0.9 else WARN, f"methylation levels [{Path(path).name}]",
                    f"fraction modified spans {lo:.3f}-{hi:.3f}; "
                    f"{zero:.1%} of calls are below 1%.\n"
                    + ("Most positions are unmethylated — this looks like a full "
                       "bedMethyl.\nPass --min-frac so unmethylated assayed positions "
                       "are not counted as methylation." if zero >= 0.9 else
                       "Apply --min-frac to define 'methylated'."))
        if ms.strands == {"."}:
            rep.add(WARN, f"methylation strands [{Path(path).name}]",
                    "All calls are unstranded; per-feature counting is effectively "
                    "strand-agnostic.")

    # ---- modBAM, for the pileup step ------------------------------------
    for path in (args.modbam or []):
        name = Path(path).name
        try:
            from ..pileup import inspect_bam, resolve_backend
            st = inspect_bam(path)
        except SystemExit as exc:
            rep.add(FAIL, f"modbam [{name}]", str(exc))
            continue
        if not st.has_modifications:
            rep.add(FAIL, f"modbam [{name}]",
                    f"no MM/ML tags in the first {st.n_checked} read(s).\n"
                    f"This BAM was not produced by a modification-aware "
                    f"basecaller, or a downstream step dropped the tags.\n"
                    f"Without them there is nothing to pile up.")
            continue
        rep.add(OK, f"modbam [{name}]", st.describe())
        if not st.is_aligned:
            rep.add(WARN, f"modbam alignment [{name}]",
                    "unaligned. 'merlin pileup' will align it with minimap2 "
                    "(needs minimap2 and samtools on PATH),\nor pass an already "
                    "aligned BAM.")
        else:
            namespaces[f"modbam[{name}]"] = set(st.ref_names)
            if not st.is_coordinate_sorted or not st.has_index:
                rep.add(WARN, f"modbam index [{name}]",
                        "not coordinate-sorted and indexed; MErlin will sort and "
                        "index a copy, which costs time and disk.")
        if st.is_duplex:
            rep.add(WARN, f"modbam duplex [{name}]",
                    "duplex reads (dx tag) present. The pileup collapses them to "
                    "per-position counts;\nper-molecule hemimethylation needs "
                    "'merlin phase'.")
        backend, _exe, why = resolve_backend("auto")
        rep.add(OK if backend == "modkit" else WARN, "pileup backend",
                f"{backend}: {why}")

    # ---- seqid reconciliation -------------------------------------------
    if len(namespaces) >= 2:
        canonical = "reference" if "reference" in namespaces else "annotation"
        res = reconcile(namespaces, canonical_key=canonical,
                        force_strip=args.strip_version)
        problems = []
        for name, ids in namespaces.items():
            if name == canonical:
                continue
            mapped = {res.apply(i) for i in ids}
            if not (mapped & res.canonical):
                problems.append(f"{name}: [{_fmt(ids)}] shares nothing with "
                                f"{canonical}: [{_fmt(res.canonical)}]")
        if problems:
            hint = ""
            for name, ids in namespaces.items():
                if {strip_version(i) for i in ids} & {strip_version(c)
                                                      for c in namespaces[canonical]}:
                    hint = ("\nThey differ only by a trailing '.N' version suffix — "
                            "add --strip-version.")
                    break
            rep.add(FAIL, "seqid reconciliation",
                    "\n".join(problems) + hint
                    + "\nWithout a fix every per-feature count is zero, which looks "
                      "identical to a genome with no methylation.")
        else:
            note = f"method={res.method}"
            if res.stripped:
                note += "; a '.N' version suffix was stripped (pass --strip-version " \
                        "to the tools)"
            rep.add(OK, "seqid reconciliation",
                    f"{len(res.canonical)} shared replicon(s): [{_fmt(res.canonical)}]\n{note}")
            for name, missing in res.unmatched.items():
                rep.add(WARN, f"seqid coverage [{name}]",
                        f"{len(missing)} identifier(s) unmatched and ignored: "
                        f"{_fmt(missing)}")

    # ---- locus_tag join for diem ----------------------------------------
    if args.geneexp:
        ge = mio.read_geneexp(args.geneexp)
        ge_ids = set(ge["locus_tag"].astype(str))
        rep.add(OK, "expression",
                f"{len(ge)} row(s); {ge['padj'].notna().sum()} with an adjusted "
                f"p-value.")
        target, tname = None, ""
        if args.meth_table and Path(args.meth_table).exists():
            import pandas as pd
            mt = pd.read_csv(args.meth_table, sep=None, engine="python")
            key = "locus_tag" if "locus_tag" in mt.columns else mt.columns[0]
            target = set(mt[key].astype(str)); tname = "xam table"
        elif ann is not None:
            target = {f.locus_tag for f in ann.features if f.locus_tag}
            tname = "annotation locus_tags"
        if target:
            shared = ge_ids & target
            frac = len(shared) / max(len(ge_ids), 1)
            level = OK if frac > 0.5 else (WARN if shared else FAIL)
            msg = (f"{len(shared)}/{len(ge_ids)} expression id(s) match the {tname} "
                   f"({frac:.1%}).")
            if not shared:
                msg += (f"\nexpression ids look like: {_fmt(list(ge_ids)[:4])}"
                        f"\n{tname} look like:      {_fmt(list(target)[:4])}"
                        f"\ndiem would produce an empty table.")
            elif frac <= 0.5:
                msg += "\nMore than half the expression table will be dropped by diem."
            rep.add(level, "expression / methylation join", msg)

    # ---- motifs ----------------------------------------------------------
    if args.motifs:
        motifs = mio.read_motifs(args.motifs)
        no_off = [m for m, o in motifs if o is None]
        rep.add(OK, "motifs",
                f"{len(motifs)} motif(s): {_fmt([m for m, _ in motifs], 6)}")
        if no_off:
            rep.add(WARN, "motif offsets",
                    f"{len(no_off)} motif(s) carry no modified-base offset "
                    f"({_fmt(no_off, 4)}).\nSite-level statistics fall back to "
                    f"whole-motif coverage, which is coarser.")
        if genome:
            from ..motifs import find_motifs
            hits = find_motifs(genome, motifs)
            missing = [m for m, h in hits.items() if len(h) == 0]
            if missing:
                rep.add(WARN, "motif occurrence",
                        f"absent from the reference: {_fmt(missing)}")

    # ---- replication geometry -------------------------------------------
    if genome:
        weak = []
        for seqid, seq in genome.items():
            sp = gc_skew(seq)
            if sp.weak:
                weak.append(f"{seqid} (rel. amplitude {sp.relative_amplitude:.4f})")
        if weak:
            rep.add(WARN, "GC skew / oriC-ter",
                    "Weak cumulative GC skew on: " + "; ".join(weak)
                    + "\nspacem's ori->ter statistics for these replicons are "
                      "unreliable; supply --oric/--ter or read them as undefined.")
        else:
            rep.add(OK, "GC skew / oriC-ter",
                    "every replicon has a usable cumulative skew.")

    # ---- Hi-C ------------------------------------------------------------
    if args.hic:
        try:
            from ..hic import read_cool, read_dense, read_hicpro
            p_ = str(args.hic)
            if p_.endswith((".cool", ".mcool")):
                maps = read_cool(p_)
            elif p_.endswith(".matrix"):
                maps = read_hicpro(p_, p_.replace(".matrix", "_abs.bed"))
            else:
                maps = read_dense(p_, None, resolution=10000)
            sizes = {k: v.n for k, v in maps.items()}
            rep.add(OK, "hi-c", f"{len(maps)} chromosome(s); bins: {sizes}")
            if genome:
                shared = set(maps) & set(genome)
                if not shared and {strip_version(k) for k in maps} & {
                        strip_version(k) for k in genome}:
                    rep.add(WARN, "hi-c seqids",
                            "Hi-C chromosome names differ from the reference by a "
                            "version suffix; pass --strip-version to hicam.")
                elif not shared:
                    rep.add(FAIL, "hi-c seqids",
                            f"no Hi-C chromosome matches the reference "
                            f"({_fmt(maps)} vs {_fmt(genome)}).")
            small = [k for k, v in sizes.items() if v < 20]
            if small:
                rep.add(WARN, "hi-c resolution",
                        f"{small} have fewer than 20 bins: insulation and compartment "
                        f"calls will be unstable. Use a finer --resolution.")
        except Exception as exc:                     # noqa: BLE001
            rep.add(FAIL, "hi-c", f"could not be read: {type(exc).__name__}: {exc}")

    text = rep.render()
    print(text)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(text + "\n", encoding="utf-8")
    return rep.worst


if __name__ == "__main__":
    raise SystemExit(main())
