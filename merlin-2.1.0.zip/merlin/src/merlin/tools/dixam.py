"""dixam — differential methylation between two conditions, per annotated feature.

2.0.1 adds biological replication (ROADMAP 1.1) and regulatory geometry
(ROADMAP 1.3).

    # replicated design: a beta-binomial LRT with shrunken dispersion
    merlin dixam -g ann.gff3 \\
        --methylation  WT_1.bed WT_2.bed WT_3.bed \\
        --methylation2 KD_1.bed KD_2.bed KD_3.bed \\
        --labels WT KD -o results/

    # score promoters rather than whole CDSs
    merlin dixam ... --regions upstream:-300..50 body --operons

Model selection, and what each one can support:

* **>=2 replicates per condition, coverage + fraction available** — beta-binomial
  likelihood-ratio test.  Dispersion is estimated per feature and shrunk towards
  a level-dependent trend, so replicate scatter widens the null.  This is the
  only configuration whose q-values support a claim of differential methylation.
* **>=2 replicates, presence-only** — quasi-Poisson LRT on call counts with a
  library-size offset.
* **1 replicate per condition** — the 2.0 single-sample contingency test, which
  screens candidates.  The tool says so, loudly, in the output.

Changes from the original ``dixam.py`` are unchanged from 2.0: overlaps are
counted once per condition and vectorised, and the test compares methylation
level rather than the distribution of call positions whenever the input allows.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .. import viz
from ..genome import replicon_lengths
from ..intervals import FeatureIndex, count_per_feature, mean_frac_per_feature
from ..logging_utils import get_logger, warn_once
from ..model import mod_description, mod_label
from ..regions import (add_region_args, derive_regions, infer_operons,
                       operon_map, parse_region_specs)
from ..replicates import (Design, betabinomial_test, check_design,
                          quasipoisson_test)
from ..stats import benjamini_hochberg, contingency_test, log2_ratio
from . import _common as C

logger = get_logger("dixam")


# --------------------------------------------------------------------------- #
# Per-replicate read counting
# --------------------------------------------------------------------------- #
def read_counts(methyl, index, mods, ignore_strand):
    """Modified- and total-read sums per (feature, mod) for one sample.

    Returns ``(n_mod, n_total)`` or ``(None, None)`` when the sample carries no
    coverage — the signal that only a call-count model is available.
    """
    n_feat, n_mod = len(index), len(mods)
    nmod = np.zeros((n_feat, n_mod))
    ntot = np.zeros((n_feat, n_mod))
    if not methyl.has_coverage or methyl.presence_only:
        return None, None
    cov = np.nan_to_num(methyl.cov, nan=0.0)
    frac = np.nan_to_num(methyl.frac, nan=0.0)
    mod_reads = np.rint(cov * frac)
    groups = methyl.groups()
    for seqid, sf in index.by_seq.items():
        for j, mod in enumerate(mods):
            for strand in ("+", "-", "."):
                if (seqid, strand, mod) not in groups:
                    continue
                sel_mask = ((methyl.seqid == seqid) & (methyl.strand == strand)
                            & (methyl.mod == mod))
                idx = np.flatnonzero(sel_mask)
                if idx.size == 0:
                    continue
                idx = idx[np.argsort(methyl.pos[idx], kind="stable")]
                pos = methyl.pos[idx]
                cm = np.r_[0.0, np.cumsum(mod_reads[idx])]
                ct = np.r_[0.0, np.cumsum(cov[idx])]
                if ignore_strand:
                    rows = np.arange(len(sf.idx))
                else:
                    rows = np.flatnonzero((sf.strand == strand) | (sf.strand == ".")
                                          | (strand == "."))
                if rows.size == 0:
                    continue
                lo = np.searchsorted(pos, sf.start[rows], side="left")
                hi = np.searchsorted(pos, sf.end[rows], side="left")
                nmod[sf.idx[rows], j] += cm[hi] - cm[lo]
                ntot[sf.idx[rows], j] += ct[hi] - ct[lo]
    return nmod, ntot


def _filtered(sets, min_frac):
    if min_frac is None:
        return list(sets)
    return [s.filter(min_frac=min_frac) for s in sets]


# --------------------------------------------------------------------------- #
def build_differential(inp: C.Inputs, args, labels):
    import pandas as pd

    ann = inp.annotation
    index = FeatureIndex(ann)
    c_sets, t_sets = inp.methyl_reps, inp.methyl2_reps
    c_meth = _filtered(c_sets, args.min_frac)
    t_meth = _filtered(t_sets, args.min_frac)

    mods = sorted(set().union(*(s.mod_codes for s in c_meth + t_meth)) or {"a"})
    design = Design(labels=labels,
                    groups=np.r_[np.zeros(len(c_sets), int), np.ones(len(t_sets), int)],
                    sample_names=(inp.methyl_names + inp.methyl2_names))
    check_design(design)

    # per-sample call counts (always available)
    call_counts = [count_per_feature(index, s, mods, args.ignore_strand)
                   for s in c_meth + t_meth]
    lib_sizes = np.array([max(len(s), 1) for s in c_meth + t_meth], dtype=float)

    # per-sample read counts (only with coverage + fraction)
    test_on = args.test_on
    reads = [read_counts(s, index, mods, args.ignore_strand) for s in c_sets + t_sets] \
        if test_on in ("auto", "reads") else [(None, None)] * len(call_counts)
    reads_available = all(r[0] is not None for r in reads)
    if test_on == "reads" and not reads_available:
        raise SystemExit("[FATAL] --test-on reads needs coverage and "
                         "fraction-modified columns in every input.")
    use_reads = reads_available and test_on in ("auto", "reads")
    if not use_reads and test_on == "auto":
        warn_once(logger, "DIXAM_CALL_LEVEL_TEST",
                  "No coverage/fraction columns available: dixam is comparing the "
                  "DISTRIBUTION of methylation calls between conditions, not "
                  "methylation level. A feature can change here because sequencing "
                  "depth changed. Use modkit bedMethyl input for a level comparison.")

    c_cols = np.flatnonzero(design.groups == 0)
    t_cols = np.flatnonzero(design.groups == 1)
    c_total = max(sum(len(s) for s in c_meth), 1)
    t_total = max(sum(len(s) for s in t_meth), 1)

    feats = ann.features
    base = pd.DataFrame({
        "replicon": [f.seqid for f in feats],
        "feature_type": [f.ftype for f in feats],
        "feat_start": [f.start for f in feats],
        "feat_end": [f.end for f in feats],
        "strand": [f.strand for f in feats],
        "feat_length_bp": [f.length for f in feats],
        "locus_tag": [f.locus_tag for f in feats],
        "gene": [f.gene for f in feats],
        "product": [f.product for f in feats],
    })
    if getattr(args, "_operon_map", None):
        om = args._operon_map
        base["operon"] = [om.get(f.locus_tag, ("", 0, ""))[0] for f in feats]
        base["operon_position"] = [om.get(f.locus_tag, ("", 0, ""))[1] for f in feats]
        base["operon_leader"] = [om.get(f.locus_tag, ("", 0, ""))[2] for f in feats]
    length = base["feat_length_bp"].to_numpy(dtype=float)
    c_lab, t_lab = labels

    frames = []
    model_used = "single-sample contingency"
    for j, mod in enumerate(mods):
        cr = np.sum([call_counts[i][:, j] for i in c_cols], axis=0).astype(float)
        tr = np.sum([call_counts[i][:, j] for i in t_cols], axis=0).astype(float)
        keep = (cr > 0) | (tr > 0)
        if not keep.any():
            continue
        sub = base.loc[keep].copy()
        crk, trk = cr[keep], tr[keep]
        ln = np.maximum(length[keep], 1.0)
        sub["mod_code"] = mod
        sub["mod_label"] = mod_label(mod)
        sub["mod_description"] = mod_description(mod)
        sub[f"{c_lab}_raw"] = crk.astype(int)
        sub[f"{t_lab}_raw"] = trk.astype(int)
        c_cpm, t_cpm = 1e6 * crk / c_total, 1e6 * trk / t_total
        sub[f"{c_lab}_cpm"] = c_cpm
        sub[f"{t_lab}_cpm"] = t_cpm
        sub[f"{c_lab}_norm"] = crk / ln
        sub[f"{t_lab}_norm"] = trk / ln
        sub["delta_raw"] = (trk - crk).astype(int)
        sub["delta_cpm"] = t_cpm - c_cpm
        sub["log2FC_cpm"] = log2_ratio(t_cpm, c_cpm, args.pseudocount)
        sub["mean_cpm"] = (c_cpm + t_cpm) / 2.0
        sub["n_replicates"] = f"{design.n_control}v{design.n_treatment}"

        if design.replicated and use_reads:
            m = np.column_stack([reads[i][0][keep, j] for i in range(len(reads))])
            n = np.column_stack([reads[i][1][keep, j] for i in range(len(reads))])
            rr = betabinomial_test(m, n, design, prior_weight=args.dispersion_prior,
                                   dist=args.lrt_dist)
            model_used = rr.model
            sub[f"{c_lab}_meth_level"] = rr.level_control
            sub[f"{t_lab}_meth_level"] = rr.level_treatment
            sub["delta_meth_level"] = rr.effect
            sub["dispersion"] = rr.dispersion
            sub["dispersion_trend"] = rr.dispersion_trend
            sub["LR_statistic"] = rr.statistic
            sub["effect"] = rr.effect
            sub["effect_name"] = "delta_meth_level"
            sub["pvalue"] = rr.pvalue
            sub["test"] = rr.model
            for k, name in enumerate(design.sample_names):
                sub[f"level_{viz.safe_name(name)}_{k}"] = rr.per_replicate["levels"][:, k]
            sub["odds_ratio"] = np.nan
        elif design.replicated:
            y = np.column_stack([call_counts[i][keep, j] for i in range(len(call_counts))])
            rr = quasipoisson_test(y.astype(float), lib_sizes, design)
            model_used = rr.model
            sub["dispersion"] = rr.dispersion
            sub["dispersion_trend"] = rr.dispersion_trend
            sub["LR_statistic"] = rr.statistic
            sub["effect"] = rr.effect
            sub["effect_name"] = "log2FC_calls"
            sub["pvalue"] = rr.pvalue
            sub["test"] = rr.model
            sub["odds_ratio"] = np.nan
        elif use_reads:
            a = reads[t_cols[0]][0][keep, j]
            b = np.maximum(reads[t_cols[0]][1][keep, j] - a, 0)
            c_ = reads[c_cols[0]][0][keep, j]
            d = np.maximum(reads[c_cols[0]][1][keep, j] - c_, 0)
            with np.errstate(invalid="ignore", divide="ignore"):
                c_level = np.where((c_ + d) > 0, c_ / np.maximum(c_ + d, 1), np.nan)
                t_level = np.where((a + b) > 0, a / np.maximum(a + b, 1), np.nan)
            sub[f"{c_lab}_meth_level"] = c_level
            sub[f"{t_lab}_meth_level"] = t_level
            sub["delta_meth_level"] = t_level - c_level
            orr, p = contingency_test(a, b, c_, d, method=args.test)
            sub["odds_ratio"], sub["pvalue"] = orr, p
            sub["test"] = "reads(mod vs canonical), single sample"
            sub["effect"] = sub["delta_meth_level"]
            sub["effect_name"] = "delta_meth_level"
            model_used = "single-sample read contingency"
        else:
            c_tot_mod = sum(s.totals_per_mod().get(mod, 0) for s in c_meth)
            t_tot_mod = sum(s.totals_per_mod().get(mod, 0) for s in t_meth)
            a, b = trk, np.maximum(t_tot_mod - trk, 0)
            c_, d = crk, np.maximum(c_tot_mod - crk, 0)
            orr, p = contingency_test(a, b, c_, d, method=args.test)
            sub["odds_ratio"], sub["pvalue"] = orr, p
            sub["test"] = "calls(in-feature vs rest), single sample"
            sub["effect"] = sub["log2FC_cpm"]
            sub["effect_name"] = "log2FC_cpm"
            model_used = "single-sample call contingency"
        frames.append(sub)

    if not frames:
        return (pd.DataFrame(), mods, index, (c_meth, t_meth), (c_total, t_total),
                use_reads, {}, design, model_used)

    table = pd.concat(frames, ignore_index=True)
    if not args.no_test:
        table["qvalue"] = np.nan
        for mod in mods:
            m = table["mod_code"] == mod
            if m.any():
                table.loc[m, "qvalue"] = benjamini_hochberg(
                    table.loc[m, "pvalue"].to_numpy(dtype=float))
    else:
        table = table.drop(columns=["pvalue", "odds_ratio", "test"], errors="ignore")

    if args.min_effect > 0 and "effect" in table:
        weak = table["effect"].abs() < args.min_effect
        if "qvalue" in table:
            table.loc[weak, "qvalue"] = np.nan
        logger.info("%d feature(s) fall below --min-effect %g and are not reported "
                    "as differential.", int(weak.sum()), args.min_effect)
    table = table.sort_values(["replicon", "feat_start", "mod_code"],
                              kind="stable").reset_index(drop=True)

    global_shift = {}
    if use_reads:
        for j, mod in enumerate(mods):
            cm_ = sum(reads[i][0][:, j].sum() for i in c_cols)
            ct_ = sum(reads[i][1][:, j].sum() for i in c_cols)
            tm_ = sum(reads[i][0][:, j].sum() for i in t_cols)
            tt_ = sum(reads[i][1][:, j].sum() for i in t_cols)
            cl = cm_ / ct_ if ct_ else np.nan
            tl = tm_ / tt_ if tt_ else np.nan
            global_shift[mod] = (float(cl), float(tl), float(tl - cl))
    return (table, mods, index, (c_meth, t_meth), (c_total, t_total), use_reads,
            global_shift, design, model_used)


# --------------------------------------------------------------------------- #
def write_condition_tables(inp, index, meths, labels, mods, args) -> list[Path]:
    from .xam import COLUMNS
    import pandas as pd

    written = []
    feats = inp.annotation.features
    base = pd.DataFrame({
        "replicon": [f.seqid for f in feats],
        "feature_type": [f.ftype for f in feats],
        "feat_start": [f.start for f in feats],
        "feat_end": [f.end for f in feats],
        "strand": [f.strand for f in feats],
        "feat_length_bp": [f.length for f in feats],
        "locus_tag": [f.locus_tag for f in feats],
        "gene": [f.gene for f in feats],
        "product": [f.product for f in feats],
    })
    length = base["feat_length_bp"].to_numpy(dtype=float)
    for group, label in zip(meths, labels):
        counts = np.sum([count_per_feature(index, s, mods, args.ignore_strand)
                         for s in group], axis=0)
        total = max(sum(len(s) for s in group), 1)
        frames = []
        for j, mod in enumerate(mods):
            raw = counts[:, j]
            keep = raw > 0
            if not keep.any():
                continue
            sub = base.loc[keep].copy()
            ln = np.maximum(length[keep], 1.0)
            sub["mod_code"] = mod
            sub["mod_label"] = mod_label(mod)
            sub["mod_description"] = mod_description(mod)
            sub["raw_count"] = raw[keep]
            sub["norm_count"] = raw[keep] / ln
            sub["calls_per_kb"] = 1000.0 * raw[keep] / ln
            sub["cpm"] = 1e6 * raw[keep] / total
            mf = np.nanmean(np.column_stack(
                [mean_frac_per_feature(index, s, mod, args.ignore_strand)
                 for s in group]), axis=1)
            sub["mean_frac_modified"] = mf[keep]
            frames.append(sub)
        out = (pd.concat(frames, ignore_index=True)[COLUMNS] if frames
               else pd.DataFrame(columns=COLUMNS))
        path = inp.out(f"by_feature.{viz.safe_name(label)}.tsv")
        out.to_csv(path, sep="\t", index=False, float_format="%.8g")
        logger.info("  [%s] %d row(s) -> %s", label, len(out), path.name)
        written.append(path)
    return written


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def plot_overlay(inp, meths, totals, labels, mods, lengths, fmt, bins, dpi):
    plt = viz.lazy_pyplot()
    if plt is None:
        return []
    c_group, t_group = meths
    reps = sorted(r for r in lengths
                  if any((s.seqid == r).any() for s in c_group + t_group))
    if not reps:
        return []
    scale, unit = viz.coord_unit(max(lengths[r] for r in reps))
    cs, ts = 1e6 / totals[0], 1e6 / totals[1]
    out = []

    def positions(group, rep, mod):
        arrs = [s.positions(rep, mod) for s in group]
        return np.concatenate(arrs) if arrs else np.empty(0)

    for kind in ("overlay", "diff"):
        fig, axes = plt.subplots(len(reps), len(mods), squeeze=False,
                                 figsize=(max(4.5 * len(mods), 6),
                                          max(2.2 * len(reps), 3)))
        for i, rep in enumerate(reps):
            edges = np.linspace(0, lengths[rep], bins + 1)
            centres = (edges[:-1] + edges[1:]) / 2.0 / scale
            for j, mod in enumerate(mods):
                ax = axes[i][j]
                cc, _ = np.histogram(positions(c_group, rep, mod), bins=edges)
                tc, _ = np.histogram(positions(t_group, rep, mod), bins=edges)
                if kind == "overlay":
                    ax.plot(centres, cc * cs, drawstyle="steps-mid",
                            color=viz.PAL["control"], lw=0.9, label=labels[0])
                    ax.plot(centres, tc * ts, drawstyle="steps-mid",
                            color=viz.PAL["treatment"], lw=0.9, label=labels[1])
                    ax.fill_between(centres, cc * cs, step="mid",
                                    color=viz.PAL["control"], alpha=0.20)
                    ax.fill_between(centres, tc * ts, step="mid",
                                    color=viz.PAL["treatment"], alpha=0.20)
                    if i == 0 and j == len(mods) - 1:
                        ax.legend(fontsize=8, frameon=True)
                    ylab = "CPM / bin"
                else:
                    delta = tc * ts - cc * cs
                    ax.fill_between(centres, delta, 0, where=(delta >= 0), step="mid",
                                    color=viz.PAL["gain"], alpha=0.85, lw=0)
                    ax.fill_between(centres, delta, 0, where=(delta < 0), step="mid",
                                    color=viz.PAL["loss"], alpha=0.85, lw=0)
                    ax.axhline(0, color="black", lw=0.5)
                    ylab = "dCPM / bin"
                if i == 0:
                    ax.set_title(f"{mod_label(mod)} ({mod})", fontsize=10)
                if j == 0:
                    ax.set_ylabel(f"{inp.label(rep)}\n{ylab}", fontsize=8)
                if i == len(reps) - 1:
                    ax.set_xlabel(f"position ({unit})", fontsize=8)
                ax.tick_params(labelsize=7); ax.margins(x=0)
        if kind == "diff":
            from matplotlib.patches import Patch
            fig.legend(handles=[Patch(facecolor=viz.PAL["gain"], label=f"gain in {labels[1]}"),
                                Patch(facecolor=viz.PAL["loss"], label=f"loss in {labels[1]}")],
                       loc="upper right", fontsize=8, frameon=True)
            fig.suptitle(f"Differential methylation along replicon(s): "
                         f"{labels[1]} - {labels[0]} (dCPM)", fontsize=12)
        else:
            fig.suptitle(f"Methylation along replicon(s): {labels[0]} vs {labels[1]} "
                         f"(library-size normalised)", fontsize=12)
        fig.tight_layout(rect=(0, 0, 1, 0.96))
        out.append(viz.savefig(fig, inp.out(f"along_replicons_{kind}.{fmt}"), dpi))
    return out


def plot_ma_volcano(inp, table, labels, mods, fmt, dpi, qthr):
    plt = viz.lazy_pyplot()
    if plt is None or table.empty or "qvalue" not in table or "effect" not in table:
        return []
    n_panels = 3 if "dispersion" in table else 2
    fig, axes = plt.subplots(1, n_panels, figsize=(6 * n_panels, 5))
    q = table["qvalue"].to_numpy(dtype=float)
    eff = table["effect"].to_numpy(dtype=float)
    eff_name = str(table["effect_name"].iloc[0])
    mean = table["mean_cpm"].to_numpy(dtype=float)
    sig = np.isfinite(q) & (q < qthr)
    ylab = (f"log2 {labels[1]} / {labels[0]}" if "log2" in eff_name
            else f"methylation level {labels[1]} - {labels[0]}")

    ax = axes[0]
    x = np.log10(np.maximum(mean, 1e-3))
    ax.scatter(x[~sig], eff[~sig], s=6, color=viz.PAL["neutral"], alpha=0.5, linewidths=0)
    ax.scatter(x[sig], eff[sig], s=8, color=viz.PAL["dual"], alpha=0.8, linewidths=0)
    ax.axhline(0, color="#555", lw=0.8, ls="--")
    ax.set_xlabel("log10 mean CPM"); ax.set_ylabel(ylab)
    ax.set_title(f"MA — differential methylation ({int(sig.sum())} at q<{qthr})")

    ax = axes[1]
    with np.errstate(divide="ignore"):
        y = -np.log10(np.clip(q, 1e-300, 1))
    ax.scatter(eff[~sig], y[~sig], s=6, color=viz.PAL["neutral"], alpha=0.5, linewidths=0)
    ax.scatter(eff[sig], y[sig], s=8, color=viz.PAL["dual"], alpha=0.8, linewidths=0)
    ax.axhline(-np.log10(qthr), color="#555", lw=0.8, ls=":")
    ax.set_xlabel(ylab); ax.set_ylabel("-log10 q")
    ax.set_title(f"Volcano ({eff_name})")

    if n_panels == 3:
        ax = axes[2]
        lvl = table.get(f"{labels[0]}_meth_level")
        xv = (lvl.to_numpy(dtype=float) if lvl is not None
              else np.log10(np.maximum(mean, 1e-3)))
        ax.scatter(xv, table["dispersion"], s=6, color=viz.PAL["neutral"],
                   alpha=0.5, linewidths=0, label="shrunken per-feature")
        order = np.argsort(xv)
        ax.plot(xv[order], table["dispersion_trend"].to_numpy()[order], lw=1.6,
                color=viz.PAL["DE"], label="trend")
        ax.set_xlabel("methylation level" if lvl is not None else "log10 mean CPM")
        ax.set_ylabel("dispersion")
        ax.set_title("Dispersion after empirical-Bayes shrinkage")
        ax.legend(fontsize=8, frameon=False)
    fig.tight_layout()
    return [viz.savefig(fig, inp.out(f"differential_ma_volcano.{fmt}"), dpi)]


# --------------------------------------------------------------------------- #
def print_summary(inp, table, labels, mods, totals, use_reads, qthr, global_shift,
                  design, model_used) -> None:
    sep, sep2 = "=" * 76, "-" * 76
    c_lab, t_lab = labels
    print(f"\n{sep}\n  dixam — differential methylation x annotation\n"
          f"  design      : {design.describe()}\n"
          f"  model       : {model_used}\n"
          f"  library size: {c_lab}={totals[0]:,}  {t_lab}={totals[1]:,}\n{sep}")
    if table.empty:
        print("\n  No feature carries methylation in either condition.\n")
        return
    print(f"\n  In-feature calls by modification\n  {sep2}")
    print(f"  {'code':<6}{'label':<8}{c_lab:>14}{t_lab:>14}{'delta':>14}")
    for mod in mods:
        m = table["mod_code"] == mod
        cv = int(table.loc[m, f"{c_lab}_raw"].sum())
        tv = int(table.loc[m, f"{t_lab}_raw"].sum())
        print(f"  {mod:<6}{mod_label(mod):<8}{cv:>14,}{tv:>14,}{tv - cv:>+14,}")

    if global_shift:
        print(f"\n  Genome-wide methylation level (all in-feature reads)\n  {sep2}")
        print(f"  {'code':<6}{'label':<8}{c_lab:>14}{t_lab:>14}{'delta':>14}")
        for mod, (cl, tl, dl) in global_shift.items():
            print(f"  {mod:<6}{mod_label(mod):<8}{cl:>14.4f}{tl:>14.4f}{dl:>+14.4f}")

    if "dispersion" in table:
        d = table["dispersion"].to_numpy(dtype=float)
        d = d[np.isfinite(d)]
        if d.size:
            print(f"\n  Dispersion (shrunken): median {np.median(d):.4f}, "
                  f"IQR {np.percentile(d, 25):.4f}-{np.percentile(d, 75):.4f}")

    if "qvalue" in table:
        sig = table[table["qvalue"] < qthr]
        eff = sig["effect"] if "effect" in sig else sig["log2FC_cpm"]
        up, down = int((eff > 0).sum()), int((eff < 0).sum())
        frac = len(sig) / max(len(table), 1)
        print(f"\n  Differential features (BH q < {qthr}): {len(sig)} "
              f"({frac:.0%} of tested)")
        print(f"    up in {t_lab}: {up}   |   down in {t_lab}: {down}")
        if frac > 0.5:
            warn_once(logger, "DIXAM_GLOBAL_SHIFT",
                      f"{frac:.0%} of features are called differential. That is the "
                      f"signature of a genome-wide shift in methylation, not of "
                      f"feature-specific differential methylation. Rank by effect "
                      f"size, and use --min-effect to require a change larger than "
                      f"the global one.")
        top = sig.reindex(sig["qvalue"].sort_values().index).head(10)
        if len(top):
            eff_name = str(table["effect_name"].iloc[0])
            print(f"  {sep2}")
            print(f"  {'locus_tag':<16}{'gene':<10}{'mod':<6}"
                  f"{eff_name[:10]:>11}{'qvalue':>11}")
            for _, r in top.iterrows():
                print(f"  {str(r['locus_tag'])[:15]:<16}{str(r['gene'])[:9]:<10}"
                      f"{r['mod_label']:<6}{r.get('effect', float('nan')):>11.3f}"
                      f"{r['qvalue']:>11.2e}")
        if not design.replicated:
            print("\n  No biological replication: these q-values screen candidates "
                  "rather than establish differential\n  methylation. Supply "
                  "replicates (--methylation a.bed b.bed c.bed) for a test that can.")
    print(f"\n{sep}\n")


# --------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin dixam",
        description="Differential methylation between two conditions per feature.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    C.add_annotation_args(p)
    C.add_reference_args(p)
    C.add_methylation_args(p, second=True)
    C.add_seqid_args(p)
    add_region_args(p)
    C.add_output_args(p, default_prefix="dixam")
    C.add_plot_args(p)
    g = p.add_argument_group("differential")
    g.add_argument("--labels", nargs=2, default=["control", "treatment"],
                   metavar=("CONTROL", "TREATMENT"),
                   help="Condition labels used in columns, filenames and figures.")
    g.add_argument("--pseudocount", type=float, default=1.0, metavar="X",
                   help="Pseudocount (CPM units) added before the log2 ratio.")
    g.add_argument("--test", default="auto", choices=["auto", "fisher", "chi2"],
                   help="Single-sample association test.")
    g.add_argument("--test-on", default="auto", choices=["auto", "reads", "calls"],
                   help="Compare modified-vs-canonical reads (needs bedMethyl) or "
                        "the distribution of calls.")
    g.add_argument("--lrt-dist", default="chi2", choices=["chi2", "f"],
                   help="Reference distribution for the replicate LRT. chi2 is "
                        "mildly anti-conservative at small n; f is conservative.")
    g.add_argument("--dispersion-prior", type=float, default=5.0, metavar="X",
                   help="Shrinkage weight of the dispersion trend. Larger pulls "
                        "per-feature dispersions harder towards the trend.")
    g.add_argument("--no-test", action="store_true", help="Skip testing entirely.")
    g.add_argument("--qvalue", type=float, default=0.05, metavar="X",
                   help="q-value threshold used for reporting and figures.")
    g.add_argument("--min-effect", type=float, default=0.0, metavar="X",
                   help="Minimum |effect| for a feature to be called differential.")
    g.add_argument("--ignore-strand", action="store_true",
                   help="Count methylation on both strands per feature.")
    g.add_argument("--no-split", action="store_true",
                   help="Write one combined differential TSV instead of one per mod.")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    labels = (viz.safe_name(args.labels[0]), viz.safe_name(args.labels[1]))
    if labels[0] == labels[1]:
        raise SystemExit("[FATAL] the two condition labels must differ.")
    inp = C.load_inputs(args, second_methylation=True)
    if not inp.methyl_reps or not inp.methyl2_reps:
        raise SystemExit("[FATAL] both conditions need methylation input.")

    lengths = replicon_lengths(inp.genome, inp.annotation.seq_regions,
                               inp.annotation.features, inp.methyl)
    args._operon_map = None
    if args.operons:
        operons = infer_operons(inp.annotation, args.operon_max_gap)
        args._operon_map = operon_map(operons)
    if args.regions:
        inp.annotation = derive_regions(inp.annotation,
                                        parse_region_specs(args.regions), lengths)

    (table, mods, index, meths, totals, use_reads, global_shift, design,
     model_used) = build_differential(inp, args, labels)
    written = write_condition_tables(inp, index, meths, labels, mods, args)

    if not table.empty:
        if args.no_split:
            path = inp.out("differential.tsv")
            table.to_csv(path, sep="\t", index=False, float_format="%.6g")
            logger.info("  [differential] %d row(s) -> %s", len(table), path.name)
            written.append(path)
        else:
            for mod in mods:
                sub = table[table["mod_code"] == mod]
                path = inp.out(f"differential.{mod_label(mod)}.tsv")
                sub.to_csv(path, sep="\t", index=False, float_format="%.6g")
                logger.info("  [differential %s] %d row(s) -> %s",
                            mod_label(mod), len(sub), path.name)
                written.append(path)

    if not args.no_plot:
        written += plot_overlay(inp, meths, totals, labels, mods, lengths,
                                args.plot_format, args.bins, args.plot_dpi)
        written += plot_ma_volcano(inp, table, labels, mods, args.plot_format,
                                   args.plot_dpi, args.qvalue)

    print_summary(inp, table, labels, mods, totals, use_reads, args.qvalue,
                  global_shift, design, model_used)
    C.finalize(inp, written, args, "merlin dixam")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
