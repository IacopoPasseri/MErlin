"""pileup — basecalled modBAM in, bedMethyl out.

    merlin pileup --modbam reads.bam --fasta ref.fasta -o results/pileup

This is the module that lets a user start from raw basecalling output instead of
a bedMethyl someone else produced. It runs ``modkit pileup`` when modkit is on
PATH and MErlin's own pysam pileup when it is not, aligning the reads first if
the BAM is unaligned and minimap2 is available.

The output is a modkit-format bedMethyl, so every other module — ``xam``,
``dixam``, ``spacem``, ``mematch``, ``discover``, ``mtase`` — takes it directly.
``merlin run`` inserts this step automatically when a config supplies ``modbam``
and no ``methylation``.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from ..logging_utils import get_logger
from ..pileup import DEFAULT_FILTER_THRESHOLD, pileup
from . import _common as C

logger = get_logger("pileup")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="merlin pileup",
        description="Extract per-position methylation from a modBAM (modkit, or "
                    "MErlin's own pileup when modkit is absent).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    g = p.add_argument_group("read input")
    g.add_argument("--modbam", "--bam", dest="modbam", required=True,
                   nargs="+", metavar="FILE",
                   help="BAM with MM/ML modification tags. Several files are "
                        "piled up separately, one bedMethyl each.")
    g.add_argument("--region", default=None, metavar="STR",
                   help="Restrict to a region, e.g. 'NZ_XXX.1:1-100000'.")
    g.add_argument("--min-mapq", type=int, default=20, metavar="N",
                   help="Minimum mapping quality.")
    g.add_argument("--max-reads", type=int, default=None, metavar="N",
                   help="Stop after this many usable reads (internal backend only).")

    C.add_reference_args(p, required=False)

    b = p.add_argument_group("backend")
    b.add_argument("--backend", default="auto",
                   choices=["auto", "modkit", "internal"],
                   help="'auto' uses modkit when it is on PATH.")
    b.add_argument("--modkit-path", default=None, metavar="EXE",
                   help="Path to the modkit executable.")
    b.add_argument("--threads", type=int, default=4, metavar="N")
    b.add_argument("--align", default="auto", choices=["auto", "never", "force"],
                   help="Align an unaligned BAM with minimap2 first. 'never' "
                        "fails instead, which is what you want if you believe "
                        "the BAM is already aligned.")
    b.add_argument("--preset", default="map-ont", metavar="X",
                   help="minimap2 preset used when aligning.")

    t = p.add_argument_group("calling thresholds")
    t.add_argument("--filter-threshold", type=float, default=None, metavar="X",
                   help=f"Confidence below which a call is counted as failed "
                        f"rather than used. The internal backend defaults to "
                        f"{DEFAULT_FILTER_THRESHOLD}; modkit's own adaptive "
                        f"percentile default is used when this is unset.")
    t.add_argument("--mod-thresholds", nargs="+", default=None, metavar="CODE:X",
                   help="Per-code threshold, e.g. 'a:0.9 m:0.75'.")
    t.add_argument("--no-filtering", action="store_true",
                   help="Use every call regardless of confidence.")
    t.add_argument("--mod-codes", default=None, metavar="CODES",
                   help="Comma-separated codes to keep (internal backend).")

    m = p.add_argument_group("modkit-only options")
    m.add_argument("--cpg", action="store_true", help="Restrict to CpG sites.")
    m.add_argument("--motif", dest="motifs", nargs="+", default=None,
                   metavar="SEQ:OFFSET",
                   help="Restrict to a motif, e.g. 'GATC:1'.")
    m.add_argument("--combine-strands", action="store_true",
                   help="Combine both strands of a symmetric motif.")
    m.add_argument("--modkit-arg", dest="extra_args", nargs="+", default=None,
                   metavar="ARG", help="Extra arguments passed to modkit verbatim.")

    C.add_output_args(p, default_prefix="pileup")
    p.add_argument("--gzip", action="store_true",
                   help="Write the bedMethyl gzipped.")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    import pandas as pd

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    base = C.resolve_prefix(args)
    keep = set(args.mod_codes.split(",")) if args.mod_codes else None
    bams = list(args.modbam)

    written: list[Path] = []
    frames = []
    for i, bam in enumerate(bams):
        prefix = base if len(bams) == 1 else f"{base}.{Path(bam).stem}"
        info = pileup(
            bam, outdir, prefix, fasta=args.fasta, backend=args.backend,
            modkit_path=args.modkit_path, threads=args.threads,
            min_mapq=args.min_mapq, filter_threshold=args.filter_threshold,
            no_filtering=args.no_filtering, mod_thresholds=args.mod_thresholds,
            region=args.region, keep_codes=keep,
            combine_strands=args.combine_strands, cpg=args.cpg,
            motifs=args.motifs, align=args.align, preset=args.preset,
            gzip_output=args.gzip, extra_args=args.extra_args,
            max_reads=args.max_reads)
        written.append(Path(info["bedmethyl"]))
        summary = info["summary"]
        if len(summary):
            summary = summary.copy()
            summary.insert(0, "sample", prefix)
            summary.insert(1, "backend", info["backend"])
            frames.append(summary)
        logger.info("%s -> %s", Path(bam).name, Path(info['bedmethyl']).name)

    if frames:
        table = pd.concat(frames, ignore_index=True)
        path = outdir / f"{base}.pileup_summary.tsv"
        table.to_csv(path, sep="\t", index=False, float_format="%.6g")
        written.append(path)
        logger.info("\n%s", table.to_string(index=False))
        for _, row in table.iterrows():
            if row["n_sites_with_coverage"] == 0:
                logger.warning(
                    "%s [%s]: every site has zero valid coverage. Either every "
                    "call failed the confidence filter, or the reads carry no "
                    "usable modification probabilities.", row["sample"],
                    row["mod_code"])
    else:
        logger.warning("No modification calls survived; the bedMethyl is empty. "
                       "Check --min-mapq, --filter-threshold and --region.")

    inp = C.Inputs(outdir=outdir, prefix=base)
    C.finalize(inp, written, args, "merlin pileup")
    return 0


if __name__ == "__main__":
    raise SystemExit(C.run_tool(main))
