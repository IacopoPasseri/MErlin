"""``merlin`` — the umbrella command.

    merlin pileup    modBAM -> bedMethyl (modkit, or MErlin's own pileup)
    merlin xam       methylation per annotated feature
    merlin dixam     differential methylation between two conditions
    merlin spacem    spatial distribution relative to oriC/ter
    merlin mematch   motif / methylation association
    merlin diem      expression x methylation integration
    merlin hicam     Hi-C 3D organisation x methylation x expression
    merlin preflight check the inputs before running anything
    merlin run       run every module the supplied inputs support

Each subcommand keeps the standalone entry point it always had, so existing
command lines and scripts continue to work unchanged.
"""

from __future__ import annotations

import argparse
import sys

from . import __version__

SUBCOMMANDS = {
    # analysis
    "pileup": "Extract methylation from a basecalled modBAM (modkit)",
    "xam": "Cross-reference methylation with a genome annotation",
    "dixam": "Differential methylation between conditions (replicate-aware)",
    "spacem": "Spatial distribution of methylation vs oriC/ter",
    "mematch": "Motif / methylation association with enrichment tests",
    "diem": "Differential expression x methylation, confounder-adjusted",
    "hicam": "Hi-C 3D organisation x methylation x expression",
    "phase": "Read-level methylation: hemimethylation and bistability",
    "discover": "Find methylation motifs de novo from the calls",
    "mtase": "Attribute motifs to methyltransferase genes",
    # integration
    "harmonise": "Join every module's output into one canonical store",
    "evidence": "Rank genes by combined evidence across layers",
    "report": "Render one self-contained HTML report for a run",
    # orchestration and checks
    "preflight": "Check inputs join correctly before running anything",
    "doctor": "Check this machine can run every module",
    "run": "Run every module the supplied inputs support",
    "export": "Emit the run plan as Nextflow, Snakemake or JSON",
}

GROUPS = [
    ("analysis", ["pileup", "xam", "dixam", "spacem", "mematch", "diem", "hicam",
                  "phase", "discover", "mtase"]),
    ("integration", ["harmonise", "evidence", "report"]),
    ("orchestration", ["preflight", "doctor", "run", "export"]),
]


def _usage() -> str:
    width = max(len(k) for k in SUBCOMMANDS)
    lines = ["usage: merlin <command> [options]", "",
             "MErlin — Methylation-driven Expression & Regulation Linkage in",
             "         Interacting Nuclear-domains", ""]
    for title, names in GROUPS:
        lines.append(f"{title}:")
        for name in names:
            lines.append(f"  {name:<{width}}  {SUBCOMMANDS[name]}")
        lines.append("")
    lines += ["", "Run 'merlin <command> --help' for a command's options.",
              "", "Modularity: every command needs only the layers it uses. "
                  "'merlin run --config' runs", "the subset your inputs support and "
                  "reports what it skipped and why."]
    return "\n".join(lines)


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(_usage())
        return 0
    if argv[0] in ("-V", "--version", "version"):
        print(f"merlin {__version__}")
        return 0

    cmd, rest = argv[0], argv[1:]
    if cmd not in SUBCOMMANDS:
        print(f"merlin: unknown command {cmd!r}\n", file=sys.stderr)
        print(_usage(), file=sys.stderr)
        return 2

    if cmd == "export":
        p = argparse.ArgumentParser(
            prog="merlin export",
            description="Emit the run plan as a workflow definition.")
        p.add_argument("--config", required=True, metavar="FILE")
        p.add_argument("--workflow", default="nextflow",
                       choices=["nextflow", "snakemake", "json"])
        p.add_argument("-o", "--out", default=None, metavar="FILE",
                       help="Write here instead of stdout.")
        args = p.parse_args(rest)
        from .workflow import export as export_workflow
        text = export_workflow(args.config, args.workflow)
        if args.out:
            from pathlib import Path
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            Path(args.out).write_text(text, encoding="utf-8")
            print(f"wrote {args.out}", file=sys.stderr)
        else:
            print(text)
        return 0

    if cmd == "run":
        p = argparse.ArgumentParser(prog="merlin run",
                                    description="Run the modules your inputs support.")
        p.add_argument("--config", required=True, metavar="FILE",
                       help="YAML or JSON run configuration.")
        p.add_argument("--dry-run", action="store_true",
                       help="Print the plan without executing it.")
        p.add_argument("--keep-going", action="store_true",
                       help="Continue after a module fails.")
        p.add_argument("--only", nargs="+", default=None, metavar="MODULE",
                       help="Run only these modules.")
        args = p.parse_args(rest)
        from .pipeline import run as run_pipeline
        return run_pipeline(args.config, args.dry_run, args.keep_going, args.only)

    from .tools import _common as C
    mod = __import__(f"merlin.tools.{cmd}", fromlist=["main"])
    return C.run_tool(mod.main, rest)


if __name__ == "__main__":
    raise SystemExit(main())
