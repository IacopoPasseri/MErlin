#!/usr/bin/env python3
"""Standalone entry point for `merlin mematch` (kept so existing command lines work)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from merlin.tools import mematch as _tool
from merlin.tools._common import run_tool
if __name__ == "__main__":
    raise SystemExit(run_tool(_tool.main))
