"""Positive control: a run that produces nothing is not a passing run.

The unit tests check that the code executes. This checks that the *biology*
comes back out — on synthetic data whose ground truth is known, MErlin must
recover the planted motifs, the planted differential methylation, the planted
domain boundaries and the planted bistability. A refactor that quietly stops
finding GATC passes every other test in the suite.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

ENV = {"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin", "HOME": "/tmp",
       "MPLBACKEND": "Agg"}


@pytest.fixture(scope="module")
def data(tmp_path_factory):
    d = tmp_path_factory.mktemp("control")
    subprocess.run([sys.executable, str(ROOT / "tools" / "make_testdata.py"),
                    "--outdir", str(d), "--replicates", "3"],
                   check=True, capture_output=True)
    return d


def run(tool, args):
    proc = subprocess.run([sys.executable, "-m", "merlin.cli", tool] + args,
                          capture_output=True, text=True, env=ENV)
    assert proc.returncode == 0, proc.stderr[-3000:]
    return proc


def test_discover_recovers_all_three_planted_motifs(data, tmp_path):
    import pandas as pd
    run("discover", ["--fasta", str(data / "reference.fasta"),
                     "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                     "-o", str(tmp_path), "--prefix", "c"])
    df = pd.read_csv(tmp_path / "c.discovered_motifs.tsv", sep="\t", comment="#")
    found = dict(zip(df["motif"], df["offset"]))
    for motif, offset in (("GATC", 1), ("GANTC", 1), ("CCWGG", 1)):
        assert motif in found, f"{motif} not discovered: {sorted(found)}"
        assert found[motif] == offset, (motif, found[motif])


def test_mematch_finds_gatc_enriched(data, tmp_path):
    import pandas as pd
    run("mematch", ["-g", str(data / "annotation.gff3"),
                    "--fasta", str(data / "reference.fasta"),
                    "--methylation", str(data / "F5.methylation.gff3"),
                    "--motifs", str(data / "motifs.txt"),
                    "-o", str(tmp_path), "--prefix", "c", "--fisher",
                    "--no-call-table", "--no-hit-table"])
    e = pd.read_csv(tmp_path / "c.enrichment.tsv", sep="\t", comment="#")
    site = e[(e["level"] == "site") & (e["motif"] == "GATC")].iloc[0]
    assert site["odds_ratio"] > 10, site["odds_ratio"]
    assert site["q_value_BH"] < 0.01


def test_dixam_recovers_the_hypomethylated_genes(data, tmp_path):
    import pandas as pd
    reps = sorted(str(p) for p in data.glob("F5_rep*.bedmethyl.bed.gz"))
    reps2 = sorted(str(p) for p in data.glob("F9_rep*.bedmethyl.bed.gz"))
    run("dixam", ["-g", str(data / "annotation.gff3"), "--features", "CDS",
                  "--methylation", *reps, "--methylation2", *reps2,
                  "-o", str(tmp_path), "--prefix", "c", "--no-split", "--no-plot"])
    t = pd.read_csv(tmp_path / "c.differential.tsv", sep="\t", comment="#")
    planted = {f"SYNT_{i:05d}" for i in range(1, 61)}     # the first 60 genes
    hit = t[t["locus_tag"].isin(planted)]
    other = t[~t["locus_tag"].isin(planted)]
    # the planted set must lose far more methylation than the rest
    assert hit["delta_meth_level"].mean() < -0.3, hit["delta_meth_level"].mean()
    assert other["delta_meth_level"].mean() > -0.15
    sig = hit[hit["qvalue"] < 0.05]
    assert len(sig) > 20, len(sig)


def test_hicam_recovers_planted_domain_boundaries(data, tmp_path):
    pytest.importorskip("h5py")
    import pandas as pd
    run("hicam", ["--hic", str(data / "contacts.cool"), "-o", str(tmp_path),
                  "--prefix", "c", "--insulation-window", "3"])
    b = pd.read_csv(tmp_path / "c.hic_boundaries.tsv", sep="\t", comment="#")
    chrom = b[b["replicon"].str.contains("TEST001")]
    called = set(chrom["bin"].astype(int))
    planted = [0, 12, 24, 36, 48]                        # linspace(0, 60, 6)[:-1]
    n = 60
    recovered = sum(
        1 for e in planted
        if any(min(abs(c - e), n - abs(c - e)) <= 2 for c in called))
    assert recovered >= 4, f"only {recovered}/5 planted boundaries recovered"


def test_phase_recovers_planted_bistability(data, tmp_path):
    pytest.importorskip("pysam")
    import pandas as pd
    bam = data / "reads.modbam.bam"
    if not bam.exists():
        pytest.skip("modBAM not generated")
    run("phase", ["--modbam", str(bam), "-g", str(data / "annotation.gff3"),
                  "--features", "CDS", "-o", str(tmp_path), "--prefix", "c"])
    b = pd.read_csv(tmp_path / "c.bistability.tsv", sep="\t", comment="#")
    assert int(b["bimodal"].sum()) >= 5, b["bimodal"].sum()
    # a bistable locus sits near 0.5 on average but has reads at both extremes
    top = b[b["bimodal"] == 1]
    assert (top["frac_reads_high"] > 0.2).any() and (top["frac_reads_low"] > 0.2).any()


def test_spacem_recovers_the_planted_origin(data, tmp_path):
    import pandas as pd
    run("spacem", ["-g", str(data / "annotation.gff3"),
                   "--fasta", str(data / "reference.fasta"),
                   "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                   "-o", str(tmp_path), "--prefix", "c"])
    s = pd.read_csv(tmp_path / "c.oriter_stats.tsv", sep="\t", comment="#")
    chrom = s[s["replicon"].str.contains("TEST001")].iloc[0]
    L = float(chrom["length"])
    oric = float(chrom["oriC"])
    # the generator puts the origin at coordinate 0 of a circular replicon
    assert min(oric, L - oric) < 0.08 * L, oric
    assert abs(float(chrom["ter"]) - L / 2) < 0.08 * L
    # and biases genes onto the leading strand
    assert float(chrom["gene_co_oriented_frac"]) > 0.6


def test_a_bam_only_run_recovers_gatc_end_to_end(data, tmp_path):
    """Start from basecalling output, end at a motif.

    This is the 2.1.0 claim in one test: with no bedMethyl anywhere, the pileup
    has to produce calls good enough for de novo discovery to name the motif
    that was planted in the reads.
    """
    import pandas as pd
    run("pileup", ["--modbam", str(data / "reads.modbam.bam"),
                   "--fasta", str(data / "reference.fasta"),
                   "-o", str(tmp_path), "--prefix", "b"])
    bed = tmp_path / "b.bedmethyl.bed"
    assert bed.exists()
    run("discover", ["--fasta", str(data / "reference.fasta"),
                     "--methylation", str(bed),
                     "-o", str(tmp_path), "--prefix", "b",
                     "--min-sites", "50"])
    df = pd.read_csv(tmp_path / "b.discovered_motifs.tsv", sep="\t", comment="#")
    found = dict(zip(df["motif"], df["offset"]))
    assert "GATC" in found, f"discovered from the BAM: {sorted(found)}"
    assert found["GATC"] == 1
