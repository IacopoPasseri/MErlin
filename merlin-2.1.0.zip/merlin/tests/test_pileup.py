"""modBAM -> bedMethyl, checked against planted truth.

The synthetic modBAM carries 6mA on the adenine of GATC on *both* strands and
nowhere else, so a correct pileup puts every call in a GATC context on the
correct strand. That is a stronger check than "the file has rows in it", which
is what a pileup bug would otherwise pass.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from merlin import io as mio                                      # noqa: E402
from merlin.pileup import (BEDMETHYL_COLUMNS, inspect_bam,        # noqa: E402
                           internal_pileup, resolve_backend,
                           summarise_bedmethyl)

pysam = pytest.importorskip("pysam")


@pytest.fixture(scope="module")
def data(tmp_path_factory):
    d = tmp_path_factory.mktemp("pileup_data")
    subprocess.run([sys.executable, str(ROOT / "tools" / "make_testdata.py"),
                    "--outdir", str(d), "--chrom-length", "60000",
                    "--plasmid-length", "20000", "--n-genes", "60"],
                   check=True, capture_output=True)
    return d


@pytest.fixture(scope="module")
def piled(data, tmp_path_factory):
    out = tmp_path_factory.mktemp("pileup_out") / "s.bedmethyl.bed"
    _, summary = internal_pileup(str(data / "reads.modbam.bam"), out)
    return out, summary


def _contexts(bed: Path, fasta: Path):
    import pandas as pd
    genome = {k.split(".")[0]: v for k, v in mio.read_fasta(str(fasta)).items()}
    df = pd.read_csv(bed, sep="\t", header=None)
    out = []
    for _, r in df.iterrows():
        seq = genome[r[0]]
        pos = int(r[1])
        # GATC is palindromic: the top-strand 6mA is at offset 1, the
        # bottom-strand one is the T at offset 2 of the same GATC.
        out.append(seq[pos - 1:pos + 3] if r[5] == "+" else seq[pos - 2:pos + 2])
    return df, out


# --------------------------------------------------------------------------- #
# Inspection
# --------------------------------------------------------------------------- #
def test_inspect_bam_sees_alignment_sorting_and_tags(data):
    st = inspect_bam(str(data / "reads.modbam.bam"))
    assert st.is_aligned and st.is_coordinate_sorted and st.has_index
    assert st.has_modifications and st.n_with_tags == st.n_checked
    assert st.mod_codes == ["a"]
    assert "MM/ML" in st.describe()


def test_bam_without_tags_is_reported_not_silently_empty(tmp_path):
    """A BAM with no MM/ML must fail loudly — an empty bedMethyl reads as
    'this genome has no methylation', which is a different claim entirely."""
    from merlin.pileup import prepare_bam
    path = tmp_path / "plain.bam"
    header = {"HD": {"VN": "1.6", "SO": "coordinate"},
              "SQ": [{"SN": "chr1", "LN": 1000}]}
    with pysam.AlignmentFile(path, "wb", header=header) as bam:
        seg = pysam.AlignedSegment()
        seg.query_name = "r1"
        seg.query_sequence = "ACGT" * 25
        seg.flag = 0
        seg.reference_id = 0
        seg.reference_start = 10
        seg.mapping_quality = 60
        seg.cigar = [(0, 100)]
        bam.write(seg)
    with pytest.raises(SystemExit) as exc:
        prepare_bam(str(path), None, tmp_path / "work")
    assert "MM/ML" in str(exc.value)


# --------------------------------------------------------------------------- #
# The internal backend against planted truth
# --------------------------------------------------------------------------- #
def test_internal_pileup_calls_only_gatc_on_both_strands(piled, data):
    bed, _ = piled
    df, contexts = _contexts(bed, data / "reference.fasta")
    assert len(df) > 100
    assert set(contexts) == {"GATC"}, sorted(set(contexts))[:5]
    strands = df[5].value_counts().to_dict()
    assert strands.get("+", 0) > 0 and strands.get("-", 0) > 0
    # GATC is palindromic, so a correct strand assignment gives a balanced table
    assert abs(strands["+"] - strands["-"]) <= 0.1 * len(df)


def test_internal_pileup_writes_the_modkit_column_layout(piled):
    bed, _ = piled
    first = bed.read_text().splitlines()[0].split("\t")
    assert len(first) == len(BEDMETHYL_COLUMNS)
    start, end = int(first[1]), int(first[2])
    assert end == start + 1                       # single-base records
    valid, pct, n_mod, n_can, n_other = (int(first[9]), float(first[10]),
                                         int(first[11]), int(first[12]),
                                         int(first[13]))
    assert valid == n_mod + n_can + n_other
    assert pct == pytest.approx(100.0 * n_mod / valid, abs=0.01)


def test_merlin_reads_its_own_pileup_output(piled):
    bed, _ = piled
    fmt, ncols = mio.sniff_methylation_format(bed)
    assert fmt == "bedmethyl" and ncols == len(BEDMETHYL_COLUMNS)
    ms = mio.read_methylation(str(bed))
    assert len(ms.pos) > 100
    assert ms.mod_codes == {"a"}
    assert (ms.frac >= 0).all() and (ms.frac <= 1).all()


def test_methylation_level_matches_what_was_planted(piled):
    """Planted probability is 0.93 outside the bistable and hemimethylated
    regions, so the mean fraction modified has to land near it rather than at
    an arbitrary value produced by a threshold applied twice."""
    bed, _ = piled
    table = summarise_bedmethyl(bed)
    row = table[table["mod_code"] == "a"].iloc[0]
    assert 0.75 < row["mean_percent_modified"] / 100 < 0.98
    assert row["mean_coverage"] > 5


def test_filter_threshold_moves_calls_into_the_fail_column(data, tmp_path):
    import pandas as pd
    loose, _ = internal_pileup(str(data / "reads.modbam.bam"),
                               tmp_path / "loose.bed", filter_threshold=0.0)
    strict, _ = internal_pileup(str(data / "reads.modbam.bam"),
                                tmp_path / "strict.bed", filter_threshold=0.999)
    a = pd.read_csv(loose, sep="\t", header=None)
    b = pd.read_csv(strict, sep="\t", header=None)
    assert a[9].sum() > b[9].sum()          # valid coverage falls
    assert b[15].sum() > a[15].sum()        # N_fail rises
    assert b[9].sum() + b[15].sum() == pytest.approx(a[9].sum() + a[15].sum())


def test_min_mapq_filters_reads(data, tmp_path):
    import pandas as pd
    kept, _ = internal_pileup(str(data / "reads.modbam.bam"),
                              tmp_path / "kept.bed", min_mapq=20)
    none, _ = internal_pileup(str(data / "reads.modbam.bam"),
                              tmp_path / "none.bed", min_mapq=99)
    assert len(pd.read_csv(kept, sep="\t", header=None)) > 0
    assert none.stat().st_size == 0


def test_region_restricts_the_pileup(data, tmp_path):
    import pandas as pd
    out, _ = internal_pileup(str(data / "reads.modbam.bam"),
                             tmp_path / "r.bed", region="NZ_TEST001:1-5000")
    df = pd.read_csv(out, sep="\t", header=None)
    assert len(df) > 0
    assert df[1].max() < 5000 + 10_000       # reads overlapping the window only


def test_gzip_output_round_trips(data, tmp_path):
    out, _ = internal_pileup(str(data / "reads.modbam.bam"),
                             tmp_path / "g.bed.gz", gzip_output=True)
    ms = mio.read_methylation(str(out))
    assert len(ms.pos) > 100


# --------------------------------------------------------------------------- #
# Backend selection
# --------------------------------------------------------------------------- #
def test_backend_auto_prefers_modkit_when_present(monkeypatch):
    monkeypatch.setattr("merlin.pileup.find_modkit", lambda p=None: "/usr/bin/modkit")
    monkeypatch.setattr("merlin.pileup.modkit_version", lambda exe: "modkit 0.4.0")
    backend, exe, why = resolve_backend("auto")
    assert backend == "modkit" and exe.endswith("modkit") and "0.4.0" in why


def test_backend_auto_falls_back_and_says_so(monkeypatch):
    monkeypatch.setattr("merlin.pileup.find_modkit", lambda p=None: None)
    backend, exe, why = resolve_backend("auto")
    assert backend == "internal" and exe is None
    assert "modkit" in why and "not on PATH" in why


def test_backend_modkit_requested_but_missing_is_fatal(monkeypatch):
    monkeypatch.setattr("merlin.pileup.find_modkit", lambda p=None: None)
    with pytest.raises(SystemExit) as exc:
        resolve_backend("modkit")
    assert "install" in str(exc.value).lower()


# --------------------------------------------------------------------------- #
# The CLI and the pipeline
# --------------------------------------------------------------------------- #
def test_cli_writes_bedmethyl_and_summary(data, tmp_path):
    import pandas as pd
    from merlin.tools import pileup as cli
    rc = cli.main(["--modbam", str(data / "reads.modbam.bam"),
                   "--fasta", str(data / "reference.fasta"),
                   "--backend", "internal", "-o", str(tmp_path), "--prefix", "p"])
    assert rc == 0
    bed = tmp_path / "p.bedmethyl.bed"
    assert bed.exists() and bed.stat().st_size > 0
    summary = pd.read_csv(tmp_path / "p.pileup_summary.tsv", sep="\t")
    assert summary.loc[0, "backend"] == "internal"
    assert summary.loc[0, "mod_code"] == "a"
    prov = (tmp_path / "p.provenance.txt").read_text()
    assert "modbam" in prov and "merlin pileup" in prov


def test_pipeline_inserts_pileup_and_points_xam_at_its_output(data):
    from merlin.pipeline import plan
    steps = plan({"outdir": "out", "prefix": "s",
                  "annotation": str(data / "annotation.gff3"),
                  "reference": str(data / "reference.fasta"),
                  "modbam": {"WT": [str(data / "reads.modbam.bam")]}})
    by_name = {s.name: s for s in steps}
    assert "pileup[WT]" in by_name
    assert not by_name["pileup[WT]"].reason_skipped
    produced = "out/pileup/s.WT.bedmethyl.bed"
    xam = by_name["xam[WT]"]
    assert produced in [str(a) for a in xam.argv], xam.argv
    assert not xam.reason_skipped


def test_pipeline_skips_pileup_when_bedmethyl_was_supplied(data):
    from merlin.pipeline import plan
    steps = plan({"outdir": "out", "prefix": "s",
                  "annotation": str(data / "annotation.gff3"),
                  "methylation": str(data / "F5.methylation.gff3"),
                  "modbam": str(data / "reads.modbam.bam")})
    step = {s.name: s for s in steps}["pileup"]
    assert step.reason_skipped and "phase" in step.reason_skipped
