"""Test suite for MErlin.

The interesting tests are the ones that pin down behaviour the original scripts
got wrong: half-open coordinates, unstranded calls counting towards stranded
features, circular motif search, the presence-only enrichment branch, and the
seqid reconciliation that must abort rather than return zeros.
"""

from __future__ import annotations

import gzip
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from merlin import io as mio                                    # noqa: E402
from merlin.genome import (bin_counts, co_oriented, gc_skew,     # noqa: E402
                           ori_ter_coordinate)
from merlin.hic import (call_boundaries, ice, insulation_score,  # noqa: E402
                        observed_over_expected)
from merlin.intervals import (FeatureIndex, count_per_feature,   # noqa: E402
                              points_in_intervals)
from merlin.model import Feature, MethylSet, resolve_mod_code    # noqa: E402
from merlin.motifs import find_motifs, reverse_complement        # noqa: E402
from merlin.seqids import reconcile, require_overlap, strip_version  # noqa: E402
from merlin.stats import (benjamini_hochberg, contingency_test,  # noqa: E402
                          permutation_spearman, uniformity)


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="session")
def data(tmp_path_factory):
    d = tmp_path_factory.mktemp("merlin_data")
    subprocess.run([sys.executable, str(ROOT / "tools" / "make_testdata.py"),
                    "--outdir", str(d), "--chrom-length", "60000",
                    "--plasmid-length", "20000", "--n-genes", "60"],
                   check=True, capture_output=True)
    return d


@pytest.fixture
def tiny_gff(tmp_path):
    p = tmp_path / "a.gff3"
    p.write_text(
        "##gff-version 3\n"
        "##sequence-region chr1 1 1000\n"
        "chr1\t.\tCDS\t11\t20\t.\t+\t0\tID=g1;locus_tag=G1;product=Fe%2FS protein\n"
        "chr1\t.\tCDS\t31\t40\t.\t-\t0\tID=g2;locus_tag=G2\n"
        "chr1\t.\tregion\t1\t1000\t.\t+\t.\tID=r\n"
        "##FASTA\n>chr1\nACGT\n")
    return p


def methylset(rows):
    """rows: (seqid, pos, mod, strand, cov, frac)"""
    cols = list(zip(*rows)) if rows else [()] * 6
    return MethylSet(np.array(cols[0], dtype=object), np.array(cols[1], dtype=np.int64),
                     np.array(cols[2], dtype=object), np.array(cols[3], dtype=object),
                     np.array(cols[4], dtype=float), np.array(cols[5], dtype=float))


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #
class TestAnnotation:
    def test_coordinates_are_half_open(self, tiny_gff):
        ann = mio.read_annotation(tiny_gff)
        g1 = ann.features[0]
        assert (g1.start, g1.end) == (10, 20)      # GFF 11..20 inclusive
        assert g1.length == 10

    def test_meta_features_excluded_and_attributes_unquoted(self, tiny_gff):
        ann = mio.read_annotation(tiny_gff)
        assert [f.ftype for f in ann.features] == ["CDS", "CDS"]
        assert ann.features[0].product == "Fe/S protein"   # %2F decoded

    def test_sequence_region_and_embedded_fasta(self, tiny_gff):
        ann = mio.read_annotation(tiny_gff)
        assert ann.seq_regions == {"chr1": 1000}
        assert ann.embedded_fasta == {"chr1": "ACGT"}

    def test_feature_type_filter(self, tiny_gff):
        assert len(mio.read_annotation(tiny_gff, feature_types={"tRNA"})) == 0


class TestMethylationIO:
    def test_sniff_gff_vs_bedmethyl(self, data):
        assert mio.sniff_methylation_format(data / "F5.methylation.gff3")[0] == "gff"
        assert mio.sniff_methylation_format(data / "F5.bedmethyl.bed.gz")[0] == "bedmethyl"

    def test_presence_only_detected(self, data):
        gff = mio.read_methylation(data / "F5.methylation.gff3")
        bed = mio.read_methylation(data / "F5.bedmethyl.bed.gz")
        assert gff.presence_only and not bed.presence_only

    def test_percent_converted_to_fraction(self, data):
        bed = mio.read_methylation(data / "F5.bedmethyl.bed.gz")
        assert np.nanmax(bed.frac) <= 1.0

    def test_min_frac_filters_bedmethyl(self, data):
        loose = mio.read_methylation(data / "F5.bedmethyl.bed.gz")
        strict = mio.read_methylation(data / "F5.bedmethyl.bed.gz", min_frac=0.95)
        assert len(strict) < len(loose)

    def test_min_frac_does_not_empty_presence_only(self, data):
        ms = mio.read_methylation(data / "F5.methylation.gff3", min_frac=0.99)
        assert len(ms) > 0, "a presence-only file must survive a fraction filter"

    def test_gzip_transparent(self, tmp_path):
        p = tmp_path / "m.bed.gz"
        with gzip.open(p, "wt") as fh:
            fh.write("chr1\t10\t11\ta\t0\t+\n")
        assert len(mio.read_methylation(p)) == 1

    def test_mod_code_synonyms(self):
        assert resolve_mod_code("6mA") == "a"
        assert resolve_mod_code("modified_base") == "m"
        assert resolve_mod_code("weird", {"mod": "5hmC"}) == "h"
        assert resolve_mod_code("novel_thing") == "novel_thing"   # preserved


class TestExpressionIO:
    def test_deseq2(self, data):
        ge = mio.read_geneexp(data / "deseq2_results.csv")
        assert {"locus_tag", "log2FoldChange", "padj"} <= set(ge.columns)

    def test_edger_column_names(self, tmp_path):
        p = tmp_path / "edger.tsv"
        p.write_text("gene_id\tlogFC\tlogCPM\tPValue\tFDR\nG1\t1.5\t5\t0.001\t0.01\n")
        ge = mio.read_geneexp(p)
        assert ge["locus_tag"].iloc[0] == "G1"
        assert ge["log2FoldChange"].iloc[0] == 1.5
        assert ge["padj"].iloc[0] == 0.01

    def test_unnamed_index_column(self, tmp_path):
        p = tmp_path / "d.csv"
        p.write_text(",baseMean,log2FoldChange,padj\nG1,10,2.0,0.001\n")
        assert mio.read_geneexp(p)["locus_tag"].iloc[0] == "G1"


# --------------------------------------------------------------------------- #
# Interval counting — the hot path the original got quadratically wrong
# --------------------------------------------------------------------------- #
class TestCounting:
    def _brute(self, feats, ms, mod, ignore_strand):
        out = []
        for f in feats:
            strands = ({"+", "-", "."} if (ignore_strand or f.strand == ".")
                       else {f.strand, "."})
            n = sum(1 for i in range(len(ms))
                    if ms.seqid[i] == f.seqid and ms.mod[i] == mod
                    and ms.strand[i] in strands and f.start <= ms.pos[i] < f.end)
            out.append(n)
        return np.array(out)

    @pytest.mark.parametrize("ignore_strand", [False, True])
    def test_matches_brute_force(self, ignore_strand):
        rng = np.random.default_rng(3)
        feats = []
        for i in range(60):
            s = int(rng.integers(0, 9000))
            feats.append(Feature("chr1", "CDS", s, s + int(rng.integers(50, 400)),
                                 str(rng.choice(["+", "-", "."])), f"f{i}"))
        rows = [("chr1", int(rng.integers(0, 10000)), "a",
                 str(rng.choice(["+", "-", "."])), np.nan, np.nan)
                for _ in range(2000)]
        ms = methylset(rows)
        got = count_per_feature(FeatureIndex(feats), ms, ["a"], ignore_strand)[:, 0]
        assert np.array_equal(got, self._brute(feats, ms, "a", ignore_strand))

    def test_unstranded_calls_count_for_stranded_features(self):
        """The original dropped '.' calls whenever the feature was stranded."""
        feats = [Feature("chr1", "CDS", 0, 100, "+", "f")]
        ms = methylset([("chr1", 10, "a", ".", np.nan, np.nan)])
        assert count_per_feature(FeatureIndex(feats), ms, ["a"], False)[0, 0] == 1

    def test_half_open_boundaries(self):
        feats = [Feature("chr1", "CDS", 10, 20, "+", "f")]
        ms = methylset([("chr1", 9, "a", "+", np.nan, np.nan),
                        ("chr1", 10, "a", "+", np.nan, np.nan),
                        ("chr1", 19, "a", "+", np.nan, np.nan),
                        ("chr1", 20, "a", "+", np.nan, np.nan)])
        assert count_per_feature(FeatureIndex(feats), ms, ["a"], False)[0, 0] == 2

    def test_wrong_replicon_never_counts(self):
        feats = [Feature("chr1", "CDS", 0, 100, "+", "f")]
        ms = methylset([("chr2", 10, "a", "+", np.nan, np.nan)])
        assert count_per_feature(FeatureIndex(feats), ms, ["a"], False)[0, 0] == 0


class TestPointsInIntervals:
    def test_disjoint_and_overlapping_paths_agree(self):
        rng = np.random.default_rng(11)
        pts = rng.integers(0, 1000, 300)
        starts = np.sort(rng.integers(0, 900, 40))
        ends = starts + rng.integers(5, 200, 40)          # overlapping
        csr = points_in_intervals(pts, starts, ends)
        for i, p in enumerate(pts):
            expect = {j for j in range(40) if starts[j] <= p < ends[j]}
            assert set(csr.get(i).tolist()) == expect

    def test_empty_inputs(self):
        csr = points_in_intervals(np.array([], dtype=int), np.array([1]), np.array([2]))
        assert csr.values.size == 0


# --------------------------------------------------------------------------- #
# Motifs
# --------------------------------------------------------------------------- #
class TestMotifs:
    def test_reverse_complement_iupac(self):
        assert reverse_complement("GATC") == "GATC"
        assert reverse_complement("GANTC") == "GANTC"
        assert reverse_complement("CCWGG") == "CCWGG"
        assert reverse_complement("AAGCTT") == "AAGCTT"
        assert reverse_complement("ACGT") == "ACGT"
        assert reverse_complement("AAAA") == "TTTT"

    def test_overlapping_occurrences_all_found(self):
        hits = find_motifs({"c": "AAAA"}, [("AA", None)], circular=False)["AA"]
        assert int((hits.strand == "+").sum()) == 3

    def test_circular_wrap(self):
        """A motif spanning the origin is invisible to a linear scan."""
        seq = "TCAAAAAAAAAAAAAAAAGA"        # ...GA | TC... — GATC spans the origin
        lin = find_motifs({"c": seq}, [("GATC", 1)], circular=False)["GATC"]
        cir = find_motifs({"c": seq}, [("GATC", 1)], circular=True)["GATC"]
        assert len(lin) == 0 and len(cir) > 0
        plus = cir.start[cir.strand == "+"]
        assert plus.tolist() == [18]         # G at 18, A 19, T 0, C 1
        assert cir.mod_pos[cir.strand == "+"].tolist() == [19]

    def test_modified_base_offset_on_both_strands(self):
        seq = "TTTGATCTTT"                    # GATC at 3..6
        hits = find_motifs({"c": seq}, [("GATC", 1)], circular=False)["GATC"]
        plus = hits.mod_pos[hits.strand == "+"]
        minus = hits.mod_pos[hits.strand == "-"]
        assert plus.tolist() == [4]           # A of GATC
        assert minus.tolist() == [5]          # A on the opposite strand (T at 5)

    def test_covered_mask(self):
        hits = find_motifs({"c": "TTGATCTT"}, [("GATC", 1)], circular=False)["GATC"]
        mask = hits.covered_mask("c", 8)
        assert mask.sum() == 4 and mask[2] and mask[5] and not mask[1]


# --------------------------------------------------------------------------- #
# Genome geometry
# --------------------------------------------------------------------------- #
class TestGenome:
    @staticmethod
    def _skewed(L=100_000, seed=1):
        rng = np.random.default_rng(seed)
        half = L // 2
        lead = rng.choice(list("ACGT"), size=half, p=[0.24, 0.20, 0.30, 0.26])
        lag = rng.choice(list("ACGT"), size=L - half, p=[0.24, 0.30, 0.20, 0.26])
        return "".join(np.concatenate([lead, lag]))

    def test_oric_and_ter_recovered(self):
        seq = self._skewed()
        sp = gc_skew(seq, window=2000)
        L = len(seq)
        assert min(sp.oric, L - sp.oric) < 0.06 * L     # origin near 0 (circular)
        assert abs(sp.ter - L / 2) < 0.06 * L
        assert not sp.weak

    def test_flat_sequence_flagged_weak(self):
        rng = np.random.default_rng(2)
        seq = "".join(rng.choice(list("ACGT"), size=50_000))
        assert gc_skew(seq, window=2000).weak

    def test_ori_ter_coordinate_bounds_and_arms(self):
        signed, folded, arm = ori_ter_coordinate(
            np.array([0, 250, 500, 750]), oric=0, ter=500, L=1000)
        assert np.allclose(folded, [0, 0.5, 1.0, 0.5])
        assert np.allclose(signed, [0, 0.5, 1.0, -0.5])
        assert arm.tolist() == [1, 1, 1, -1]

    def test_ori_ter_wraps_circularly(self):
        _s, folded, _a = ori_ter_coordinate(np.array([900]), oric=950, ter=450, L=1000)
        assert 0.0 <= folded[0] <= 1.0

    def test_co_orientation(self):
        out = co_oriented(np.array(["+", "-", "."], dtype=object), np.array([1, 1, 1]))
        assert out[0] == 1.0 and out[1] == 0.0 and np.isnan(out[2])

    def test_bin_counts(self):
        assert bin_counts([0, 5, 15], 20, 10).tolist() == [2, 1]


# --------------------------------------------------------------------------- #
# Statistics
# --------------------------------------------------------------------------- #
class TestStats:
    def test_bh_matches_statsmodels(self):
        pytest.importorskip("statsmodels")
        from statsmodels.stats.multitest import multipletests
        rng = np.random.default_rng(5)
        p = rng.uniform(0, 1, 500)
        assert np.allclose(benjamini_hochberg(p), multipletests(p, method="fdr_bh")[1])

    def test_bh_preserves_nan(self):
        q = benjamini_hochberg([0.01, np.nan, 0.5])
        assert np.isnan(q[1]) and np.isfinite(q[0])

    def test_permutation_spearman_matches_scipy_rho(self):
        pytest.importorskip("scipy")
        from scipy.stats import spearmanr
        rng = np.random.default_rng(6)
        x = rng.gamma(2, 1, 400); y = 0.4 * x + rng.normal(0, 1, 400)
        rho, p = permutation_spearman(x, y, n_perm=1000, seed=0)
        assert abs(rho - spearmanr(x, y)[0]) < 1e-10
        assert 0 < p <= 1                      # add-one correction: never exactly 0

    def test_permutation_p_is_large_under_the_null(self):
        rng = np.random.default_rng(7)
        _rho, p = permutation_spearman(rng.normal(size=200), rng.normal(size=200),
                                       n_perm=1000, seed=1)
        assert p > 0.01

    def test_contingency_auto_matches_fisher_when_sparse(self):
        pytest.importorskip("scipy")
        from scipy.stats import fisher_exact
        _or, p = contingency_test([2], [3], [1], [40], method="auto")
        assert abs(p[0] - fisher_exact([[2, 3], [1, 40]])[1]) < 1e-12

    def test_contingency_handles_degenerate_tables(self):
        orr, p = contingency_test([5], [0], [3], [0])
        assert np.isfinite(orr[0]) and np.isnan(p[0])

    def test_uniformity_reports_effect_size(self):
        rng = np.random.default_rng(8)
        flat = uniformity(rng.uniform(size=5000))
        skewed = uniformity(rng.beta(1, 3, size=5000))
        assert flat.ks_D < skewed.ks_D
        assert skewed.bias == "origin-proximal"


# --------------------------------------------------------------------------- #
# Seqid reconciliation
# --------------------------------------------------------------------------- #
class TestSeqids:
    def test_identity(self):
        res = reconcile({"reference": {"c1"}, "methylation": {"c1"}}, "reference")
        assert res.method == "identity" and not res.stripped

    def test_version_suffix_auto_stripped(self):
        res = reconcile({"reference": {"NZ_X.1"}, "annotation": {"NZ_X"}}, "reference")
        assert res.stripped and res.apply("NZ_X.1") == "NZ_X"

    def test_explicit_map_wins(self):
        res = reconcile({"reference": {"chr"}, "methylation": {"weird"}}, "reference",
                        explicit_map={"weird": "chr"})
        assert res.apply("weird") == "chr"

    def test_rank_map_requires_opt_in(self):
        ns = {"reference": {"a", "b"}, "methylation": {"x", "y"}}
        assert not (set(reconcile(ns, "reference").mapping.values()) & {"a", "b"})
        res = reconcile(ns, "reference", allow_rank_map=True)
        assert res.apply("x") in {"a", "b"}

    def test_unreconcilable_aborts_loudly(self):
        ns = {"annotation": {"c1"}, "methylation": {"zzz"}}
        res = reconcile(ns, "annotation")
        with pytest.raises(SystemExit) as e:
            require_overlap(res, ns, "annotation", hard=("methylation",))
        assert "indistinguishable" in str(e.value)

    def test_strip_version_helper(self):
        assert strip_version("NZ_CP012345.1") == "NZ_CP012345"
        assert strip_version("contig1") == "contig1"


# --------------------------------------------------------------------------- #
# Hi-C
# --------------------------------------------------------------------------- #
class TestHiC:
    @staticmethod
    def _map(n=48, n_dom=4, seed=0):
        rng = np.random.default_rng(seed)
        ii = np.arange(n)
        d = np.minimum(np.abs(ii[:, None] - ii[None, :]), n - np.abs(ii[:, None] - ii[None, :]))
        base = 5000.0 / np.maximum(d, 1) ** 1.1
        edges = np.linspace(0, n, n_dom + 1).astype(int)
        for a, b in zip(edges[:-1], edges[1:]):
            base[a:b, a:b] *= 3.0
        m = rng.poisson(base).astype(float)
        return np.triu(m) + np.triu(m, 1).T, edges[:-1]

    def test_ice_equalises_marginals(self):
        m, _ = self._map()
        m[5, :] *= 4.0; m[:, 5] *= 4.0            # a strongly biased bin
        bal, mask = ice(m)
        marg = np.nansum(bal, axis=1)[mask]
        assert marg.std() / marg.mean() < 0.05

    def test_oe_is_flat_in_separation(self):
        m, _ = self._map()
        oe, _exp = observed_over_expected(m, circular=True)
        n = m.shape[0]
        ii = np.arange(n)
        d = np.minimum(np.abs(ii[:, None] - ii[None, :]),
                       n - np.abs(ii[:, None] - ii[None, :]))
        for k in (1, 5, 10):
            vals = oe[d == k]
            assert abs(np.nanmean(vals) - 1.0) < 1e-9

    def test_insulation_finds_planted_boundaries(self):
        m, edges = self._map(n=60, n_dom=5, seed=2)
        ins = insulation_score(m, window_bins=4, circular=True)
        called = call_boundaries(ins, min_prominence=0.05, circular=True)
        for e in edges:
            assert min(abs(called - e).min(), abs(called - (e + 60)).min()) <= 2

    def test_native_cool_reader(self, data):
        pytest.importorskip("h5py")
        from merlin.hic import read_cool
        maps = read_cool(str(data / "contacts.cool"))
        assert maps
        for cm in maps.values():
            assert cm.matrix.shape[0] == cm.matrix.shape[1] == cm.n
            assert np.allclose(cm.matrix, cm.matrix.T)


# --------------------------------------------------------------------------- #
# End-to-end
# --------------------------------------------------------------------------- #
def run_tool(name, args):
    proc = subprocess.run([sys.executable, "-m", "merlin.cli", name] + args,
                          capture_output=True, text=True,
                          env={"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin",
                               "HOME": "/tmp", "MPLBACKEND": "Agg"})
    assert proc.returncode == 0, proc.stderr[-3000:]
    return proc


class TestEndToEnd:
    def test_preflight_exit_codes(self, data):
        proc = subprocess.run(
            [sys.executable, "-m", "merlin.cli", "preflight",
             "--gff", str(data / "annotation.gff3"),
             "--fasta", str(data / "reference.fasta"),
             "--methylation", str(data / "F5.methylation.gff3")],
            capture_output=True, text=True,
            env={"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin", "HOME": "/tmp"})
        assert proc.returncode in (0, 1)
        assert "seqid reconciliation" in proc.stdout

    def test_xam(self, data, tmp_path):
        run_tool("xam", ["-g", str(data / "annotation.gff3"),
                         "--methylation", str(data / "F5.methylation.gff3"),
                         "-o", str(tmp_path), "--prefix", "t", "--no-split", "--no-plot"])
        import pandas as pd
        t = pd.read_csv(tmp_path / "t.by_feature.tsv", sep="\t")
        assert len(t) > 0
        assert np.allclose(t["norm_count"], t["raw_count"] / t["feat_length_bp"])

    def test_xam_include_zero_adds_rows(self, data, tmp_path):
        run_tool("xam", ["-g", str(data / "annotation.gff3"),
                         "--methylation", str(data / "F5.methylation.gff3"),
                         "-o", str(tmp_path), "--prefix", "z", "--no-split",
                         "--no-plot", "--include-zero"])
        import pandas as pd
        assert (pd.read_csv(tmp_path / "z.by_feature.tsv", sep="\t")["raw_count"] == 0).any()

    def test_dixam_reads_vs_calls(self, data, tmp_path):
        run_tool("dixam", ["-g", str(data / "annotation.gff3"),
                           "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                           "--methylation2", str(data / "F9.bedmethyl.bed.gz"),
                           "-o", str(tmp_path), "--prefix", "d", "--no-split",
                           "--no-plot"])
        import pandas as pd
        t = pd.read_csv(tmp_path / "d.differential.tsv", sep="\t")
        assert t["test"].str.startswith("reads(mod vs canonical)").all()
        assert "delta_meth_level" in t.columns

    def test_spacem(self, data, tmp_path):
        run_tool("spacem", ["-g", str(data / "annotation.gff3"),
                            "--fasta", str(data / "reference.fasta"),
                            "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                            "-o", str(tmp_path), "--prefix", "s"])
        import pandas as pd
        t = pd.read_csv(tmp_path / "s.oriter_stats.tsv", sep="\t")
        assert "GENOME" in t["replicon"].values
        assert "meth_uniform_KS_D" in t.columns

    def test_mematch_presence_only_uses_genomic_background(self, data, tmp_path):
        run_tool("mematch", ["-g", str(data / "annotation.gff3"),
                             "--fasta", str(data / "reference.fasta"),
                             "--methylation", str(data / "F5.methylation.gff3"),
                             "--motifs", str(data / "motifs.txt"),
                             "-o", str(tmp_path), "--prefix", "m", "--fisher",
                             "--no-call-table", "--no-hit-table"])
        import pandas as pd
        e = pd.read_csv(tmp_path / "m.enrichment.tsv", sep="\t")
        site = e[e["level"] == "site"]
        assert (site["basis"] == "genomic").all()
        # the background class must be non-empty, unlike the original's b=d=0
        assert (site["b_onmotif_unmeth"] + site["d_offmotif_unmeth"] > 0).all()

    def test_diem_left_join_keeps_unmethylated_genes(self, data, tmp_path):
        run_tool("xam", ["-g", str(data / "annotation.gff3"),
                         "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                         "-o", str(tmp_path), "--prefix", "x", "--no-split",
                         "--no-plot", "--include-zero", "--features", "CDS"])
        import pandas as pd
        for join in ("left", "inner"):
            run_tool("diem", ["--geneexp", str(data / "deseq2_results.csv"),
                              "--methylation", str(tmp_path / "x.by_feature.tsv"),
                              "--outdir", str(tmp_path), "--prefix", join,
                              "--join", join, "--n-perm", "50", "--no-ml", "--no-plot"])
        left = pd.read_csv(tmp_path / "left.integrated_table.tsv", sep="\t")
        inner = pd.read_csv(tmp_path / "inner.integrated_table.tsv", sep="\t")
        assert len(left) >= len(inner)
        assert "is_HM" in left.columns          # DM without --dm-table is really HM

    def test_hicam_runs_on_hic_alone(self, data, tmp_path):
        pytest.importorskip("h5py")
        run_tool("hicam", ["--hic", str(data / "contacts.cool"),
                           "-o", str(tmp_path), "--prefix", "h",
                           "--insulation-window", "3"])
        assert (tmp_path / "h.hic_bins.tsv").exists()
        assert (tmp_path / "h.hic_integration.tsv").exists()

    def test_pipeline_skips_absent_layers(self, data, tmp_path):
        cfg = tmp_path / "c.json"
        cfg.write_text('{"outdir": "%s", "prefix": "p", "annotation": "%s", '
                       '"methylation": "%s"}'
                       % (tmp_path / "res", data / "annotation.gff3",
                          data / "F5.methylation.gff3"))
        proc = run_tool("run", ["--config", str(cfg)])
        assert "SKIPPED  dixam" in proc.stdout
        assert "SKIPPED  hicam" in proc.stdout
        assert "OK       xam" in proc.stdout


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))


# =========================================================================== #
# 2.0.1 — ROADMAP implementations
# =========================================================================== #
from merlin.covariates import partial_correlation                # noqa: E402
from merlin.discover import discover_motifs                       # noqa: E402
from merlin.regions import (RegionSpec, derive_regions,           # noqa: E402
                            infer_operons, intergenic_regions,
                            parse_region_specs)
from merlin.replicates import (Design, betabinomial_test,         # noqa: E402
                               moment_dispersion, quasipoisson_test,
                               shrink_dispersion)
from merlin.stats import (block_bootstrap_ci, circular_shift_null,  # noqa: E402
                          robust_rank_aggregation, stouffer)
from merlin.store import (MerlinStore, Provenance,                # noqa: E402
                          assign_features_to_bins)


class TestReplicates:
    """The point of 1.1: a dispersion term, and a null that is not 60 % positive."""

    @staticmethod
    def _sample(rng, n_feat, nrep, p_true, phi, n_sites=8, cov=50, shift=0.0):
        m = np.zeros((n_feat, nrep)); n = np.zeros((n_feat, nrep))
        s = (1 - phi) / phi
        for j in range(nrep):
            p = np.clip(p_true + shift + rng.normal(0, 0.02), 0.01, 0.99)
            pj = rng.beta(p * s, (1 - p) * s)
            m[:, j] = rng.binomial(n_sites * cov, pj); n[:, j] = n_sites * cov
        return m, n

    def test_null_is_roughly_calibrated(self):
        rng = np.random.default_rng(0)
        n_feat, nrep, phi = 2000, 3, 0.03
        p_true = rng.uniform(0.6, 0.95, n_feat)
        mc, nc = self._sample(rng, n_feat, nrep, p_true, phi)
        mt, nt = self._sample(rng, n_feat, nrep, p_true, phi)
        d = Design(("A", "B"), np.r_[np.zeros(nrep, int), np.ones(nrep, int)])
        rr = betabinomial_test(np.c_[mc, mt], np.c_[nc, nt], d)
        rate = float(np.mean(rr.pvalue[np.isfinite(rr.pvalue)] < 0.05))
        # nominal 5 %; the LRT is mildly anti-conservative at n=3, never 60 %
        assert 0.02 < rate < 0.15, rate

    def test_recovers_a_real_difference(self):
        rng = np.random.default_rng(1)
        n_feat, nrep, phi = 1500, 3, 0.03
        p_true = rng.uniform(0.6, 0.9, n_feat)
        shift = np.zeros(n_feat)
        idx = rng.choice(n_feat, 200, replace=False)
        shift[idx] = -0.25
        mc, nc = self._sample(rng, n_feat, nrep, p_true, phi)
        mt, nt = self._sample(rng, n_feat, nrep, p_true, phi, shift=shift)
        d = Design(("A", "B"), np.r_[np.zeros(nrep, int), np.ones(nrep, int)])
        rr = betabinomial_test(np.c_[mc, mt], np.c_[nc, nt], d)
        q = benjamini_hochberg(rr.pvalue)
        detected = int(np.nansum(q[idx] < 0.05))
        assert detected > 100, detected
        assert np.nanmean(rr.effect[idx]) < -0.15

    def test_dispersion_estimate_tracks_the_truth(self):
        rng = np.random.default_rng(2)
        p_true = rng.uniform(0.5, 0.9, 800)
        for phi in (0.01, 0.05):
            m, n = self._sample(rng, 800, 4, p_true, phi)
            groups = np.r_[np.zeros(2, int), np.ones(2, int)]
            est = np.median(moment_dispersion(m, n, groups))
            assert abs(est - phi) < 0.03, (phi, est)

    def test_shrinkage_pulls_towards_the_trend(self):
        phi = np.r_[np.full(100, 0.02), np.full(5, 0.9)]
        w = np.r_[np.full(100, 1.0), np.full(5, 1.0)]
        out, trend = shrink_dispersion(phi, w, prior_weight=5.0)
        assert out[-1] < phi[-1]                      # the outlier is pulled in
        assert np.allclose(trend[:100], np.median(phi), atol=0.5)

    def test_quasipoisson_runs_on_presence_only_counts(self):
        rng = np.random.default_rng(3)
        y = rng.poisson(20, size=(300, 6)).astype(float)
        d = Design(("A", "B"), np.r_[np.zeros(3, int), np.ones(3, int)])
        rr = quasipoisson_test(y, np.ones(6), d)
        rate = float(np.mean(rr.pvalue[np.isfinite(rr.pvalue)] < 0.05))
        assert rate < 0.15
        assert (rr.dispersion >= 1.0).all()

    def test_unreplicated_design_is_flagged(self):
        d = Design(("A", "B"), np.array([0, 1]))
        assert not d.replicated


class TestRegions:
    def test_spec_parsing(self):
        specs = parse_region_specs(["upstream:-300..50", "body"])
        assert specs[0].kind == "upstream" and specs[0].start_off == -300
        assert specs[1].kind == "body"
        with pytest.raises(SystemExit):
            parse_region_specs(["nonsense:1..2"])

    def test_upstream_is_strand_aware(self, tiny_gff):
        ann = mio.read_annotation(tiny_gff)
        out = derive_regions(ann, [RegionSpec("upstream", -100, 10)],
                             {"chr1": 1000})
        plus = [f for f in out.features if f.locus_tag == "G1"][0]
        minus = [f for f in out.features if f.locus_tag == "G2"][0]
        assert (plus.start, plus.end) == (0, 20)      # clamped at the replicon start
        assert (minus.start, minus.end) == (30, 140)  # relative to the high end

    def test_body_reproduces_the_feature(self, tiny_gff):
        ann = mio.read_annotation(tiny_gff)
        out = derive_regions(ann, [RegionSpec("body")], {"chr1": 1000})
        assert [(f.start, f.end) for f in out.features] == [(10, 20), (30, 40)]

    def test_operons_group_adjacent_same_strand_genes(self, tmp_path):
        p = tmp_path / "op.gff3"
        rows = ["##gff-version 3"]
        for i, (s, e, st) in enumerate([(100, 200, "+"), (210, 300, "+"),
                                        (310, 400, "+"), (5000, 5100, "-")]):
            rows.append(f"c1\t.\tCDS\t{s}\t{e}\t.\t{st}\t0\tlocus_tag=G{i}")
        p.write_text("\n".join(rows) + "\n")
        operons = infer_operons(mio.read_annotation(p), max_gap=50)
        assert sorted(o.size for o in operons) == [1, 3]
        big = [o for o in operons if o.size == 3][0]
        assert big.leader == "G0"

    def test_intergenic_regions_fill_the_gaps(self, tiny_gff):
        ann = mio.read_annotation(tiny_gff)
        ig = intergenic_regions(ann, {"chr1": 1000}, min_length=5)
        spans = [(f.start, f.end) for f in ig.features]
        assert (20, 30) in spans and (40, 1000) in spans


class TestCovariates:
    def test_partial_correlation_removes_a_confounder(self):
        rng = np.random.default_rng(4)
        z = rng.normal(size=400)
        x = z + rng.normal(0, 0.3, 400)          # x and y share only z
        y = z + rng.normal(0, 0.3, 400)
        res = partial_correlation(x, y, z[:, None], ["z"])
        assert res.marginal_rho > 0.7
        assert abs(res.partial_rho) < 0.2
        assert res.attenuated

    def test_partial_correlation_keeps_a_real_effect(self):
        rng = np.random.default_rng(5)
        z = rng.normal(size=400)
        x = rng.normal(size=400)
        y = 1.5 * x + 0.5 * z + rng.normal(0, 0.3, 400)
        res = partial_correlation(x, y, z[:, None], ["z"])
        assert res.partial_rho > 0.7 and not res.attenuated


class TestStructuredNulls:
    @staticmethod
    def _smooth(seed, n=400, w=25):
        x = np.random.default_rng(seed).normal(size=n)
        k = np.ones(w) / w
        return np.convolve(np.r_[x, x, x], k, "same")[n:2 * n]

    def test_circular_shift_null_is_not_fooled_by_autocorrelation(self):
        pytest.importorskip("scipy")
        from scipy.stats import spearmanr
        a, b = self._smooth(1), self._smooth(2)          # independent
        naive_p = spearmanr(a, b)[1]
        _rho, shift_p = circular_shift_null(a, b, n_perm=2000, seed=3)
        assert naive_p < 0.01                            # naive: spuriously "real"
        assert shift_p > 0.05                            # structure-preserving: not

    def test_circular_shift_null_keeps_a_real_alignment(self):
        a = self._smooth(7)
        b = a + np.random.default_rng(8).normal(0, 0.05, a.size)
        _rho, p = circular_shift_null(a, b, n_perm=1000, seed=1)
        assert p < 0.01

    def test_block_bootstrap_interval_brackets_rho(self):
        a = self._smooth(9)
        b = a + np.random.default_rng(10).normal(0, 0.2, a.size)
        rho, lo, hi = block_bootstrap_ci(a, b, n_boot=300, seed=2)
        assert lo <= rho <= hi and lo > 0


class TestEvidenceCombination:
    def test_stouffer_uses_direction(self):
        z_up, _p = stouffer([2.0, 2.0])
        z_mixed, _p2 = stouffer([2.0, -2.0])
        assert z_up > 2.5 and abs(z_mixed) < 1e-9

    def test_rra_prefers_consistently_top_ranked_items(self):
        q = robust_rank_aggregation([[0.001, 0.9], [0.002, 0.8]], 2)
        assert q[0] < q[1]


class TestStore:
    def test_roundtrip_and_provenance(self, tmp_path):
        pytest.importorskip("h5py")
        import pandas as pd
        df = pd.DataFrame({"locus_tag": ["A", "B"], "replicon": ["c1", "c1"],
                           "start": [0, 100], "end": [50, 150],
                           "value": [1.5, np.nan]})
        prov = Provenance(command="merlin harmonise")
        prov.thresholds["min_frac"] = 0.5
        path = tmp_path / "s.h5"
        with MerlinStore(path, "w") as st:
            st.write_table("features", df)
            st.write_provenance(prov)
        with MerlinStore(path, "r") as st:
            back = st.read_table("features")
            assert list(back["locus_tag"]) == ["A", "B"]
            assert np.isnan(back["value"].iloc[1])
            assert st.provenance.thresholds["min_frac"] == 0.5

    def test_feature_to_bin_map(self):
        import pandas as pd
        feats = pd.DataFrame({"replicon": ["c1", "c1", "c2"],
                              "start": [0, 12000, 0], "end": [100, 12100, 100]})
        bins = pd.DataFrame({"replicon": ["c1", "c1", "c1"],
                             "start": [0, 5000, 10000],
                             "end": [5000, 10000, 15000]})
        m = assign_features_to_bins(feats, bins)
        assert m[0] == 0 and m[1] == 2 and m[2] == -1


class TestDiscovery:
    def test_recovers_a_planted_motif(self):
        rng = np.random.default_rng(11)
        seq = "".join(rng.choice(list("ACGT"), size=200_000))
        arr = list(seq)
        for p in rng.choice(len(seq) - 4, size=1200, replace=False):
            arr[p:p + 4] = list("GATC")
        genome = {"c1": "".join(arr)}
        import re as _re
        pos, strand = [], []
        for m in _re.finditer("(?=(GATC))", genome["c1"]):
            pos.append(m.start() + 1); strand.append("+")
        ms = MethylSet(np.array(["c1"] * len(pos), dtype=object),
                       np.array(pos, dtype=np.int64),
                       np.array(["a"] * len(pos), dtype=object),
                       np.array(strand, dtype=object),
                       np.full(len(pos), np.nan), np.full(len(pos), np.nan))
        found = discover_motifs(genome, ms, "a", seed=0)
        assert found, "no motif discovered"
        assert found[0].motif == "GATC"
        assert found[0].offset == 1


class TestReadLevel:
    def test_modbam_roundtrip_and_bistability(self, data):
        pytest.importorskip("pysam")
        from merlin.reads import (bistability_table, cis_comethylation,
                                  read_fraction_per_region, read_modbam,
                                  site_table)
        bam = data / "reads.modbam.bam"
        if not bam.exists():
            pytest.skip("no modBAM in the generated data")
        calls = read_modbam(str(bam))
        assert calls.n_reads > 0 and calls.n_sites > 0
        sites = site_table(calls)
        assert {"+", "-"} <= set(sites["strand"])       # both strands recovered
        ann = mio.read_annotation(data / "annotation.gff3", feature_types={"CDS"})
        fracs = read_fraction_per_region(calls, ann.features)
        bist = bistability_table(fracs)
        assert len(bist) > 0
        assert int(bist["bimodal"].sum()) > 0, "planted bistable regions not found"
        cis = cis_comethylation(calls, max_distance=2000)
        assert len(cis) > 0 and np.isfinite(cis["phi"]).any()

    def test_bimodality_coefficient(self):
        from merlin.reads import bimodality_coefficient
        rng = np.random.default_rng(12)
        uni = rng.normal(0.5, 0.05, 300)
        bim = np.r_[rng.normal(0.05, 0.02, 150), rng.normal(0.95, 0.02, 150)]
        assert bimodality_coefficient(bim) > 5 / 9
        assert bimodality_coefficient(uni) < 5 / 9


class TestWorkflowExport:
    def test_nextflow_and_snakemake_render(self, data, tmp_path):
        from merlin.workflow import export
        cfg = tmp_path / "c.json"
        cfg.write_text('{"outdir": "%s", "prefix": "p", "annotation": "%s", '
                       '"methylation": "%s"}'
                       % (tmp_path / "res", data / "annotation.gff3",
                          data / "F5.methylation.gff3"))
        nf = export(str(cfg), "nextflow")
        assert "nextflow.enable.dsl = 2" in nf and "process XAM_SAMPLE" in nf
        sm = export(str(cfg), "snakemake")
        assert "rule all:" in sm
        js = export(str(cfg), "json")
        import json as _json
        plan = _json.loads(js)
        assert any(s["module"] == "xam" and not s["skipped"] for s in plan)


class TestNewToolsEndToEnd:
    def test_discover_then_mematch(self, data, tmp_path):
        run_tool("discover", ["--fasta", str(data / "reference.fasta"),
                              "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                              "-o", str(tmp_path), "--prefix", "d"])
        motifs = tmp_path / "d.motifs.txt"
        assert motifs.exists()
        text = motifs.read_text()
        assert "GATC" in text
        run_tool("mematch", ["-g", str(data / "annotation.gff3"),
                             "--fasta", str(data / "reference.fasta"),
                             "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                             "--motifs", str(motifs), "-o", str(tmp_path),
                             "--prefix", "m", "--no-call-table", "--no-hit-table"])
        assert (tmp_path / "m.motif_summary.tsv").exists()

    def test_dixam_with_replicates_uses_the_beta_binomial(self, data, tmp_path):
        import pandas as pd
        reps = sorted(data.glob("F5_rep*.bedmethyl.bed.gz"))
        reps2 = sorted(data.glob("F9_rep*.bedmethyl.bed.gz"))
        if len(reps) < 2 or len(reps2) < 2:
            pytest.skip("replicates not generated")
        run_tool("dixam", ["-g", str(data / "annotation.gff3"), "--features", "CDS",
                           "--methylation", *[str(p) for p in reps],
                           "--methylation2", *[str(p) for p in reps2],
                           "-o", str(tmp_path), "--prefix", "r", "--no-split",
                           "--no-plot"])
        t = pd.read_csv(tmp_path / "r.differential.tsv", sep="\t", comment="#")
        assert t["test"].str.contains("beta-binomial").all()
        assert "dispersion" in t.columns and t["dispersion"].notna().any()

    def test_harmonise_evidence_report(self, data, tmp_path):
        pytest.importorskip("h5py")
        import pandas as pd
        res = tmp_path / "res"
        run_tool("xam", ["-g", str(data / "annotation.gff3"), "--features", "CDS",
                         "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                         "-o", str(res / "xam"), "--prefix", "s", "--no-split",
                         "--no-plot", "--include-zero"])
        run_tool("dixam", ["-g", str(data / "annotation.gff3"), "--features", "CDS",
                           "--methylation", str(data / "F5.bedmethyl.bed.gz"),
                           "--methylation2", str(data / "F9.bedmethyl.bed.gz"),
                           "-o", str(res / "dixam"), "--prefix", "s",
                           "--no-split", "--no-plot"])
        run_tool("harmonise", ["--results", str(res), "--gff",
                               str(data / "annotation.gff3"), "-o", str(res),
                               "--prefix", "s", "--export-tsv"])
        store = res / "s.merlin_store.h5"
        assert store.exists()
        with MerlinStore(store, "r") as st:
            feats = st.read_table("features")
        assert len(feats) > 0
        assert any(c.startswith("dmeth_") for c in feats.columns)
        run_tool("evidence", ["--store", str(store), "-o", str(res), "--prefix", "s"])
        ev = pd.read_csv(res / "s.evidence.tsv", sep="\t", comment="#")
        assert "stouffer_q" in ev.columns and "n_layers" in ev.columns
        run_tool("report", ["--results", str(res), "-o", str(res), "--prefix", "s"])
        html = (res / "s.report.html").read_text()
        assert html.startswith("<!doctype html>") and "data:image" in html or True

    def test_doctor_reports_module_availability(self):
        proc = subprocess.run(
            [sys.executable, "-m", "merlin.cli", "doctor", "--no-check-r"],
            capture_output=True, text=True,
            env={"PYTHONPATH": str(ROOT / "src"), "PATH": "/usr/bin:/bin",
                 "HOME": "/tmp"})
        assert proc.returncode in (0, 1)
        assert "module availability" in proc.stdout
