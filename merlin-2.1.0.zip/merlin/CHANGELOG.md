# 2.1.0 — a BAM is now a valid input

Until now the toolkit began at a bedMethyl, which meant `modkit` was an
undocumented prerequisite of everything and the single most consequential
parameter in the analysis — the probability at which an ML value becomes a
methylation call — lived outside MErlin's provenance record, in whoever's shell
history produced the file.

Thirteen modules, up from twelve. `merlin pileup` is the new one.

## `merlin pileup` — modBAM to bedMethyl

```bash
merlin pileup --modbam calls.bam --fasta ref.fasta -o results/pileup
```

Two backends produce the same 18-column modkit-format bedMethyl:

| Backend | Chosen when | What it is |
|---|---|---|
| `modkit` | modkit is on PATH (`--backend modkit` to require it) | ONT's own tool, the reference implementation. `--cpg`, `--motif`, `--combine-strands` and `--modkit-arg` pass through to it |
| `internal` | modkit is absent, or `--backend internal` | a pysam pileup written here so a missing modkit degrades the run instead of ending it |

The internal backend takes, per reference position and strand, the argmax over
every modification probability and the implied canonical probability, and counts
the winner; calls whose winning probability is below `--filter-threshold`
(default 0.667) go to `N_fail` and out of the valid coverage. It does **not**
model deletions, reference mismatches or duplex tags — `N_delete`, `N_diff` and
`N_nocall` are written as 0 — and it does not reproduce modkit's adaptive
percentile threshold. The two therefore agree closely rather than exactly, which
is why the backend used is printed, written to `<prefix>.pileup_summary.tsv` and
recorded in the provenance sidecar.

**Measured against planted truth.** The synthetic modBAM carries 6mA on the
adenine of GATC on both strands and nowhere else. The internal pileup puts
576 of 576 calls in a GATC context on the correct strand, 288 per strand — a
palindromic motif has to come back balanced, and a strand-assignment bug is
exactly what would unbalance it. Running `merlin discover` on that output
recovers `GATC/1` with no motif list supplied, which is the 2.1.0 claim
end to end: basecalling output in, motif out.

## Unaligned BAMs

An unaligned modBAM (dorado's uBAM) is aligned before the pileup with
`samtools fastq -T MM,ML | minimap2 -y | samtools sort`, the recipe that keeps
the modification tags attached through the FASTQ round trip — losing them there
produces an empty pileup rather than an error, which is the failure mode worth
spending a subprocess to avoid. `--align never` refuses instead of aligning,
which is the setting to use when you believe the BAM is already aligned and want
to be told if it is not. A BAM with no MM/ML tags in its first reads is a fatal
error, not an empty output.

## `merlin run` starts from BAMs

`modbam:` now takes the same shape as `methylation:` — a path, a list, or a
mapping of condition to replicate list — and when a config supplies `modbam:`
and no `methylation:`, the planner inserts one `pileup` step per condition and
points every downstream module at the bedMethyl it will produce. `--dry-run`
shows those paths before anything runs. With both keys present the pileup is
skipped with a stated reason and the modBAM is used only by `phase`.

`options: {pileup: {...}}` configures the step; `merlin export` emits it in the
Nextflow and Snakemake plans like any other module.

## Checks

- `merlin preflight --modbam` reports alignment, sort order, index, MM/ML tag
  presence, modification codes and duplex tags, and — because it runs before the
  seqid section — the BAM's reference names take part in seqid reconciliation.
  A BAM aligned to a different assembly than the annotation is now caught before
  the pileup rather than after it.
- `merlin doctor` reports `modkit`, `samtools` and `minimap2` alongside the
  Python packages, and lists `pileup` in the module-availability table.

## Fixed

- **The test-data generator planted a spurious motif.** It tested the top-strand
  GATC context against bottom-strand adenines, so the synthetic modBAM carried
  6mA at `GTTC` positions as well, and `discover` dutifully reported a second
  motif that no enzyme in the fixture makes. The bottom-strand adenine of a GATC
  is the T at offset 2 of the same GATC; the generator now says so. This changed
  no MErlin code — it made the positive control mean what it claims.

## Not built

- **Per-read pileup of duplex molecules.** A pileup collapses both strands of a
  duplex read into per-position counts. Per-molecule hemimethylation needs
  `merlin phase`, and duplex-aware phasing is still on the roadmap.
- **Basecalling.** MErlin starts at a basecalled BAM. Calling modifications from
  raw signal is dorado's job and reimplementing it here would be absurd.

---

# 2.0.1 — the ROADMAP, implemented

Everything in 2.0's `ROADMAP.md` tiers 1–4 is now in the toolkit, except the two
items the roadmap's own "what not to build" section argued against. Each section
below says what changed, what it is measured against, and what it now licenses
you to claim.

Twelve modules, up from six:

```
xam  dixam  spacem  mematch  diem  hicam        analysis  (hicam new in 2.0)
phase  discover  mtase                          analysis  (new)
harmonise  evidence  report                     integration (new)
preflight  doctor  run  export                  orchestration
```

---

## Tier 1 — the things that change what the numbers mean

### 1.1 Biological replication  →  `merlin dixam --methylation a.bed b.bed c.bed`

`dixam` now takes replicate lists per condition and chooses its model from what
the input carries:

| design | model | what it supports |
|---|---|---|
| ≥2 replicates, coverage + fraction | beta-binomial LRT, dispersion shrunk to a level-dependent trend | differential methylation |
| ≥2 replicates, presence-only | quasi-Poisson LRT on call counts with a library-size offset | differential call distribution |
| 1 per condition | the 2.0 contingency test | a candidate screen, and it says so |

Dispersion is estimated per feature by method of moments within condition, then
shrunk empirical-Bayes towards the median dispersion of features at a similar
methylation level — the DSS idea, because a dispersion from three replicates is
far too noisy to use raw.

**Measured on simulated null data** (no true difference, only replicate
variation at φ = 0.03, 3v3, 8 sites × 50×):

| | rejects at p < 0.05 | false discoveries at BH q < 0.05 |
|---|---|---|
| 2.0 single-sample read test | **60.0 %** | 1 672 / 3 000 |
| 2.0.1 beta-binomial LRT | **9.6 %** | 8 / 3 000 |

Dispersion is recovered (median 0.027 for a true 0.03). Null calibration by
design size is documented in the docstring and warned about at run time:

| design | chi²(1) | F(1, n−2) |
|---|---|---|
| 2 v 2 | 10.6 % | 0.1 % |
| 3 v 3 | 6.0 % | 1.0 % |
| 5 v 5 | 7.8 % | 4.1 % |

chi² is the default and its mild anti-conservatism at small n is stated rather
than hidden; `--lrt-dist f` errs the other way.

`merlin xam` also accepts several files, writing one table per sample plus a
pooled one.

### 1.2 Confounder control  →  `merlin diem --gff ... --covariates auto`

A per-feature covariate block (`merlin/covariates.py`): gene length, gene
density, upstream intergenic distance, GC content, GC skew, ori→ter position,
assayed-site density, mean coverage, per-motif density, expression baseMean.

`diem` reports the **marginal and the covariate-adjusted association side by
side**, plus which covariates the methylation track itself follows, and warns
when adjustment removes more than half the marginal strength — because that
disagreement *is* the finding. On the synthetic data:

```
marginal  rho = +0.0305   partial rho = -0.0124   (gc_skew and log_length absorb it)
```

**Structure-preserving nulls** (`merlin/stats.py`) replace label permutation for
anything positional:

- `circular_shift_null` rotates one track around the replicon, preserving its
  autocorrelation exactly. On two independent smoothed tracks the naive Spearman
  gives p = 4×10⁻⁷; the circular-shift null gives p = 0.14.
- `block_bootstrap_ci` resamples contiguous blocks for correlation intervals.

`hicam` now reports a bootstrap interval and a circular-shift p-value next to
every bin correlation, so the warning it used to print is no longer the only
defence.

### 1.3 Regulatory geometry  →  `--regions upstream:-300..50 body --operons`

`merlin/regions.py` derives strand-aware windows relative to the translation
start, treats intergenic space as features, and infers operons from same-strand
runs with a maximum gap. `xam` and `dixam` both take `--regions` and `--operons`;
the operon id, position and leader are added as columns, so a promoter can be
scored once per transcription unit instead of once per co-transcribed gene.

This is what lets MErlin see Dam-in-a-promoter regulation at all — a whole-CDS
average dilutes a 200 bp effect to nothing.

---

## Tier 2 — harmonisation

### 2.1 One canonical store  →  `merlin harmonise`

`<prefix>.merlin_store.h5` with `/features`, `/bins`, `/maps/feature_to_bin` and
`/meta`. Discovers whatever the modules wrote, joins features on `locus_tag` and
bins on coordinates, stores the many-to-one feature→bin map so either unit can
answer a cross-layer question, and records provenance (version, inputs, SHA-256
digests, thresholds, resolved seqid mapping, warnings).

On the example run: 121 features × 54 columns, 72 bins × 25 columns, five layers
(`meth`, `dmeth`, `expr`, `motif`, `hic`) in one object.

### 2.2 One evidence score  →  `merlin evidence`

Per gene: signed z-scores per layer, a weighted **Stouffer** combination (uses
direction), a **robust rank aggregation** score (ignores scale, for layers that
are not comparable), BH over genes, `n_layers` and `direction_concordance`. The
per-layer columns stay, so a gene ranked highly for one strong reason is
distinguishable from one ranked highly for four weak ones.

### 2.3 One report  →  `merlin report`

A single self-contained HTML file: warnings first, then provenance, then the run
plan, then each module's figures (embedded as data URIs) and tables. No external
assets — it survives being emailed or attached to a thesis chapter.

---

## Tier 3 — new biology from data already on disk

### 3.1 Read-level methylation  →  `merlin phase --modbam calls.bam`

Reads `MM`/`ML` tags through pysam. Calls at or above `--high` are methylated,
at or below `--low` unmethylated, and the ambiguous middle is **dropped rather
than forced to a side** — forcing it is what turns a bimodal population into an
intermediate average.

- **Hemimethylation**: strand asymmetry at paired palindromic motif positions,
  explicitly labelled a population measure (a short read covers one strand).
- **Bistability**: Sarle's bimodality coefficient of the *per-read* fraction
  distribution per region. On synthetic data with 12 planted bistable loci,
  11/18 scored regions come out bimodal.
- **Cis co-methylation**: phi between site pairs on the same molecule, binned by
  separation. Recovers φ = +0.74 at 20–31 bp on the planted data.

The MM strand character is honoured, so `T-a` and `G-m` records land on the
opposite strand rather than the read's own — the distinction the whole
hemimethylation analysis rests on.

### 3.2 MTase attribution  →  `merlin mtase`

Scans product names for RM-system genes, matches motifs against a small offline
table of canonical systems (Dam/GATC, Dcm/CCWGG, CcrM/GANTC …), and — with a
second condition — measures which motif loses methylation. Confidence is
reported, not implied: `weak (canonical motif table only)` is annotation
transfer; `strong (knockout + annotation)` is evidence from this genome.

### 3.3 De novo motif discovery  →  `merlin discover`

Flanks of methylated positions, aligned strand-aware on the modified base,
compared with a background of the same canonical base assayed but not
methylated. Exact k-mers seed distinct motifs; each seed is then relaxed
greedily — trim an end, or degenerate one position — accepting whichever change
explains the most calls while enrichment stays above a floor.

That relaxation is the part that matters: a k-mer seed fixes its own flanking
bases *because they were selected on*, so consensus-from-the-seed returns GATCG
for Dam and four separate motifs for GANTC. On the synthetic genome (three
planted systems), from both bedMethyl and presence-only GFF3:

```
GATC    offset 1   6mA   3,486 sites   20919x
GANTC   offset 1   6mA   1,442 sites     125x
CCWGG   offset 1   5mC     787 sites     249x
```

Output is a motif file `mematch` and `spacem` read directly.

### 3.4 Differential 3D organisation  →  `merlin hicam --hic2 second.cool`

Which boundaries strengthen or weaken, which bins flip compartment, Δinsulation
as a track, and Δinsulation correlated against methylation and expression with a
circular-shift null. Plus the Le *et al.* test — are CID boundaries enriched for
highly expressed genes — which needed only what `hicam` already loaded.

---

## Tier 4 — engineering

- **Chunked bedMethyl parsing**: converted per block so peak memory does not
  track file size.
- **`merlin export --workflow nextflow|snakemake|json`**: the step graph in
  `pipeline.py` already *is* the dependency graph, so it is emitted rather than
  reimplemented. Resumability and cluster execution without MErlin growing a
  scheduler.
- **Provenance**: every run writes `<prefix>.provenance.txt` — version, inputs
  with SHA-256 digests, thresholds, resolved seqid mapping, warnings. Inline
  headers are opt-in (`--provenance`), because prefixing a TSV with `#` lines
  breaks readers that do not skip them, gratuitously, for a record that fits in
  its own file.
- **`merlin doctor`**: environment check to `preflight`'s data check. Reports
  each module as ready / degraded / unusable and what to install.
- **CI** (`.github/workflows/ci.yml`) across Python 3.10–3.12, plus a job that
  installs R and renders the circos figure so `roundtable.R` stops being the
  module that only breaks on someone else's machine.
- **Dockerfile** with R and Bioconductor included.
- **Positive control** (`tests/test_positive_control.py`): six tests asserting
  the *biology* comes back out — the planted motifs, the planted differential
  methylation, the planted domain boundaries, the planted bistability, the
  planted origin. A refactor that quietly stops finding GATC passes every other
  test in the suite.

**86 unit and end-to-end tests + 6 positive controls, all passing.**

---

## Deliberately not built

Unchanged from the roadmap's own reasoning:

- **A DMR caller.** `dixam` screens features against an annotation; genuine
  coverage-aware region finding is what DSS, methylKit and `modkit dmr` do well.
- **Loop calling.** Bacterial maps have CIDs and a replichore-alignment signal,
  not CTCF loops. A loop caller would produce confident-looking artefacts.
- **A causal claim.** More layers narrow a hypothesis; a knockout, a point
  mutation of the methylation site, or an MTase complementation tests it. That
  line is still in every report footer.

## Compatibility

Every 2.0 command line still works. New behaviour is opt-in except in `dixam`,
where supplying more than one file per condition switches the model — which is
the point, and which the output states on every run.

`--methylation` now takes one or more files. `diem` gained `--gff`, `--fasta`
and `--covariates`. Output columns were appended, never renamed.


---

# 2.0 — changes from the original MErlin scripts

Grouped by what they do to your results. Everything under **Numbers that move**
changes output values, and each entry says how to get the old behaviour back.

---

## Correctness

### mematch: the site-level enrichment test was degenerate on presence-only input

The README's own example passes a methylation GFF3 (`--methylation F5.gff3`).
A GFF3 of modification calls carries no fraction-modified column, so
`methylated` was `True` for every record and the 2×2 table came out with
`b = d = 0`:

```
level  motif  a     b  c     d  odds_ratio  p_value   (original, on F5.gff3)
site   GATC   3159  0  1256  0  2.515       1
site   GANTC  1256  0  3159  0  0.398       1
```

The odds ratio there is `(a+0.5)(d+0.5) / ((b+0.5)(c+0.5))` = the ratio of the
two motifs' call counts, with a p-value of exactly 1 — no test was performed,
but the number was printed and plotted as an enrichment.

Presence-only input now uses a genomic background: on-motif *candidate bases*
(all A positions for 6mA, all C for 5mC, both strands) that carry a call versus
those that do not.

```
level  basis    motif  a     b    c     d       odds_ratio  p_value  (now)
site   genomic  GATC   3159  331  1256  355254  2694.7      0
site   genomic  GANTC  1256  137  3159  355448  1028.1      0
```

The `basis` column records which regime ran. With bedMethyl input the original
`assayed` contrast is used and is unchanged.

### Unstranded methylation calls were silently dropped

`count_overlaps` matched a stranded feature only against calls on the same
strand. A basecaller emitting `.` in the strand column therefore produced
**all-zero counts with no error** in `xam` and `dixam`. `.` calls now count
towards features on either strand, and a run whose calls are entirely
unstranded is recorded in the warning ledger.

### Coordinate conventions disagreed between tools

`xam`/`dixam` used 0-based half-open ends; `mematch`/`spacem` used 0-based
inclusive. The same feature spanned a different number of bases depending on
which tool looked at it. Everything is now half-open `[start, end)` internally,
converted only in writers. Per-feature windows in `mematch`/`spacem` shift by
one base.

### Motifs spanning the origin were invisible

Bacterial replicons are circular but the regex scan was linear, so a GATC split
across position 0 was never found — in `mematch`, `spacem` and `roundtable.R`.
Motif search is now circular-aware (`--linear` opts out).

### diem: "DM" did not mean differentially methylated

`is_DM` was `max total_norm_count > threshold` — *highly* methylated in a single
condition. The "dual-hit" set inherited the mislabel, so a gene could be a
dual-hit without any methylation change at all. `--dm-table` (a `dixam`
differential output) now supplies the real contrast; without it the column is
named `is_HM` and aliased to `is_DM`, and a warning is recorded.

### diem: `.iloc` on positional access

`model.conf_int().loc[col]` followed by `ci[0]`/`ci[1]` is positional indexing
on a Series and is removed in pandas 3. Fixed, along with `model.params[col]`.

### roundtable.R: crashed on anything but a full bedMethyl

`read_meth` indexed `V10`/`V11` unconditionally, so a 6-column BED or the GFF3
that every other MErlin tool accepts raised an error. It now sniffs the format
and handles all three.

### roundtable.R: installed packages without asking

`install.packages()` and `BiocManager::install()` ran at load time. That writes
to the user's library without consent and fails on a read-only cluster library.
Dependencies are now checked with an actionable message; `--install-deps` opts in.

### Other fixes

- GFF3 attributes are percent-decoded (`product=Fe%2FS+protein` reached the
  output escaped).
- `read_fasta_labels` was called with `strip=True` hardcoded regardless of
  whether stripping had happened, so labels silently missed and figures fell
  back to raw seqids.
- Replicon labels are made filesystem-safe and unique — two records both
  described as "plasmid" overwrote each other's figures.
- `spacem`'s per-replicon figure crashed on a boxplot of entirely empty groups.
- Modification codes now include modkit's ChEBI code `21839` (4mC).
- `_split_gff_line`'s whitespace fallback no longer silently truncates
  attributes containing spaces.

---

## Numbers that move

### diem inner-joined expression with methylation

```python
merged = ge_agg.merge(me_pivot, on="locus_tag", how="inner")
```

Every gene with no methylation call was dropped before the correlation, the
random forest and the odds ratios — so all of them were conditioned on the gene
being methylated, and "methylation is associated with DE" was partly a
restatement of "genes with methylation calls differ from genes without". The
join is now `left` with zero-fill for count columns. `--join inner` restores the
original behaviour exactly.

### diem scaled features outside cross-validation

```python
X_sc = scaler.fit_transform(X)          # fitted on everything
cross_val_predict(rf, X_sc, y, cv=cv)   # then cross-validated
```

Test-fold information leaked into training, inflating the reported AUC. Scaling
and imputation now live in a `Pipeline` refitted per fold. Reported AUC will be
equal or lower, and is the honest one.

### diem's classifier defaults changed

LOOCV with 500 trees and `n_jobs=-1` spawned a worker pool per fold; on n≈120
this took minutes. The default is now stratified k-fold (LOOCV when the minority
class is under 15), 300 trees, parallelism at the CV level. `--cv loocv` forces
the old strategy. AUC values shift slightly with the CV scheme.

The summary now prints DE prevalence next to accuracy, because 92% accuracy at
53% prevalence and 92% accuracy at 90% prevalence are very different results.
An AUC under 0.6 is flagged: feature importances from a model that does not
predict are not a ranking of biological relevance.

### diem's permutation p-value can no longer be exactly zero

`np.mean(np.abs(null) >= abs(r_s))` returns 0.0 when no permutation is more
extreme, which is not a p-value. The add-one correction `(k+1)/(n_perm+1)` gives
a floor of 1/5001 with the default 5 000 shuffles.

### dixam tests methylation level when it can

With coverage and fraction-modified columns the test is now modified versus
canonical reads summed over the feature — a methylation *level* comparison. The
original always compared the *distribution* of call positions, which changes
when sequencing depth changes and does not change when methylation level does.
`--test-on calls` forces the original contrast. On real bedMethyl the two answer
different questions and will not agree.

A genome-wide level row is reported, and a run where more than half of features
come out significant is flagged: that is a global shift, not feature-specific
differential methylation. `--min-effect` requires a change larger than it.

### dixam corrects within modification

BH was applied across all features and all modifications pooled. 6mA and 5mC are
separate hypotheses families with very different prior probabilities; q-values
are now computed per modification. Existing q-values shift.

### dixam's exact test is used only where it is needed

`--test auto` uses Fisher where an expected cell count is under 5 and the
asymptotic test elsewhere. On the ~10⁴ tables with ~10⁶ margins this tool
produces, the two agree to many digits and the asymptotic path is ~50× faster.
`--test fisher` forces exactness.

### spacem separates methylation density from assay coverage

The density track was built from every *assayed* position, so on bedMethyl it
showed where coverage was, not where methylation was. Density now uses calls
passing `--min-frac`; the level gradient still uses every assayed call, because
that is the set that question is about. Density tracks and their KS statistics
change on bedMethyl input; presence-only input is unaffected.

### spacem reports effect sizes

KS results carry their D statistic and co-orientation carries a Wilson 95%
interval. With 10⁵–10⁶ calls a KS p-value is ~0 for a deviation far too small to
mean anything, so a significant p with D = 0.004 should be read as "uniform".

### spacem refuses to pretend about weak GC skew

Replicons whose cumulative skew amplitude is under 2% of replicon length are
flagged, and `--skip-weak-skew` excludes them from the genome row. Previously
the argmin of a flat noisy curve became "oriC" and every ori→ter statistic was
built on it. Plasmids are the usual case.

### diem's redundant methylation features are dropped

`xam` emits one row per feature × modification, so grouping by
`locus_tag × mod_label` gave `n_sites = 1` for almost every gene and made
`total_norm_count`, `mean_norm_count` and `n_sites` mutually redundant. The
random forest was splitting an importance signal across four copies of the same
number. Constant and collinear (|r| > 0.999) features are now dropped, and
features more than 20% missing are excluded rather than zero-filled.

---

## Performance

Measured on this machine; counting benchmark against the original algorithm.

### Overlap counting was quadratic

```python
lo = <binary search>
for pos in positions[lo:]:      # copies the tail of the list, per feature, per mod
    if pos >= feature.end: break
```

| calls | features | original | merlin | speed-up |
|---|---|---|---|---|
| 50 000 | 3 000 | 0.21 s | 0.5 ms | ~450× |
| 200 000 | 6 000 | 2.16 s | 1.5 ms | ~1 500× |
| 1 000 000 | 6 000 | 27.8 s | 3.5 ms | ~8 000× |
| 2 000 000 | 12 000 | >110 s | 7 ms | — |

Counts agree exactly. That is *one* pass; `xam` does one per modification and
`dixam` did four (it counted each condition twice — once for the per-condition
listing, once for the crossed table — which is now computed once and reused).
Verified byte-identical to the original output on the synthetic dataset.

### Permutation Spearman ranked both vectors 5 000 times

| n | original | merlin | speed-up |
|---|---|---|---|
| 500 | 3.12 s | 0.079 s | 40× |
| 3 000 | 6.27 s | 0.60 s | 10× |

ρ matches `scipy.stats.spearmanr` to 1e-10. Ranks are computed once; each
permutation is a dot product, evaluated in chunks so memory is bounded.

### Other

- Methylation is stored columnar (numpy) instead of one dataclass per call.
- `mematch`'s `set[(seqid, pos)]` over every motif-covered base became a boolean
  array per replicon: ~50 MB → ~7 MB for GATC on a 7 Mb genome, and indexed
  rather than hashed.
- Per-call feature assignment returns CSR arrays instead of a dict of Python
  lists — for a million calls, ~40 MB instead of ~500 MB.
- bedMethyl parsing goes through pandas' C parser.
- `mematch`'s per-call table (the largest output) can be skipped
  (`--no-call-table`) or gzipped (`--gzip-calls`).

---

## Structure

- One implementation of GFF3, FASTA, bedMethyl, BED, GFF3-methylation, motif and
  expression parsing (`merlin.io`), of seqid reconciliation (`merlin.seqids`),
  interval arithmetic (`merlin.intervals`), motifs (`merlin.motifs`), replication
  geometry (`merlin.genome`), statistics (`merlin.stats`) and plotting
  (`merlin.viz`). These existed in three to five divergent copies: `xam`/`dixam`
  could not read gzip and never stripped version suffixes, `mematch`/`spacem`
  could do both, `roundtable.R` accepted only bedMethyl. A file one tool could
  read was unreadable by another.
- Colours are fixed package-wide, so a modification keeps its colour across
  every figure.
- `merlin` umbrella CLI plus `merlin run --config` (the modular orchestrator) and
  `merlin preflight`.
- Standalone scripts under `scripts/` preserve every existing command line.
- Every module writes `<prefix>.warnings.txt`.
- 58 tests, including brute-force agreement for the counting fast path and
  end-to-end runs of every module.

## Compatibility

Kept working: `-b/--bed`, `-m/--methyl-gff`, `-B/--bed2`, `-M/--methyl-gff2`,
`-n/--name`, `-o/--output-dir`, `--no-split`, `--features`, `--ignore-strand`,
`--padj_thr`/`--lfc_thr`/`--meth_thr`, `--seqid-map`, `--strip-version`.

Changed: output filenames are now `<prefix>.<what>.tsv` (e.g.
`WT.by_feature.6mA.tsv`) rather than `<stem>_<MOD>.tsv`. `xam`'s table gains
`calls_per_kb`, `cpm` and `mean_frac_modified` at the end; `dixam`'s gains
`mean_cpm`, `effect`, `effect_name`, `odds_ratio` and, on bedMethyl,
`<label>_meth_level` and `delta_meth_level`. Columns were appended, so
name-based readers are unaffected.
